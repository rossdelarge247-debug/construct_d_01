/* Post bank-connection dashboard components */
(function(){
const { useState } = React;

/* ---- tokens shared across both variants ---- */
const INK  = "#1A1A1A";
const SUB  = "#57534E";
const MUTE = "#78716C";
const LINE = "#E5E3DC";
const CANVAS = "#FAFAF7";
const BG   = "#F5F5F4";

/* category palette for task chips */
const CATS = {
  legal:      { label: "Legal",      fg: "#7C3AED", bg: "#F3EEFE" },
  evidence:   { label: "Evidence",   fg: "#0369A1", bg: "#E0F2FE" },
  practical:  { label: "Practical",  fg: "#BE185D", bg: "#FCE7F3" },
  indecouple: { label: "In Decouple", fg: "#047857", bg: "#D1FAE5" }
};

/* ---- tiny icons ---- */
const Ic = ({ children, size = 14, sw = 1.8 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">{children}</svg>
);
const Chev  = (p) => <Ic {...p}><polyline points="6 9 12 15 18 9"/></Ic>;
const Check = (p) => <Ic {...p}><polyline points="5 12 10 17 19 7"/></Ic>;
const Plus  = (p) => <Ic {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const Lock  = (p) => <Ic {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></Ic>;
const Arrow = (p) => <Ic {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></Ic>;
const Upload= (p) => <Ic {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></Ic>;
const Sync  = (p) => <Ic {...p}><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.5 9a9 9 0 0 1 14.8-3.4L23 10M1 14l4.7 4.4A9 9 0 0 0 20.5 15"/></Ic>;
const Help  = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.8.4-1 1-1 1.7V14"/><circle cx="12" cy="17" r="0.5" fill="currentColor"/></Ic>;
const Settings = (p) => <Ic {...p}><circle cx="12" cy="12" r="3"/><path d="M19 13.5a2 2 0 0 0 .3 1.8l.1.1a1.8 1.8 0 1 1-2.6 2.6l-.1-.1a2 2 0 0 0-3.3 1.4V21a1.8 1.8 0 1 1-3.7 0v-.1a2 2 0 0 0-3.3-1.4l-.1.1A1.8 1.8 0 1 1 3.7 17l.1-.1a2 2 0 0 0-1.4-3.3H2a1.8 1.8 0 1 1 0-3.7h.1A2 2 0 0 0 3.7 6.6l-.1-.1A1.8 1.8 0 1 1 6.2 3.9l.1.1a2 2 0 0 0 3.3-1.4V2a1.8 1.8 0 1 1 3.7 0v.1a2 2 0 0 0 3.3 1.4l.1-.1a1.8 1.8 0 1 1 2.6 2.6l-.1.1a2 2 0 0 0 1.4 3.3H21a1.8 1.8 0 1 1 0 3.7h-.1a2 2 0 0 0-1.4 1.4z"/></Ic>;
const Bell     = (p) => <Ic {...p}><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></Ic>;

function Wordmark() {
  return (
    <div className="flex items-center gap-2 select-none">
      <div className="relative" style={{ width: 20, height: 20 }}>
        <div className="absolute inset-0 rounded-full" style={{ background: "#111" }}/>
        <div className="absolute rounded-full" style={{ left:"42%", top:0, width:"58%", height:"100%", background: BG }}/>
        <div className="absolute rounded-full" style={{ left:"45%", top:"12%", width:"10%", height:"76%", background:"#111" }}/>
      </div>
      <span style={{ fontSize: 14.5, letterSpacing: "-0.01em", fontWeight: 600, color: "#111" }}>decouple</span>
    </div>
  );
}

/* ---- top bar (shared) ---- */
function TopBar() {
  return (
    <header className="flex items-center justify-between px-5 flex-shrink-0"
        style={{ height: 56, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
      <div className="flex items-center gap-3">
        <Wordmark/>
        <span style={{ color: "#E5E7EB" }}>/</span>
        <div className="text-[12.5px]" style={{ color: INK, fontWeight: 600 }}>Dashboard</div>
      </div>
      <div className="flex items-center gap-1.5">
        <button className="p-2 rounded-md hover:bg-gray-50" style={{ color: SUB }}><Help size={16}/></button>
        <button className="p-2 rounded-md hover:bg-gray-50" style={{ color: SUB }}><Bell size={16}/></button>
        <button className="p-2 rounded-md hover:bg-gray-50" style={{ color: SUB }}><Settings size={16}/></button>
        <div className="ml-1 flex items-center gap-2 pl-2" style={{ borderLeft: `1px solid ${LINE}`}}>
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-semibold"
               style={{ background: "#F5F3EE", color: "#57534E" }}>S</div>
          <div className="text-[12px] leading-tight pr-1">
            <div style={{ fontWeight: 600, color: INK }}>Sarah</div>
            <div style={{ color: MUTE, fontSize: 11 }}>Just joined</div>
          </div>
        </div>
      </div>
    </header>
  );
}

/* ---- journey rail (left sidebar) ---- */
const JOURNEY = [
  { k:"dash",    label:"Dashboard",     phase:"1 · Prepare",   active:true },
  { k:"picture", label:"Your picture",  phase:"2 · Disclose",  locked:true, lockReason:"Starts during disclosure" },
  { k:"house",   label:"Our household", phase:"3 · Reconcile", locked:true, lockReason:"When Mark's shared" },
  { k:"prop",    label:"Proposals",     phase:"4 · Settle",    locked:true },
  { k:"final",   label:"Finalise",      phase:"5 · Finalise",  locked:true }
];

function JourneyRail() {
  return (
    <aside className="flex-shrink-0 flex flex-col" style={{
      width: 248, borderRight: `1px solid ${LINE}`, background: "#FFFFFF", padding: "24px 12px"
    }}>
      <div className="px-3 pb-3">
        <div className="label-xs" style={{ color: MUTE }}>Your journey</div>
      </div>
      <nav className="flex flex-col gap-0.5">
        {JOURNEY.map((j,i) => {
          const active = j.active;
          const locked = j.locked;
          return (
            <div key={j.k} className="group">
              <button
                disabled={locked}
                className="w-full flex items-start gap-3 px-3 py-2.5 rounded-lg text-left"
                style={{
                  background: active ? "#F5F3EE" : "transparent",
                  opacity: locked ? 0.55 : 1,
                  cursor: locked ? "default" : "pointer"
                }}>
                <div className="flex-shrink-0 mt-0.5 rounded-full flex items-center justify-center text-[10.5px] font-semibold"
                     style={{
                       width: 20, height: 20,
                       background: active ? INK : (locked ? "#F5F5F4" : "#FFFFFF"),
                       color:      active ? "#FFF" : (locked ? MUTE : SUB),
                       border:     active ? "none" : `1px solid ${LINE}`
                     }}>
                  {i+1}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13px]" style={{
                    color: active ? INK : (locked ? MUTE : SUB),
                    fontWeight: active ? 600 : 500
                  }}>{j.label}</div>
                  <div className="text-[11px] mt-0.5" style={{ color: MUTE }}>
                    {j.phase}
                  </div>
                  {locked && j.lockReason && (
                    <div className="text-[10.5px] mt-0.5" style={{ color: MUTE, fontStyle: "italic" }}>
                      {j.lockReason}
                    </div>
                  )}
                </div>
              </button>
            </div>
          );
        })}
      </nav>
      <div className="mt-auto pt-4 px-3" style={{ borderTop: `1px solid ${LINE}`}}>
        <div className="text-[11px]" style={{ color: MUTE, lineHeight: 1.55 }}>
          Mark hasn't been invited yet. Share your picture when it feels ready.
        </div>
      </div>
    </aside>
  );
}

/* ---- phase strip (dimmed locked states) ---- */
function PhaseStrip({ variant }) {
  const phases = [
    { n: 1, l: "Preparation", state: "active", sub: "in progress" },
    { n: 2, l: "Disclose",    state: "locked" },
    { n: 3, l: "Reconcile",   state: "locked" },
    { n: 4, l: "Settle",      state: "locked" },
    { n: 5, l: "Finalise",    state: "locked" }
  ];
  return (
    <div className="flex items-stretch gap-0 rounded-xl overflow-hidden"
         style={{ background: "#FFF", border: `1px solid ${LINE}` }}>
      {phases.map((p, i, arr) => {
        const isActive = p.state === "active";
        return (
          <div key={p.n} className="flex-1 flex items-center gap-2.5 px-3.5 py-3 relative"
               style={{
                 borderRight: i < arr.length-1 ? `1px solid ${LINE}` : "none",
                 background: isActive ? CANVAS : "#FFF",
                 opacity: isActive ? 1 : 0.42,
                 cursor: "default"
               }}
               title={isActive ? "" : "Unlocks when preparation is complete"}>
            <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10.5px] font-semibold flex-shrink-0"
                 style={{
                   background: isActive ? INK : "transparent",
                   color: isActive ? "#FFF" : MUTE,
                   border: isActive ? "none" : `1px solid ${LINE}`
                 }}>
              {p.n}
            </div>
            <div className="min-w-0">
              <div className="text-[12.5px] font-semibold truncate" style={{ color: isActive ? INK : SUB }}>
                {p.l}
              </div>
              {isActive && <div className="text-[10.5px]" style={{ color: MUTE }}>{p.sub}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---- connected-bank banner (expandable) ---- */
function ConnectedBanner({ variant, expanded, onToggle }) {
  const accounts = [
    { name: "Everyday Current",    type: "Current", sort: "20-00-00", num: "••••4821", bal: "£2,847.13" },
    { name: "Reward Credit Card",  type: "Credit",  sort: "20-00-00", num: "••••9930", bal: "−£382.44"  },
    { name: "Joint Savings",       type: "Savings", sort: "20-00-00", num: "••••1104", bal: "£28,402.00"}
  ];

  const isExpressive = variant === "expressive";

  return (
    <div className="rounded-xl overflow-hidden" style={{
      background: "#FFF",
      border: `1px solid ${LINE}`
    }}>
      <div
        className="w-full flex items-center gap-4 px-5 py-4"
        style={{ background: isExpressive ? "#F5F1EB" : "#FFF", transition: "background 140ms" }}>
        <button
          onClick={onToggle}
          className="flex items-center gap-4 flex-1 min-w-0 text-left"
          style={{ background: "transparent", padding: 0 }}>
          <div className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-white text-[14px] font-bold"
               style={{ background: "#00AEEF" }}>B</div>
          <div className="flex-1 min-w-0">
            <div className="label-xs" style={{ color: MUTE, marginBottom: 2 }}>Step 1 complete</div>
            <div className="flex items-center gap-2">
              <Check size={14} sw={2.5} style={{ color: "#059669" }}/>
              <div className="text-[15px] font-semibold" style={{ color: INK, letterSpacing: "-0.01em" }}>
                Connected to Barclays
              </div>
            </div>
            <div className="text-[11.5px] mt-1 flex items-center gap-2" style={{ color: MUTE }}>
              <span>3 accounts · 1,284 transactions classified</span>
              <span className="w-1 h-1 rounded-full" style={{ background: "#D6D3CC" }}/>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#059669" }}/>
                Synced 4 min ago
              </span>
            </div>
          </div>
        </button>
        <div className="flex items-center gap-2 flex-shrink-0">
          <button
            className="h-8 px-3 rounded-md text-[12px] font-medium text-white"
            style={{ background: isExpressive ? "#4338CA" : INK }}>
            Add another bank
          </button>
          <button
            onClick={onToggle}
            className="w-7 h-7 rounded-md flex items-center justify-center"
            style={{ color: MUTE, transform: expanded ? "rotate(180deg)" : "none", transition: "transform 180ms" }}>
            <Chev size={14}/>
          </button>
        </div>
      </div>

      {expanded && (
        <div className="px-5 pb-4 pt-1" style={{ borderTop: `1px solid ${LINE}` }}>
          <div className="mt-3 space-y-1">
            {accounts.map((a, i) => (
              <div key={i} className="flex items-center gap-3 py-2 px-2 rounded-md hover:bg-[#FAFAF7]">
                <div className="w-6 h-6 rounded flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0"
                     style={{ background: "#00AEEF" }}>B</div>
                <div className="flex-1 min-w-0">
                  <div className="text-[12.5px] font-semibold" style={{ color: INK }}>{a.name}</div>
                  <div className="text-[10.5px]" style={{ color: MUTE }}>{a.type} · {a.sort} {a.num}</div>
                </div>
                <div className="mono tabular text-[12.5px] font-semibold" style={{ color: a.bal.startsWith("−") ? "#B91C1C" : INK }}>
                  {a.bal}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-between text-[11px]" style={{ color: MUTE }}>
            <div className="flex items-center gap-1.5"><Sync size={11}/> Auto-syncs daily · read-only via TrueLayer</div>
            <button className="underline" style={{ color: INK }}>Manage connection</button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---- section cards shared by both variants ---- */
function DisclosureCard({ variant }) {
  const pct = 32;
  const isExpressive = variant === "expressive";
  return (
    <div className="rounded-xl px-5 py-5" style={{ background: "#FFF", border: `1px solid ${LINE}` }}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="label-xs" style={{ color: isExpressive ? "#9D174D" : MUTE }}>Your private area</div>
          <h3 className="serif mt-1.5" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-0.015em", color: INK, fontStyle: "italic" }}>
            View your disclosure picture
          </h3>
          <p className="mt-1 text-[12.5px]" style={{ color: SUB, lineHeight: 1.5 }}>
            We've pre-filled the first draft from your Barclays data. Review, add anything missing, and keep it private until you're ready to share.
          </p>
          <div className="mt-3.5 flex items-center gap-2.5" style={{ maxWidth: 320 }}>
            <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: "#F5F3EE" }}>
              <div className="h-full rounded-full" style={{ width: `${pct}%`, background: isExpressive ? "#9D174D" : INK }}/>
            </div>
          </div>
        </div>
        <button className="h-9 px-3.5 rounded-lg text-[12.5px] font-medium text-white whitespace-nowrap flex-shrink-0 flex items-center gap-1.5"
                style={{ background: INK }}>
          Go to your picture
          <Arrow size={13}/>
        </button>
      </div>
    </div>
  );
}

/* ---- task row ---- */
function TaskRow({ task, variant }) {
  const cat = CATS[task.cat];
  const isExpressive = variant === "expressive";

  const actionStyles = {
    done:   { bg: "#FFF", fg: INK, border: `1px solid ${LINE}` },
    primary:{ bg: INK, fg: "#FFF", border: "none" },
    special:{ bg: isExpressive ? "#7C3AED" : INK, fg: "#FFF", border: "none" }
  };
  const a = actionStyles[task.actionKind || "primary"];

  return (
    <div className="flex items-center gap-3 py-3"
         style={{ borderBottom: task.last ? "none" : `1px solid ${LINE}` }}>
      {/* category chip */}
      <div className="flex-shrink-0 flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold"
           style={{ background: cat.bg, color: cat.fg, letterSpacing: "0.02em" }}>
        {cat.label}
      </div>

      <div className="flex-1 min-w-0 text-[13px]" style={{ color: INK, lineHeight: 1.45 }}>
        {task.title}
        {task.link && <> <a href="#" className="underline" style={{ color: isExpressive ? "#4338CA" : INK }}>{task.link}</a></>}
      </div>

      <button className="h-8 px-3 rounded-md text-[12px] font-medium flex-shrink-0 flex items-center gap-1 whitespace-nowrap"
              style={{ background: a.bg, color: a.fg, border: a.border }}>
        {task.actionKind === "special" && <Upload size={12}/>}
        {task.action}
      </button>
    </div>
  );
}

/* ---- preparation tasks block ---- */
const PREP_TASKS = [
  { cat: "evidence",   title: "Have you applied for your pension CETV yet? (Don't forget it takes a while)", action: "Done", actionKind: "done" },
  { cat: "practical",  title: "You haven't outlined your child situation yet", action: "Outline now", actionKind: "primary" },
  { cat: "practical",  title: "Fill out your post separation budgetary needs", action: "Outline now", actionKind: "primary" },
  { cat: "legal",      title: "Have you applied for your divorce online yet?", link: "For guidance click here", action: "Done", actionKind: "done" },
  { cat: "legal",      title: "Book your MIAM and use your free £500 voucher", action: "Done", actionKind: "done" },
  { cat: "evidence",   title: "Upload your mortgage statement", action: "Upload now", actionKind: "special" },
  { cat: "practical",  title: "You haven't outlined your spending needs yet", action: "Outline now", actionKind: "primary", last: true }
];

function PrepTasksCard({ variant }) {
  const isExpressive = variant === "expressive";
  return (
    <div className="rounded-xl px-5 py-5" style={{ background: "#FFF", border: `1px solid ${LINE}` }}>
      <div className="label-xs" style={{ color: isExpressive ? "#9D174D" : MUTE }}>Get these 3 done ASAP</div>
      <h3 className="serif mt-1" style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.015em", color: INK }}>
        Next preparation tasks
      </h3>

      <div className="mt-3">
        {PREP_TASKS.map((t, i) => (
          <TaskRow key={i} task={{ ...t, last: i === PREP_TASKS.length - 1 }} variant={variant}/>
        ))}
      </div>

      <button className="mt-3 text-[12.5px] font-medium flex items-center gap-1.5" style={{ color: MUTE }}>
        <Plus size={12}/> Add a task
      </button>
    </div>
  );
}

/* ---- locked section (Disclosure & reconcile / Settle & finalise) ---- */
function LockedSection({ title, variant, phaseColor, subtitle, primary, tasks, unlockReason }) {
  const isExpressive = variant === "expressive";
  return (
    <div style={{ opacity: 0.55 }}>
      <div className="flex items-center gap-2.5 mb-3">
        <h2 className="serif" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", color: INK }}>
          {title}
        </h2>
        <div className="flex items-center gap-1 text-[10.5px] px-2 py-0.5 rounded-full"
             style={{ background: "#F5F3EE", color: MUTE, letterSpacing: "0.04em", textTransform: "uppercase", fontWeight: 600 }}>
          <Lock size={10} sw={2.2}/> Locked
        </div>
        <div className="text-[11px]" style={{ color: MUTE, fontStyle: "italic" }}>
          {unlockReason}
        </div>
      </div>

      <div className="space-y-4 pointer-events-none">
        {/* primary locked card */}
        <div className="rounded-xl px-5 py-5" style={{ background: "#FFF", border: `1px dashed ${LINE}` }}>
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="label-xs" style={{ color: isExpressive ? phaseColor : MUTE }}>{primary.kicker}</div>
              <h3 className="serif mt-1.5" style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.015em", color: INK, fontStyle: "italic" }}>
                {primary.title}
              </h3>
              <p className="mt-1 text-[12.5px]" style={{ color: SUB, lineHeight: 1.5 }}>{primary.sub}</p>
            </div>
            <button className="h-9 px-3.5 rounded-lg text-[12.5px] font-medium hairline flex items-center gap-1.5 flex-shrink-0"
                    style={{ background: "#FFF", color: MUTE, border: `1px solid ${LINE}` }}>
              {primary.cta} <Lock size={11}/>
            </button>
          </div>
        </div>

        {/* locked tasks preview */}
        <div className="rounded-xl px-5 py-5" style={{ background: "#FFF", border: `1px dashed ${LINE}` }}>
          <div className="label-xs" style={{ color: isExpressive ? phaseColor : MUTE }}>Next up</div>
          <h3 className="serif mt-1" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.015em", color: INK }}>
            {tasks.title}
          </h3>
          <div className="mt-3 space-y-0">
            {tasks.items.map((t, i) => (
              <div key={i} className="flex items-center gap-3 py-2.5"
                   style={{ borderBottom: i < tasks.items.length - 1 ? `1px solid ${LINE}` : "none" }}>
                <div className="flex-shrink-0 px-2 py-0.5 rounded-full text-[10px] font-semibold"
                     style={{ background: CATS[t.cat].bg, color: CATS[t.cat].fg, opacity: 0.7 }}>
                  {CATS[t.cat].label}
                </div>
                <div className="flex-1 text-[13px]" style={{ color: SUB }}>{t.title}</div>
                <div className="h-8 px-3 rounded-md text-[12px] flex items-center" style={{ color: MUTE, border: `1px solid ${LINE}` }}>
                  Locked
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ==================================================================
   MAIN DASHBOARD  — shared layout, two variants via `variant` prop
   ================================================================== */
function Dashboard({ variant = "conservative" }) {
  const [expanded, setExpanded] = useState(false);

  const isExpressive = variant === "expressive";
  const pageBg = isExpressive
    ? "linear-gradient(180deg, #F3EEFE 0%, #F5F5F4 360px)"
    : BG;

  return (
    <div className="h-full flex flex-col" style={{ background: BG, overflow: "hidden" }}>
      <TopBar/>
      <main className="flex-1 overflow-y-auto nice-scroll" style={{ background: pageBg }}>
        <div className="mx-auto" style={{ maxWidth: 960, padding: "36px 40px 80px" }}>

          {/* Greeting */}
          <div>
            <div className="label-xs" style={{ color: MUTE }}>Today · 21 April</div>
            <h1 className="serif mt-2" style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.1, color: INK }}>
              Welcome, Sarah.
              <br/>
              <span style={{ color: SUB, fontStyle: "italic" }}>Let's build your picture.</span>
            </h1>
          </div>

          {/* Phase strip */}
          <div className="mt-7">
            <PhaseStrip variant={variant}/>
          </div>

          {/* ===== PREPARATION ===== */}
          <div className="mt-9">
            <div className="flex items-center gap-2.5 mb-3">
              <h2 className="serif" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", color: INK }}>
                Preparation
              </h2>
              {isExpressive && (
                <span className="text-[10.5px] font-semibold px-2 py-0.5 rounded-full"
                      style={{ background: "#EEF2FF", color: "#4338CA", letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  Current phase
                </span>
              )}
            </div>
            <div className="space-y-4">
              <ConnectedBanner variant={variant} expanded={expanded} onToggle={() => setExpanded(e => !e)}/>
              <DisclosureCard variant={variant}/>
              <PrepTasksCard variant={variant}/>
            </div>
          </div>

          {/* ===== DISCLOSURE & RECONCILE (locked) ===== */}
          <div className="mt-10">
            <LockedSection
              title="Disclosure & reconcile"
              variant={variant}
              phaseColor="#9D174D"
              unlockReason="Unlocks when preparation is complete"
              primary={{
                kicker: "Your shared area",
                title:  "View your shared household picture",
                sub:    "Where you will find your reconciled household disclosure.",
                cta:    "View your shared area"
              }}
              tasks={{
                title: "Next disclosure tasks",
                items: [
                  { cat: "evidence",  title: "Share your private disclosure with Mark" },
                  { cat: "practical", title: "Review Mark's additions and flag differences" },
                  { cat: "legal",     title: "Sign off on the reconciled picture" }
                ]
              }}
            />
          </div>

          {/* ===== SETTLE & FINALISE (locked) ===== */}
          <div className="mt-10">
            <LockedSection
              title="Settle & finalise"
              variant={variant}
              phaseColor="#0369A1"
              unlockReason="Unlocks when reconciliation is complete"
              primary={{
                kicker: "Your private area",
                title:  "Create your draft proposal",
                sub:    "Build your opening position with AI legal assurance and reasonableness flags.",
                cta:    "Go to your area"
              }}
              tasks={{
                title: "Next settlement tasks",
                items: [
                  { cat: "legal",     title: "Draft capital split proposal" },
                  { cat: "legal",     title: "Review Mark's counter-proposal" },
                  { cat: "evidence",  title: "Generate Consent Order & Form D81" }
                ]
              }}
            />
          </div>

        </div>
      </main>
    </div>
  );
}

Object.assign(window, { Dashboard });
})();
