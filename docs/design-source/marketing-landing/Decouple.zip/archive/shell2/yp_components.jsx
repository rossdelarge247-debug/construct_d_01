/* Your Picture v4 — components
   View dropdown, dynamic Share CTA, delta markers, pending-deltas pill, share modal, doc body.
*/
(function(){
const { useState, useEffect, useRef, useMemo } = React;
const {
  Wordmark, ChevronRight, ChevronDown, Check, Share, Edit, FileText, History,
  LifeBuoy, Lock, PanelRight
} = window;
const T = window.YP_TOKENS;

/* ============================================================
   VIEW DROPDOWN (Private / Shared) — lives on top bar left,
   next to the document title.
   ============================================================ */
function ViewDropdown({ view, setView, hasShared }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const current = view === "shared" ? "Shared with Mark" : "Private";

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(o => !o)}
        className="inline-flex items-center gap-1.5 rounded-md text-[12.5px] font-medium"
        style={{
          padding: "5px 9px 5px 8px",
          border: `1px solid ${T.LINE}`,
          background: "#FFF",
          color: T.INK
        }}>
        {view === "shared"
          ? <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/></svg>
          : <Lock size={13}/>}
        <span>{current}</span>
        <ChevronDown size={13} style={{ color: T.MUTE }}/>
      </button>

      {open && (
        <div className="absolute z-40 mt-1.5 rounded-lg"
          style={{
            background: "#FFF", border: `1px solid ${T.LINE}`,
            boxShadow: "0 8px 24px rgba(0,0,0,0.08)", minWidth: 260, left: 0
          }}>
          <ViewOption
            active={view === "private"}
            icon={<Lock size={13}/>}
            label="Private"
            sub="What only you see. Your working draft."
            onClick={() => { setView("private"); setOpen(false); }}/>
          <ViewOption
            active={view === "shared"}
            disabled={!hasShared}
            icon={<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/></svg>}
            label="Shared with Mark"
            sub={hasShared ? "Exactly what Mark is looking at. Read-only preview." : "Nothing shared yet"}
            onClick={() => { if (hasShared) { setView("shared"); setOpen(false); } }}/>
          <div className="px-3 py-2.5 text-[10.5px]" style={{ color: T.MUTE, borderTop: `1px solid ${T.LINE}`, letterSpacing: "0.05em", textTransform: "uppercase", fontWeight: 600 }}>
            More views coming
          </div>
          <div className="px-3 pb-2.5 text-[11.5px]" style={{ color: T.MUTE, lineHeight: 1.45 }}>
            Later: Shared with lawyer · Shared with mediator.
          </div>
        </div>
      )}
    </div>
  );
}

function ViewOption({ active, disabled, icon, label, sub, onClick }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="w-full text-left px-3 py-2.5 flex items-start gap-2.5"
      style={{
        background: active ? "#F5F3EE" : "transparent",
        opacity: disabled ? 0.4 : 1,
        cursor: disabled ? "default" : "pointer"
      }}>
      <span style={{ color: T.SUB, marginTop: 2 }}>{icon}</span>
      <span className="flex-1 min-w-0">
        <span className="flex items-center gap-1.5" style={{ fontSize: 13, fontWeight: 600, color: T.INK }}>
          {label}
          {active && <Check size={12} style={{ color: T.ACCENT }} strokeWidth={2.5}/>}
        </span>
        <span className="block mt-0.5" style={{ fontSize: 11.5, color: T.SUB, lineHeight: 1.4 }}>{sub}</span>
      </span>
    </button>
  );
}

/* ============================================================
   DYNAMIC SHARE CTA — 3 states:
     new        → primary "Share with Mark"
     in-sync    → muted status button
     pending    → accent with count
   ============================================================ */
function ShareCTA({ shareState, deltaCount, version, date, onOpen }) {
  if (shareState === "new") {
    return (
      <button onClick={onOpen}
        className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-semibold text-white"
        style={{ background: T.INK }}>
        <Share size={13}/> Share with Mark
      </button>
    );
  }
  if (shareState === "sync") {
    return (
      <button onClick={onOpen}
        className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-medium whitespace-nowrap"
        style={{ background: "#FFF", color: T.SUB, border: `1px solid ${T.LINE}`, flexShrink: 0 }}>
        <Check size={13} style={{ color: T.ACCENT }}/>
        <span className="hidden xl:inline">Shared — up to date · {version} · {date}</span>
        <span className="xl:hidden">Shared · {version}</span>
      </button>
    );
  }
  // pending
  return (
    <button onClick={onOpen}
      className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-semibold text-white whitespace-nowrap"
      style={{ background: T.AMBER, flexShrink: 0 }}>
      <Share size={13}/>
      <span className="hidden lg:inline">Share updates with Mark</span>
      <span className="lg:hidden">Share updates</span>
      <span style={{
        padding: "1px 6px", borderRadius: 999, background: "rgba(255,255,255,0.25)",
        fontSize: 11, fontWeight: 700, marginLeft: 2
      }}>{deltaCount}</span>
    </button>
  );
}

/* ============================================================
   PENDING-DELTAS PILL — subtle inline header chip;
   click → opens share modal scrolled to checklist.
   ============================================================ */
function PendingPill({ count, onClick }) {
  return (
    <button onClick={onClick}
      className="inline-flex items-center gap-1.5 whitespace-nowrap"
      style={{
        padding: "3px 9px 3px 8px", borderRadius: 999,
        background: T.AMBER_BG, color: T.AMBER,
        fontSize: 11, fontWeight: 600, letterSpacing: "0.02em",
        border: `1px solid #F5DFA8`, cursor: "pointer",
        flexShrink: 0
      }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: T.AMBER, flexShrink: 0 }}/>
      <span className="hidden xl:inline">{count} held-back {count === 1 ? "update" : "updates"}</span>
      <span className="xl:hidden">{count} pending</span>
      <ChevronRight size={11}/>
    </button>
  );
}

/* ============================================================
   DELTA MARKER on ITEM ROW (Private view only)
   ============================================================ */
function ItemRow({ item, delta, showDelta, markerStyle }) {
  // markerStyle ∈ { "dot", "tint", "rule", "chip" }
  const hasDelta = !!delta && showDelta;
  const showValue = hasDelta ? delta.newValue : item.sharedValue;

  const baseBox = {
    padding: "11px 14px",
    background: "#FFFFFF",
    border: `1px solid ${T.LINE}`,
    borderRadius: 6,
    display: "flex",
    alignItems: "center",
    gap: 10,
    position: "relative"
  };
  const styleMap = {
    dot:  {},
    tint: hasDelta ? { background: T.AMBER_SOFT, borderColor: "#F5DFA8" } : {},
    rule: hasDelta ? { borderLeft: `3px solid ${T.AMBER}`, paddingLeft: 12 } : {},
    chip: {}
  };
  const rowStyle = { ...baseBox, ...styleMap[markerStyle] };

  return (
    <div style={rowStyle}>
      {markerStyle === "dot" && hasDelta && (
        <span style={{
          position: "absolute", left: -3, top: "50%", transform: "translateY(-50%)",
          width: 6, height: 6, borderRadius: "50%", background: T.AMBER,
          boxShadow: "0 0 0 2px #F5F5F4"
        }}/>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span style={{ fontSize: 13, fontWeight: 500, color: T.INK }}>{item.label}</span>
          {markerStyle === "chip" && hasDelta && (
            <span className="chip" style={{ background: T.AMBER_BG, color: T.AMBER, fontSize: 9.5 }}>
              Edited
            </span>
          )}
        </div>
        <div className="mt-0.5" style={{ fontSize: 11.5, color: T.MUTE }}>{item.category}</div>
      </div>
      <div className="flex items-baseline gap-2 tabular-nums">
        {hasDelta && (
          <span style={{
            fontSize: 11.5, color: T.MUTE, textDecoration: "line-through", fontWeight: 400
          }}>{item.sharedValue}</span>
        )}
        <span style={{ fontSize: 13.5, fontWeight: 600, color: hasDelta ? T.AMBER : T.INK }}>
          {showValue}
        </span>
      </div>
    </div>
  );
}

/* ============================================================
   SHARE MODAL (center dialog)
   Layout options: 'center' (default) | 'sheet' | 'fullwidth'
   ============================================================ */
function ShareModal({ onClose, shareState, deltas, layout, onConfirm }) {
  const [checked, setChecked] = useState(() => {
    const m = {}; deltas.forEach(d => { m[d.itemId] = true; });
    return m;
  });
  useEffect(() => {
    const h = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  const itemsById = useMemo(() => Object.fromEntries(window.YP_ITEMS.map(i => [i.id, i])), []);
  const checkedCount = Object.values(checked).filter(Boolean).length;

  const isNew = shareState === "new";
  const isPending = shareState === "pending";

  const modalStyles = {
    center:    { width: 560, maxHeight: "82vh", top: "50%", left: "50%", transform: "translate(-50%,-50%)", borderRadius: 14, position: "fixed" },
    sheet:     { width: 440, height: "100%",    top: 0,     right: 0,    position: "fixed", borderRadius: 0 },
    fullwidth: { width: "min(820px, 92vw)", maxHeight: "86vh", top: "50%", left: "50%", transform: "translate(-50%,-50%)", borderRadius: 14, position: "fixed" }
  };
  const backdrop = {
    position: "fixed", inset: 0, background: "rgba(15,18,22,0.45)", zIndex: 60
  };
  const modal = {
    background: "#FFF", boxShadow: "0 20px 60px rgba(0,0,0,0.25)", zIndex: 61,
    display: "flex", flexDirection: "column", overflow: "hidden",
    ...modalStyles[layout]
  };

  return (
    <>
      <div style={backdrop} onClick={onClose}/>
      <div style={modal} onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="px-6 pt-5 pb-4 flex-shrink-0" style={{ borderBottom: `1px solid ${T.LINE}` }}>
          <div className="flex items-start justify-between">
            <div>
              <div className="label-xs mb-1" style={{ color: T.MUTE }}>
                {isNew ? "First share" : "Share updates"}
              </div>
              <h2 style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em" }}>
                {isNew ? "Share your picture with Mark" : `Share ${deltas.length} update${deltas.length === 1 ? "" : "s"} with Mark`}
              </h2>
              <p className="mt-1.5" style={{ fontSize: 13, color: T.SUB, lineHeight: 1.55, maxWidth: 460 }}>
                {isNew
                  ? "Mark will be emailed a link to build his own picture. He can't see yours until he shares back."
                  : "Tick the updates you're ready to share. Unchecked ones stay private until you share again."}
              </p>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-md hover:bg-gray-100" style={{ color: T.SUB, marginTop: -4 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
                <line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/>
              </svg>
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto nice-scroll px-6 py-5">
          {isNew ? (
            <FirstShareBody/>
          ) : (
            <DeltaChecklist
              deltas={deltas}
              itemsById={itemsById}
              checked={checked}
              setChecked={setChecked}/>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 flex items-center justify-between flex-shrink-0"
          style={{ borderTop: `1px solid ${T.LINE}`, background: "#FAFAF7" }}>
          <div style={{ fontSize: 11.5, color: T.MUTE }}>
            {isPending && `${checkedCount} of ${deltas.length} selected · unchecked stay private`}
            {isNew && "Mark receives a plain-language email invitation"}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onClose}
              style={{
                padding: "7px 14px", fontSize: 12.5, fontWeight: 500,
                background: "#FFF", color: T.INK, border: `1px solid ${T.LINE}`, borderRadius: 6,
                cursor: "pointer"
              }}>Cancel</button>
            <button
              onClick={() => onConfirm(checked)}
              disabled={isPending && checkedCount === 0}
              style={{
                padding: "7px 14px", fontSize: 12.5, fontWeight: 600,
                background: T.INK, color: "#FFF", borderRadius: 6, border: "none",
                opacity: (isPending && checkedCount === 0) ? 0.4 : 1,
                cursor: (isPending && checkedCount === 0) ? "not-allowed" : "pointer"
              }}>
              {isNew
                ? "Send to Mark"
                : `Share ${checkedCount} update${checkedCount === 1 ? "" : "s"}`}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function FirstShareBody() {
  return (
    <div>
      <div style={{ fontSize: 13, fontWeight: 600, color: T.INK, marginBottom: 10 }}>What Mark will get</div>
      <ul className="flex flex-col gap-2" style={{ fontSize: 13, color: T.INK, lineHeight: 1.55 }}>
        {[
          "An email invitation with a link to start his own picture",
          "A read-only view of your picture, once he's shared his back",
          "Any held-back updates you make will stay private until you choose to share"
        ].map((t,i) => (
          <li key={i} className="flex items-start gap-2.5">
            <Check size={15} style={{ color: T.ACCENT, marginTop: 1, flexShrink: 0 }}/>
            <span>{t}</span>
          </li>
        ))}
      </ul>
      <div className="mt-5 p-3.5 rounded-lg" style={{ background: "#FAFAF7", border: `1px solid ${T.LINE}`, fontSize: 12.5, color: T.SUB, lineHeight: 1.55 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: T.INK, marginBottom: 4, letterSpacing: "0.02em", textTransform: "uppercase" }}>
          Preview of Mark's email
        </div>
        "Sarah has started her financial picture on Decouple and would like to build one with you. When you've shared yours, you'll both see a side-by-side view of your assets, pensions and debts…"
      </div>
    </div>
  );
}

function DeltaChecklist({ deltas, itemsById, checked, setChecked }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <div style={{ fontSize: 12.5, fontWeight: 600, color: T.INK }}>Updates since v1</div>
        <div className="flex gap-1">
          <button
            onClick={() => { const m = {}; deltas.forEach(d => m[d.itemId] = true); setChecked(m); }}
            style={{ fontSize: 11.5, color: T.SUB, padding: "3px 8px", cursor: "pointer", background: "transparent", border: "none" }}>
            Select all
          </button>
          <button
            onClick={() => setChecked({})}
            style={{ fontSize: 11.5, color: T.SUB, padding: "3px 8px", cursor: "pointer", background: "transparent", border: "none" }}>
            Clear
          </button>
        </div>
      </div>

      <div className="flex flex-col gap-2">
        {deltas.map(d => {
          const item = itemsById[d.itemId];
          const on = !!checked[d.itemId];
          return (
            <label key={d.itemId}
              className="flex items-start gap-3 rounded-lg cursor-pointer"
              style={{
                padding: "12px 14px",
                background: on ? "#FFFBEB" : "#FFF",
                border: on ? `1px solid #F5DFA8` : `1px solid ${T.LINE}`,
                transition: "all 120ms ease"
              }}>
              <input
                type="checkbox" checked={on}
                onChange={e => setChecked(s => ({ ...s, [d.itemId]: e.target.checked }))}
                style={{ marginTop: 3, accentColor: T.AMBER }}/>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <span style={{ fontSize: 13, fontWeight: 600, color: T.INK }}>{item.label}</span>
                  <span className="chip" style={{ background: "#F3F4F6", color: T.SUB, fontSize: 9.5 }}>{item.category}</span>
                </div>
                <div className="mt-1.5 flex items-center gap-2 tabular-nums">
                  <span style={{ fontSize: 11.5, color: T.MUTE, textDecoration: "line-through" }}>{d.oldValue}</span>
                  <ChevronRight size={11} style={{ color: T.MUTE }}/>
                  <span style={{ fontSize: 13.5, fontWeight: 600, color: T.AMBER }}>{d.newValue}</span>
                </div>
                <div className="mt-1.5" style={{ fontSize: 12, color: T.SUB, lineHeight: 1.5 }}>
                  {d.reason}
                </div>
                <div className="mt-1" style={{ fontSize: 11, color: T.MUTE }}>{d.source}</div>
              </div>
            </label>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, {
  YP_ViewDropdown: ViewDropdown,
  YP_ShareCTA: ShareCTA,
  YP_PendingPill: PendingPill,
  YP_ItemRow: ItemRow,
  YP_ShareModal: ShareModal
});
})();
