/* Floating nav variations — minimal Structured Rail base
   4 variations × desktop + mobile
*/
(function(){
const { useState, useEffect, useRef } = React;
const { MenuIcon, XIcon, ChevronRight, ChevronDown, MessageSquare, Check, Plus, History,
        FileText, Home, Compass, Share, Edit, LifeBuoy, Settings, Dot, BookOpen,
        ASSETS, COMMENT_THREAD, ACTIVITY, STATES } = window;

const INK = "#1A1A1A", SUB = "#6B7280", MUTE = "#9CA3AF", LINE = "#EFEFEF", ACCENT = "#2F6D5F";

/* ---- Sparkle icon for AI action ---- */
const Sparkle = ({ size = 14, stroke = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={stroke}
       strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3l1.8 4.8L18 9l-4.2 1.2L12 15l-1.8-4.8L6 9l4.2-1.2z"/>
    <path d="M19 14l.7 1.8L21 16.5l-1.3.7L19 19l-.7-1.8L17 16.5l1.3-.7z"/>
  </svg>
);
const Download = ({ size = 14, stroke = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={stroke}
       strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
  </svg>
);

/* ================================================================= */
/*  SHARED: minimal base doc (no chapter strip, no right column)       */
/* ================================================================= */
function DocBase({ compact }) {
  return (
    <div className="max-w-[640px] mx-auto px-8 py-10">
      <div className="label-xs mb-1.5" style={{ color: MUTE }}>Phase 4 · Settlement</div>
      <h1 style={{ fontSize: 32, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
        Mark replied to your proposal.
      </h1>
      <p className="mt-2" style={{ fontSize: 15, color: SUB, lineHeight: 1.55 }}>
        Two items still need your response. Six of eight clauses accepted.
      </p>
      {/* Thin single progress bar */}
      <div className="mt-5 flex items-center gap-3">
        <div className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
          <div className="h-full rounded-full" style={{ width: "75%", background: INK }}/>
        </div>
        <span className="text-[11px] tabular-nums" style={{ color: SUB, fontWeight: 600 }}>75%</span>
      </div>

      <div className="mt-8 space-y-6">
        <Section n="§3.1" title="Household finances" done>
          <p>Sarah and Mark's combined assets stand at £486,850 after the pension CETV transfer and equity valuation on the Harrogate property. See ledger below.</p>
          <MiniLedger/>
        </Section>

        <Section n="§3.2" title="Housing" flagged>
          <p>Proposal: Sarah retains primary residence; Mark's share (£93,750) paid from joint savings and a 24-month promissory note.</p>
        </Section>

        <Section n="§4.1" title="Children — contact schedule" flagged>
          <p>Weekdays with Sarah; alternating weekends with Mark; holidays split equally by duration.</p>
        </Section>
      </div>
      {!compact && <div className="h-24"/>}
    </div>
  );
}
function Section({ n, title, children, done, flagged }) {
  return (
    <div>
      <div className="flex items-baseline gap-2 mb-1.5">
        <span className="label-xs tabular-nums" style={{ color: MUTE }}>{n}</span>
        <h3 style={{ fontSize: 16, fontWeight: 600 }}>{title}</h3>
        {done && <span className="chip-xs" style={{ background: "#D1FAE5", color: "#065F46" }}>ACCEPTED</span>}
        {flagged && <span className="chip-xs" style={{ background: "#FEE2E2", color: "#991B1B" }}>PENDING</span>}
      </div>
      <div style={{ fontSize: 14.5, color: "#1A1A1A", lineHeight: 1.65 }}>{children}</div>
    </div>
  );
}
function MiniLedger() {
  return (
    <div className="mt-3 rounded-xl p-4" style={{ background: "#FAFAFA", border: `1px solid ${LINE}` }}>
      {ASSETS.slice(0, 4).map(([l,,v,done], i) => (
        <div key={i} className="flex items-center justify-between py-1.5"
             style={{ borderBottom: i < 3 ? `1px dashed #E5E7EB` : "none" }}>
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-3 h-3 rounded-[2px] flex items-center justify-center flex-shrink-0"
                 style={{ background: done ? ACCENT : "#E5E7EB" }}>
              {done && <Check size={8} strokeWidth={3} stroke="#FFF"/>}
            </div>
            <span className="text-[13px] truncate" style={{ color: done ? INK : MUTE }}>{l}</span>
          </div>
          <span className="text-[12.5px] tabular-nums" style={{ color: done ? INK : MUTE }}>{v}</span>
        </div>
      ))}
    </div>
  );
}

/* ================================================================= */
/*  Faded minimal chrome — desktop version                             */
/* ================================================================= */
function DesktopBase({ children }) {
  return (
    <div className="relative flex flex-col h-full" style={{ background: "#FCFCFB" }}>
      {/* Very quiet top strip */}
      <div className="flex items-center justify-between px-5"
           style={{ height: 44, borderBottom: `1px solid #F3F3F1` }}>
        <div className="flex items-center gap-2 opacity-60">
          <div className="w-4 h-4 rounded-full relative" aria-hidden>
            <div className="absolute inset-0 rounded-full" style={{ background: INK }}/>
            <div className="absolute rounded-full" style={{ left: "42%", top: 0, width: "58%", height: "100%", background: "#FCFCFB" }}/>
            <div className="absolute rounded-full" style={{ left: "45%", top: "12%", width: "10%", height: "76%", background: INK }}/>
          </div>
          <span style={{ fontSize: 12.5, fontWeight: 600 }}>decouple</span>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <span style={{ fontSize: 12, color: SUB }}>Settlement</span>
          <span className="chip-xs" style={{ background: "#FEE2E2", color: "#991B1B" }}>v2.1 · 2 pending</span>
        </div>
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-semibold"
             style={{ background: ACCENT }}>SJ</div>
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll relative">
        <DocBase/>
        {children}
      </div>
    </div>
  );
}

/* Mobile minimal base */
function MobileBase({ children }) {
  return (
    <div className="relative flex flex-col h-full" style={{ background: "#FCFCFB" }}>
      <div className="flex items-center justify-between px-3"
           style={{ height: 48, borderBottom: `1px solid #F3F3F1`, flexShrink: 0 }}>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full relative" aria-hidden>
            <div className="absolute inset-0 rounded-full" style={{ background: INK }}/>
            <div className="absolute rounded-full" style={{ left: "42%", top: 0, width: "58%", height: "100%", background: "#FCFCFB" }}/>
            <div className="absolute rounded-full" style={{ left: "45%", top: "12%", width: "10%", height: "76%", background: INK }}/>
          </div>
          <span style={{ fontSize: 12.5, fontWeight: 600 }}>decouple</span>
        </div>
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-semibold"
             style={{ background: ACCENT }}>SJ</div>
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll relative">
        <div className="max-w-[640px] mx-auto px-5 py-7">
          <div className="label-xs mb-1.5" style={{ color: MUTE }}>Phase 4 · Settlement</div>
          <h1 style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.2 }}>
            Mark replied to your proposal.
          </h1>
          <p className="mt-1.5" style={{ fontSize: 13.5, color: SUB, lineHeight: 1.55 }}>
            Two items still need your response.
          </p>
          <div className="mt-4 flex items-center gap-2">
            <div className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
              <div className="h-full rounded-full" style={{ width: "75%", background: INK }}/>
            </div>
            <span className="text-[11px] tabular-nums" style={{ color: SUB, fontWeight: 600 }}>75%</span>
          </div>
          <div className="mt-7 space-y-5">
            <Section n="§3.1" title="Household finances" done>
              <p>Combined assets £486,850 after the pension CETV and equity valuation.</p>
              <MiniLedger/>
            </Section>
            <Section n="§3.2" title="Housing" flagged>
              <p>Sarah retains primary residence; Mark's share paid from joint savings and a 24-month note.</p>
            </Section>
            <Section n="§4.1" title="Children — contact schedule" flagged>
              <p>Weekdays with Sarah; alternating weekends with Mark.</p>
            </Section>
          </div>
          <div className="h-28"/>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ================================================================= */
/*  F1 — Command dock (⌘K expandable palette)                         */
/* ================================================================= */
function useCmdK(openSetter) {
  useEffect(() => {
    const h = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault(); openSetter(v => !v);
      }
      if (e.key === "Escape") openSetter(false);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [openSetter]);
}
function F1_Desktop() {
  const [open, setOpen] = useState(false);
  useCmdK(setOpen);
  return (
    <DesktopBase>
      <CommandDock open={open} setOpen={setOpen}/>
    </DesktopBase>
  );
}
function F1_Mobile() {
  const [open, setOpen] = useState(false);
  return (
    <MobileBase>
      <MobileDockTrigger onClick={() => setOpen(true)}/>
      {open && <MobileBottomSheet onClose={() => setOpen(false)}/>}
    </MobileBase>
  );
}

function CommandDock({ open, setOpen }) {
  const items = [
    { icon: <Sparkle size={15} stroke={INK}/>, label: "Respond to Mark's comment on §3.2 Housing", hint: "Suggested · AI", kbd: "↵" },
    { icon: <MessageSquare size={15} stroke={INK}/>, label: "Open comments & activity", hint: "2 unread", kbd: "C" },
    { icon: <Share size={15} stroke={INK}/>, label: "Share document with advisor", hint: "", kbd: "S" },
    { icon: <Download size={15} stroke={INK}/>, label: "Export as PDF", hint: "", kbd: "E" }
  ];
  return (
    <div className="absolute left-0 right-0 bottom-6 flex justify-center pointer-events-none" style={{ zIndex: 30 }}>
      <div className="pointer-events-auto flex flex-col items-center">
        {open && (
          <div className="mb-2 rounded-2xl bg-white p-1.5"
               style={{
                 border: `1px solid ${LINE}`,
                 boxShadow: "0 14px 40px rgba(0,0,0,0.14), 0 2px 6px rgba(0,0,0,0.05)",
                 minWidth: 460,
                 animation: "dockRise 180ms cubic-bezier(.2,.9,.2,1)"
               }}>
            <div className="flex items-center gap-2 px-3 py-2.5" style={{ borderBottom: `1px solid ${LINE}` }}>
              <Sparkle size={13} stroke={MUTE}/>
              <input autoFocus placeholder="Jump, search, or ask…"
                     className="flex-1 bg-transparent outline-none text-[13.5px]"
                     style={{ color: INK }}/>
              <kbd className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#F3F4F6", color: SUB }}>esc</kbd>
            </div>
            <div className="py-1">
              {items.map((it, i) => (
                <button key={i}
                  className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition"
                  style={{ background: i === 0 ? "#F7F7F6" : "transparent" }}
                  onMouseEnter={e => e.currentTarget.style.background = "#F7F7F6"}
                  onMouseLeave={e => e.currentTarget.style.background = i === 0 ? "#F7F7F6" : "transparent"}>
                  <span className="w-6 h-6 rounded-md flex items-center justify-center" style={{ background: "#F3F4F6" }}>{it.icon}</span>
                  <span className="flex-1 text-[13px]">{it.label}</span>
                  {it.hint && <span className="text-[10.5px]" style={{ color: MUTE }}>{it.hint}</span>}
                  {it.kbd && <kbd className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#F3F4F6", color: SUB }}>{it.kbd}</kbd>}
                </button>
              ))}
            </div>
          </div>
        )}
        <button onClick={() => setOpen(o => !o)}
          className="flex items-center gap-2 h-11 px-4 rounded-full bg-white transition hover:scale-[1.02]"
          style={{
            border: `1px solid ${LINE}`,
            boxShadow: "0 10px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.04)"
          }}>
          <Sparkle size={14} stroke={INK}/>
          <span style={{ fontSize: 13, fontWeight: 500 }}>
            {open ? "What would you like to do?" : "1 suggestion · 2 unread"}
          </span>
          <span className="w-px h-4 mx-0.5" style={{ background: LINE }}/>
          <kbd className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "#F3F4F6", color: SUB }}>⌘K</kbd>
        </button>
      </div>
    </div>
  );
}

function MobileDockTrigger({ onClick }) {
  return (
    <div className="absolute left-0 right-0 bottom-3 flex justify-center pointer-events-none" style={{ zIndex: 30 }}>
      <button onClick={onClick}
        className="pointer-events-auto flex items-center gap-2 h-10 px-3.5 rounded-full bg-white"
        style={{
          border: `1px solid ${LINE}`,
          boxShadow: "0 8px 24px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.04)"
        }}>
        <Sparkle size={13} stroke={INK}/>
        <span style={{ fontSize: 12.5, fontWeight: 500 }}>2 unread · 1 suggestion</span>
        <ChevronDown size={12} stroke={SUB} style={{ transform: "rotate(180deg)" }}/>
      </button>
    </div>
  );
}
function MobileBottomSheet({ onClose }) {
  return (
    <div className="absolute inset-0 z-40">
      <div onClick={onClose} className="absolute inset-0" style={{ background: "rgba(0,0,0,0.22)" }}/>
      <div className="absolute left-0 right-0 bottom-0 bg-white rounded-t-3xl p-4"
           style={{ animation: "sheetUp 220ms cubic-bezier(.2,.9,.2,1)" }}>
        <div className="w-10 h-1 rounded-full mx-auto mb-3" style={{ background: "#E5E7EB" }}/>
        <SheetRow icon={<Sparkle size={15} stroke={INK}/>} title="Respond to Mark's comment" sub="§3.2 Housing · Suggested by AI" accent/>
        <SheetRow icon={<MessageSquare size={15} stroke={INK}/>} title="Comments & activity" sub="2 unread from Mark"/>
        <SheetRow icon={<Share size={15} stroke={INK}/>} title="Share with advisor" sub="Create a shareable link"/>
        <SheetRow icon={<Download size={15} stroke={INK}/>} title="Export as PDF" sub="Current version · v2.1"/>
      </div>
    </div>
  );
}
function SheetRow({ icon, title, sub, accent }) {
  return (
    <button className="w-full flex items-center gap-3 py-3 px-1" style={{ borderBottom: `1px solid ${LINE}` }}>
      <span className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ background: accent ? "#F3F4F6" : "#FAFAFA", border: accent ? `1px solid ${LINE}` : "none" }}>
        {icon}
      </span>
      <div className="flex-1 text-left">
        <div style={{ fontSize: 13.5, fontWeight: 600 }}>{title}</div>
        <div style={{ fontSize: 11.5, color: SUB, marginTop: 1 }}>{sub}</div>
      </div>
      <ChevronRight size={14} stroke={MUTE}/>
    </button>
  );
}

/* ================================================================= */
/*  F2 — Ambient section-follow (desktop) / edge pull tab (mobile)    */
/* ================================================================= */
function F2_Desktop() {
  return (
    <DesktopBase>
      <SectionFollowChip/>
    </DesktopBase>
  );
}
function F2_Mobile() {
  const [open, setOpen] = useState(false);
  return (
    <MobileBase>
      <EdgePullTab open={open} setOpen={setOpen}/>
    </MobileBase>
  );
}
function SectionFollowChip() {
  /* A section-aware chip attaches itself next to the currently focused section.
     Hover the section → chip follows. For the mock we anchor it near §3.2. */
  return (
    <div className="absolute pointer-events-none" style={{ top: 420, right: 48, zIndex: 20 }}>
      <div className="pointer-events-auto flex items-center gap-1 rounded-full bg-white p-1 pl-3"
           style={{
             border: `1px solid ${LINE}`,
             boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
             animation: "chipIn 240ms cubic-bezier(.2,.9,.2,1)"
           }}>
        <span className="text-[11px] font-semibold tabular-nums" style={{ color: MUTE }}>§3.2</span>
        <span className="w-px h-3.5 mx-1" style={{ background: LINE }}/>
        <FollowAction icon={<Sparkle size={13} stroke={INK}/>} label="Suggest response" accent/>
        <FollowAction icon={<MessageSquare size={13} stroke={INK}/>} label="Comments" badge="2"/>
        <FollowAction icon={<Share size={13} stroke={INK}/>} label="Share"/>
        <FollowAction icon={<Download size={13} stroke={INK}/>} label="Export"/>
      </div>
      {/* Thin connector line back to the section */}
      <div className="absolute" style={{ left: -18, top: 18, width: 16, height: 1, background: LINE }}/>
    </div>
  );
}
function FollowAction({ icon, label, badge, accent }) {
  return (
    <button className="relative group flex items-center justify-center w-8 h-8 rounded-full transition"
            style={{ background: accent ? "#F7F7F6" : "transparent" }}
            onMouseEnter={e => e.currentTarget.style.background = "#F3F4F6"}
            onMouseLeave={e => e.currentTarget.style.background = accent ? "#F7F7F6" : "transparent"}>
      {icon}
      {badge && (
        <span className="absolute -top-0.5 -right-0.5 text-[9px] font-semibold rounded-full flex items-center justify-center"
              style={{ minWidth: 14, height: 14, padding: "0 3px", background: "#E5484D", color: "#FFF" }}>{badge}</span>
      )}
      <span className="absolute -bottom-7 whitespace-nowrap text-[10.5px] px-1.5 py-0.5 rounded pointer-events-none opacity-0 group-hover:opacity-100 transition"
            style={{ background: INK, color: "#FFF" }}>
        {label}
      </span>
    </button>
  );
}
function EdgePullTab({ open, setOpen }) {
  return (
    <>
      {!open && (
        <button onClick={() => setOpen(true)}
                className="absolute right-0 top-1/2 -translate-y-1/2 pr-2 pl-2.5 py-4 flex flex-col items-center gap-1 rounded-l-2xl bg-white"
                style={{
                  border: `1px solid ${LINE}`, borderRight: "none",
                  boxShadow: "-4px 4px 20px rgba(0,0,0,0.05)",
                  zIndex: 30
                }}>
          <Sparkle size={14} stroke={INK}/>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#E5484D" }}/>
        </button>
      )}
      {open && (
        <div className="absolute inset-0 z-40 flex justify-end">
          <div onClick={() => setOpen(false)} className="absolute inset-0" style={{ background: "rgba(0,0,0,0.22)" }}/>
          <div className="relative h-full bg-white rounded-l-3xl p-4"
               style={{ width: "80%", maxWidth: 300, boxShadow: "-8px 0 30px rgba(0,0,0,0.1)",
                        animation: "slideInRight 220ms cubic-bezier(.2,.9,.2,1)" }}>
            <div className="flex items-center justify-between mb-3">
              <div style={{ fontSize: 13, fontWeight: 600 }}>§3.2 Housing</div>
              <button onClick={() => setOpen(false)} className="w-8 h-8 rounded-lg flex items-center justify-center">
                <XIcon size={15} stroke={INK}/>
              </button>
            </div>
            <SheetRow icon={<Sparkle size={15} stroke={INK}/>} title="Suggest response" sub="AI · drafts a reply to Mark" accent/>
            <SheetRow icon={<MessageSquare size={15} stroke={INK}/>} title="Comments" sub="2 unread"/>
            <SheetRow icon={<Share size={15} stroke={INK}/>} title="Share section" sub="Copy a deep link"/>
            <SheetRow icon={<Download size={15} stroke={INK}/>} title="Export section" sub="PDF or DOCX"/>
          </div>
        </div>
      )}
    </>
  );
}

/* ================================================================= */
/*  F3 — Radial FAB                                                   */
/* ================================================================= */
function F3_Desktop() {
  const [open, setOpen] = useState(false);
  return (
    <DesktopBase>
      <RadialFab open={open} setOpen={setOpen} big/>
    </DesktopBase>
  );
}
function F3_Mobile() {
  const [open, setOpen] = useState(false);
  return (
    <MobileBase>
      <RadialFab open={open} setOpen={setOpen}/>
    </MobileBase>
  );
}
function RadialFab({ open, setOpen, big }) {
  const items = [
    { icon: <Sparkle size={15} stroke="#FFF"/>, label: "Suggest", angle: -150, bg: INK },
    { icon: <MessageSquare size={15} stroke={INK}/>, label: "Comments", angle: -120, badge: 2 },
    { icon: <Share size={15} stroke={INK}/>, label: "Share", angle: -90 },
    { icon: <Download size={15} stroke={INK}/>, label: "Export", angle: -60 }
  ];
  const R = big ? 78 : 66;
  const size = big ? 56 : 52;
  return (
    <div className="absolute" style={{ bottom: big ? 32 : 16, right: big ? 32 : 16, zIndex: 30 }}>
      {/* Radial buttons */}
      {items.map((it, i) => {
        const rad = (it.angle * Math.PI) / 180;
        const x = Math.cos(rad) * R;
        const y = Math.sin(rad) * R;
        return (
          <button key={i}
            className="absolute rounded-full flex items-center justify-center transition"
            style={{
              right: size / 2 - 18, bottom: size / 2 - 18,
              width: 36, height: 36,
              background: it.bg || "#FFFFFF",
              border: it.bg ? "none" : `1px solid ${LINE}`,
              boxShadow: "0 6px 14px rgba(0,0,0,0.12)",
              transform: open ? `translate(${x}px, ${y}px) scale(1)` : "translate(0,0) scale(0.3)",
              opacity: open ? 1 : 0,
              pointerEvents: open ? "auto" : "none",
              transitionDelay: open ? `${i * 30}ms` : "0ms",
              transitionDuration: "220ms",
              transitionTimingFunction: "cubic-bezier(.2,.9,.2,1)"
            }}>
            {it.icon}
            {it.badge && (
              <span className="absolute -top-0.5 -right-0.5 text-[9px] font-semibold rounded-full flex items-center justify-center"
                    style={{ minWidth: 14, height: 14, padding: "0 3px", background: "#E5484D", color: "#FFF" }}>{it.badge}</span>
            )}
          </button>
        );
      })}
      {/* Labels arc — only when open */}
      {open && items.map((it, i) => {
        const rad = (it.angle * Math.PI) / 180;
        const x = Math.cos(rad) * (R + 22);
        const y = Math.sin(rad) * (R + 22);
        return (
          <div key={`l${i}`} className="absolute text-[10.5px] font-medium whitespace-nowrap pointer-events-none"
               style={{
                 right: size / 2 - 18 - x + 18, bottom: size / 2 - 18 - y - 6,
                 color: SUB,
                 animation: `fadeIn 200ms cubic-bezier(.2,.9,.2,1) ${i * 30 + 120}ms both`
               }}>
            {it.label}
          </div>
        );
      })}
      {/* Main FAB */}
      <button onClick={() => setOpen(o => !o)}
        className="relative rounded-full flex items-center justify-center transition"
        style={{
          width: size, height: size, background: INK, color: "#FFF",
          boxShadow: "0 10px 24px rgba(0,0,0,0.2)",
          transform: open ? "rotate(45deg)" : "rotate(0deg)"
        }}>
        <Plus size={big ? 20 : 18} stroke="#FFF"/>
        {!open && (
          <span className="absolute -top-0.5 -right-0.5 text-[9px] font-semibold rounded-full flex items-center justify-center"
                style={{ minWidth: 16, height: 16, padding: "0 3px", background: "#E5484D", color: "#FFF" }}>2</span>
        )}
      </button>
    </div>
  );
}

/* ================================================================= */
/*  F4 — Floating breadcrumb pill (top-center with dropdown)          */
/* ================================================================= */
function F4_Desktop() {
  const [open, setOpen] = useState(false);
  return (
    <DesktopBase>
      <BreadcrumbPill open={open} setOpen={setOpen} top={14} wide/>
    </DesktopBase>
  );
}
function F4_Mobile() {
  const [open, setOpen] = useState(false);
  return (
    <MobileBase>
      <BreadcrumbPill open={open} setOpen={setOpen} top={10}/>
    </MobileBase>
  );
}
function BreadcrumbPill({ open, setOpen, top, wide }) {
  return (
    <div className="absolute left-0 right-0 flex justify-center pointer-events-none" style={{ top, zIndex: 30 }}>
      <div className="pointer-events-auto flex flex-col items-center">
        <button onClick={() => setOpen(o => !o)}
          className="flex items-center gap-2 h-9 px-3 rounded-full bg-white transition"
          style={{
            border: `1px solid ${LINE}`,
            boxShadow: "0 6px 18px rgba(0,0,0,0.08)",
            minWidth: wide ? 320 : 240
          }}>
          <BookOpen size={12} stroke={SUB} style={{ flexShrink: 0 }}/>
          <span className="text-[11.5px] whitespace-nowrap" style={{ color: SUB }}>Ch II · Settlement ·</span>
          <span className="text-[11.5px] font-semibold tabular-nums whitespace-nowrap">§3.2 Housing</span>
          <span className="flex-1"/>
          <Sparkle size={12} stroke={INK} style={{ flexShrink: 0 }}/>
          {wide && <span className="text-[11px] whitespace-nowrap" style={{ color: SUB }}>1 suggestion</span>}
          <span className="w-px h-3.5" style={{ background: LINE }}/>
          <span className="relative">
            <MessageSquare size={12} stroke={INK}/>
            <span className="absolute -top-1 -right-1 w-1.5 h-1.5 rounded-full" style={{ background: "#E5484D" }}/>
          </span>
          <ChevronDown size={12} stroke={SUB}
                       style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 180ms" }}/>
        </button>
        {open && (
          <div className="mt-1.5 bg-white rounded-xl p-1.5"
               style={{
                 border: `1px solid ${LINE}`,
                 boxShadow: "0 14px 40px rgba(0,0,0,0.12)",
                 minWidth: wide ? 380 : 280,
                 animation: "dockRise 180ms cubic-bezier(.2,.9,.2,1)"
               }}>
            <div className="py-1">
              <PillRow icon={<Sparkle size={14} stroke={INK}/>} title="Suggest a response" sub="AI · draft reply to Mark's comment" accent/>
              <PillRow icon={<MessageSquare size={14} stroke={INK}/>} title="Comments & activity" sub="2 unread from Mark" badge="2"/>
              <PillRow icon={<Share size={14} stroke={INK}/>} title="Share" sub="Create a private link for advisor"/>
              <PillRow icon={<Download size={14} stroke={INK}/>} title="Export" sub="PDF · v2.1 snapshot"/>
            </div>
            <div className="px-2 py-1.5 flex items-center gap-2" style={{ borderTop: `1px solid ${LINE}` }}>
              <span className="label-xs" style={{ color: MUTE }}>Jump to section</span>
              <span className="flex-1"/>
              <button className="text-[11px]" style={{ color: INK, fontWeight: 500 }}>§3.1 · §3.2 · §4.1 →</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
function PillRow({ icon, title, sub, accent, badge }) {
  return (
    <button className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition"
            style={{ background: accent ? "#F7F7F6" : "transparent" }}
            onMouseEnter={e => e.currentTarget.style.background = "#F7F7F6"}
            onMouseLeave={e => e.currentTarget.style.background = accent ? "#F7F7F6" : "transparent"}>
      <span className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: "#F3F4F6" }}>{icon}</span>
      <div className="flex-1 min-w-0">
        <div style={{ fontSize: 12.5, fontWeight: 600 }}>{title}</div>
        <div style={{ fontSize: 11, color: SUB, marginTop: 1 }}>{sub}</div>
      </div>
      {badge && (
        <span className="text-[10px] font-semibold rounded-full flex items-center justify-center"
              style={{ minWidth: 16, height: 16, padding: "0 4px", background: "#E5484D", color: "#FFF" }}>{badge}</span>
      )}
    </button>
  );
}

Object.assign(window, {
  F1_Desktop, F1_Mobile, F2_Desktop, F2_Mobile, F3_Desktop, F3_Mobile, F4_Desktop, F4_Mobile
});
})();
