/* Picture Shell — top bar + doc/edit toggle + Share modal wrapping PictureDoc */
(function(){
const { useState, useEffect } = React;
const { Wordmark, STATES, ChevronRight, ChevronDown, MessageSquare, Check, Share,
        Edit, History, Plus, FileText, Home, Compass, LifeBuoy, Users, Dot,
        XIcon, COMMENT_THREAD, ACTIVITY } = window;
const { PictureDoc } = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";

/* ============================================================
   TOP BAR
   ============================================================ */
function TopBar({ mode, setMode, onShare }) {
  return (
    <div className="flex items-center justify-between px-5 flex-shrink-0"
         style={{ height: 56, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
      <div className="flex items-center gap-3">
        <Wordmark small/>
        <span style={{ color: "#E5E7EB" }}>/</span>
        <div className="flex items-center gap-1.5 text-[12.5px]" style={{ color: SUB }}>
          <span>Your picture</span>
          <ChevronRight size={12} style={{ color: "#D4D4D4" }}/>
          <span className="whitespace-nowrap" style={{ color: INK, fontWeight: 600 }}>Sarah's Picture</span>
          <span className="chip ml-1 whitespace-nowrap" style={{ background: "#FEF3C7", color: "#92400E" }}>
            v0.8 · DRAFT
          </span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        {/* Doc / Edit toggle */}
        <div className="inline-flex items-center rounded-md p-0.5"
             style={{ background: "#F3F4F6", border: `1px solid ${LINE}` }}>
          {[
            { k: "doc",  label: "Read",   icon: <FileText size={12}/> },
            { k: "edit", label: "Edit",   icon: <Edit size={12}/> }
          ].map(t => {
            const on = mode === t.k;
            return (
              <button key={t.k} onClick={() => setMode(t.k)}
                className="inline-flex items-center gap-1.5 h-6.5 px-2.5 py-1 rounded text-[11.5px] font-medium transition"
                style={{
                  background: on ? "#FFFFFF" : "transparent",
                  color: on ? INK : SUB,
                  boxShadow: on ? "0 1px 2px rgba(0,0,0,0.06)" : "none"
                }}>
                {t.icon}{t.label}
              </button>
            );
          })}
        </div>

        <button className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium bg-white hover:bg-[#FAFAF9]"
                style={{ borderColor: LINE, color: INK }}>
          <History size={13}/> Version history
        </button>

        <button onClick={onShare}
                className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-medium text-white"
                style={{ background: DANGER }}>
          <Share size={13}/> Share with Mark
        </button>

        <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold"
             style={{ background: ACCENT }}>SJ</div>
      </div>
    </div>
  );
}

/* ============================================================
   LEFT RAIL — chapters + progress
   ============================================================ */
const CHAPTERS = [
  { n: 1, title: "The children",           items: 3,  done: 3 },
  { n: 2, title: "The home",               items: 4,  done: 4, gap: 1 },
  { n: 3, title: "Pensions",               items: 3,  done: 1, gap: 1 },
  { n: 4, title: "Savings & investments",  items: 4,  done: 4 },
  { n: 5, title: "Vehicles & other",       items: 4,  done: 4 },
  { n: 6, title: "Debts",                  items: 5,  done: 5 },
  { n: 7, title: "Income",                 items: 2,  done: 2, gap: 1 },
  { n: 8, title: "Monthly spending",       items: 6,  done: 6 },
  { n: 9, title: "Summary",                items: 6,  done: 6 }
];

function Rail({ active, setActive }) {
  return (
    <div style={{ width: 240, background: "#FAFAFA", borderRight: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">
      <div className="px-4 py-3.5">
        <div className="label-xs mb-2" style={{ color: MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: INK }}>Sarah's Picture</div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full" style={{ width: "86%", background: ACCENT }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 11, color: ACCENT, fontWeight: 600 }}>86%</span>
        </div>
      </div>
      <div className="px-2 pb-3 flex-1 overflow-y-auto nice-scroll">
        {CHAPTERS.map(c => {
          const isActive = active === c.n;
          const complete = c.done === c.items && !c.gap;
          return (
            <button key={c.n} onClick={() => setActive(c.n)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{
                background: isActive ? "#EEF1F0" : "transparent",
                color: INK, fontSize: 12.5,
                fontWeight: isActive ? 600 : 500
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "#F1F1F0"; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: MUTE, width: 14 }}>{c.n}</span>
              <span className="flex-1 truncate">{c.title}</span>
              {c.gap ? (
                <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
                      style={{ width: 14, height: 14, background: "#FEF7E7",
                               color: "#92620A", fontSize: 10, fontWeight: 700 }}>!</span>
              ) : complete ? (
                <Check size={11} style={{ color: ACCENT }} strokeWidth={2.5}/>
              ) : null}
            </button>
          );
        })}
      </div>
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
           style={{ color: SUB, borderTop: `1px solid ${LINE}` }}>
        <LifeBuoy size={12}/> Get support
      </div>
    </div>
  );
}

/* ============================================================
   RIGHT RAIL — summary snapshot + data sources
   ============================================================ */
function RightRail() {
  return (
    <div style={{ width: 320, background: "#FAFAFA", borderLeft: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">
      <div className="p-4" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Snapshot</div>
        <div className="space-y-2">
          {[
            ["Net position",         "£54,560",  INK],
            ["Assets",               "£282,240", INK],
            ["Debts",                "(£227,680)", DANGER],
            ["Monthly gap",          "(£892)",  DANGER]
          ].map(([k,v,c], i) => (
            <div key={i} className="flex items-baseline justify-between gap-2">
              <span className="whitespace-nowrap" style={{ fontSize: 12, color: SUB }}>{k}</span>
              <span className="tabular-nums whitespace-nowrap" style={{ fontSize: 13, fontWeight: 600, color: c }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Data sources</div>
        <div className="space-y-1.5">
          <SourceLine name="Barclays"        last="8 min ago"  kind="bank" n={3}/>
          <SourceLine name="Monzo"           last="8 min ago"  kind="bank" n={1}/>
          <SourceLine name="Halifax"         last="1 day ago"  kind="bank" n={1}/>
          <SourceLine name="NHS Pensions"    last="Pending"    kind="pending" n={0}/>
          <SourceLine name="HMRC"            last="3 days ago" kind="bank" n={1}/>
        </div>
        <button className="mt-3 w-full h-7 rounded-md text-[11.5px] font-medium inline-flex items-center justify-center gap-1.5 bg-white"
                style={{ border: `1px solid ${LINE}`, color: INK }}>
          <Plus size={11}/> Connect another account
        </button>
      </div>

      <div className="p-4 flex-1">
        <div className="label-xs mb-2" style={{ color: MUTE }}>What needs your attention</div>
        <AttentionItem title="NHS CETV figure" sub="Awaiting provider response" />
        <AttentionItem title="Property valuation" sub="Currently a self-estimate" />
        <AttentionItem title="Recent payslip" sub="Needed for finalisation" />
      </div>
    </div>
  );
}

function SourceLine({ name, last, kind, n }) {
  const pending = kind === "pending";
  return (
    <div className="flex items-center gap-1.5 min-w-0">
      <span className="inline-block w-1.5 h-1.5 rounded-full flex-shrink-0"
            style={{ background: pending ? "#E5B048" : ACCENT }}/>
      <span className="whitespace-nowrap flex-shrink-0" style={{ fontSize: 12, color: INK, fontWeight: 500 }}>{name}</span>
      {n > 0 && <span className="tabular-nums whitespace-nowrap flex-shrink-0" style={{ fontSize: 10.5, color: MUTE }}>· {n} {n === 1 ? "acct" : "accts"}</span>}
      <span className="flex-1"/>
      <span className="whitespace-nowrap flex-shrink-0" style={{ fontSize: 10.5, color: pending ? "#B45309" : MUTE, fontWeight: pending ? 600 : 400 }}>{last}</span>
    </div>
  );
}

function AttentionItem({ title, sub }) {
  return (
    <button className="w-full flex items-start gap-2 py-2 text-left rounded-md px-1 hover:bg-[#F1F1F0]"
            style={{ borderBottom: `1px dashed ${LINE}` }}>
      <span className="inline-flex items-center justify-center rounded-full flex-shrink-0 mt-0.5"
            style={{ width: 14, height: 14, background: "#FEF7E7",
                     color: "#92620A", fontSize: 10, fontWeight: 700 }}>!</span>
      <div className="flex-1 min-w-0">
        <div style={{ fontSize: 12.5, fontWeight: 500, color: INK }}>{title}</div>
        <div style={{ fontSize: 11, color: MUTE, lineHeight: 1.4, marginTop: 1 }}>{sub}</div>
      </div>
    </button>
  );
}

/* ============================================================
   SHARE MODAL
   ============================================================ */
function ShareModal({ onClose }) {
  const [message, setMessage] = useState(
    "Hi Mark — this is my side of the financial picture. Nothing here is a proposal yet; it's just my numbers so we've got a shared starting point. Have a look when you can."
  );
  const [allowComments, setAllowComments] = useState(true);
  const [notifyOnChanges, setNotifyOnChanges] = useState(true);

  useEffect(() => {
    const h = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [onClose]);

  return (
    <div className="absolute inset-0 flex items-center justify-center z-50"
         style={{ background: "rgba(15, 18, 22, 0.45)" }}
         onClick={onClose}>
      <div onClick={e => e.stopPropagation()}
           className="bg-white rounded-xl overflow-hidden flex flex-col"
           style={{ width: 540, maxHeight: "90%", boxShadow: "0 24px 48px rgba(0,0,0,0.22)" }}>
        {/* Header */}
        <div className="px-6 pt-5 pb-3 flex items-start gap-3" style={{ borderBottom: `1px solid ${LINE}` }}>
          <div className="flex-1">
            <div style={{ fontSize: 17, fontWeight: 600, color: INK }}>Share with Mark</div>
            <div style={{ fontSize: 12.5, color: SUB, marginTop: 2, lineHeight: 1.5 }}>
              Mark will see a private copy of your picture. He can't edit yours — only add comments and share his own picture back.
            </div>
          </div>
          <button onClick={onClose} className="w-7 h-7 rounded-md hover:bg-[#F3F4F6] flex items-center justify-center">
            <XIcon size={14}/>
          </button>
        </div>

        <div className="px-6 py-5 overflow-y-auto nice-scroll" style={{ background: "#FAFAFA" }}>
          {/* Recipient card */}
          <div className="bg-white rounded-lg p-3 flex items-center gap-3"
               style={{ border: `1px solid ${LINE}` }}>
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-white font-semibold"
                 style={{ background: "#7E5A4E", fontSize: 13 }}>M</div>
            <div className="flex-1">
              <div style={{ fontSize: 13.5, fontWeight: 600, color: INK }}>Mark Bennett</div>
              <div style={{ fontSize: 12, color: SUB }}>mark.bennett@gmail.com · invited 4 days ago</div>
            </div>
            <span className="chip" style={{ background: "#F1ECFA", color: "#5A3EB8" }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#5A3EB8" }}/>
              Pending
            </span>
          </div>

          {/* Message */}
          <div className="mt-4">
            <label className="label-xs block mb-1.5" style={{ color: MUTE }}>Message to Mark (optional)</label>
            <textarea value={message} onChange={e => setMessage(e.target.value)}
              rows={4}
              className="w-full rounded-lg px-3 py-2.5 bg-white resize-none"
              style={{
                fontSize: 13, lineHeight: 1.55, color: INK,
                border: `1px solid ${LINE}`,
                fontFamily: "inherit"
              }}/>
          </div>

          {/* Permissions */}
          <div className="mt-4">
            <div className="label-xs mb-2" style={{ color: MUTE }}>What Mark can do</div>
            <div className="bg-white rounded-lg" style={{ border: `1px solid ${LINE}` }}>
              <PermRow label="View every section" locked fixedOn/>
              <PermRow label="Add comments on any section" value={allowComments} onChange={setAllowComments}/>
              <PermRow label="Notify me when Mark comments" value={notifyOnChanges} onChange={setNotifyOnChanges} last/>
            </div>
          </div>

          {/* Snapshot summary */}
          <div className="mt-4 bg-white rounded-lg p-3.5" style={{ border: `1px solid ${LINE}` }}>
            <div className="label-xs mb-2" style={{ color: MUTE }}>Mark will be able to see</div>
            <div className="space-y-1.5">
              {[
                ["9 sections",                  "247 transactions across 12 months"],
                ["£282,240 in assets",          "5 accounts · NHS pension pending"],
                ["£227,680 in debts",           "incl. £220k Halifax mortgage"],
                ["2 items marked as gaps",      "CETV · property valuation"]
              ].map(([k, v], i) => (
                <div key={i} className="flex items-baseline justify-between text-[12.5px]">
                  <span style={{ color: INK, fontWeight: 500 }}>{k}</span>
                  <span style={{ color: MUTE }}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 flex items-start gap-2 text-[11.5px]" style={{ color: SUB, lineHeight: 1.5 }}>
            <Check size={12} style={{ color: ACCENT, marginTop: 2 }} strokeWidth={2.5}/>
            <span>Once shared, this version (<b>v0.8</b>) is locked. Your picture keeps evolving in a new draft; Mark sees both when there's a new version.</span>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 flex items-center justify-between flex-shrink-0"
             style={{ borderTop: `1px solid ${LINE}`, background: "#FFFFFF" }}>
          <button onClick={onClose} className="text-[12.5px] font-medium px-3 h-8 rounded-md"
                  style={{ color: SUB }}>
            Cancel
          </button>
          <div className="flex items-center gap-2">
            <button className="h-8 px-3 rounded-md text-[12.5px] font-medium bg-white"
                    style={{ border: `1px solid ${LINE}`, color: INK }}>
              Preview as Mark
            </button>
            <button className="h-8 px-3.5 rounded-md text-[12.5px] font-semibold text-white inline-flex items-center gap-1.5"
                    style={{ background: DANGER }}>
              <Share size={12}/> Share now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PermRow({ label, value, onChange, locked, fixedOn, last }) {
  return (
    <div className="flex items-center justify-between px-3 py-2.5"
         style={{ borderBottom: last ? "none" : `1px solid ${LINE}` }}>
      <span style={{ fontSize: 13, color: locked ? SUB : INK }}>{label}</span>
      {locked ? (
        <span className="text-[11px] font-medium" style={{ color: MUTE }}>
          {fixedOn ? "Always on" : "Off"}
        </span>
      ) : (
        <Toggle on={value} onChange={onChange}/>
      )}
    </div>
  );
}
function Toggle({ on, onChange }) {
  return (
    <button onClick={() => onChange(!on)}
            className="relative rounded-full transition"
            style={{
              width: 30, height: 18,
              background: on ? ACCENT : "#D4D4D3"
            }}>
      <span className="absolute rounded-full bg-white transition" style={{
        width: 14, height: 14, top: 2, left: on ? 14 : 2,
        boxShadow: "0 1px 2px rgba(0,0,0,0.2)"
      }}/>
    </button>
  );
}

/* ============================================================
   APP
   ============================================================ */
function App() {
  const [mode, setMode] = useState(() => localStorage.getItem("picture_mode") || "edit");
  const [active, setActive] = useState(1);
  const [shareOpen, setShareOpen] = useState(false);
  useEffect(() => { localStorage.setItem("picture_mode", mode); }, [mode]);

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: "#F5F5F4" }}>
      <TopBar mode={mode} setMode={setMode} onShare={() => setShareOpen(true)}/>
      <div className="flex-1 flex min-h-0 relative">
        <Rail active={active} setActive={setActive}/>
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFFFFF" }}>
          <PictureDoc editMode={mode === "edit"}/>
        </div>
        <RightRail/>
        {shareOpen && <ShareModal onClose={() => setShareOpen(false)}/>}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
