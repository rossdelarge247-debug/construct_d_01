/* RAIL FAMILY — 4 variations
   R1: Current (persistent rail + always-on right column)
   R2: Collapsible right column
   R3: Split rail (doc nav top, chapters bottom)
   R4: Icon-only compressed state
*/
(function(){
const { useState, useEffect } = React;
const { MenuIcon, XIcon, ChevronRight, ChevronLeft, ChevronDown, MessageSquare, Check, Share, Edit,
        History, Plus, FileText, Home, Compass, Lock, Settings, LifeBuoy, Users, Dot, PanelRight,
        Wordmark, STATES, ASSETS, COMMENT_THREAD, ACTIVITY } = window;

/* ---- shared buttons ---- */
function Ghost({ children, icon }) {
  return (
    <button className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium bg-white hover:bg-[#FAFAF9]"
            style={{ borderColor: "#E5E7EB", color: "#1A1A1A" }}>
      {icon}<span>{children}</span>
    </button>
  );
}
function Primary({ children, icon }) {
  return (
    <button className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-medium text-white"
            style={{ background: "#E5484D" }}>
      {icon}<span>{children}</span>
    </button>
  );
}
function TopControls({ state }) {
  if (state === "A") return <Ghost icon={<Check size={13}/>}>Save & continue later</Ghost>;
  if (state === "B") return <><Ghost icon={<Edit size={13}/>}>Edit</Ghost><Primary icon={<Share size={13}/>}>Share with Mark</Primary></>;
  return <><Ghost icon={<History size={13}/>}>Version history <ChevronDown size={11}/></Ghost><Ghost icon={<Plus size={13}/>}>Add comment</Ghost></>;
}
function Breadcrumb({ state }) {
  const s = STATES[state];
  return (
    <div className="flex items-center gap-1.5 text-[12.5px]" style={{ color: "#6B7280" }}>
      <span>The document</span>
      <ChevronRight size={12} style={{ color: "#D4D4D4" }}/>
      <span style={{ color: "#1A1A1A", fontWeight: 600 }}>{s.title}</span>
      <span className="chip ml-1.5" style={{ background: s.chipBg, color: s.chipFg }}>
        {s.version} · {s.status}
      </span>
    </div>
  );
}
function Avatar() {
  return (
    <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold"
         style={{ background: "#2F6D5F" }}>SJ</div>
  );
}

/* ---- shared doc body ---- */
function DocBody({ state }) {
  const s = STATES[state];
  return (
    <div className="max-w-[620px] mx-auto px-8 py-10">
      <div className="label-xs mb-2" style={{ color: "#9CA3AF" }}>{s.phase}</div>
      <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.2 }}>
        {state === "A" && "Let's finish your picture, Sarah."}
        {state === "B" && "Your picture is ready."}
        {state === "C" && "Mark replied to your proposal."}
      </h1>
      <p className="mt-2" style={{ fontSize: 14.5, color: "#6B7280", lineHeight: 1.55 }}>
        {state === "A" && "Four sections left. Everything saves as you go."}
        {state === "B" && "Sharing creates a private copy for Mark."}
        {state === "C" && "Two items still need your response."}
      </p>
      <div className="mt-7 rounded-xl shadow-card bg-white p-6">
        <div className="label-xs mb-3" style={{ color: "#9CA3AF" }}>Assets & liabilities</div>
        <div className="space-y-0">
          {ASSETS.map(([l,,v,done], i) => (
            <div key={i} className="flex items-center justify-between py-2.5"
                 style={{ borderBottom: i < ASSETS.length - 1 ? "1px dashed #EDEDEC" : "none" }}>
              <div className="flex items-center gap-2.5">
                <div className="w-3.5 h-3.5 rounded-[3px] flex items-center justify-center"
                     style={{ background: done ? "#2F6D5F" : "#F3F4F6", color: "white" }}>
                  {done && <Check size={10} strokeWidth={3}/>}
                </div>
                <span className="text-[13px]" style={{ color: done ? "#1A1A1A" : "#9CA3AF" }}>{l}</span>
              </div>
              <span className="text-[12.5px] tabular-nums" style={{ color: done ? "#1A1A1A" : "#C4C4C2" }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---- activity column (shared) ---- */
function ActivityColumn({ state, onClose }) {
  return (
    <>
      <div className="px-4 py-3 flex items-center gap-2" style={{ borderBottom: "1px solid #EFEFEF" }}>
        <MessageSquare size={14} style={{ color: "#6B7280" }}/>
        <span className="text-[12.5px] font-semibold">Activity & comments</span>
        <span className="ml-auto text-[10.5px] px-1.5 rounded-full font-semibold"
              style={{ background: "#111", color: "#FFF" }}>
          {state === "C" ? 2 : 0}
        </span>
        {onClose && (
          <button onClick={onClose} className="w-6 h-6 rounded hover:bg-[#F3F4F6] flex items-center justify-center">
            <XIcon size={14}/>
          </button>
        )}
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll px-3 py-3 space-y-2">
        {state === "C" && COMMENT_THREAD.items.map((it, i) => (
          <div key={i} className="bg-white rounded-lg shadow-card p-2.5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[9.5px] font-semibold"
                   style={{ background: it.color }}>{it.initial}</div>
              <div className="text-[12px] font-semibold">{it.who}</div>
              <div className="text-[10.5px]" style={{ color: "#9CA3AF" }}>· {it.time}</div>
            </div>
            <div className="text-[12px] leading-[1.55]">{it.text}</div>
            <div className="label-xs mt-1.5" style={{ color: "#9CA3AF" }}>{COMMENT_THREAD.target}</div>
          </div>
        ))}
        {ACTIVITY[state].map(([text, time], i) => (
          <div key={i} className="flex items-start gap-2 px-1 py-1">
            <div className="mt-1.5 w-1 h-1 rounded-full flex-shrink-0" style={{ background: "#D1D5DB" }}/>
            <div className="flex-1">
              <div className="text-[12px]">{text}</div>
              <div className="text-[10.5px] mt-0.5" style={{ color: "#9CA3AF" }}>{time}</div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

/* ---- RAIL ITEM primitives ---- */
function RailSection({ label, children }) {
  return (
    <div className="mb-4">
      {label && <div className="label-xs px-2 mb-1" style={{ color: "#9CA3AF" }}>{label}</div>}
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}
function RailItem({ icon, children, active, right, muted, onClick }) {
  return (
    <button onClick={onClick}
            className="w-full flex items-center gap-2 pl-2 pr-2 py-1.5 rounded-md text-left transition"
            style={{
              background: active ? "#EEF1F0" : "transparent",
              color: muted ? "#9CA3AF" : "#1A1A1A",
              fontWeight: active ? 600 : 500,
              fontSize: 12.5
            }}
            onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#F1F1F0"; }}
            onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      {icon && <span style={{ color: muted ? "#D1D5DB" : (active ? "#1A1A1A" : "#6B7280") }}>{icon}</span>}
      <span className="truncate flex-1">{children}</span>
      {right}
    </button>
  );
}
function IconRailItem({ icon, label, active, badge, onClick }) {
  return (
    <button onClick={onClick}
            title={label}
            className="w-9 h-9 mx-auto rounded-md flex items-center justify-center transition relative"
            style={{
              background: active ? "#EEF1F0" : "transparent",
              color: active ? "#111" : "#6B7280"
            }}
            onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#F4F4F2"; }}
            onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      {icon}
      {badge && (
        <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full" style={{ background: "#2F6D5F" }}/>
      )}
    </button>
  );
}

/* ===================================================== */
/*  R1 — Current: persistent rail + always-on right      */
/* ===================================================== */
function Rail_R1({ state }) {
  return (
    <div className="flex flex-col h-full bg-white">
      <TopBarStd state={state}/>
      <div className="flex-1 flex min-h-0">
        <FullRail state={state} width={220}/>
        <div className="flex-1 overflow-y-auto nice-scroll"><DocBody state={state}/></div>
        <div style={{ width: 320, background: "#FAFAFA", borderLeft: "1px solid #EFEFEF" }} className="flex flex-col">
          <ActivityColumn state={state}/>
        </div>
      </div>
    </div>
  );
}

/* ===================================================== */
/*  R2 — Collapsible right column                        */
/* ===================================================== */
function Rail_R2({ state }) {
  const [open, setOpen] = useState(state === "C");
  useEffect(() => { setOpen(state === "C"); }, [state]);
  return (
    <div className="flex flex-col h-full bg-white">
      <TopBarStd state={state} rightExtra={
        <button onClick={() => setOpen(o => !o)}
                className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium transition"
                style={{
                  borderColor: open ? "#111" : "#E5E7EB",
                  background: open ? "#111" : "#FFF",
                  color: open ? "#FFF" : "#1A1A1A"
                }}>
          <MessageSquare size={13}/>
          {state === "C" && (
            <span className="inline-flex items-center justify-center rounded-full text-[10px] font-semibold"
                  style={{ minWidth: 14, height: 14, padding: "0 4px",
                           background: open ? "#FFF" : "#E5484D",
                           color: open ? "#111" : "#FFF" }}>2</span>
          )}
        </button>
      }/>
      <div className="flex-1 flex min-h-0">
        <FullRail state={state} width={220}/>
        <div className="flex-1 overflow-y-auto nice-scroll"><DocBody state={state}/></div>
        <div style={{
          width: open ? 320 : 0,
          background: "#FAFAFA",
          borderLeft: open ? "1px solid #EFEFEF" : "none",
          transition: "width 220ms cubic-bezier(.2,.8,.2,1)",
          overflow: "hidden"
        }} className="flex flex-col flex-shrink-0">
          <div style={{ width: 320, height: "100%" }} className="flex flex-col">
            <ActivityColumn state={state} onClose={() => setOpen(false)}/>
          </div>
        </div>
      </div>
      {/* Floating tab when closed */}
      {!open && (
        <button onClick={() => setOpen(true)}
                className="absolute right-0 top-1/2 -translate-y-1/2 flex items-center gap-1.5 pr-2 pl-2 py-3 rounded-l-lg bg-white"
                style={{
                  border: "1px solid #EFEFEF", borderRight: "none",
                  boxShadow: "-2px 4px 14px rgba(0,0,0,0.05)",
                  writingMode: "vertical-rl", fontSize: 11.5, fontWeight: 500
                }}>
          <MessageSquare size={13}/>
          Activity & comments
          {state === "C" && <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#E5484D" }}/>}
        </button>
      )}
    </div>
  );
}

/* ===================================================== */
/*  R3 — Split rail (doc nav top · chapters bottom)      */
/* ===================================================== */
function Rail_R3({ state }) {
  return (
    <div className="flex flex-col h-full bg-white">
      <TopBarStd state={state}/>
      <div className="flex-1 flex min-h-0">
        <div style={{ width: 240, background: "#FAFAFA", borderRight: "1px solid #EFEFEF" }}
             className="flex flex-col">
          {/* TOP: document-level nav */}
          <div className="px-3 py-3" style={{ borderBottom: "1px solid #EFEFEF" }}>
            <div className="label-xs px-2 mb-1.5 flex items-center gap-1.5" style={{ color: "#9CA3AF" }}>
              <FileText size={11}/> Document
            </div>
            <div className="space-y-0.5">
              <RailItem icon={<Compass size={14}/>} active>Overview</RailItem>
              <RailItem icon={<Home size={14}/>}>Household</RailItem>
              <RailItem icon={<FileText size={14}/>}>Settlement</RailItem>
            </div>
          </div>

          {/* BOTTOM: chapters with progress */}
          <div className="flex-1 overflow-y-auto nice-scroll px-3 py-3">
            <div className="label-xs px-2 mb-1.5 flex items-center gap-1.5" style={{ color: "#9CA3AF" }}>
              <Dot size={11}/> Chapters
            </div>
            <div className="space-y-2">
              <ChapterRow title="My picture" pct={80} active/>
              <ChapterRow title="Children"   pct={40}/>
              <ChapterRow title="Housing"    pct={60}/>
              <ChapterRow title="Future needs" pct={15}/>
            </div>
            <div className="label-xs px-2 mt-5 mb-1.5" style={{ color: "#9CA3AF" }}>Shared</div>
            <RailItem
              icon={<div className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-semibold" style={{ background: "#E7E5E4", color: "#6B7280" }}>M</div>}
              right={<span className="text-[10px]" style={{ color: "#9CA3AF" }}>Invited</span>}
              muted>Mark</RailItem>
          </div>
          <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
               style={{ color: "#6B7280", borderTop: "1px solid #EFEFEF" }}>
            <LifeBuoy size={12}/> Get support
          </div>
        </div>
        <div className="flex-1 overflow-y-auto nice-scroll"><DocBody state={state}/></div>
        <div style={{ width: 300, background: "#FAFAFA", borderLeft: "1px solid #EFEFEF" }} className="flex flex-col">
          <ActivityColumn state={state}/>
        </div>
      </div>
    </div>
  );
}
function ChapterRow({ title, pct, active }) {
  return (
    <button className="w-full text-left rounded-md px-2 py-1.5 transition"
            style={{ background: active ? "#EEF1F0" : "transparent" }}
            onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#F1F1F0"; }}
            onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      <div className="flex items-center justify-between">
        <span className="text-[12.5px]" style={{ fontWeight: active ? 600 : 500, color: "#1A1A1A" }}>{title}</span>
        <span className="text-[10.5px] tabular-nums" style={{ color: pct >= 80 ? "#2F6D5F" : "#9CA3AF", fontWeight: 600 }}>{pct}%</span>
      </div>
      <div className="mt-1 h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
        <div className="h-full rounded-full" style={{ width: pct + "%", background: pct >= 80 ? "#2F6D5F" : "#9CA3AF" }}/>
      </div>
    </button>
  );
}

/* ===================================================== */
/*  R4 — Icon-only compressed rail                        */
/* ===================================================== */
function Rail_R4({ state }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="flex flex-col h-full bg-white">
      <TopBarStd state={state}/>
      <div className="flex-1 flex min-h-0">
        <div
          onMouseEnter={() => setExpanded(true)}
          onMouseLeave={() => setExpanded(false)}
          style={{
            width: expanded ? 220 : 56,
            background: "#FAFAFA",
            borderRight: "1px solid #EFEFEF",
            transition: "width 200ms cubic-bezier(.2,.8,.2,1)"
          }}
          className="flex flex-col overflow-hidden">
          {expanded ? (
            <FullRailInner/>
          ) : (
            <div className="flex-1 flex flex-col py-3 gap-0.5">
              <IconRailItem icon={<Compass size={17}/>}  label="Overview" active/>
              <IconRailItem icon={<Home size={17}/>}     label="Household"/>
              <IconRailItem icon={<FileText size={17}/>} label="Settlement"/>
              <div className="my-2 mx-3 h-px" style={{ background: "#EFEFEF" }}/>
              <IconRailItem icon={<div className="text-[10px] font-semibold tabular-nums" style={{ color: "#2F6D5F" }}>80%</div>} label="My picture" badge/>
              <IconRailItem icon={<Users size={17}/>}    label="Children"/>
              <IconRailItem icon={<Home size={17}/>}     label="Housing"/>
              <IconRailItem icon={<Compass size={17}/>}  label="Future needs"/>
              <div className="flex-1"/>
              <IconRailItem icon={<Settings size={17}/>} label="Settings"/>
              <IconRailItem icon={<LifeBuoy size={17}/>} label="Support"/>
            </div>
          )}
        </div>
        <div className="flex-1 overflow-y-auto nice-scroll"><DocBody state={state}/></div>
        <div style={{ width: 300, background: "#FAFAFA", borderLeft: "1px solid #EFEFEF" }} className="flex flex-col">
          <ActivityColumn state={state}/>
        </div>
      </div>
    </div>
  );
}

/* ---- top bar (shared by all Rail variations) ---- */
function TopBarStd({ state, rightExtra }) {
  return (
    <div className="flex items-center justify-between px-5"
         style={{ height: 52, borderBottom: "1px solid #EFEFEF", background: "#FFFFFF" }}>
      <div className="flex items-center gap-3">
        <Wordmark small/>
        <span style={{ color: "#E5E7EB" }}>/</span>
        <Breadcrumb state={state}/>
      </div>
      <div className="flex items-center gap-2">
        <TopControls state={state}/>
        {rightExtra}
        <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
        <Avatar/>
      </div>
    </div>
  );
}

/* ---- full rail content (shared) ---- */
function FullRailInner() {
  return (
    <div className="flex-1 overflow-y-auto nice-scroll px-3 py-3">
      <RailSection label="The document">
        <RailItem icon={<Compass size={14}/>} active>Overview</RailItem>
        <RailItem icon={<Home size={14}/>}>Household</RailItem>
        <RailItem icon={<FileText size={14}/>}>Settlement</RailItem>
      </RailSection>
      <RailSection label="Working on">
        <RailItem right={<span className="text-[10.5px] tabular-nums font-semibold" style={{ color: "#2F6D5F" }}>80%</span>}>My picture</RailItem>
        <RailItem right={<span className="text-[10.5px] tabular-nums" style={{ color: "#9CA3AF" }}>—</span>}>Children</RailItem>
        <RailItem right={<span className="text-[10.5px] tabular-nums" style={{ color: "#9CA3AF" }}>—</span>}>Housing</RailItem>
        <RailItem right={<span className="text-[10.5px] tabular-nums" style={{ color: "#9CA3AF" }}>—</span>}>Future needs</RailItem>
      </RailSection>
      <RailSection label="Shared">
        <RailItem
          icon={<div className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-semibold" style={{ background: "#E7E5E4", color: "#6B7280" }}>M</div>}
          right={<span className="text-[10px]" style={{ color: "#9CA3AF" }}>Invited</span>}
          muted>Mark</RailItem>
      </RailSection>
    </div>
  );
}
function FullRail({ state, width = 220 }) {
  return (
    <div style={{ width, background: "#FAFAFA", borderRight: "1px solid #EFEFEF" }}
         className="flex flex-col">
      <FullRailInner/>
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
           style={{ color: "#6B7280", borderTop: "1px solid #EFEFEF" }}>
        <LifeBuoy size={12}/> Get support
      </div>
    </div>
  );
}

Object.assign(window, { Rail_R1, Rail_R2, Rail_R3, Rail_R4 });
})();
