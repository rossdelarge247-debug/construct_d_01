/* NOTEBOOK FAMILY — 4 variations in cool newsprint palette
   N1: Current structure (editable title, margin notes, paper card) — newsprint recolor
   N2: Two-column editorial (document + running commentary)
   N3: Full-bleed page with footnotes
   N4: Chapter-based navigation (table of contents)
*/
(function(){
const { useState, useEffect } = React;
const { MenuIcon, XIcon, ChevronRight, ChevronDown, MessageSquare, Check, Share, Edit,
        History, Plus, FileText, Home, Compass, Lock, Settings, LifeBuoy, BookOpen,
        Wordmark, STATES, ASSETS, COMMENT_THREAD, ACTIVITY } = window;

/* Palette: newsprint
   paper: #F7F7F5
   card:  #FFFFFF
   line:  #E4E4E0
   ink:   #15171A (charcoal)
   sub:   #5B5E63
   mute:  #9AA0A6
   accent: #15171A (black ink) + #7A8893 (cool steel)
*/
const INK = "#15171A", SUB = "#5B5E63", MUTE = "#9AA0A6", LINE = "#E4E4E0", PAPER = "#F7F7F5";

function SerifFont(extra = {}) {
  return { fontFamily: "'Fraunces', 'Times New Roman', Georgia, serif", color: INK, ...extra };
}

function Controls({ state, dark }) {
  const ghost = "inline-flex items-center gap-1.5 h-8 px-3 text-[12.5px] font-medium transition rounded-sm";
  if (state === "A") return (
    <button className={ghost + " hover:bg-white"} style={{ border: `1px solid ${LINE}`, color: INK, background: "transparent" }}>
      <Check size={13}/> Save & continue
    </button>
  );
  if (state === "B") return (<>
    <button className={ghost + " hover:bg-white"} style={{ border: `1px solid ${LINE}`, color: INK, background: "transparent" }}>
      <Edit size={13}/> Edit
    </button>
    <button className={ghost} style={{ background: INK, color: PAPER, fontWeight: 600 }}>
      <Share size={13}/> Share with Mark
    </button>
  </>);
  return (<>
    <button className={ghost + " hover:bg-white"} style={{ border: `1px solid ${LINE}`, color: INK, background: "transparent" }}>
      <History size={13}/> Earlier drafts
    </button>
    <button className={ghost + " hover:bg-white"} style={{ border: `1px solid ${LINE}`, color: INK, background: "transparent" }}>
      <Plus size={13}/> Note
    </button>
  </>);
}

function Avatar() {
  return (
    <div className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-semibold"
         style={{ background: INK, color: PAPER, fontFamily: "'Inter', sans-serif" }}>SJ</div>
  );
}

function VersionStamp({ state }) {
  const s = STATES[state];
  return (
    <span style={{
      fontSize: 10.5,
      fontFamily: "'JetBrains Mono', ui-monospace, monospace",
      color: INK,
      border: `1.25px solid ${INK}`,
      padding: "2px 7px",
      textTransform: "uppercase",
      letterSpacing: "0.08em",
      fontWeight: 600
    }}>
      {s.version} · {s.status}
    </span>
  );
}

function EditableTitle({ state }) {
  const s = STATES[state];
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(s.title);
  useEffect(() => setText(s.title), [state]);
  return (
    <div className="flex items-center gap-2.5">
      {editing ? (
        <input autoFocus value={text} onChange={e => setText(e.target.value)}
               onBlur={() => setEditing(false)}
               onKeyDown={e => { if (e.key === "Enter") setEditing(false); }}
               className="text-center outline-none bg-transparent"
               style={{ ...SerifFont(), fontSize: 18, fontWeight: 500, fontStyle: "italic",
                        borderBottom: `1px solid ${MUTE}`, minWidth: 220 }}/>
      ) : (
        <button onClick={() => setEditing(true)}
                className="flex items-center gap-2 px-2 py-1 hover:bg-white rounded-sm">
          <span style={{ ...SerifFont(), fontSize: 18, fontWeight: 500, fontStyle: "italic" }}>{text}</span>
          <Edit size={11} style={{ color: MUTE }}/>
        </button>
      )}
      <span style={{ color: MUTE }}>·</span>
      <VersionStamp state={state}/>
    </div>
  );
}

/* ---- Hand-drawn ink underline ---- */
function InkUnderline({ width = 180 }) {
  return (
    <svg width={width} height="8" viewBox={`0 0 ${width} 8`} className="mt-1">
      <path d={`M 2 5 Q ${width*0.35} 2, ${width*0.6} 5 T ${width - 2} 4`} stroke={INK} strokeWidth="1.4" fill="none" strokeLinecap="round" opacity="0.8"/>
    </svg>
  );
}

/* ---- Display headline (serif) ---- */
function Headline({ state, size = 36 }) {
  return (
    <h1 style={{ ...SerifFont(), fontSize: size, fontWeight: 400, lineHeight: 1.12, letterSpacing: "-0.015em", textWrap: "pretty" }}>
      {state === "A" && <><em style={{ fontStyle: "italic", fontWeight: 400 }}>Let's finish</em> your picture, Sarah.</>}
      {state === "B" && <>Your picture is <em style={{ fontStyle: "italic", fontWeight: 400 }}>ready</em>.</>}
      {state === "C" && <>Mark <em style={{ fontStyle: "italic", fontWeight: 400 }}>replied</em> to your proposal.</>}
    </h1>
  );
}
function Dek({ state }) {
  return (
    <p style={{ ...SerifFont({ color: SUB }), fontSize: 16.5, lineHeight: 1.65, maxWidth: 580 }}>
      {state === "A" && "Four sections remain. Take your time. Nothing you write here is shared with Mark until you decide."}
      {state === "B" && "You've captured what matters. When you're ready, sharing opens a private mirror for Mark to fill his side of the picture."}
      {state === "C" && "Two items still need your thoughts. You may accept, counter, or leave a note to return to later."}
    </p>
  );
}

/* ---- Asset ledger, serif style ---- */
function Ledger({ showFootnoteMarks = false }) {
  return (
    <div>
      <div className="label-xs mb-3" style={{ color: MUTE, fontFamily: "'Inter', sans-serif" }}>Assets & liabilities</div>
      <div className="space-y-0">
        {ASSETS.map(([l,,v,done], i) => (
          <div key={i} className="flex items-baseline gap-3 py-2" style={{ borderBottom: i < ASSETS.length - 1 ? `1px dotted ${LINE}` : "none" }}>
            <span style={{ ...SerifFont(), fontSize: 14, fontWeight: done ? 500 : 400, color: done ? INK : MUTE }}>
              {done ? "✓" : "○"}
            </span>
            <span style={{ ...SerifFont(), fontSize: 15, fontWeight: done ? 500 : 400, color: done ? INK : MUTE, flex: 1 }}>
              {l}
              {showFootnoteMarks && i === 1 && <sup style={{ fontSize: 10, color: INK, fontWeight: 600, marginLeft: 3 }}>¹</sup>}
              {showFootnoteMarks && i === 3 && <sup style={{ fontSize: 10, color: INK, fontWeight: 600, marginLeft: 3 }}>²</sup>}
            </span>
            <span style={{ fontSize: 14, fontFamily: "'JetBrains Mono', monospace", color: done ? INK : MUTE }}>{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ===================================================== */
/*  N1 — Current structure, newsprint palette            */
/* ===================================================== */
function Notebook_N1({ state }) {
  const [navOpen, setNavOpen] = useState(false);
  return (
    <div className="flex flex-col" style={{ height: "100%", background: PAPER, color: INK }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-5" style={{ height: 56, borderBottom: `1px solid ${LINE}` }}>
        <div className="flex items-center gap-3">
          <button onClick={() => setNavOpen(o => !o)} className="w-8 h-8 rounded-sm hover:bg-white flex items-center justify-center">
            <MenuIcon size={17} stroke={INK}/>
          </button>
          <Wordmark small serif/>
        </div>
        <div className="absolute left-1/2 -translate-x-1/2"><EditableTitle state={state}/></div>
        <div className="flex items-center gap-2">
          <Controls state={state}/>
          <div className="w-px h-6 mx-1" style={{ background: LINE }}/>
          <Avatar/>
        </div>
      </div>

      <div className="flex-1 flex min-h-0 relative">
        {navOpen && <NotebookDrawer onClose={() => setNavOpen(false)}/>}

        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[720px] mx-auto px-12 py-10">
            <div className="label-xs mb-1" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Chapter · {STATES[state].phase}</div>
            <Headline state={state}/>
            <InkUnderline/>
            <div className="mt-5"><Dek state={state}/></div>

            {/* Paper card */}
            <div className="mt-8 p-8 relative"
                 style={{ background: "#FFFFFF", border: `1px solid ${LINE}`, boxShadow: "0 1px 0 #EAEAE6", borderRadius: 2 }}>
              <div className="absolute top-4 bottom-4" style={{ left: 52, width: 1, background: "#CAD1D8", opacity: 0.45 }}/>
              <div className="pl-10">
                <div className="text-[12.5px] italic mb-3" style={{ ...SerifFont({ color: SUB }) }}>
                  Dated {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
                </div>
                <Ledger/>
                <p className="mt-4" style={{ ...SerifFont({ color: SUB }), fontSize: 14, lineHeight: 1.7, fontStyle: "italic" }}>
                  Still to gather — statement from Vanguard, confirmation letter for the joint savings.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right margin notes */}
        <div style={{ width: 260, borderLeft: `1px dashed ${LINE}`, background: PAPER }}
             className="flex flex-col py-6 px-5 overflow-y-auto nice-scroll">
          <div className="label-xs mb-3" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Margin notes</div>
          {state === "C" ? (
            <>
              {COMMENT_THREAD.items.map((it, i) => (
                <MarginNote key={i} who={it.who} time={it.time} tilt={i === 0 ? -1 : 1.2}>
                  {it.text}
                </MarginNote>
              ))}
              <div className="mt-2 label-xs" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Earlier</div>
              <div className="mt-2 text-[12px] italic" style={{ ...SerifFont({ color: SUB }) }}>
                Sarah proposed v2.1 yesterday.<br/>Mark accepted 6 of 8 clauses in Children.
              </div>
            </>
          ) : state === "B" ? (
            <MarginNote who="You" time="just now" tilt={-0.5}>Picture marked <em>Ready</em>. Nothing is shared until you press Share.</MarginNote>
          ) : (
            <MarginNote who="Guide" time="" tilt={-0.8}>Your picture is a <em>private draft</em>. Only you can see it until you're ready.</MarginNote>
          )}
        </div>
      </div>
    </div>
  );
}

function MarginNote({ who, time, tilt = 0, children }) {
  return (
    <div className="mb-3 p-3" style={{
      background: "#FFFFFF", border: `1px solid ${LINE}`, borderRadius: 2,
      boxShadow: "0 2px 6px rgba(21,23,26,0.05)", transform: `rotate(${tilt}deg)`
    }}>
      <div className="flex items-baseline gap-2 mb-1">
        <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-semibold"
             style={{ background: INK, color: PAPER, fontFamily: "'Inter', sans-serif" }}>{who[0]}</div>
        <span style={{ fontSize: 12, fontWeight: 600, fontFamily: "'Inter', sans-serif" }}>{who}</span>
        {time && <span className="text-[10.5px] italic" style={{ ...SerifFont({ color: SUB }) }}>· {time}</span>}
      </div>
      <div style={{ ...SerifFont(), fontSize: 13.5, lineHeight: 1.55 }}>{children}</div>
    </div>
  );
}

function NotebookDrawer({ onClose }) {
  return (
    <div className="absolute inset-0 z-30 flex">
      <div onClick={onClose} className="absolute inset-0" style={{ background: "rgba(21,23,26,0.14)" }}/>
      <aside className="relative z-10 flex flex-col"
             style={{ width: 280, background: PAPER, borderRight: `1px solid ${LINE}` }}>
        <div className="flex items-center justify-between px-4 py-3">
          <Wordmark small serif/>
          <button onClick={onClose} className="w-7 h-7 rounded-sm hover:bg-white flex items-center justify-center">
            <XIcon size={15} stroke={INK}/>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto nice-scroll px-3 pb-3">
          <DrawerSection label="The document">
            <DrawerItem>Overview</DrawerItem>
            <DrawerItem>Household</DrawerItem>
            <DrawerItem>Settlement</DrawerItem>
          </DrawerSection>
          <DrawerSection label="Chapters">
            <DrawerItem right="80">My picture</DrawerItem>
            <DrawerItem>Children</DrawerItem>
            <DrawerItem>Housing</DrawerItem>
            <DrawerItem>Future needs</DrawerItem>
          </DrawerSection>
          <DrawerSection label="Shared">
            <DrawerItem muted>Mark — invited</DrawerItem>
          </DrawerSection>
        </div>
      </aside>
    </div>
  );
}
function DrawerSection({ label, children }) {
  return (
    <div className="mb-4">
      <div className="label-xs px-2 mb-1.5" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>{label}</div>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}
function DrawerItem({ children, right, muted }) {
  return (
    <button className="w-full flex items-baseline gap-2 px-2 py-1.5 rounded-sm text-left"
            style={{ color: muted ? MUTE : INK, fontSize: 14, ...SerifFont({ color: muted ? MUTE : INK }) }}
            onMouseEnter={e => e.currentTarget.style.background = "#FFFFFF"}
            onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
      <span className="flex-1">{children}</span>
      {right && <span style={{ fontSize: 11, color: INK, fontFamily: "'JetBrains Mono', monospace" }}>{right}</span>}
    </button>
  );
}

/* ===================================================== */
/*  N2 — Two-column editorial                            */
/* ===================================================== */
function Notebook_N2({ state }) {
  const [navOpen, setNavOpen] = useState(false);
  return (
    <div className="flex flex-col" style={{ height: "100%", background: PAPER, color: INK }}>
      <div className="flex items-center justify-between px-5" style={{ height: 56, borderBottom: `1px solid ${LINE}` }}>
        <div className="flex items-center gap-3">
          <button onClick={() => setNavOpen(o => !o)} className="w-8 h-8 rounded-sm hover:bg-white flex items-center justify-center">
            <MenuIcon size={17} stroke={INK}/>
          </button>
          <Wordmark small serif/>
        </div>
        <div className="absolute left-1/2 -translate-x-1/2"><EditableTitle state={state}/></div>
        <div className="flex items-center gap-2">
          <Controls state={state}/>
          <div className="w-px h-6 mx-1" style={{ background: LINE }}/>
          <Avatar/>
        </div>
      </div>

      <div className="flex-1 flex min-h-0 relative">
        {navOpen && <NotebookDrawer onClose={() => setNavOpen(false)}/>}

        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[1040px] mx-auto px-10 py-10">
            <div className="label-xs mb-1" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Chapter · {STATES[state].phase}</div>
            <Headline state={state} size={42}/>
            <InkUnderline width={220}/>

            {/* Two-column flow */}
            <div className="mt-8 grid" style={{ gridTemplateColumns: "1fr 320px", gap: 56 }}>
              {/* LEFT: document */}
              <div>
                <Dek state={state}/>
                <div className="mt-8" style={{ columnCount: 1 }}>
                  <p style={{ ...SerifFont(), fontSize: 15.5, lineHeight: 1.75, textIndent: 0 }}>
                    <span style={{ float: "left", fontSize: 52, lineHeight: 0.9, paddingRight: 8, paddingTop: 4, fontWeight: 500 }}>T</span>
                    his picture records everything you and Mark jointly own, owe, and earn, alongside what belongs to each of you alone. It is the foundation for a fair settlement, not the settlement itself.
                  </p>
                </div>
                <div className="mt-8">
                  <Ledger/>
                </div>
              </div>

              {/* RIGHT: running commentary */}
              <div style={{ borderLeft: `1px solid ${LINE}`, paddingLeft: 28 }}>
                <div className="label-xs mb-3" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Running commentary</div>
                <div className="space-y-5">
                  {state === "C" ? COMMENT_THREAD.items.map((it, i) => (
                    <Commentary key={i} who={it.who} time={it.time}>{it.text}</Commentary>
                  )) : (
                    <Commentary who={state === "B" ? "You" : "Guide"} time={state === "B" ? "just now" : ""}>
                      {state === "B"
                        ? <>Picture marked <em>Ready</em>. Nothing is shared until you press Share.</>
                        : <>Your picture is a <em>private draft</em>. Only you can see it until you're ready.</>}
                    </Commentary>
                  )}
                  <div className="label-xs pt-3" style={{ color: SUB, fontFamily: "'Inter', sans-serif", borderTop: `1px solid ${LINE}` }}>Recent activity</div>
                  {ACTIVITY[state].slice(0,3).map(([text, time], i) => (
                    <div key={i} style={{ ...SerifFont({ color: SUB }), fontSize: 13, fontStyle: "italic", lineHeight: 1.6 }}>
                      {text} <span style={{ color: MUTE, fontStyle: "normal", fontSize: 11, fontFamily: "'Inter', sans-serif" }}>· {time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
function Commentary({ who, time, children }) {
  return (
    <div>
      <div className="flex items-baseline gap-2 mb-1">
        <span style={{ fontSize: 11.5, fontWeight: 600, fontFamily: "'Inter', sans-serif", textTransform: "uppercase", letterSpacing: "0.06em" }}>{who}</span>
        {time && <span style={{ fontSize: 11, color: MUTE }}>· {time}</span>}
      </div>
      <div style={{ ...SerifFont(), fontSize: 14, lineHeight: 1.65, fontStyle: "italic" }}>{children}</div>
    </div>
  );
}

/* ===================================================== */
/*  N3 — Full-bleed page with footnotes                  */
/* ===================================================== */
function Notebook_N3({ state }) {
  const [navOpen, setNavOpen] = useState(false);
  return (
    <div className="flex flex-col" style={{ height: "100%", background: PAPER, color: INK }}>
      <div className="flex items-center justify-between px-5" style={{ height: 56, borderBottom: `1px solid ${LINE}` }}>
        <div className="flex items-center gap-3">
          <button onClick={() => setNavOpen(o => !o)} className="w-8 h-8 rounded-sm hover:bg-white flex items-center justify-center">
            <MenuIcon size={17} stroke={INK}/>
          </button>
          <Wordmark small serif/>
        </div>
        <div className="absolute left-1/2 -translate-x-1/2"><EditableTitle state={state}/></div>
        <div className="flex items-center gap-2">
          <Controls state={state}/>
          <div className="w-px h-6 mx-1" style={{ background: LINE }}/>
          <Avatar/>
        </div>
      </div>

      <div className="flex-1 flex min-h-0 relative">
        {navOpen && <NotebookDrawer onClose={() => setNavOpen(false)}/>}

        <div className="flex-1 overflow-y-auto nice-scroll">
          {/* Full-bleed page */}
          <div className="mx-auto py-10 px-14" style={{
            maxWidth: 820, background: "#FFFFFF", minHeight: "calc(100% - 20px)",
            margin: "10px auto", border: `1px solid ${LINE}`, boxShadow: "0 1px 0 #EAEAE6"
          }}>
            {/* Folio */}
            <div className="flex items-baseline justify-between mb-8" style={{ borderBottom: `1px solid ${LINE}`, paddingBottom: 10 }}>
              <span className="label-xs" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>
                Decouple · Private draft
              </span>
              <span className="label-xs" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>
                {STATES[state].phase} · Page 1
              </span>
            </div>

            <div className="label-xs mb-2" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Chapter I</div>
            <Headline state={state} size={40}/>
            <InkUnderline width={200}/>
            <div className="mt-5">
              <Dek state={state}/>
            </div>

            <div className="mt-8">
              <p style={{ ...SerifFont(), fontSize: 15.5, lineHeight: 1.8 }}>
                This picture records what Sarah Johnson owns, owes, and earns as of today. It includes her share of
                joint holdings with Mark — the mortgage on the family home in Harrogate, a small pool of savings,
                and the pensions each has accrued during the marriage. Items noted with a footnote require
                additional documentation before the picture can be considered complete.
              </p>
            </div>

            <h2 className="mt-8" style={{ ...SerifFont(), fontSize: 22, fontWeight: 500 }}>
              § 3. Assets & liabilities
            </h2>
            <div className="mt-3">
              <Ledger showFootnoteMarks/>
            </div>

            <h2 className="mt-8" style={{ ...SerifFont(), fontSize: 22, fontWeight: 500 }}>
              § 4. Income
            </h2>
            <p className="mt-2" style={{ ...SerifFont(), fontSize: 15, lineHeight: 1.75 }}>
              Sarah is employed by Leeds Teaching Hospitals NHS Trust as a consultant haematologist.
              Gross annual salary £104,200, net of pension contributions £78,410.
            </p>

            {/* Footnotes */}
            <div className="mt-14 pt-5" style={{ borderTop: `1px solid ${LINE}` }}>
              <div className="label-xs mb-3" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Footnotes</div>
              <div className="space-y-2.5">
                <Footnote n="1">
                  Halifax mortgage — figure shown is equity after outstanding balance of £142,000.
                  {state === "C" && <em style={{ color: INK }}> Mark has raised a note about the 2018 deposit; see margin.</em>}
                </Footnote>
                <Footnote n="2">
                  Vanguard ISA — awaiting year-end statement (requested 12 April).
                </Footnote>
              </div>
            </div>

            {state === "C" && (
              <div className="mt-10 pt-5" style={{ borderTop: `1px solid ${LINE}` }}>
                <div className="label-xs mb-3" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Marginalia — {COMMENT_THREAD.target}</div>
                <div className="space-y-3">
                  {COMMENT_THREAD.items.map((it, i) => (
                    <div key={i} className="flex gap-3">
                      <div style={{ ...SerifFont(), fontSize: 12.5, fontStyle: "italic", width: 60, flexShrink: 0, color: SUB }}>
                        — {it.who}
                      </div>
                      <div style={{ ...SerifFont(), fontSize: 14, lineHeight: 1.6, flex: 1 }}>{it.text}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
function Footnote({ n, children }) {
  return (
    <div className="flex gap-2" style={{ ...SerifFont({ color: SUB }), fontSize: 12.5, lineHeight: 1.6 }}>
      <span style={{ color: INK, fontWeight: 600 }}>{n}.</span>
      <span>{children}</span>
    </div>
  );
}

/* ===================================================== */
/*  N4 — Chapter-based navigation (TOC)                  */
/* ===================================================== */
function Notebook_N4({ state }) {
  const CHAPTERS = [
    { n: "I",   title: "The household picture",  pages: "1-4",   status: "Complete" },
    { n: "II",  title: "My financial picture",   pages: "5-12",  status: "In draft · 80%", active: true },
    { n: "III", title: "Children",               pages: "13-18", status: "Not started" },
    { n: "IV",  title: "Housing",                pages: "19-22", status: "In draft · 60%" },
    { n: "V",   title: "Future needs",           pages: "23-24", status: "In draft · 15%" },
    { n: "VI",  title: "The settlement",         pages: "25+",   status: "Awaiting Mark" }
  ];
  return (
    <div className="flex flex-col" style={{ height: "100%", background: PAPER, color: INK }}>
      <div className="flex items-center justify-between px-5" style={{ height: 56, borderBottom: `1px solid ${LINE}` }}>
        <div className="flex items-center gap-3">
          <Wordmark small serif/>
        </div>
        <div className="absolute left-1/2 -translate-x-1/2"><EditableTitle state={state}/></div>
        <div className="flex items-center gap-2">
          <Controls state={state}/>
          <div className="w-px h-6 mx-1" style={{ background: LINE }}/>
          <Avatar/>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Left: Table of Contents */}
        <div style={{ width: 320, background: PAPER, borderRight: `1px solid ${LINE}` }} className="flex flex-col">
          <div className="px-7 py-6 flex-1 overflow-y-auto nice-scroll">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen size={15} stroke={INK}/>
              <span style={{ ...SerifFont(), fontSize: 15.5, fontWeight: 500, fontStyle: "italic" }}>Contents</span>
            </div>
            <div className="space-y-1">
              {CHAPTERS.map((c, i) => (
                <button key={i} className="w-full text-left py-2 px-1 transition"
                        onMouseEnter={e => e.currentTarget.style.background = "#FFFFFF"}
                        onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                        style={{ background: c.active ? "#FFFFFF" : "transparent", borderRadius: 2 }}>
                  <div className="flex items-baseline gap-3">
                    <span style={{ ...SerifFont({ color: c.active ? INK : SUB }), fontSize: 11.5, fontWeight: 600, fontFamily: "'JetBrains Mono', monospace", width: 24 }}>
                      {c.n}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div style={{ ...SerifFont(), fontSize: 14, fontWeight: c.active ? 600 : 500, fontStyle: c.active ? "italic" : "normal" }}>
                        {c.title}
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span style={{ fontSize: 11, color: c.status.includes("Complete") ? "#047857" : c.status.includes("80") ? INK : MUTE, fontFamily: "'Inter', sans-serif" }}>
                          {c.status}
                        </span>
                      </div>
                    </div>
                    <span style={{ fontSize: 11, color: MUTE, fontFamily: "'JetBrains Mono', monospace" }}>{c.pages}</span>
                  </div>
                </button>
              ))}
            </div>
            <div className="mt-8 pt-4" style={{ borderTop: `1px solid ${LINE}` }}>
              <div className="label-xs mb-2" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Shared with</div>
              <div className="flex items-center gap-2.5 py-1.5">
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-semibold"
                     style={{ background: "#D1D5DB", color: SUB, fontFamily: "'Inter', sans-serif" }}>M</div>
                <div>
                  <div style={{ ...SerifFont(), fontSize: 13, fontStyle: "italic" }}>Mark</div>
                  <div style={{ fontSize: 11, color: MUTE, fontFamily: "'Inter', sans-serif" }}>
                    {state === "C" ? "2 comments" : "Invited · not joined"}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Middle: reading page */}
        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[640px] mx-auto px-10 py-10">
            <div className="label-xs mb-1" style={{ color: SUB, fontFamily: "'Inter', sans-serif" }}>Chapter II · {STATES[state].phase}</div>
            <Headline state={state}/>
            <InkUnderline/>
            <div className="mt-5"><Dek state={state}/></div>
            <div className="mt-8 p-7" style={{ background: "#FFFFFF", border: `1px solid ${LINE}`, borderRadius: 2 }}>
              <Ledger/>
              <p className="mt-4" style={{ ...SerifFont({ color: SUB }), fontSize: 14, lineHeight: 1.7, fontStyle: "italic" }}>
                Still to gather — statement from Vanguard, confirmation letter for the joint savings.
              </p>
            </div>

            <div className="mt-8 flex items-center justify-between pt-4" style={{ borderTop: `1px solid ${LINE}` }}>
              <button className="flex items-center gap-2 text-[13px]" style={{ ...SerifFont({ color: SUB }), fontStyle: "italic" }}>
                <ChevronRight size={14} style={{ transform: "rotate(180deg)" }}/>
                I · The household picture
              </button>
              <span className="text-[11px]" style={{ color: MUTE, fontFamily: "'JetBrains Mono', monospace" }}>page 7 of 12</span>
              <button className="flex items-center gap-2 text-[13px]" style={{ ...SerifFont(), fontStyle: "italic" }}>
                III · Children
                <ChevronRight size={14}/>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Notebook_N1, Notebook_N2, Notebook_N3, Notebook_N4 });
})();
