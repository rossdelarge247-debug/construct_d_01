/* Household Right Column — 3 tabs: Comments / Activity / Versions */
(function(){
const { useState, useEffect, useRef } = React;
const { WhoChip, ArrowI, CheckI } = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";
const AMBER_INK = "#9A4E0A", BLUE_INK = "#1E4080";
const SARAH = "#2F6D5F", MARK = "#7E5A4E";

const X = (p) => <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></svg>;

/* ============================================================
   Main column shell with tabs
   ============================================================ */
function CollabColumn({ itemStates, setItemStates, activeItemId, activity, onClose, onSelectVersion, selectedVersion }) {
  const [tab, setTab] = useState("comments");
  const commentsRef = useRef(null);

  useEffect(() => {
    if (activeItemId && tab === "comments" && commentsRef.current) {
      const el = commentsRef.current.querySelector(`[data-thread="${activeItemId}"]`);
      if (el) el.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, [activeItemId, tab]);

  return (
    <div className="flex flex-col h-full" style={{ width: 360, background: "#FAFAFA", borderLeft: `1px solid ${LINE}` }}>
      <div className="px-3 pt-3 pb-0 flex items-center gap-2 flex-shrink-0 bg-white" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="flex gap-0.5 flex-1">
          {[
            { k: "comments", label: "Comments", count: 3 },
            { k: "activity", label: "Activity", count: 6 },
            { k: "versions", label: "Versions", count: 6 }
          ].map(t => {
            const on = tab === t.k;
            return (
              <button key={t.k} onClick={() => setTab(t.k)}
                className="flex items-center gap-1.5 px-3 py-2 transition relative"
                style={{ fontSize: 12.5, fontWeight: 600, color: on ? INK : SUB }}>
                {t.label}
                <span className="tabular-nums" style={{ fontSize: 10.5, color: MUTE, fontWeight: 500 }}>{t.count}</span>
                {on && <span className="absolute bottom-0 left-2 right-2" style={{ height: 2, background: INK }}/>}
              </button>
            );
          })}
        </div>
        <button onClick={onClose} className="w-7 h-7 rounded-md hover:bg-[#F3F4F6] flex items-center justify-center">
          <X s={14}/>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto nice-scroll">
        {tab === "comments" && <CommentsTab ref={commentsRef} activeItemId={activeItemId} itemStates={itemStates} setItemStates={setItemStates}/>}
        {tab === "activity" && <ActivityTab/>}
        {tab === "versions" && <VersionsTab selected={selectedVersion} onSelect={onSelectVersion}/>}
      </div>
    </div>
  );
}

/* ============================================================
   COMMENTS TAB
   ============================================================ */
const CommentsTab = React.forwardRef(({ activeItemId, itemStates, setItemStates }, ref) => {
  return (
    <div ref={ref} className="p-3 space-y-3">
      <Thread id="home_value" itemStates={itemStates} setItemStates={setItemStates} active={activeItemId === "home_value"}
        title="Property value — §2 The home" state="contested"
        messages={[
          { who: "Sarah", time: "31 Mar", text: "My estimate — £450,000. Based on Rightmove for similar properties on Oak Road.", attachment: "rightmove-comps.pdf" },
          { who: "Mark",  time: "1 Apr",  text: "I got a recent valuation from Wilkinson Grant at £480,000. Surveyor's note attached." }
        ]}
        resolveOptions={[
          { label: "Resolve at £450,000", value: "£450,000" },
          { label: "Resolve at £465,000 (midpoint)", value: "£465,000", primary: true },
          { label: "Resolve at £480,000", value: "£480,000" }
        ]}
        onResolve={(v) => setItemStates(s => ({ ...s, home_value: { resolved: true, resolvedValue: v } }))}
      />

      <Thread id="joint_barclays" itemStates={itemStates} setItemStates={setItemStates} active={activeItemId === "joint_barclays"}
        title="Joint savings — Barclays" state="contested"
        messages={[
          { who: "Sarah", time: "31 Mar", text: "Statement shows £12,000 as of 31 March.", attachment: "barclays-march.pdf" },
          { who: "Mark",  time: "1 Apr",  text: "The Barclays app showed £8k when I checked. Maybe the £4k difference was the tax bill you mentioned?" },
          { who: "Sarah", time: "2 Apr",  text: "You're right — I moved £4k to HMRC on 2 April. Let's use £8,000." }
        ]}
        resolveOptions={[
          { label: "Resolve at £8,000 (post-tax)", value: "£8,000", primary: true },
          { label: "Resolve at £12,000 (pre-tax)", value: "£12,000" }
        ]}
        onResolve={(v) => setItemStates(s => ({ ...s, joint_barclays: { resolved: true, resolvedValue: v } }))}
      />

      <Thread id="mark_hl_isa" itemStates={itemStates} setItemStates={setItemStates} active={activeItemId === "mark_hl_isa"}
        title="Mark's HL ISA — £15,000" state="new"
        messages={[
          { who: "Mark", time: "16 Apr", text: "Stocks & shares ISA, opened 2022. I've been putting £200/mo in." }
        ]}
        promptForQuery
      />
    </div>
  );
});

function Thread({ id, title, state, messages, resolveOptions, onResolve, active, promptForQuery, itemStates, setItemStates }) {
  const resolved = itemStates[id]?.resolved;
  const stateColor = resolved ? { bg: "#ECF6F0", fg: "#0A6B39", label: "✓ Resolved" }
    : state === "contested" ? { bg: "#FFF7ED", fg: AMBER_INK, label: "⚠ Values differ" }
    : { bg: "#EFF6FF", fg: BLUE_INK, label: "• New" };

  return (
    <div data-thread={id}
         className="bg-white rounded-xl p-3 transition"
         style={{
           border: `1px solid ${LINE}`,
           boxShadow: active ? `0 0 0 3px #FDE9B9` : "none"
         }}>
      <div className="flex items-center justify-between gap-2 mb-2">
        <div style={{ fontSize: 12.5, fontWeight: 600, color: INK }}>{title}</div>
        <span className="chip whitespace-nowrap" style={{ background: stateColor.bg, color: stateColor.fg, fontSize: 9.5, padding: "2px 7px" }}>
          {stateColor.label}
        </span>
      </div>
      <div className="space-y-2.5 mb-2.5">
        {messages.map((m, i) => (
          <div key={i} className="flex items-start gap-2">
            <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
                  style={{ width: 22, height: 22, background: m.who === "Sarah" ? SARAH : MARK, fontSize: 10.5 }}>
              {m.who[0]}
            </span>
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-1.5">
                <span style={{ fontSize: 12, fontWeight: 600 }}>{m.who}</span>
                <span style={{ fontSize: 11, color: MUTE }}>· {m.time}</span>
              </div>
              <div style={{ fontSize: 12.5, color: INK, lineHeight: 1.5, marginTop: 1 }}>{m.text}</div>
              {m.attachment && (
                <div className="mt-1.5 inline-flex items-center gap-1.5 px-2 py-1 rounded bg-[#F4F7FB]"
                     style={{ fontSize: 11, color: BLUE_INK }}>
                  📎 {m.attachment}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {!resolved && (
        <>
          <textarea rows={2} placeholder="Reply…"
            className="w-full rounded-md px-2.5 py-1.5 resize-none"
            style={{ fontSize: 12, border: `1px solid ${LINE}`, background: "#FAFAFA" }}/>
          {resolveOptions && (
            <div className="mt-2 pt-2 space-y-1" style={{ borderTop: `1px dashed ${LINE}` }}>
              <div className="label-xs mb-1" style={{ color: MUTE }}>Resolve together</div>
              {resolveOptions.map((o, i) => (
                <button key={i} onClick={() => onResolve(o.value)}
                  className="w-full text-left rounded-md px-2.5 py-1.5 transition flex items-center justify-between"
                  style={{
                    background: o.primary ? INK : "#F3F4F6",
                    color: o.primary ? "#FFFFFF" : INK,
                    fontSize: 12, fontWeight: o.primary ? 600 : 500
                  }}>
                  <span>{o.label}</span>
                  <CheckI s={11} c={o.primary ? "#FFFFFF" : SUB} w={2.5}/>
                </button>
              ))}
            </div>
          )}
          {promptForQuery && (
            <div className="mt-2 pt-2 text-[11.5px]" style={{ color: SUB, borderTop: `1px dashed ${LINE}`, lineHeight: 1.5 }}>
              Confirm or query this item inline in the document.
            </div>
          )}
        </>
      )}
      {resolved && (
        <div className="text-[11.5px] pt-2" style={{ color: ACCENT, fontWeight: 500, borderTop: `1px dashed ${LINE}` }}>
          ✓ Resolved — both parties agreed. Document updated, new version created.
        </div>
      )}
    </div>
  );
}

/* ============================================================
   ACTIVITY TAB
   ============================================================ */
function ActivityTab() {
  const feed = [
    { time: "17 Apr · 09:14", who: "M", text: "Mark opened Our Household Picture" },
    { time: "17 Apr · 09:14", who: "S", text: "Sarah opened Our Household Picture" },
    { time: "16 Apr · 14:22", who: "M", text: "Mark added his HL ISA (£15,000)" },
    { time: "16 Apr · 14:18", who: "M", text: "Mark added his Amex (£5,800)" },
    { time: "16 Apr · 14:05", who: "M", text: "Mark confirmed Sarah's mortgage balance" },
    { time: "16 Apr · 13:58", who: "M", text: "Mark queried joint savings (says £8k)" },
    { time: "15 Apr · 09:00", who: "S", text: "Sarah shared her picture with Mark" },
    { time: "14 Apr · 16:30", who: "S", text: "Sarah finalised her picture v1.0" }
  ];
  let lastDay = "";
  return (
    <div className="p-3">
      {feed.map((a, i) => {
        const day = a.time.split(" · ")[0];
        const showDay = day !== lastDay;
        lastDay = day;
        return (
          <React.Fragment key={i}>
            {showDay && (
              <div className="label-xs mt-3 mb-2 first:mt-0" style={{ color: MUTE }}>{day}</div>
            )}
            <div className="flex items-start gap-2 py-1.5">
              <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
                    style={{ width: 20, height: 20, background: a.who === "S" ? SARAH : MARK, fontSize: 9.5 }}>
                {a.who}
              </span>
              <div className="flex-1 min-w-0">
                <div style={{ fontSize: 12.5, color: INK, lineHeight: 1.45 }}>{a.text}</div>
                <div style={{ fontSize: 10.5, color: MUTE, marginTop: 1 }}>{a.time.split(" · ")[1]}</div>
              </div>
            </div>
          </React.Fragment>
        );
      })}
    </div>
  );
}

/* ============================================================
   VERSIONS TAB
   ============================================================ */
const VERSIONS = [
  { id: "v2.0", label: "UNIFIED",     date: "16 Apr",    note: "Mark completed his side",   who: "M", current: true },
  { id: "v1.5", label: "IN PROGRESS", date: "15 Apr",    note: "Mark started building",     who: "M" },
  { id: "v1.0", label: "SHARED",      date: "14 Apr",    note: "Sarah shared with Mark",    who: "S" },
  { id: "v0.8", label: "DRAFT",       date: "13 Apr",    note: "Sarah added spending review", who: "S" },
  { id: "v0.5", label: "DRAFT",       date: "12 Apr",    note: "Sarah connected bank",      who: "S" },
  { id: "v0.1", label: "DRAFT",       date: "12 Apr",    note: "Sarah started",             who: "S" }
];

function VersionsTab({ selected, onSelect }) {
  return (
    <div className="p-3">
      <div className="label-xs mb-2" style={{ color: MUTE }}>Timeline</div>
      <div style={{ position: "relative" }}>
        <div style={{ position: "absolute", left: 11, top: 12, bottom: 12, width: 1, background: "#E5E7EB" }}/>
        {VERSIONS.map((v, i) => {
          const isCurrent = v.current;
          const isSelected = selected === v.id;
          const phaseTint = v.label === "UNIFIED" ? { bg: "#ECF6F0", fg: "#0A6B39" }
            : v.label === "SHARED" ? { bg: "#D1FAE5", fg: "#065F46" }
            : v.label === "IN PROGRESS" ? { bg: "#EFF6FF", fg: BLUE_INK }
            : { bg: "#FEF3C7", fg: "#92400E" };
          return (
            <button key={v.id} onClick={() => onSelect(isCurrent ? null : v.id)}
              className="w-full flex items-start gap-3 py-2.5 px-1.5 rounded-md text-left transition"
              style={{
                background: isSelected ? "#F1F1EE" : "transparent"
              }}
              onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = "#F4F4F2"; }}
              onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = "transparent"; }}>
              <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0 relative z-10 mt-0.5"
                    style={{ width: 22, height: 22, background: v.who === "S" ? SARAH : MARK, fontSize: 10.5,
                             boxShadow: `0 0 0 3px #FAFAFA` }}>
                {v.who}
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-1.5 flex-wrap">
                  <span className="tabular-nums" style={{ fontSize: 12.5, fontWeight: 700, color: INK }}>{v.id}</span>
                  <span className="chip whitespace-nowrap" style={{ background: phaseTint.bg, color: phaseTint.fg, fontSize: 9, padding: "1.5px 5.5px" }}>
                    {v.label}
                  </span>
                  {isCurrent && <span style={{ fontSize: 10.5, color: ACCENT, fontWeight: 600 }}>current</span>}
                </div>
                <div style={{ fontSize: 11.5, color: SUB, marginTop: 1, lineHeight: 1.4 }}>{v.date} · {v.note}</div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, { CollabColumn });
})();
