/* Mobile Structured Rail — screen content
   Builds 4 variations of the logged-in workspace for State C (Proposal · with comments)
   Each returns the *inner* screen (no device chrome) sized to width/height from frame.
*/
(function(){
const { useState } = React;
const { MenuIcon, XIcon, ChevronRight, ChevronDown, MessageSquare, Check, Plus, History,
        FileText, Home, Compass, LifeBuoy, Dot, Settings, ASSETS, COMMENT_THREAD, ACTIVITY,
        STATES } = window;

const INK = "#1A1A1A", SUB = "#6B7280", MUTE = "#9CA3AF", LINE = "#EFEFEF", ACCENT = "#2F6D5F";

/* ---- shared chrome ---- */
function TopBar({ onMenu, onActivity, title, sub, pendingCount }) {
  return (
    <div className="flex items-center gap-2 px-3"
         style={{ height: 52, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF", flexShrink: 0 }}>
      <button onClick={onMenu}
              className="w-10 h-10 rounded-lg flex items-center justify-center"
              style={{ background: "transparent" }}>
        <MenuIcon size={20} stroke={INK}/>
      </button>
      <div className="flex-1 min-w-0 px-1">
        <div className="truncate" style={{ fontSize: 14, fontWeight: 600, color: INK, lineHeight: 1.15 }}>{title}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span className="chip-sm" style={{ background: STATES.C.chipBg, color: STATES.C.chipFg }}>
            {STATES.C.version} · {pendingCount} PENDING
          </span>
        </div>
      </div>
      <button onClick={onActivity}
              className="relative w-10 h-10 rounded-lg flex items-center justify-center">
        <MessageSquare size={19} stroke={INK}/>
        {pendingCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ background: "#E5484D" }}/>
        )}
      </button>
      <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[11px] font-semibold ml-1"
           style={{ background: ACCENT }}>SJ</div>
    </div>
  );
}

function ChapterStrip({ compact }) {
  const chapters = [
    { name: "Household",   pct: 100, done: true },
    { name: "My picture",  pct: 80,  active: true },
    { name: "Children",    pct: 40 },
    { name: "Housing",     pct: 60 },
    { name: "Future",      pct: 15 }
  ];
  return (
    <div className="nice-scroll overflow-x-auto" style={{
      background: "#FAFAFA", borderBottom: `1px solid ${LINE}`, flexShrink: 0
    }}>
      <div className="flex gap-1.5 px-3 py-2.5" style={{ width: "max-content" }}>
        {chapters.map((c, i) => (
          <button key={i}
            className="flex flex-col gap-1 rounded-lg px-3 py-1.5 transition"
            style={{
              background: c.active ? "#FFFFFF" : "transparent",
              border: c.active ? `1px solid #111` : `1px solid transparent`,
              minWidth: compact ? 100 : 110
            }}>
            <div className="flex items-center gap-1.5">
              {c.done && (
                <span className="w-3 h-3 rounded-full flex items-center justify-center" style={{ background: ACCENT }}>
                  <Check size={8} strokeWidth={3} stroke="#FFF"/>
                </span>
              )}
              <span style={{ fontSize: 12, fontWeight: c.active ? 600 : 500, color: c.done ? SUB : INK }}>
                {c.name}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
                <div className="h-full rounded-full" style={{
                  width: c.pct + "%",
                  background: c.done ? ACCENT : c.active ? "#111" : MUTE
                }}/>
              </div>
              <span className="text-[10px] tabular-nums" style={{ color: c.done ? ACCENT : (c.active ? INK : MUTE), fontWeight: 600 }}>
                {c.pct}%
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---- drawer (full-screen on mobile) ---- */
function Drawer({ open, onClose }) {
  if (!open) return null;
  return (
    <div className="absolute inset-0 z-40 flex">
      <div onClick={onClose} className="absolute inset-0" style={{ background: "rgba(0,0,0,0.22)" }}/>
      <aside className="relative flex flex-col bg-white"
             style={{ width: "86%", maxWidth: 340, height: "100%",
                      boxShadow: "2px 0 24px rgba(0,0,0,0.08)",
                      animation: "slideIn 220ms cubic-bezier(.2,.8,.2,1)" }}>
        <div className="flex items-center justify-between px-4" style={{ height: 52, borderBottom: `1px solid ${LINE}` }}>
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full relative" aria-hidden>
              <div className="absolute inset-0 rounded-full" style={{ background: INK }}/>
              <div className="absolute rounded-full" style={{ left: "42%", top: 0, width: "58%", height: "100%", background: "#F7F7F5" }}/>
              <div className="absolute rounded-full" style={{ left: "45%", top: "12%", width: "10%", height: "76%", background: INK }}/>
            </div>
            <span style={{ fontSize: 14, fontWeight: 600, letterSpacing: "-0.01em" }}>decouple</span>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-lg flex items-center justify-center">
            <XIcon size={17} stroke={INK}/>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto nice-scroll py-2">
          <DrawerSection label="The document">
            <DrawerItem icon={<Compass size={16}/>} active>Overview</DrawerItem>
            <DrawerItem icon={<Home size={16}/>}>Household</DrawerItem>
            <DrawerItem icon={<FileText size={16}/>}>Settlement</DrawerItem>
          </DrawerSection>
          <DrawerSection label="Chapters">
            <DrawerChapter name="Household" pct={100} done/>
            <DrawerChapter name="My picture" pct={80} active/>
            <DrawerChapter name="Children" pct={40}/>
            <DrawerChapter name="Housing" pct={60}/>
            <DrawerChapter name="Future needs" pct={15}/>
          </DrawerSection>
          <DrawerSection label="Shared with">
            <DrawerItem icon={<div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-semibold" style={{ background: "#E7E5E4", color: SUB }}>M</div>}
                        right={<span className="text-[10.5px]" style={{ color: MUTE }}>2 comments</span>}>Mark</DrawerItem>
          </DrawerSection>
          <DrawerSection label="">
            <DrawerItem icon={<Settings size={16}/>}>Settings</DrawerItem>
            <DrawerItem icon={<LifeBuoy size={16}/>}>Get support</DrawerItem>
          </DrawerSection>
        </div>
      </aside>
    </div>
  );
}
function DrawerSection({ label, children }) {
  return (
    <div className="mb-3">
      {label && <div className="label-xs px-5 pt-3 pb-1.5" style={{ color: MUTE }}>{label}</div>}
      <div>{children}</div>
    </div>
  );
}
function DrawerItem({ icon, children, active, right }) {
  return (
    <button className="w-full flex items-center gap-3 px-5 py-2.5 text-left"
            style={{ background: active ? "#F4F4F2" : "transparent" }}>
      {icon && <span style={{ color: active ? INK : SUB }}>{icon}</span>}
      <span className="flex-1" style={{ fontSize: 14.5, fontWeight: active ? 600 : 500, color: INK }}>{children}</span>
      {right}
    </button>
  );
}
function DrawerChapter({ name, pct, active, done }) {
  return (
    <button className="w-full flex items-center gap-3 px-5 py-2.5 text-left"
            style={{ background: active ? "#F4F4F2" : "transparent" }}>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-2 mb-1">
          <span style={{ fontSize: 14.5, fontWeight: active ? 600 : 500, color: done ? SUB : INK }}>
            {name}
          </span>
          <span className="tabular-nums" style={{ fontSize: 11, color: done ? ACCENT : (active ? INK : MUTE), fontWeight: 600 }}>
            {pct}%
          </span>
        </div>
        <div className="h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
          <div className="h-full rounded-full" style={{
            width: pct + "%",
            background: done ? ACCENT : active ? "#111" : MUTE
          }}/>
        </div>
      </div>
    </button>
  );
}

/* ---- activity screen (full-screen overlay) ---- */
function ActivityScreen({ open, onClose }) {
  if (!open) return null;
  const [tab, setTab] = useState("comments");
  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-white"
         style={{ animation: "slideUp 220ms cubic-bezier(.2,.8,.2,1)" }}>
      <div className="flex items-center gap-2 px-3"
           style={{ height: 52, borderBottom: `1px solid ${LINE}`, flexShrink: 0 }}>
        <button onClick={onClose} className="w-10 h-10 rounded-lg flex items-center justify-center">
          <XIcon size={18} stroke={INK}/>
        </button>
        <div className="flex-1 text-center" style={{ fontSize: 14, fontWeight: 600 }}>Activity & comments</div>
        <div className="w-10"/>
      </div>
      <div className="flex gap-1 px-3 pt-2" style={{ borderBottom: `1px solid ${LINE}`, flexShrink: 0 }}>
        {[["comments", "Comments", 2], ["activity", "Activity", 3]].map(([k, l, n]) => (
          <button key={k} onClick={() => setTab(k)}
                  className="flex items-center gap-1.5 px-3 py-2.5"
                  style={{
                    borderBottom: tab === k ? "2px solid #111" : "2px solid transparent",
                    fontSize: 13,
                    fontWeight: tab === k ? 600 : 500,
                    color: tab === k ? INK : SUB
                  }}>
            {l}
            <span className="text-[10.5px] px-1.5 rounded-full font-semibold"
                  style={{ background: tab === k ? "#111" : "#F3F4F6", color: tab === k ? "#FFF" : SUB }}>{n}</span>
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll p-3 space-y-2.5">
        {tab === "comments" ? (
          <>
            <div className="label-xs" style={{ color: MUTE }}>{COMMENT_THREAD.target}</div>
            {COMMENT_THREAD.items.map((it, i) => (
              <div key={i} className="rounded-xl p-3" style={{ background: "#FAFAFA", border: `1px solid ${LINE}` }}>
                <div className="flex items-center gap-2 mb-1.5">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-[10px] font-semibold"
                       style={{ background: it.color }}>{it.initial}</div>
                  <div className="text-[13px] font-semibold">{it.who}</div>
                  <div className="text-[11px]" style={{ color: MUTE }}>· {it.time}</div>
                </div>
                <div className="text-[13px] leading-[1.55]">{it.text}</div>
              </div>
            ))}
            <button className="w-full py-3 rounded-xl text-[13px] font-medium flex items-center justify-center gap-1.5"
                    style={{ border: `1px dashed ${MUTE}`, color: SUB }}>
              <Plus size={14}/> Reply to Mark
            </button>
          </>
        ) : (
          ACTIVITY.C.map(([text, time], i) => (
            <div key={i} className="flex items-start gap-2.5 px-2 py-2.5">
              <div className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "#D1D5DB" }}/>
              <div className="flex-1">
                <div className="text-[13px]">{text}</div>
                <div className="text-[11px] mt-0.5" style={{ color: MUTE }}>{time}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ---- doc body cards ---- */
function HeroCard({ tight }) {
  return (
    <div className="rounded-2xl p-4" style={{ background: "#FFFFFF", border: `1px solid ${LINE}`, boxShadow: "0 1px 2px rgba(0,0,0,0.02)" }}>
      <div className="label-xs mb-1.5" style={{ color: MUTE }}>Proposal · v2.1</div>
      <h1 style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.2 }}>
        Mark replied to your proposal.
      </h1>
      <p className="mt-1.5" style={{ fontSize: 13.5, color: SUB, lineHeight: 1.5 }}>
        Two items still need your response.
      </p>
      {!tight && (
        <div className="mt-3 flex items-center gap-2 pt-3" style={{ borderTop: `1px solid ${LINE}` }}>
          <button className="flex-1 h-10 rounded-lg text-[13px] font-semibold text-white" style={{ background: "#111" }}>
            Review 2 pending
          </button>
          <button className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ border: `1px solid ${LINE}` }}>
            <History size={16} stroke={INK}/>
          </button>
        </div>
      )}
    </div>
  );
}

function PendingCard() {
  return (
    <div className="rounded-2xl p-4" style={{ background: "#FFFFFF", border: `1px solid ${LINE}` }}>
      <div className="flex items-center justify-between mb-3">
        <div className="label-xs" style={{ color: MUTE }}>Pending from Mark</div>
        <span className="chip-sm" style={{ background: "#FEE2E2", color: "#991B1B" }}>2 ITEMS</span>
      </div>
      <div className="space-y-2.5">
        <PendingRow
          sect="§3.2 Housing"
          text="Revisit Halifax equity split — doesn't reflect 2018 deposit."
          who="Mark" time="2h ago" color="#7E5A4E"/>
        <PendingRow
          sect="§4.1 Children"
          text="Would like to discuss Saturday contact hours in term-time."
          who="Mark" time="Yesterday" color="#7E5A4E"/>
      </div>
    </div>
  );
}
function PendingRow({ sect, text, who, time, color }) {
  return (
    <div className="rounded-lg p-3" style={{ background: "#FAFAFA" }}>
      <div className="flex items-center gap-1.5 mb-1.5">
        <div className="w-5 h-5 rounded-full flex items-center justify-center text-white text-[9.5px] font-semibold" style={{ background: color }}>
          {who[0]}
        </div>
        <span className="text-[11.5px] font-semibold">{who}</span>
        <span className="text-[10.5px]" style={{ color: MUTE }}>· {time}</span>
        <span className="ml-auto label-xs" style={{ color: MUTE }}>{sect}</span>
      </div>
      <div className="text-[13px] leading-[1.5]">{text}</div>
      <div className="flex gap-1.5 mt-2.5">
        <button className="flex-1 h-8 rounded-md text-[12px] font-semibold text-white" style={{ background: "#111" }}>Respond</button>
        <button className="flex-1 h-8 rounded-md text-[12px] font-medium" style={{ border: `1px solid ${LINE}`, color: INK }}>View section</button>
      </div>
    </div>
  );
}

function LedgerCard({ title = "Assets & liabilities" }) {
  return (
    <div className="rounded-2xl p-4" style={{ background: "#FFFFFF", border: `1px solid ${LINE}` }}>
      <div className="flex items-center justify-between mb-2.5">
        <div className="label-xs" style={{ color: MUTE }}>{title}</div>
        <span className="text-[11.5px] font-semibold tabular-nums" style={{ color: INK }}>£486,850</span>
      </div>
      {ASSETS.slice(0, 4).map(([l,,v,done], i) => (
        <div key={i} className="flex items-center justify-between py-2.5"
             style={{ borderBottom: i < 3 ? `1px dashed ${LINE}` : "none" }}>
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-3.5 h-3.5 rounded-[3px] flex items-center justify-center flex-shrink-0"
                 style={{ background: done ? ACCENT : "#F3F4F6" }}>
              {done && <Check size={9} strokeWidth={3} stroke="#FFF"/>}
            </div>
            <span className="text-[13px] truncate" style={{ color: done ? INK : MUTE }}>{l}</span>
          </div>
          <span className="text-[12.5px] tabular-nums ml-2 flex-shrink-0" style={{ color: done ? INK : MUTE }}>{v}</span>
        </div>
      ))}
    </div>
  );
}

function SignoffCard() {
  return (
    <div className="rounded-2xl p-4" style={{ background: "#FFFFFF", border: `1px solid ${LINE}` }}>
      <div className="label-xs mb-2" style={{ color: MUTE }}>Advisor sign-off</div>
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-semibold text-white" style={{ background: "#4B5563" }}>RP</div>
        <div className="flex-1">
          <div className="text-[13px] font-semibold">Rachel Patel</div>
          <div className="text-[11.5px]" style={{ color: MUTE }}>Signed off · 2 days ago</div>
        </div>
        <span className="w-5 h-5 rounded-full flex items-center justify-center" style={{ background: ACCENT }}>
          <Check size={11} strokeWidth={3} stroke="#FFF"/>
        </span>
      </div>
    </div>
  );
}

/* ============================================================ */
/*  M1 — Baseline: hamburger drawer, chapter strip, stacked cards */
/* ============================================================ */
function Mobile_M1() {
  const [drawer, setDrawer] = useState(false);
  const [activity, setActivity] = useState(false);
  return (
    <div className="relative flex flex-col h-full" style={{ background: "#F5F5F4" }}>
      <TopBar onMenu={() => setDrawer(true)} onActivity={() => setActivity(true)}
              title="Settlement" sub="Proposal · v2.1" pendingCount={2}/>
      <ChapterStrip/>
      <div className="flex-1 overflow-y-auto nice-scroll p-3 space-y-3">
        <HeroCard/>
        <PendingCard/>
        <LedgerCard/>
        <SignoffCard/>
        <div className="h-4"/>
      </div>
      <Drawer open={drawer} onClose={() => setDrawer(false)}/>
      <ActivityScreen open={activity} onClose={() => setActivity(false)}/>
    </div>
  );
}

/* ============================================================ */
/*  M2 — Pending-first: unresolved items hoisted to the top      */
/* ============================================================ */
function Mobile_M2() {
  const [drawer, setDrawer] = useState(false);
  const [activity, setActivity] = useState(false);
  return (
    <div className="relative flex flex-col h-full" style={{ background: "#F5F5F4" }}>
      <TopBar onMenu={() => setDrawer(true)} onActivity={() => setActivity(true)}
              title="Settlement" sub="Proposal · v2.1" pendingCount={2}/>
      <ChapterStrip/>
      {/* Pending banner */}
      <div className="px-3 pt-3">
        <div className="rounded-2xl p-3 flex items-center gap-2.5"
             style={{ background: "#FFFFFF", border: `1px solid #FECACA` }}>
          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "#FEE2E2" }}>
            <MessageSquare size={14} stroke="#991B1B"/>
          </div>
          <div className="flex-1 min-w-0">
            <div style={{ fontSize: 12.5, fontWeight: 600, color: "#991B1B" }}>2 items need your response</div>
            <div style={{ fontSize: 11.5, color: SUB }} className="truncate">§3.2 Housing · §4.1 Children</div>
          </div>
          <ChevronRight size={16} stroke={SUB}/>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll p-3 pt-3 space-y-3">
        <PendingCard/>
        <HeroCard tight/>
        <LedgerCard/>
        <SignoffCard/>
        <div className="h-4"/>
      </div>
      <Drawer open={drawer} onClose={() => setDrawer(false)}/>
      <ActivityScreen open={activity} onClose={() => setActivity(false)}/>
    </div>
  );
}

/* ============================================================ */
/*  M3 — Dense chapter-as-tabs (pinned section header)           */
/* ============================================================ */
function Mobile_M3() {
  const [drawer, setDrawer] = useState(false);
  const [activity, setActivity] = useState(false);
  return (
    <div className="relative flex flex-col h-full" style={{ background: "#F5F5F4" }}>
      <TopBar onMenu={() => setDrawer(true)} onActivity={() => setActivity(true)}
              title="Settlement" sub="Proposal · v2.1" pendingCount={2}/>
      <ChapterStrip compact/>
      {/* Sticky section header */}
      <div className="flex items-center gap-2 px-4"
           style={{ height: 40, background: "#FFFFFF", borderBottom: `1px solid ${LINE}`, flexShrink: 0 }}>
        <span className="label-xs" style={{ color: MUTE }}>CHAPTER 2</span>
        <span style={{ fontSize: 13, fontWeight: 600 }}>My financial picture</span>
        <span className="ml-auto text-[11px] tabular-nums font-semibold" style={{ color: "#111" }}>80%</span>
        <ChevronDown size={14} stroke={SUB}/>
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll">
        <div className="p-3 space-y-3">
          <HeroCard/>
          <PendingCard/>
        </div>
        {/* Next chapter section break */}
        <div className="flex items-center gap-2 px-4 py-2.5 mt-2"
             style={{ background: "#FAFAFA", borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}` }}>
          <span className="label-xs" style={{ color: MUTE }}>CHAPTER 3</span>
          <span style={{ fontSize: 13, fontWeight: 600 }}>Housing</span>
          <span className="ml-auto text-[11px] tabular-nums font-semibold" style={{ color: MUTE }}>60%</span>
        </div>
        <div className="p-3 space-y-3">
          <LedgerCard title="Halifax mortgage — equity"/>
          <SignoffCard/>
        </div>
        <div className="h-4"/>
      </div>
      <Drawer open={drawer} onClose={() => setDrawer(false)}/>
      <ActivityScreen open={activity} onClose={() => setActivity(false)}/>
    </div>
  );
}

/* ============================================================ */
/*  M4 — Single-column minimal: no strip, progress inline        */
/* ============================================================ */
function Mobile_M4() {
  const [drawer, setDrawer] = useState(false);
  const [activity, setActivity] = useState(false);
  return (
    <div className="relative flex flex-col h-full" style={{ background: "#FAFAFA" }}>
      <TopBar onMenu={() => setDrawer(true)} onActivity={() => setActivity(true)}
              title="Settlement" sub="Proposal · v2.1" pendingCount={2}/>
      <div className="flex-1 overflow-y-auto nice-scroll">
        {/* Inline progress header */}
        <div className="px-4 pt-4 pb-3">
          <div className="label-xs mb-1" style={{ color: MUTE }}>Phase 4 · Settlement</div>
          <h1 style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
            Mark replied.
          </h1>
          <p className="mt-1.5" style={{ fontSize: 13.5, color: SUB, lineHeight: 1.5 }}>
            2 items need your response. 6 of 8 clauses accepted.
          </p>
          <div className="mt-3 flex items-center gap-2">
            <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
              <div className="h-full rounded-full" style={{ width: "75%", background: "#111" }}/>
            </div>
            <span className="text-[11px] tabular-nums font-semibold">75%</span>
          </div>
        </div>
        <div className="px-3 pb-3 space-y-3">
          <PendingCard/>
          <LedgerCard/>
          <button className="w-full flex items-center justify-between rounded-2xl p-4"
                  style={{ background: "#FFFFFF", border: `1px solid ${LINE}` }}>
            <div className="text-left">
              <div className="text-[13px] font-semibold">Browse chapters</div>
              <div className="text-[11.5px] mt-0.5" style={{ color: SUB }}>Household · My picture · Housing · Future needs</div>
            </div>
            <ChevronRight size={16} stroke={SUB}/>
          </button>
          <SignoffCard/>
          <div className="h-4"/>
        </div>
      </div>
      <Drawer open={drawer} onClose={() => setDrawer(false)}/>
      <ActivityScreen open={activity} onClose={() => setActivity(false)}/>
    </div>
  );
}

Object.assign(window, { Mobile_M1, Mobile_M2, Mobile_M3, Mobile_M4 });
})();
