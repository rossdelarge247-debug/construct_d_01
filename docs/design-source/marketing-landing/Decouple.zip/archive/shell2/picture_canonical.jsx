/* Canonical Your Picture layout — replaces LayoutFull / LayoutIconRail / LayoutMobile.
   Three-column:
     LEFT    — chapter rail (contextual to picture being built)
     CENTER  — the document
     RIGHT   — snapshot + evidence/to-do rail (MIAM, CETV, etc.)
*/
(function(){
const { useState } = React;
const {
  Wordmark, ChevronRight, Check, Share, Edit, FileText, History,
  LifeBuoy, PictureDoc
} = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D", AMBER = "#B45309", AMBER_BG = "#FEF7E7";

const CHAPTERS = [
  { n: 1, title: "The children",          items: 3, done: 3 },
  { n: 2, title: "The home",              items: 4, done: 4, gap: 1 },
  { n: 3, title: "Pensions",              items: 3, done: 1, gap: 1 },
  { n: 4, title: "Savings & investments", items: 4, done: 4 },
  { n: 5, title: "Vehicles & other",      items: 4, done: 4 },
  { n: 6, title: "Debts",                 items: 5, done: 5 },
  { n: 7, title: "Income",                items: 2, done: 2, gap: 1 },
  { n: 8, title: "Monthly spending",      items: 6, done: 6 },
  { n: 9, title: "Summary",               items: 6, done: 6 }
];

/* ============================================================
   TASK DATA — legal / evidence / practical
   Ordered by urgency. Each has:
     question (conversational), action (imperative), category, urgency, why, linkedChapter
   ============================================================ */
const TASKS = [
  {
    id: "miam",
    category: "legal",
    urgency: "critical",
    question: "Have you booked your MIAM yet?",
    action: "Book MIAM",
    why: "Required before court. Takes 2–3 weeks to get an appointment.",
    eta: "Do this week",
    linkedChapter: null
  },
  {
    id: "cetv",
    category: "evidence",
    urgency: "critical",
    question: "Have you requested your NHS pension CETV?",
    action: "Request CETV",
    why: "Providers take up to 3 months to issue. Without it, Pensions section can't close.",
    eta: "Do this week",
    linkedChapter: 3
  },
  {
    id: "valuation",
    category: "evidence",
    urgency: "high",
    question: "Have you got three estate agent valuations?",
    action: "Request valuations",
    why: "Your £450k is currently a self-estimate. Courts expect three.",
    eta: "Next 2 weeks",
    linkedChapter: 2
  },
  {
    id: "statements",
    category: "evidence",
    urgency: "high",
    question: "Downloaded the last 12 months of bank statements?",
    action: "Download statements",
    why: "Barclays & Monzo auto-synced. Halifax joint account needs manual export.",
    eta: "Next 2 weeks",
    linkedChapter: null
  },
  {
    id: "payslip",
    category: "evidence",
    urgency: "medium",
    question: "Got your last three payslips ready?",
    action: "Upload payslips",
    why: "Needed to confirm income section before finalisation.",
    eta: "Next month",
    linkedChapter: 7
  },
  {
    id: "mortgage",
    category: "practical",
    urgency: "medium",
    question: "Told your mortgage lender about the separation?",
    action: "Notify Halifax",
    why: "Joint mortgage holders should be informed of the process.",
    eta: "Next month",
    linkedChapter: 2
  },
  {
    id: "will",
    category: "practical",
    urgency: "medium",
    question: "Reviewed your will recently?",
    action: "Review will",
    why: "Separation doesn't revoke a will. If Mark is named, consider updating.",
    eta: "Next month",
    linkedChapter: null
  },
  {
    id: "beneficiaries",
    category: "practical",
    urgency: "low",
    question: "Updated life insurance beneficiaries?",
    action: "Update beneficiaries",
    why: "Check pension & life policies that may still name Mark.",
    eta: "Before finalisation",
    linkedChapter: null
  },
  {
    id: "p60",
    category: "evidence",
    urgency: "low",
    question: "Saved your most recent P60?",
    action: "Upload P60",
    why: "Confirms annual income for the Form E / financial disclosure.",
    eta: "Before finalisation",
    linkedChapter: 7
  },
  {
    id: "solicitor",
    category: "legal",
    urgency: "low",
    question: "Had an initial chat with a solicitor?",
    action: "Find solicitor",
    why: "Recommended before signing anything binding. Decouple has a panel.",
    eta: "Before finalisation",
    linkedChapter: null
  }
];

const CAT_META = {
  legal:     { label: "Legal",     color: "#7C3AED", bg: "#F3EEFE" },
  evidence:  { label: "Evidence",  color: "#0369A1", bg: "#E0F2FE" },
  practical: { label: "Practical", color: "#BE185D", bg: "#FCE7F3" }
};

const URG_META = {
  critical: { label: "Do this week",     dot: DANGER },
  high:     { label: "Next 2 weeks",     dot: "#F59E0B" },
  medium:   { label: "Next month",       dot: ACCENT },
  low:      { label: "Before finalise",  dot: MUTE }
};

/* ============================================================
   COMPONENT
   ============================================================ */
function LayoutCanonical({ onOpenShare }) {
  const [mode, setMode] = useState("edit");
  const [active, setActive] = useState(1);
  const [taskState, setTaskState] = useState(() => {
    /* Default: miam done (Sarah booked it). Everything else open. */
    return { miam: "done" };
  });
  const [filter, setFilter] = useState("open"); // open | all | done

  const markDone = (id) => setTaskState(s => ({ ...s, [id]: s[id] === "done" ? "open" : "done" }));
  const snooze   = (id) => setTaskState(s => ({ ...s, [id]: s[id] === "snoozed" ? "open" : "snoozed" }));

  return (
    <div className="flex flex-col h-full bg-white" style={{ overflow: "hidden" }}>
      <TopBar mode={mode} setMode={setMode} onOpenShare={onOpenShare}/>
      <div className="flex-1 flex min-h-0">
        <ChapterRail active={active} setActive={setActive}/>
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFFFFF" }}>
          <PictureDoc editMode={mode === "edit"}/>
        </div>
        <RightRail
          taskState={taskState}
          markDone={markDone}
          snooze={snooze}
          filter={filter}
          setFilter={setFilter}
        />
      </div>
    </div>
  );
}

/* ------- top bar (same shape as before) ------- */
function TopBar({ mode, setMode, onOpenShare }) {
  return (
    <div className="flex items-center justify-between px-5 flex-shrink-0"
         style={{ height: 56, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
      <div className="flex items-center gap-3">
        <Wordmark small/>
        <span style={{ color: "#E5E7EB" }}>/</span>
        <div className="flex items-center gap-1.5 text-[12.5px]" style={{ color: SUB }}>
          <span>Your picture</span>
          <ChevronRight size={12} style={{ color: "#D4D4D4" }}/>
          <span className="whitespace-nowrap" style={{ color: INK, fontWeight: 600 }}>Sarah's Picture</span>
          <span className="chip ml-1 whitespace-nowrap" style={{ background: "#FEF3C7", color: "#92400E" }}>v0.8 · DRAFT</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className="inline-flex items-center rounded-md p-0.5" style={{ background: "#F3F4F6", border: `1px solid ${LINE}` }}>
          {[{k:"doc",l:"Read",i:<FileText size={12}/>},{k:"edit",l:"Edit",i:<Edit size={12}/>}].map(t => {
            const on = mode === t.k;
            return (
              <button key={t.k} onClick={() => setMode(t.k)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11.5px] font-medium"
                style={{ background: on ? "#FFFFFF" : "transparent", color: on ? INK : SUB,
                         boxShadow: on ? "0 1px 2px rgba(0,0,0,0.06)" : "none" }}>
                {t.i}{t.l}
              </button>
            );
          })}
        </div>
        <button className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium"
                style={{ borderColor: LINE, background: "#FFFFFF", color: INK }}>
          <History size={13}/> v0.8
        </button>
        <button onClick={onOpenShare}
                className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-medium text-white"
                style={{ background: DANGER }}>
          <Share size={13}/> Share with Mark
        </button>
        <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold"
             style={{ background: ACCENT }}>SJ</div>
      </div>
    </div>
  );
}

/* ------- left chapter rail ------- */
function ChapterRail({ active, setActive }) {
  return (
    <div style={{ width: 240, background: "#FAFAFA", borderRight: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">
      <div className="px-4 py-3.5">
        <div className="label-xs mb-2" style={{ color: MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: INK }}>Sarah's Picture</div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full" style={{ width: "86%", background: ACCENT }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 11, color: ACCENT, fontWeight: 600 }}>86%</span>
        </div>
      </div>
      <div className="px-2 pb-3 flex-1 overflow-y-auto nice-scroll">
        {CHAPTERS.map(c => {
          const isActive = active === c.n;
          const complete = c.done === c.items && !c.gap;
          return (
            <button key={c.n} onClick={() => setActive(c.n)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{ background: isActive ? "#EEF1F0" : "transparent",
                       color: INK, fontSize: 12.5, fontWeight: isActive ? 600 : 500 }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: MUTE, width: 14 }}>{c.n}</span>
              <span className="flex-1 truncate">{c.title}</span>
              {c.gap ? (
                <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
                      style={{ width: 14, height: 14, background: AMBER_BG, color: AMBER, fontSize: 10, fontWeight: 700 }}>!</span>
              ) : complete ? (
                <Check size={11} style={{ color: ACCENT }} strokeWidth={2.5}/>
              ) : null}
            </button>
          );
        })}
      </div>
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
           style={{ color: SUB, borderTop: `1px solid ${LINE}` }}>
        <LifeBuoy size={12}/> Get support
      </div>
    </div>
  );
}

/* ------- right rail: snapshot + tasks ------- */
function RightRail({ taskState, markDone, snooze, filter, setFilter }) {
  const openTasks = TASKS.filter(t => (taskState[t.id] || "open") === "open");
  const doneTasks = TASKS.filter(t => taskState[t.id] === "done");
  const snoozedTasks = TASKS.filter(t => taskState[t.id] === "snoozed");

  const visible = filter === "all" ? TASKS
                : filter === "done" ? doneTasks
                : [...openTasks, ...snoozedTasks];

  return (
    <div style={{ width: 340, background: "#FAFAFA", borderLeft: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">

      {/* SNAPSHOT (compact) */}
      <div className="p-4 flex-shrink-0" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Snapshot</div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
          {[["Net position","£54,560",INK],["Assets","£282,240",INK],["Debts","(£227,680)",DANGER],["Monthly gap","(£892)",DANGER]].map(([k,v,c],i)=>(
            <div key={i} className="flex items-baseline justify-between gap-2">
              <span className="whitespace-nowrap" style={{ fontSize: 11.5, color: SUB }}>{k}</span>
              <span className="tabular-nums whitespace-nowrap" style={{ fontSize: 12.5, fontWeight: 600, color: c }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      {/* TASKS HEADER */}
      <div className="px-4 pt-3.5 pb-2 flex-shrink-0">
        <div className="flex items-baseline gap-2 mb-2">
          <span className="label-xs" style={{ color: MUTE }}>Your to-do list</span>
          <span className="tabular-nums label-xs" style={{ color: INK, fontWeight: 700 }}>{openTasks.length} open</span>
          {doneTasks.length > 0 && <span className="tabular-nums label-xs" style={{ color: ACCENT, fontWeight: 700 }}>· {doneTasks.length} done</span>}
        </div>
        <div style={{ fontSize: 12, color: SUB, lineHeight: 1.45 }}>
          Based on your situation, a few things are best done soon. We'll remind you.
        </div>
        {/* Filter tabs */}
        <div className="mt-2.5 flex gap-1">
          {[["open","Open"],["done","Done"],["all","All"]].map(([k,l]) => {
            const on = filter === k;
            return (
              <button key={k} onClick={() => setFilter(k)}
                className="h-6 px-2 rounded text-[11px] font-semibold transition"
                style={{ background: on ? "#111" : "#EEEEEC", color: on ? "#FFF" : SUB }}>
                {l}
              </button>
            );
          })}
        </div>
      </div>

      {/* TASK LIST */}
      <div className="flex-1 overflow-y-auto nice-scroll px-3 pb-4">
        {visible.length === 0 && (
          <div className="px-3 py-8 text-center" style={{ fontSize: 12, color: MUTE }}>
            Nothing here yet.
          </div>
        )}
        {visible.map(t => {
          const state = taskState[t.id] || "open";
          return (
            <TaskCard key={t.id} task={t} state={state}
                      onDone={() => markDone(t.id)}
                      onSnooze={() => snooze(t.id)}/>
          );
        })}
      </div>
    </div>
  );
}

/* ------- task card ------- */
function TaskCard({ task, state, onDone, onSnooze }) {
  const cat = CAT_META[task.category];
  const urg = URG_META[task.urgency];
  const isDone = state === "done";
  const isSnoozed = state === "snoozed";

  return (
    <div className="rounded-lg p-3 mb-1.5 transition"
         style={{
           background: "#FFFFFF",
           border: `1px solid ${LINE}`,
           opacity: isDone || isSnoozed ? 0.62 : 1
         }}>
      <div className="flex items-start gap-2">
        {/* Checkbox */}
        <button onClick={onDone}
          className="flex-shrink-0 inline-flex items-center justify-center rounded transition mt-0.5"
          style={{
            width: 18, height: 18,
            background: isDone ? ACCENT : "#FFF",
            border: `1.5px solid ${isDone ? ACCENT : "#D4D4D3"}`
          }}>
          {isDone && <Check size={11} style={{ color: "#FFF" }} strokeWidth={3}/>}
        </button>

        <div className="flex-1 min-w-0">
          {/* Chips row */}
          <div className="flex items-center gap-1.5 mb-1 flex-wrap">
            <span className="chip whitespace-nowrap" style={{ background: cat.bg, color: cat.color, fontSize: 9.5, padding: "1px 6px" }}>
              {cat.label}
            </span>
            {!isDone && (
              <span className="inline-flex items-center gap-1 whitespace-nowrap" style={{ fontSize: 10, color: urg.dot === MUTE ? MUTE : urg.dot, fontWeight: 600 }}>
                <span className="inline-block w-1.5 h-1.5 rounded-full" style={{ background: urg.dot }}/>
                {urg.label}
              </span>
            )}
            {isSnoozed && (
              <span className="whitespace-nowrap" style={{ fontSize: 10, color: MUTE, fontStyle: "italic" }}>snoozed</span>
            )}
          </div>

          {/* Question */}
          <div style={{
            fontSize: 12.5, fontWeight: 600, color: INK,
            lineHeight: 1.4,
            textDecoration: isDone ? "line-through" : "none"
          }}>
            {task.question}
          </div>

          {/* Why */}
          {!isDone && (
            <div style={{ fontSize: 11.5, color: SUB, lineHeight: 1.45, marginTop: 2 }}>
              {task.why}
            </div>
          )}

          {/* Actions */}
          {!isDone && !isSnoozed && (
            <div className="flex items-center gap-1.5 mt-2">
              <button className="inline-flex items-center h-6 px-2 rounded text-[11px] font-semibold text-white"
                      style={{ background: INK }}>
                {task.action}
              </button>
              <button onClick={onSnooze}
                      className="inline-flex items-center h-6 px-2 rounded text-[11px] font-medium"
                      style={{ background: "transparent", color: MUTE }}>
                Remind me next time
              </button>
            </div>
          )}
          {isDone && (
            <button onClick={onDone} className="mt-1.5 text-[10.5px]" style={{ color: MUTE }}>
              Undo
            </button>
          )}
          {isSnoozed && (
            <button onClick={onSnooze} className="mt-1.5 text-[10.5px]" style={{ color: MUTE }}>
              Unsnooze
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { LayoutCanonical });
})();
