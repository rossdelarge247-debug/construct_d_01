/* Your Picture v4 — dual-view + delta model
   State logic + shared data live here.
*/
(function(){

const INK="#1A1A1A", SUB="#5F6368", MUTE="#9AA0A6", LINE="#EAECEF";
const ACCENT="#2F6D5F", DANGER="#E5484D";
const AMBER="#B45309", AMBER_BG="#FEF7E7", AMBER_SOFT="#FFFBEB";
const PRIVATE_BG = "#FFFFFF";
const SHARED_TINT_COOL = "#F1F5F4"; // default shared tint
const SHARED_TINT_WARM = "#F8F5EE";
const SHARED_TINT_BLUE = "#EEF3F7";

/* ---- Canonical item data. Values below are Shared (v1) baseline. ----
   Private overlays with held-back deltas from PENDING_DELTAS.
*/
const ITEMS = [
  { id:"home-market", ch:2, label:"Family home — market value",    sharedValue:"£505,000",    category:"Property" },
  { id:"home-mort",   ch:2, label:"Halifax mortgage balance",      sharedValue:"£187,500",    category:"Property" },
  { id:"nhs",         ch:3, label:"NHS pension (CETV)",            sharedValue:"£214,000",    category:"Pensions" },
  { id:"workplace",   ch:3, label:"Workplace pension (Aviva)",     sharedValue:"£38,200",     category:"Pensions" },
  { id:"isa",         ch:4, label:"Vanguard ISA — Sarah",          sharedValue:"£42,150",     category:"Savings" },
  { id:"joint-cash",  ch:4, label:"First Direct joint savings",    sharedValue:"£28,400",     category:"Savings" },
  { id:"premium",     ch:4, label:"Premium bonds",                 sharedValue:"£8,000",      category:"Savings" },
  { id:"car",         ch:5, label:"Ford Kuga 2021",                sharedValue:"£14,800",     category:"Vehicles" },
  { id:"salary",      ch:7, label:"Sarah — salary (NHS)",          sharedValue:"£62,400 / yr",category:"Income" },
  { id:"freelance",   ch:7, label:"Sarah — freelance income",      sharedValue:"£0 / yr",     category:"Income" }
];

/* Pending deltas — edits Sarah has made that are NOT yet shared. */
const PENDING_DELTAS = [
  {
    itemId: "home-market",
    oldValue: "£505,000",
    newValue: "£510,000",
    reason: "Midpoint of 3 new valuations (Foxtons £505k · Winkworth £515k · Savills £510k)",
    source: "You · 2 days ago",
    category: "Property"
  },
  {
    itemId: "freelance",
    oldValue: "£0 / yr",
    newValue: "£4,200 / yr",
    reason: "Copy-editing work for The Lancet. Started Oct 2025.",
    source: "You · yesterday",
    category: "Income"
  }
];

const CHAPTERS = [
  { n:1, title:"The children",          items:3, done:3 },
  { n:2, title:"The home",              items:4, done:4 },
  { n:3, title:"Pensions",              items:3, done:3 },
  { n:4, title:"Savings & investments", items:4, done:4 },
  { n:5, title:"Vehicles & other",      items:4, done:4 },
  { n:6, title:"Debts",                 items:5, done:5 },
  { n:7, title:"Income",                items:2, done:2 },
  { n:8, title:"Monthly spending",      items:6, done:6 },
  { n:9, title:"Summary",               items:6, done:6 }
];

const VERSIONS = {
  priv_v0:    { label: "Private · draft",       stamp: "Private · last updated today", v: "v0.8", date: "today" },
  priv_v1:    { label: "Private · v1 in sync",   stamp: "Private · last updated 14 Nov · in sync with shared", v: "v1.0", date: "14 Nov" },
  priv_delta: { label: "Private · 2 updates held", stamp: "Private · 2 updates held · last updated today",     v: "v1.0 + 2", date: "today" },
  shared:     { label: "Shared with Mark",       stamp: "Shared with Mark · v1 · 14 Nov",                      v: "v1", date: "14 Nov" }
};

Object.assign(window, {
  YP_TOKENS: {
    INK, SUB, MUTE, LINE, ACCENT, DANGER, AMBER, AMBER_BG, AMBER_SOFT,
    PRIVATE_BG, SHARED_TINT_COOL, SHARED_TINT_WARM, SHARED_TINT_BLUE
  },
  YP_ITEMS: ITEMS,
  YP_DELTAS: PENDING_DELTAS,
  YP_CHAPTERS: CHAPTERS,
  YP_VERSIONS: VERSIONS
});
})();
