/* Your Picture v4 — shell layout
   Top bar with view dropdown, chapter rail, doc body, right rail.
*/
(function(){
const { useState, useEffect, useMemo } = React;
const {
  Wordmark, ChevronRight, ChevronDown, Check, Edit, FileText, History,
  LifeBuoy, Lock, YP_ViewDropdown, YP_ShareCTA, YP_PendingPill, YP_ItemRow, YP_ShareModal
} = window;
const T = window.YP_TOKENS;

function YPShell({ state, view, setView, markerStyle, sharedTintStyle, modalLayout, onCycleState }) {
  // Map high-level state → share CTA mode + delta visibility
  const cfg = useMemo(() => {
    if (state === "priv_v0")    return { share: "new",     deltas: [],                    version: "v0.8" };
    if (state === "priv_v1")    return { share: "sync",    deltas: [],                    version: "v1.0" };
    if (state === "priv_delta") return { share: "pending", deltas: window.YP_DELTAS,      version: "v1.0" };
    if (state === "shared")     return { share: "sync",    deltas: [],                    version: "v1.0" };
    return { share: "new", deltas: [], version: "v0.8" };
  }, [state]);

  const [modalOpen, setModalOpen] = useState(false);
  const [active, setActive] = useState(2);
  const [mode, setMode] = useState("edit"); // 'edit' | 'read'

  const hasShared = state !== "priv_v0";
  const effectiveView = view === "shared" && !hasShared ? "private" : view;
  const showDeltas = effectiveView === "private";
  const isSharedView = effectiveView === "shared";

  // Tint backgrounds for the doc canvas depending on view
  const SHARED_TINTS = {
    none:  "#FFFFFF",
    cool:  T.SHARED_TINT_COOL,
    warm:  T.SHARED_TINT_WARM,
    blue:  T.SHARED_TINT_BLUE
  };
  const docBg = isSharedView ? SHARED_TINTS[sharedTintStyle] : "#FFFFFF";

  return (
    <div className="flex flex-col h-full bg-white" style={{ overflow: "hidden" }}>
      <TopBar
        state={state}
        cfg={cfg}
        view={effectiveView}
        setView={setView}
        mode={mode}
        setMode={setMode}
        hasShared={hasShared}
        onOpenShare={() => setModalOpen(true)}
        onOpenPending={() => setModalOpen(true)}
        onCycleState={onCycleState}/>

      <div className="flex-1 flex min-h-0">
        <ChapterRail active={active} setActive={setActive} version={cfg.version}/>

        <div className="flex-1 overflow-y-auto nice-scroll relative" style={{
          background: docBg, transition: "background 240ms ease"
        }}>
          {isSharedView && (
            <div className="pointer-events-none absolute inset-0" style={{
              backgroundImage: "repeating-linear-gradient(45deg, transparent 0 40px, rgba(47,109,95,0.015) 40px 41px)"
            }}/>
          )}
          <DocBody
            view={effectiveView}
            markerStyle={markerStyle}
            isSharedView={isSharedView}
            showDeltas={showDeltas}
            deltas={cfg.deltas}
            mode={mode}/>
        </div>

        <RightRail state={state} view={effectiveView}/>
      </div>

      {modalOpen && (
        <YP_ShareModal
          onClose={() => setModalOpen(false)}
          shareState={cfg.share === "pending" ? "pending" : "new"}
          deltas={cfg.deltas.length ? cfg.deltas : window.YP_DELTAS}
          layout={modalLayout}
          onConfirm={() => { setModalOpen(false); }}/>
      )}
    </div>
  );
}

/* ========================== TOP BAR ========================== */
function TopBar({ state, cfg, view, setView, mode, setMode, hasShared, onOpenShare, onOpenPending, onCycleState }) {
  const V = window.YP_VERSIONS[state];
  return (
    <header className="flex items-center justify-between px-5 flex-shrink-0"
      style={{ height: 56, borderBottom: `1px solid ${T.LINE}`, background: "#FFFFFF" }}>
      <div className="flex items-center gap-2 min-w-0 flex-1" style={{ minWidth: 0 }}>
        <Wordmark small/>
        <span style={{ color: "#E5E7EB", flexShrink: 0 }}>/</span>
        <div className="flex items-center gap-2 text-[12.5px] min-w-0 flex-1" style={{ minWidth: 0 }}>
          <span className="hidden md:inline whitespace-nowrap" style={{ color: T.SUB }}>Your picture</span>
          <ChevronRight size={12} style={{ color: "#D4D4D4", flexShrink: 0 }} className="hidden md:inline"/>
          <span className="whitespace-nowrap" style={{ color: T.INK, fontWeight: 600 }}>Sarah</span>
          <div className="ml-1 flex-shrink-0">
            <YP_ViewDropdown view={view} setView={setView} hasShared={hasShared}/>
          </div>
          {cfg.share === "pending" && view === "private" && (
            <div className="ml-1 flex-shrink-0">
              <YP_PendingPill count={cfg.deltas.length} onClick={onOpenPending}/>
            </div>
          )}
          {view === "shared" && (
            <span className="chip ml-1 flex-shrink-0" style={{ background: "#EEF2F6", color: "#0369A1" }}>
              Read-only
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        {view === "private" && (
          <div className="hidden md:inline-flex items-center rounded-md p-0.5" style={{ background: "#F3F4F6", border: `1px solid ${T.LINE}` }}>
            {[{k:"doc",l:"Read",i:<FileText size={12}/>},{k:"edit",l:"Edit",i:<Edit size={12}/>}].map(t => {
              const on = mode === t.k;
              return (
                <button key={t.k} onClick={() => setMode(t.k)}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11.5px] font-medium"
                  style={{ background: on ? "#FFFFFF" : "transparent", color: on ? T.INK : T.SUB,
                           boxShadow: on ? "0 1px 2px rgba(0,0,0,0.06)" : "none" }}>
                  {t.i}{t.l}
                </button>
              );
            })}
          </div>
        )}
        <button className="hidden lg:inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium"
          style={{ borderColor: T.LINE, background: "#FFFFFF", color: T.INK }}>
          <History size={13}/> {cfg.version}
        </button>
        <YP_ShareCTA
          shareState={cfg.share}
          deltaCount={cfg.deltas.length}
          version={cfg.version}
          date={window.YP_VERSIONS[state].date}
          onOpen={onOpenShare}/>
        <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
        <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold flex-shrink-0"
          style={{ background: T.ACCENT }}>SJ</div>
      </div>
    </header>
  );
}

/* ========================== CHAPTER RAIL ========================== */
function ChapterRail({ active, setActive, version }) {
  return (
    <aside className="flex-shrink-0 flex flex-col" style={{
      width: 240, borderRight: `1px solid ${T.LINE}`, background: "#FAFAFA"
    }}>
      <div className="px-4 py-3.5">
        <div className="label-xs mb-2" style={{ color: T.MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: T.INK }}>Sarah's Picture</div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full" style={{ width: "100%", background: T.ACCENT }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 11, color: T.ACCENT, fontWeight: 600 }}>{version}</span>
        </div>
      </div>
      <div className="px-2 pb-3 flex-1 overflow-y-auto nice-scroll">
        {window.YP_CHAPTERS.map(c => {
          const isActive = active === c.n;
          return (
            <button key={c.n} onClick={() => setActive(c.n)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{ background: isActive ? "#EEF1F0" : "transparent",
                       color: T.INK, fontSize: 12.5, fontWeight: isActive ? 600 : 500 }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: T.MUTE, width: 14 }}>{c.n}</span>
              <span className="flex-1 truncate">{c.title}</span>
              <Check size={11} style={{ color: T.ACCENT }} strokeWidth={2.5}/>
            </button>
          );
        })}
      </div>
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
        style={{ color: T.SUB, borderTop: `1px solid ${T.LINE}` }}>
        <LifeBuoy size={12}/> Get support
      </div>
    </aside>
  );
}

/* ========================== DOC BODY ========================== */
function DocBody({ view, markerStyle, isSharedView, showDeltas, deltas, mode }) {
  const deltaByItem = useMemo(() => Object.fromEntries(deltas.map(d => [d.itemId, d])), [deltas]);
  const itemsByCh = useMemo(() => {
    const m = {};
    window.YP_ITEMS.forEach(i => { (m[i.ch] ||= []).push(i); });
    return m;
  }, []);
  const activeCh = 2; // For demo simplicity, mirror rail

  return (
    <div className="max-w-[860px] mx-auto px-8 py-10" style={{ position: "relative", zIndex: 1 }}>
      {/* Document title */}
      <div className="mb-1 flex items-center gap-2 flex-wrap">
        <span className="label-xs" style={{ color: T.MUTE }}>Chapter 2</span>
        {isSharedView && (
          <span className="chip" style={{ background: "#EEF2F6", color: "#0369A1", fontSize: 9.5 }}>
            As Mark sees it
          </span>
        )}
      </div>
      <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.015em", color: T.INK }}>The home</h1>
      <p className="mt-2" style={{ fontSize: 14, color: T.SUB, lineHeight: 1.6, maxWidth: 620 }}>
        {isSharedView
          ? "This is exactly what Mark is looking at. Your in-progress edits are hidden until you share them."
          : "Your working picture. Anything you change stays private until you share the update."}
      </p>

      {/* Items list — grouped in "sections" */}
      <div className="mt-8 flex flex-col gap-6">
        <ItemGroup label="Property"    items={itemsByCh[2]} deltas={deltaByItem} showDelta={showDeltas} markerStyle={markerStyle}/>
        <ItemGroup label="Pensions"    items={itemsByCh[3]} deltas={deltaByItem} showDelta={showDeltas} markerStyle={markerStyle}/>
        <ItemGroup label="Savings"     items={itemsByCh[4]} deltas={deltaByItem} showDelta={showDeltas} markerStyle={markerStyle}/>
        <ItemGroup label="Income"      items={itemsByCh[7]} deltas={deltaByItem} showDelta={showDeltas} markerStyle={markerStyle}/>
      </div>

      {/* Footer stamp */}
      <div className="mt-10 pt-5" style={{ borderTop: `1px dashed ${T.LINE}`, fontSize: 11.5, color: T.MUTE }}>
        {isSharedView ? "Shared with Mark · v1 · 14 Nov 2025" : "Private working picture"}
      </div>
    </div>
  );
}

function ItemGroup({ label, items, deltas, showDelta, markerStyle }) {
  if (!items || items.length === 0) return null;
  return (
    <section>
      <div className="label-xs mb-2" style={{ color: T.MUTE }}>{label}</div>
      <div className="flex flex-col gap-1.5">
        {items.map(i => (
          <YP_ItemRow
            key={i.id}
            item={i}
            delta={deltas[i.id]}
            showDelta={showDelta}
            markerStyle={markerStyle}/>
        ))}
      </div>
    </section>
  );
}

/* ========================== RIGHT RAIL ========================== */
function RightRail({ state, view }) {
  const V = window.YP_VERSIONS[state];
  return (
    <aside className="flex-shrink-0 flex flex-col" style={{
      width: 308, borderLeft: `1px solid ${T.LINE}`, background: "#FAFAFA"
    }}>
      <div className="p-4" style={{ borderBottom: `1px solid ${T.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: T.MUTE }}>Snapshot</div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
          {[
            ["Net position","£54,560",T.INK],
            ["Assets","£282,240",T.INK],
            ["Debts","(£227,680)",T.DANGER],
            ["Monthly gap","(£892)",T.DANGER]
          ].map(([k,v,c],i)=>(
            <div key={i} className="flex items-baseline justify-between gap-2">
              <span className="whitespace-nowrap" style={{ fontSize: 11.5, color: T.SUB }}>{k}</span>
              <span className="tabular-nums whitespace-nowrap" style={{ fontSize: 12.5, fontWeight: 600, color: c }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4" style={{ borderBottom: `1px solid ${T.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: T.MUTE }}>Version</div>
        <div style={{ fontSize: 12.5, color: T.INK, fontWeight: 500 }}>{V.v}</div>
        <div className="mt-0.5" style={{ fontSize: 11.5, color: T.MUTE }}>{V.stamp}</div>
      </div>

      {state === "priv_delta" && (
        <div className="p-4" style={{ borderBottom: `1px solid ${T.LINE}`, background: "#FFFBEB" }}>
          <div className="label-xs mb-1.5" style={{ color: T.AMBER }}>Held back</div>
          <div style={{ fontSize: 12.5, color: T.INK, lineHeight: 1.5 }}>
            {window.YP_DELTAS.length} {window.YP_DELTAS.length === 1 ? "update" : "updates"} made since last share.
            Click <em>Share updates with Mark</em> to review and send.
          </div>
        </div>
      )}

      <div className="p-4 flex-1">
        <div className="label-xs mb-2" style={{ color: T.MUTE }}>Activity</div>
        <ul className="flex flex-col gap-2.5" style={{ fontSize: 11.5, color: T.SUB }}>
          {state === "priv_v0" && (
            <>
              <ActItem who="You" time="just now" text="Added Vanguard ISA"/>
              <ActItem who="You" time="2h ago" text="Marked 'Children' as complete"/>
              <ActItem who="You" time="this morning" text="Linked Halifax joint account"/>
            </>
          )}
          {state === "priv_v1" && (
            <>
              <ActItem who="You" time="14 Nov" text="Shared v1 with Mark"/>
              <ActItem who="You" time="14 Nov" text="Finalised all chapters"/>
              <ActItem who="You" time="12 Nov" text="Added payslip evidence"/>
            </>
          )}
          {state === "priv_delta" && (
            <>
              <ActItem who="You" time="today" text="Updated home value → £510k"/>
              <ActItem who="You" time="yesterday" text="Added freelance income"/>
              <ActItem who="You" time="14 Nov" text="Shared v1 with Mark"/>
            </>
          )}
          {state === "shared" && (
            <>
              <ActItem who="Mark" time="18 Nov" text="Opened your picture" tone="mark"/>
              <ActItem who="You" time="14 Nov" text="Shared v1 with Mark"/>
              <ActItem who="You" time="14 Nov" text="Finalised all chapters"/>
            </>
          )}
        </ul>
      </div>
    </aside>
  );
}

function ActItem({ who, time, text, tone }) {
  return (
    <li className="flex items-start gap-2">
      <span className="rounded-full flex-shrink-0" style={{
        width: 6, height: 6, marginTop: 6,
        background: tone === "mark" ? "#7E5A4E" : "#D4D4D4"
      }}/>
      <span>
        <span style={{ color: T.INK, fontWeight: 500 }}>{who}</span>
        <span style={{ color: T.MUTE }}> · {time}</span>
        <br/>
        <span>{text}</span>
      </span>
    </li>
  );
}

Object.assign(window, { YPShell });
})();
