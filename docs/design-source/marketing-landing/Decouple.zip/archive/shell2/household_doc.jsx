/* Household Picture — unified document v2.0 with 4 item states */
(function(){
const { useState } = React;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";
const AMBER_BG = "#FFF7ED", AMBER_BORDER = "#FBD3A5", AMBER_INK = "#9A4E0A";
const BLUE_BG  = "#EFF6FF", BLUE_BORDER  = "#BFD7F7", BLUE_INK  = "#1E4080";
const GAP_BG   = "#F9FAFB", GAP_BORDER   = "#E5E7EB", GAP_INK   = "#6B7280";

const SARAH = "#2F6D5F", MARK = "#7E5A4E";

/* ---- icons ---- */
const I = (ch, p={}) => (
  <svg width={p.s||12} height={p.s||12} viewBox="0 0 24 24" fill="none"
       stroke={p.c||"currentColor"} strokeWidth={p.w||2}
       strokeLinecap="round" strokeLinejoin="round">{ch}</svg>
);
const CheckI = (p) => I(<polyline points="5 12 10 17 19 7"/>, p);
const ArrowI = (p) => I(<><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></>, p);
const Pin = (p) => I(<><path d="M21.44 11.05 12.25 20.24a6 6 0 0 1-8.49-8.49L12.83 2.68a4 4 0 0 1 5.66 5.66L9.41 17.41a2 2 0 0 1-2.83-2.83l8.49-8.49"/></>, p);

/* evidence icon rendered inline */
function Evidence({ kind }) {
  if (kind === "doc")  return <span title="document" style={{ fontSize: 11 }}>📎</span>;
  if (kind === "self") return <span title="self-declared" style={{ fontSize: 11 }}>📝</span>;
  if (kind === "pdf")  return <span title="statement" style={{ fontSize: 11 }}>📄</span>;
  return null;
}

function WhoChip({ who }) {
  const isSarah = who === "Sarah";
  return (
    <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
      <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
            style={{ width: 16, height: 16, background: isSarah ? SARAH : MARK, fontSize: 9 }}>
        {isSarah ? "S" : "M"}
      </span>
      <span style={{ fontSize: 12.5, color: INK, fontWeight: 500 }}>{who}</span>
    </span>
  );
}

/* ============================================================
   ITEM ROW — 4 states
   ============================================================ */

function AgreedRow({ label, value, evidence, bothConfirmed, sub }) {
  return (
    <div className="flex items-baseline gap-3 py-2" style={{ borderBottom: `1px dashed ${LINE}` }}>
      <span className="flex-shrink-0 mt-0.5">
        <CheckI s={12} c={ACCENT} w={2.5}/>
      </span>
      <div className="flex-1 min-w-0">
        <span style={{ fontSize: 14, color: INK }}>{label}</span>
        {sub && <span style={{ fontSize: 12, color: MUTE, marginLeft: 6 }}>· {sub}</span>}
        {bothConfirmed && (
          <span style={{ fontSize: 11.5, color: MUTE, marginLeft: 8 }}>agreed by both</span>
        )}
      </div>
      {value && (
        <div className="flex items-center gap-1.5">
          {evidence && <Evidence kind={evidence}/>}
          <span className="tabular-nums whitespace-nowrap" style={{ fontSize: 13.5, fontWeight: 500, color: INK }}>{value}</span>
        </div>
      )}
    </div>
  );
}

function ContestedRow({ label, sarah, mark, diff, onDiscuss, highlighted }) {
  return (
    <div className="my-2 rounded-lg p-3 transition"
         style={{
           background: AMBER_BG, border: `1px solid ${AMBER_BORDER}`,
           boxShadow: highlighted ? `0 0 0 3px ${AMBER_BORDER}` : "none"
         }}>
      <div className="flex items-center gap-2 mb-2">
        <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
              style={{ width: 16, height: 16, background: "#FCE7C2", color: AMBER_INK, fontSize: 10.5, fontWeight: 700 }}>!</span>
        <span style={{ fontSize: 13.5, fontWeight: 600, color: INK }}>{label}</span>
        <span className="ml-auto text-[11px] font-medium" style={{ color: AMBER_INK }}>Values differ by {diff}</span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <ClaimCard claim={sarah} who="Sarah"/>
        <ClaimCard claim={mark}  who="Mark"/>
      </div>
      <div className="mt-2.5 flex items-center justify-between">
        <span style={{ fontSize: 11.5, color: AMBER_INK }}>Resolve together — doesn't need to be a debate.</span>
        <button onClick={onDiscuss}
          className="inline-flex items-center gap-1 h-7 px-2.5 rounded-md text-[11.5px] font-semibold"
          style={{ background: "#FFFFFF", color: AMBER_INK, border: `1px solid ${AMBER_BORDER}` }}>
          Discuss this <ArrowI s={11}/>
        </button>
      </div>
    </div>
  );
}

function ClaimCard({ claim, who }) {
  return (
    <div className="rounded-md bg-white p-2.5" style={{ border: `1px solid #F1E6D0` }}>
      <div className="flex items-center justify-between mb-1.5">
        <WhoChip who={who}/>
        <Evidence kind={claim.evidence}/>
      </div>
      <div className="tabular-nums" style={{ fontSize: 15, fontWeight: 600, color: INK }}>{claim.value}</div>
      {claim.note && <div style={{ fontSize: 11, color: SUB, marginTop: 1, lineHeight: 1.4 }}>"{claim.note}"</div>}
    </div>
  );
}

function NewRow({ label, disclosedBy, value, evidence, note, onConfirm, onQuery, resolved }) {
  if (resolved) {
    return <AgreedRow label={label} value={value} evidence={evidence} bothConfirmed/>;
  }
  return (
    <div className="my-2 rounded-lg p-3"
         style={{ background: BLUE_BG, border: `1px solid ${BLUE_BORDER}` }}>
      <div className="flex items-start gap-2">
        <span className="inline-flex items-center justify-center rounded-full flex-shrink-0 mt-0.5"
              style={{ width: 16, height: 16, background: "#CFE0F7", color: BLUE_INK, fontSize: 10, fontWeight: 700 }}>•</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-2 flex-wrap">
            <span style={{ fontSize: 13.5, fontWeight: 600, color: INK }}>{label}</span>
            <span className="text-[11px]" style={{ color: BLUE_INK }}>New — disclosed by</span>
            <WhoChip who={disclosedBy}/>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            {evidence && <Evidence kind={evidence}/>}
            <span className="tabular-nums" style={{ fontSize: 14.5, fontWeight: 600, color: INK }}>{value}</span>
          </div>
          {note && <div style={{ fontSize: 11.5, color: SUB, marginTop: 2, lineHeight: 1.45 }}>"{note}"</div>}
        </div>
        <div className="flex flex-col gap-1.5 flex-shrink-0">
          <button onClick={onConfirm}
            className="h-7 px-2.5 rounded-md text-[11.5px] font-semibold whitespace-nowrap"
            style={{ background: BLUE_INK, color: "#FFFFFF" }}>
            Confirm I knew
          </button>
          <button onClick={onQuery}
            className="h-7 px-2.5 rounded-md text-[11.5px] font-semibold whitespace-nowrap bg-white"
            style={{ border: `1px solid ${BLUE_BORDER}`, color: BLUE_INK }}>
            Query
          </button>
        </div>
      </div>
    </div>
  );
}

function GapRow({ label, note, onAdd }) {
  return (
    <div className="my-2 rounded-lg p-3"
         style={{ background: GAP_BG, border: `1px dashed ${GAP_BORDER}` }}>
      <div className="flex items-center gap-2">
        <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
              style={{ width: 16, height: 16, background: "#E5E7EB", color: GAP_INK, fontSize: 10, fontWeight: 700 }}>?</span>
        <span style={{ fontSize: 13.5, fontWeight: 600, color: INK }}>{label}</span>
        <span className="ml-auto"/>
        <button onClick={onAdd}
          className="h-7 px-2.5 rounded-md text-[11.5px] font-semibold bg-white whitespace-nowrap"
          style={{ border: `1px solid ${GAP_BORDER}`, color: INK }}>
          Add this
        </button>
      </div>
      {note && <div style={{ fontSize: 11.5, color: SUB, marginTop: 3, lineHeight: 1.45, paddingLeft: 24 }}>{note}</div>}
    </div>
  );
}

/* ============================================================
   SECTION wrapper
   ============================================================ */
function Section({ n, title, meta, children }) {
  return (
    <section className="mb-6">
      <div className="flex items-baseline gap-3 py-1.5 mb-1">
        <span className="label-xs tabular-nums" style={{ color: MUTE, width: 22 }}>§{n}</span>
        <h2 style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em", color: INK }}>{title}</h2>
        {meta && <span style={{ fontSize: 12, color: MUTE }}>— {meta}</span>}
      </div>
      <div className="pl-[34px] pr-1" style={{ borderLeft: `2px solid ${LINE}` }}>
        {children}
      </div>
    </section>
  );
}

/* ============================================================
   DOCUMENT HEADER with status badges
   ============================================================ */
function DocHeader({ stats, readonly, onResolveAll }) {
  const total = stats.agreed + stats.contested + stats.newItems + stats.gaps + stats.resolvedDuringSession;
  const attention = stats.contested + stats.newItems + stats.gaps;
  const allAgreed = attention === 0;
  return (
    <div className="mb-8 pb-6" style={{ borderBottom: `1px solid ${LINE}` }}>
      <div className="flex items-baseline justify-between">
        <div className="label-xs" style={{ color: MUTE }}>Phase 3 · Agreeing the facts</div>
        <span className="chip" style={{ background: allAgreed ? "#D1FAE5" : "#FEF3C7", color: allAgreed ? "#065F46" : "#92400E" }}>
          v2.0 {allAgreed ? "· COMPLETE" : "· UNIFIED"}
        </span>
      </div>
      <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15, marginTop: 4 }}>
        Our Household Picture
      </h1>
      <div style={{ fontSize: 13, color: SUB, marginTop: 4 }}>Sarah Johnson & Mark Johnson · generated 17 April 2026</div>

      {/* status row */}
      <div className="mt-5 grid grid-cols-4 gap-2">
        <StatusCard icon="✓" tone="green" n={stats.agreed + stats.resolvedDuringSession} label="agreed by both"/>
        <StatusCard icon="⚠" tone="amber" n={stats.contested} label="values differ"/>
        <StatusCard icon="•" tone="blue"  n={stats.newItems}  label="new to you"/>
        <StatusCard icon="?" tone="grey"  n={stats.gaps}      label="gap to address"/>
      </div>

      {!allAgreed && !readonly && (
        <div className="mt-4 rounded-lg p-3 flex items-center gap-3"
             style={{ background: "#F4F7FB", border: `1px solid #DCE4F0` }}>
          <div className="flex-1">
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "#1E4080" }}>
              {attention} items need attention before you can start a proposal
            </div>
            <div style={{ fontSize: 12, color: "#3557A0", marginTop: 1 }}>
              Work through them one at a time — no rush.
            </div>
          </div>
          <button onClick={onResolveAll}
            className="h-8 px-3 rounded-md text-[12.5px] font-semibold text-white inline-flex items-center gap-1.5"
            style={{ background: "#1E4080" }}>
            Resolve all <ArrowI s={11}/>
          </button>
        </div>
      )}

      {allAgreed && !readonly && (
        <div className="mt-4 rounded-lg p-3 flex items-center gap-3"
             style={{ background: "#ECF6F0", border: `1px solid #C7E4D1` }}>
          <div className="flex-1">
            <div style={{ fontSize: 13.5, fontWeight: 600, color: "#0A6B39" }}>
              🎉 Your facts are agreed. Ready to discuss settlement.
            </div>
            <div style={{ fontSize: 12, color: "#2F6D5F", marginTop: 1 }}>All 22 items confirmed by both parties.</div>
          </div>
          <button className="h-8 px-3 rounded-md text-[12.5px] font-semibold text-white"
            style={{ background: ACCENT }}>
            Start a proposal →
          </button>
        </div>
      )}
    </div>
  );
}

function StatusCard({ icon, tone, n, label }) {
  const tones = {
    green: { bg: "#ECF6F0", border: "#C7E4D1", ink: "#0A6B39" },
    amber: { bg: AMBER_BG,  border: AMBER_BORDER, ink: AMBER_INK },
    blue:  { bg: BLUE_BG,   border: BLUE_BORDER,  ink: BLUE_INK },
    grey:  { bg: GAP_BG,    border: GAP_BORDER,   ink: GAP_INK }
  }[tone];
  return (
    <div className="rounded-lg px-3 py-2" style={{ background: tones.bg, border: `1px solid ${tones.border}` }}>
      <div className="flex items-baseline gap-1.5">
        <span className="tabular-nums" style={{ fontSize: 20, fontWeight: 700, color: tones.ink }}>{n}</span>
        <span style={{ fontSize: 13, color: tones.ink, fontWeight: 700 }}>{icon}</span>
      </div>
      <div style={{ fontSize: 11, color: tones.ink, fontWeight: 500, marginTop: -2 }}>{label}</div>
    </div>
  );
}

/* ============================================================
   DOCUMENT
   ============================================================ */
function HouseholdDoc({ itemStates, setItemStates, onDiscuss, readonly, showCallout, onDismissCallout, onResolveAll }) {
  /* compute stats from itemStates */
  const st = computeStats(itemStates);

  const isResolved = (id) => !!itemStates[id]?.resolved;
  const wrap = (id, node) => {
    if (isResolved(id)) return null; /* replaced by AgreedRow */
    return node;
  };
  const maybeResolved = (id, label, value, evidence) => {
    if (isResolved(id)) return <AgreedRow label={label} value={value} evidence={evidence} bothConfirmed sub="just confirmed"/>;
    return null;
  };

  return (
    <div className="max-w-[760px] mx-auto px-10 py-10" style={{ color: INK }}>
      <DocHeader stats={st} readonly={readonly} onResolveAll={onResolveAll}/>

      {showCallout && !readonly && (
        <div className="mb-7 rounded-xl p-4 flex items-start gap-3"
             style={{ background: "#FCFBF7", border: `1px solid #ECE6D2` }}>
          <div className="flex-shrink-0 mt-0.5" style={{ fontSize: 18 }}>🕊️</div>
          <div className="flex-1">
            <div style={{ fontSize: 14, fontWeight: 600, color: INK, letterSpacing: "-0.005em" }}>
              This is the first time you've both seen the same picture.
            </div>
            <div style={{ fontSize: 12.5, color: SUB, lineHeight: 1.55, marginTop: 2 }}>
              Take your time. There's no rush — and no judgement. You can come back to any item later.
            </div>
          </div>
          <button onClick={onDismissCallout} className="flex-shrink-0 text-[11.5px] font-medium px-2 py-1 rounded hover:bg-[#F3F0E5]"
                  style={{ color: SUB }}>Got it</button>
        </div>
      )}

      <Section n={1} title="The children">
        <AgreedRow label="Emma (7) and Jake (4) · primary care: Sarah" bothConfirmed/>
        <AgreedRow label="Bright Horizons Nursery" value="£600 / mo" evidence="doc" bothConfirmed/>
      </Section>

      <Section n={2} title="The home" meta="12 Oak Road, Exeter · joint ownership">
        {maybeResolved("home_value", "Property value", itemStates.home_value?.resolvedValue || "£465,000", "doc")}
        {wrap("home_value",
          <ContestedRow label="Property value"
            diff="£30,000"
            sarah={{ value: "£450,000", evidence: "self", note: "estimated, 31 March" }}
            mark={{  value: "£480,000", evidence: "self", note: "Recent valuation from agent" }}
            onDiscuss={() => onDiscuss("home_value")}
            highlighted={itemStates.home_value?.highlight}/>
        )}
        <AgreedRow label="Mortgage balance — Halifax" value="£220,000" evidence="doc" bothConfirmed/>
        <AgreedRow label="Net equity (calculated)" value="£230,000 – £260,000" sub="range pending agreement"/>
        <AgreedRow label="Ownership · joint" bothConfirmed/>
        <AgreedRow label="Occupation · Sarah + children (Mark moved out)" bothConfirmed/>
      </Section>

      <Section n={3} title="Pensions">
        <AgreedRow label="Sarah's NHS Pension — CETV" value="£180,412" evidence="pdf" bothConfirmed/>
        {maybeResolved("mark_nest", "Mark's NEST Pension — CETV", "£12,000", "self")}
        {wrap("mark_nest",
          <NewRow label="Mark's NEST Pension" disclosedBy="Mark"
            value="£12,000" evidence="self"
            note="Workplace defined contribution, opened 2019"
            onConfirm={() => setItemStates(s => ({ ...s, mark_nest: { resolved: true } }))}
            onQuery={() => onDiscuss("mark_nest")}/>
        )}
      </Section>

      <Section n={4} title="Savings & investments">
        {maybeResolved("joint_barclays", "Joint savings — Barclays", itemStates.joint_barclays?.resolvedValue || "£10,000", "doc")}
        {wrap("joint_barclays",
          <ContestedRow label="Joint savings — Barclays"
            diff="£4,000"
            sarah={{ value: "£12,000", evidence: "doc",  note: "statement 31 March" }}
            mark={{  value: "£8,000",  evidence: "self", note: "Barclays app showed £8k — maybe £4k taken out for tax?" }}
            onDiscuss={() => onDiscuss("joint_barclays")}
            highlighted={itemStates.joint_barclays?.highlight}/>
        )}
        <AgreedRow label="Sarah's Monzo" value="£1,240" evidence="doc" bothConfirmed/>
        <AgreedRow label="Sarah's Hargreaves Lansdown ISA" value="£6,000" evidence="self" bothConfirmed/>
        {maybeResolved("mark_hsbc", "Mark's HSBC current", "£3,800", "doc")}
        {wrap("mark_hsbc",
          <NewRow label="Mark's HSBC current account" disclosedBy="Mark" value="£3,800" evidence="doc"
            onConfirm={() => setItemStates(s => ({ ...s, mark_hsbc: { resolved: true } }))}
            onQuery={() => onDiscuss("mark_hsbc")}/>
        )}
        {maybeResolved("mark_hl_isa", "Mark's Hargreaves Lansdown ISA", "£15,000", "doc")}
        {wrap("mark_hl_isa",
          <NewRow label="Mark's Hargreaves Lansdown ISA" disclosedBy="Mark" value="£15,000" evidence="doc"
            note="Stocks & shares ISA, opened 2022"
            onConfirm={() => setItemStates(s => ({ ...s, mark_hl_isa: { resolved: true } }))}
            onQuery={() => onDiscuss("mark_hl_isa")}/>
        )}
      </Section>

      <Section n={5} title="Vehicles & other assets">
        <AgreedRow label="Sarah's Ford Escort (2019) · £8,000 − £4,200 finance" value="net £3,800" bothConfirmed/>
        <AgreedRow label="Mark's BMW 3 Series (2021) · £18,000 − £12,000 finance" value="net £6,000" bothConfirmed/>
        <AgreedRow label="Life insurance — L&G surrender value" value="£4,500" bothConfirmed/>
      </Section>

      <Section n={6} title="Debts">
        <AgreedRow label="Sarah's Barclaycard" value="(£3,200)" evidence="self" bothConfirmed/>
        <AgreedRow label="Sarah's Klarna" value="(£280)" evidence="doc" bothConfirmed/>
        {maybeResolved("mark_amex", "Mark's Amex", "(£5,800)", "self")}
        {wrap("mark_amex",
          <NewRow label="Mark's Amex" disclosedBy="Mark" value="(£5,800)" evidence="self"
            note="Rolling balance, paid down monthly"
            onConfirm={() => setItemStates(s => ({ ...s, mark_amex: { resolved: true } }))}
            onQuery={() => onDiscuss("mark_amex")}/>
        )}
        <AgreedRow label="Mark's Student Loan (SLC)" value="(£18,000)" evidence="self" sub="informational" bothConfirmed/>
      </Section>

      <Section n={7} title="Income">
        <AgreedRow label="Sarah · NHS salary" value="£2,400 / mo" evidence="doc" bothConfirmed/>
        <AgreedRow label="Sarah · Child Benefit" value="£96 / 4-weekly" evidence="doc" bothConfirmed/>
        <AgreedRow label="Mark · HSBC salary" value="£4,800 / mo" evidence="doc" bothConfirmed/>
        <div className="mt-2 p-2.5 rounded-md flex items-center gap-3"
             style={{ background: "#FAFAFA", border: `1px solid ${LINE}` }}>
          <span style={{ fontSize: 12, color: SUB }}>Income ratio</span>
          <div className="flex-1 flex h-[6px] rounded-full overflow-hidden" style={{ background: "#F1F1EE" }}>
            <div style={{ width: "33.3%", background: SARAH }}/>
            <div style={{ width: "66.7%", background: MARK }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 12, fontWeight: 600 }}>Sarah 34% · Mark 66%</span>
        </div>
      </Section>

      <Section n={8} title="Monthly spending">
        <AgreedRow label="Sarah's needs" value="£3,388 / mo" evidence="doc" bothConfirmed/>
        <AgreedRow label="Mark's needs"  value="£2,455 / mo" evidence="doc" bothConfirmed/>
        <div className="mt-2 p-3 rounded-lg"
             style={{ background: "#F4F7FB", border: `1px solid #DCE4F0` }}>
          <div style={{ fontSize: 12.5, color: "#1E4080", lineHeight: 1.55 }}>
            <b>Sarah's needs exceed her income by £892/mo.</b> Mark's income exceeds his needs by £2,345/mo.
            Relevant for maintenance discussion — noted, not decided.
          </div>
        </div>
      </Section>

      <Section n={9} title="Summary" meta="household totals">
        <GapRow label="Mark's P60 for 2025/26"
          note="Needed to confirm annual gross income for the settlement record."
          onAdd={() => {}}/>
        <div className="mt-4 rounded-xl p-4" style={{ background: "#FAFAFA", border: `1px solid ${LINE}` }}>
          <div className="grid grid-cols-2 gap-x-8 gap-y-2">
            <Line label="Total assets"    value="£243,800 – £273,800" sub="range pending property value"/>
            <Line label="Total debts"     value="(£253,480)" neg/>
            <Line label="Net household"   value="(£9,680) to £20,320" bold/>
            <Line label="Equal division"  value="−£4,840 to £10,160 each" sub="illustrative only"/>
          </div>
          <div className="mt-3 pt-3 text-[11.5px]" style={{ color: SUB, lineHeight: 1.55, borderTop: `1px solid ${LINE}` }}>
            Equal division is illustrative only. Many factors affect a fair settlement — including primary care of children, income disparity, and future needs.
          </div>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div style={{ fontSize: 12.5, color: SUB }}>
            <b style={{ color: INK }}>{st.agreed + st.resolvedDuringSession} of {st.agreed + st.resolvedDuringSession + st.contested + st.newItems + st.gaps} items agreed.</b>
            {(st.contested + st.newItems + st.gaps) > 0 && (
              <span> · {st.contested} to resolve · {st.newItems} to acknowledge · {st.gaps} gap</span>
            )}
          </div>
        </div>
      </Section>

      <div className="mt-8 pt-5 text-[11.5px]" style={{ color: MUTE, borderTop: `1px solid ${LINE}` }}>
        Generated by Decouple · v2.0 UNIFIED · viewed together by Sarah and Mark · 17 April 2026
      </div>
    </div>
  );
}

function Line({ label, value, sub, neg, bold }) {
  return (
    <div>
      <div style={{ fontSize: 12, color: SUB }}>{label}</div>
      <div className="tabular-nums mt-0.5" style={{ fontSize: bold ? 17 : 15, fontWeight: bold ? 700 : 600, color: neg ? DANGER : INK }}>{value}</div>
      {sub && <div style={{ fontSize: 10.5, color: MUTE, marginTop: 1 }}>{sub}</div>}
    </div>
  );
}

function computeStats(itemStates) {
  const contestedIds = ["home_value", "joint_barclays"];
  const newIds       = ["mark_nest", "mark_hsbc", "mark_hl_isa", "mark_amex"];
  const gapIds       = ["mark_p60"];
  const contested = contestedIds.filter(id => !itemStates[id]?.resolved).length;
  const newItems  = newIds.filter(id => !itemStates[id]?.resolved).length;
  const gaps      = gapIds.filter(id => !itemStates[id]?.resolved).length;
  const resolvedDuringSession = contestedIds.filter(id => itemStates[id]?.resolved).length
                              + newIds.filter(id => itemStates[id]?.resolved).length
                              + gapIds.filter(id => itemStates[id]?.resolved).length;
  return { agreed: 17, contested, newItems, gaps, resolvedDuringSession };
}

Object.assign(window, { HouseholdDoc, computeStats, WhoChip, Evidence, CheckI, ArrowI });
})();
