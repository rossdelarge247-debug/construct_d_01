/* Canvas shell — variant switcher + full-screen render */
(function(){
const { useState, useEffect } = React;
const { V1_ES2Schedule, V2_Kanban, V3_Diff, V4_SplitScreen, V5_Timeline } = window;
const { ReconIcons: I, ReconColors: C, RWordmark } = window;

const VARIANTS = [
  { id: "v1", name: "ES2 Schedule",        sub: "Formal two-column ledger",   Comp: V1_ES2Schedule,
    dna: "Legal-feeling mediation schedule; every line accept/challenge/evidence/counter." },
  { id: "v2", name: "Reconciliation Board", sub: "Kanban by state",           Comp: V2_Kanban,
    dna: "Cards grouped into Differs / New / Missing / Agreed. Progress is visible at a glance." },
  { id: "v3", name: "Diff View",            sub: "Sarah vs Mark, side-by-side", Comp: V3_Diff,
    dna: "GitHub-style diff: left column Sarah's picture, right column Mark's, markers show what moved." },
  { id: "v4", name: "Split-Screen",         sub: "Doc + deliberation panel",   Comp: V4_SplitScreen,
    dna: "Doc reads normally on the left; right panel deliberates the item you just clicked. AI-ordered queue." },
  { id: "v5", name: "Timeline-First",       sub: "Version history is the nav", Comp: V5_Timeline,
    dna: "Scrub through snapshots. The doc is the viewer — audit trail is the primary surface." }
];

function App() {
  const [variant, setVariant] = useState(() => localStorage.getItem("recon_variant") || "v1");
  const [paneOpen, setPaneOpen] = useState(true);
  useEffect(() => { localStorage.setItem("recon_variant", variant); }, [variant]);

  const current = VARIANTS.find(v => v.id === variant);

  return (
    <div className="flex flex-col" style={{ height: "100vh" }}>
      {/* Canvas top bar */}
      <div className="flex items-center gap-3 px-4 flex-shrink-0"
           style={{ height: 48, background: "#111315", color: "#FFFFFF" }}>
        <RWordmark/>
        <span style={{ color: "#3A3D44" }}>/</span>
        <span style={{ fontSize: 12.5, color: "#D0D4DB" }}>Reconciliation — 5 variants</span>
        <div className="ml-auto flex items-center gap-1.5">
          {VARIANTS.map(v => {
            const on = v.id === variant;
            return (
              <button key={v.id} onClick={() => setVariant(v.id)}
                className="h-7 px-3 rounded-md text-[11.5px] font-semibold transition"
                style={{
                  background: on ? "#FFFFFF" : "transparent",
                  color: on ? "#111315" : "#D0D4DB",
                  border: on ? "none" : "1px solid #2A2D33"
                }}>
                {v.name}
              </button>
            );
          })}
          <div className="w-px h-5 mx-1" style={{ background: "#2A2D33" }}/>
          <button onClick={() => setPaneOpen(!paneOpen)}
                  className="h-7 px-2.5 rounded-md text-[11.5px] font-medium"
                  style={{ color: "#D0D4DB", border: "1px solid #2A2D33" }}>
            {paneOpen ? "Hide notes" : "Show notes"}
          </button>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* variant surface */}
        <div className="flex-1 min-w-0">
          <current.Comp/>
        </div>

        {paneOpen && (
          <div style={{ width: 260, background: "#FAFAF7", borderLeft: `1px solid ${C.LINE}` }}
               className="flex-shrink-0 overflow-y-auto nice-scroll">
            <div className="p-4">
              <div className="label-xs mb-2" style={{ color: C.MUTE }}>Variant</div>
              <div style={{ fontSize: 15, fontWeight: 700, letterSpacing: "-0.005em", color: C.INK }}>{current.name}</div>
              <div style={{ fontSize: 12, color: C.SUB, marginTop: 1, fontWeight: 500 }}>{current.sub}</div>
              <div className="mt-3 rounded-md p-2.5" style={{ background: "#FFFFFF", border: `1px solid ${C.LINE}` }}>
                <div style={{ fontSize: 11.5, color: C.INK, lineHeight: 1.55 }}>{current.dna}</div>
              </div>
            </div>

            <div className="p-4" style={{ borderTop: `1px solid ${C.LINE}` }}>
              <div className="label-xs mb-2" style={{ color: C.MUTE }}>Across all variants</div>
              <div className="space-y-2" style={{ fontSize: 11.5, color: C.SUB, lineHeight: 1.55 }}>
                <LegendRow><b>4 item states</b> — agreed, differs, new, missing</LegendRow>
                <LegendRow><b>AI flags (6 kinds)</b> — cross-ref, sanity, evidence age, parity, midpoint, missing-asset</LegendRow>
                <LegendRow><b>Formal actions</b> — Accept / Challenge / Request evidence / Counter-propose</LegendRow>
                <LegendRow><b>Disclosure tracker</b> — per-party progress in every left rail</LegendRow>
              </div>
            </div>

            <div className="p-4" style={{ borderTop: `1px solid ${C.LINE}` }}>
              <div className="label-xs mb-2" style={{ color: C.MUTE }}>How they differ</div>
              <ul className="space-y-1.5" style={{ fontSize: 11.5, color: C.SUB, lineHeight: 1.5 }}>
                <li><b style={{ color: C.INK }}>V1 ES2</b>: most legal/formal, row-by-row drawer</li>
                <li><b style={{ color: C.INK }}>V2 Kanban</b>: best for seeing "what's left"</li>
                <li><b style={{ color: C.INK }}>V3 Diff</b>: best for "what did Mark change"</li>
                <li><b style={{ color: C.INK }}>V4 Split</b>: best for focused 1-item deliberation</li>
                <li><b style={{ color: C.INK }}>V5 Timeline</b>: best for audit/mediator review</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function LegendRow({ children }) {
  return <div className="flex items-start gap-1.5">
    <span style={{ color: "#6B4EE8", marginTop: 1 }}>·</span>
    <span>{children}</span>
  </div>;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
