/* V3 — Diff view. Sarah's picture | middle gutter | Mark's picture. GitHub-diff style. */
(function(){
const { useState, useMemo } = React;
const { RECON_ITEMS, RECON_DISCLOSURE, RECON_SARAH, RECON_MARK } = window;
const { Who, Evidence, StatusDot, StatusChip, AIBadge, AICard, ReconIcons: I, ReconColors: C } = window;

const CHAPTERS = [
  { n: 1, title: "Children" },
  { n: 2, title: "Home" },
  { n: 3, title: "Pensions" },
  { n: 4, title: "Savings" },
  { n: 5, title: "Vehicles" },
  { n: 6, title: "Debts" },
  { n: 7, title: "Income" },
  { n: 8, title: "Spending" },
  { n: 9, title: "Open" }
];

function V3_Diff() {
  const [states, setStates] = useState({});
  const [focus, setFocus] = useState(null);
  const statusOf = (id) => states[id]?.status || RECON_ITEMS.find(x => x.id === id)?.status;
  const setStatus = (id, s) => setStates(st => ({ ...st, [id]: { ...st[id], status: s } }));

  const items = useMemo(() => {
    const atten = RECON_ITEMS.filter(i => ["differs","new","missing","gap"].includes(statusOf(i.id)));
    const agreed = RECON_ITEMS.filter(i => statusOf(i.id) === "agreed");
    return [...atten, ...agreed];
  }, [states]);

  return (
    <div className="flex h-full" style={{ background: "#F7F7F6" }}>
      <DiffLeftRail onJump={(id) => {
        setFocus(id);
        setTimeout(() => {
          const el = document.querySelector(`[data-diff="${id}"]`);
          if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
        }, 100);
      }} statusOf={statusOf}/>

      <div className="flex-1 flex flex-col min-w-0">
        <DiffHeader statusOf={statusOf}/>
        <div className="flex-1 overflow-y-auto nice-scroll">
          {CHAPTERS.map(ch => {
            const chapterItems = items.filter(i => i.chapter === ch.n);
            if (chapterItems.length === 0) return null;
            return (
              <div key={ch.n}>
                <div className="sticky top-0 z-10 px-6 py-2 flex items-center gap-3"
                     style={{ background: "#EDEDEA", borderBottom: `1px solid ${C.LINE}`, borderTop: `1px solid ${C.LINE}` }}>
                  <span className="tabular-nums" style={{ fontSize: 11, color: C.MUTE, fontWeight: 700, letterSpacing: "0.1em" }}>§{ch.n}</span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: C.INK }}>{ch.title}</span>
                  <span className="ml-auto" style={{ fontSize: 11, color: C.MUTE }}>{chapterItems.length} items</span>
                </div>
                {chapterItems.map(item => (
                  <DiffRow key={item.id} item={item} status={statusOf(item.id)}
                           setStatus={(s) => setStatus(item.id, s)} focus={focus === item.id}/>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function DiffLeftRail({ onJump, statusOf }) {
  return (
    <div style={{ width: 260, background: "#FFFFFF", borderRight: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 flex flex-col overflow-y-auto nice-scroll">
      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-3" style={{ color: C.MUTE }}>Compare</div>
        <div className="rounded-lg p-2.5 flex items-center gap-2.5" style={{ background: "#FAFAFA", border: `1px solid ${C.LINE}` }}>
          <Who who="S" size={22}/>
          <div style={{ fontSize: 12, fontWeight: 600 }}>Sarah's v1.0</div>
        </div>
        <div className="flex items-center justify-center py-1.5" style={{ color: C.MUTE }}>
          <I.ArrowR s={14}/>
        </div>
        <div className="rounded-lg p-2.5 flex items-center gap-2.5" style={{ background: "#FAFAFA", border: `1px solid ${C.LINE}` }}>
          <Who who="M" size={22}/>
          <div style={{ fontSize: 12, fontWeight: 600 }}>Mark's v1.8</div>
        </div>
      </div>

      <div className="p-4 flex-1">
        <div className="label-xs mb-2" style={{ color: C.MUTE }}>AI attention</div>
        {RECON_ITEMS.filter(i => i.ai).slice(0, 6).map(item => (
          <button key={item.id} onClick={() => onJump(item.id)}
            className="w-full text-left rounded-md p-2 mb-1.5 transition"
            style={{ background: C.AI_BG, border: `1px solid ${C.AI_BORDER}` }}>
            <div className="flex items-center gap-1.5 mb-0.5">
              <I.Sparkle s={10} c={C.AI_INK} w={2}/>
              <StatusDot status={statusOf(item.id)} size={6}/>
              <span style={{ fontSize: 11, fontWeight: 600, color: C.INK, lineHeight: 1.3 }}>{item.label}</span>
            </div>
            <div style={{ fontSize: 10.5, color: "#3D2E7A", lineHeight: 1.4 }}>{item.ai.text.slice(0, 72)}…</div>
          </button>
        ))}
      </div>
    </div>
  );
}

function DiffHeader({ statusOf }) {
  const diff = RECON_ITEMS.filter(i => statusOf(i.id) === "differs").length;
  const added = RECON_ITEMS.filter(i => statusOf(i.id) === "new").length;
  const missing = RECON_ITEMS.filter(i => ["missing","gap"].includes(statusOf(i.id))).length;
  return (
    <div className="px-6 py-3 flex items-center gap-4 flex-shrink-0" style={{ background: "#FFFFFF", borderBottom: `1px solid ${C.LINE}` }}>
      <h1 style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em" }}>Sarah's picture → Mark's picture</h1>
      <div className="flex items-center gap-2 text-[11.5px] tabular-nums">
        <span style={{ color: C.AMBER_INK }}>~{diff} changed</span>
        <span style={{ color: C.BLUE_INK }}>+{added} added</span>
        <span style={{ color: C.PURPLE_INK }}>?{missing} missing</span>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <button className="h-7 px-2.5 rounded-md bg-white text-[11.5px] font-medium" style={{ border: `1px solid ${C.LINE}`, color: C.INK }}>
          Unified view
        </button>
        <button className="h-7 px-2.5 rounded-md text-[11.5px] font-semibold text-white" style={{ background: "#111" }}>
          Split view
        </button>
      </div>
    </div>
  );
}

function DiffRow({ item, status, setStatus, focus }) {
  const [expanded, setExpanded] = useState(false);

  const leftBg  = status === "differs" ? "rgba(47, 109, 95, 0.06)" : status === "missing" ? "rgba(107, 114, 128, 0.04)" : status === "new" ? "rgba(107, 114, 128, 0.03)" : "#FFFFFF";
  const rightBg = status === "differs" ? "rgba(126, 90, 78, 0.07)" : status === "missing" ? "rgba(107, 114, 128, 0.04)" : status === "new" ? "rgba(30, 64, 128, 0.05)" : "#FFFFFF";
  const leftMarker  = status === "differs" ? "~" : status === "missing" ? "?" : status === "new" ? "·" : " ";
  const rightMarker = status === "differs" ? "~" : status === "missing" ? "?" : status === "new" ? "+" : " ";
  const markerColor = status === "differs" ? C.AMBER_INK : status === "missing" ? C.PURPLE_INK : status === "new" ? C.BLUE_INK : C.MUTE;

  /* what to show per side */
  const sarahCell = status === "differs" ? item.sarah
    : status === "new" ? null
    : item.both || item.contributedBy === "S" ? { label: item.value, evidence: item.evidence } : null;
  const markCell = status === "differs" ? item.mark
    : status === "new" ? { label: item.value, evidence: item.evidence, note: item.note }
    : item.both || item.contributedBy === "M" ? { label: item.value, evidence: item.evidence } : null;

  return (
    <div data-diff={item.id}
         className="transition"
         style={{ borderBottom: `1px solid ${C.LINE}`, background: focus ? "#FFFBE6" : "transparent" }}>
      <button onClick={() => setExpanded(!expanded)} className="w-full text-left">
        <div className="grid grid-cols-[1fr_1fr] items-stretch">
          {/* Sarah side */}
          <div className="px-4 py-2.5 flex items-start gap-2 min-w-0" style={{ background: leftBg, borderRight: `1px solid ${C.LINE}` }}>
            <span className="tabular-nums flex-shrink-0" style={{ fontSize: 12, color: markerColor, fontWeight: 700, width: 12, textAlign: "center" }}>{leftMarker}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                <span style={{ fontSize: 12.5, fontWeight: 500, color: C.INK }}>{item.label}</span>
                {item.ai && status !== "agreed" && <AIBadge label=""/>}
              </div>
              {sarahCell ? (
                <div className="mt-1 flex items-center gap-1.5 tabular-nums" style={{ fontSize: 13, fontWeight: 600, color: C.INK }}>
                  {sarahCell.evidence && <Evidence kind={sarahCell.evidence} small/>}
                  {sarahCell.label}
                  {sarahCell.note && <span style={{ fontSize: 11, color: C.SUB, fontWeight: 400, fontStyle: "italic", marginLeft: 4 }}>"{sarahCell.note.slice(0, 30)}…"</span>}
                </div>
              ) : (
                <div style={{ fontSize: 12, color: C.MUTE, fontStyle: "italic", marginTop: 2 }}>
                  {status === "new" ? "— not in Sarah's picture" : status === "missing" ? "— not listed" : "—"}
                </div>
              )}
            </div>
          </div>

          {/* Mark side */}
          <div className="px-4 py-2.5 flex items-start gap-2 min-w-0" style={{ background: rightBg }}>
            <span className="tabular-nums flex-shrink-0" style={{ fontSize: 12, color: markerColor, fontWeight: 700, width: 12, textAlign: "center" }}>{rightMarker}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                <span style={{ fontSize: 12.5, fontWeight: 500, color: C.INK }}>{item.label}</span>
                <StatusChip status={status}/>
              </div>
              {markCell ? (
                <div className="mt-1 flex items-center gap-1.5 tabular-nums" style={{ fontSize: 13, fontWeight: 600, color: C.INK }}>
                  {markCell.evidence && <Evidence kind={markCell.evidence} small/>}
                  {markCell.label}
                  {markCell.note && <span style={{ fontSize: 11, color: C.SUB, fontWeight: 400, fontStyle: "italic", marginLeft: 4 }}>"{markCell.note.slice(0, 30)}…"</span>}
                </div>
              ) : (
                <div style={{ fontSize: 12, color: C.MUTE, fontStyle: "italic", marginTop: 2 }}>
                  {status === "missing" ? "— not listed" : "—"}
                </div>
              )}
            </div>
          </div>
        </div>
      </button>

      {expanded && status !== "agreed" && (
        <div className="px-4 py-3" style={{ background: "#FAFAF7", borderTop: `1px dashed ${C.LINE}` }}>
          {item.ai && <div className="mb-2.5"><AICard flag={item.ai} inline onApply={() => setStatus("agreed")} onDismiss={() => {}}/></div>}
          <div className="flex items-center gap-1.5 flex-wrap">
            <MiniBtn kind="accept" onClick={() => setStatus("agreed")}>Accept</MiniBtn>
            <MiniBtn kind="challenge">Challenge</MiniBtn>
            <MiniBtn kind="evidence">Request evidence</MiniBtn>
            <MiniBtn kind="counter">Counter-propose</MiniBtn>
            <span className="ml-auto text-[11px]" style={{ color: C.MUTE }}>Or comment inline below</span>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniBtn({ kind, children, onClick }) {
  const styles = {
    accept:    { bg: C.ACCENT,  fg: "#FFFFFF", border: C.ACCENT },
    challenge: { bg: "#FFFFFF", fg: C.AMBER_INK, border: C.AMBER_BORDER },
    evidence:  { bg: "#FFFFFF", fg: C.BLUE_INK, border: C.BLUE_BORDER },
    counter:   { bg: "#FFFFFF", fg: C.INK, border: C.LINE }
  }[kind];
  return (
    <button onClick={onClick} className="rounded text-[11px] font-semibold" style={{ background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}`, padding: "4px 9px" }}>
      {children}
    </button>
  );
}

Object.assign(window, { V3_Diff });
})();
