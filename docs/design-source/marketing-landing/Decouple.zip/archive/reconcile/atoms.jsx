/* Shared atoms — icons, chips, avatars, person dots for all reconciliation variants */
(function(){
const { RECON_SARAH, RECON_MARK } = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";
const AMBER_BG = "#FFF7ED", AMBER_BORDER = "#FBD3A5", AMBER_INK = "#9A4E0A";
const BLUE_BG  = "#EFF6FF", BLUE_BORDER  = "#BFD7F7", BLUE_INK  = "#1E4080";
const PURPLE_BG = "#F5F3FF", PURPLE_BORDER = "#D8CFFB", PURPLE_INK = "#5B3EC0";
const GAP_BG   = "#F9FAFB", GAP_BORDER   = "#E5E7EB", GAP_INK   = "#6B7280";
const AI_BG    = "#FAF5FF", AI_BORDER    = "#E4D4FB", AI_INK    = "#6B4EE8";
const GREEN_BG = "#ECF6F0", GREEN_INK = "#0A6B39";

/* icons */
const I = (ch, p={}) => (
  <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none"
       stroke={p.c||"currentColor"} strokeWidth={p.w||1.8}
       strokeLinecap="round" strokeLinejoin="round">{ch}</svg>
);
const Check     = (p) => I(<polyline points="5 12 10 17 19 7"/>, p);
const X         = (p) => I(<><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></>, p);
const ArrowR    = (p) => I(<><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></>, p);
const ChevR     = (p) => I(<polyline points="9 6 15 12 9 18"/>, p);
const ChevD     = (p) => I(<polyline points="6 9 12 15 18 9"/>, p);
const Doc       = (p) => I(<><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="14 3 14 9 20 9"/></>, p);
const Pencil    = (p) => I(<><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4z"/></>, p);
const Paperclip = (p) => I(<path d="M21 10.5L12 19.5a5 5 0 0 1-7-7L14 3.5a3.5 3.5 0 0 1 5 5L10 17.5a2 2 0 0 1-3-3l8-8"/>, p);
const Sparkle   = (p) => I(<><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/></>, p);
const AlertI    = (p) => I(<><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><circle cx="12" cy="16" r="0.5" fill="currentColor"/></>, p);
const Plus      = (p) => I(<><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>, p);
const Eye       = (p) => I(<><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>, p);
const Filter    = (p) => I(<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>, p);
const Msg       = (p) => I(<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>, p);
const Hist      = (p) => I(<><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></>, p);
const Scale     = (p) => I(<><path d="M12 3v18M3 7h18M7 7l-3 7a5 5 0 0 0 6 0zM17 7l-3 7a5 5 0 0 0 6 0z"/></>, p);

/* Person dot */
function Who({ who, size = 18 }) {
  const S = who === "S" || who === "Sarah";
  return (
    <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
          style={{ width: size, height: size, background: S ? RECON_SARAH : RECON_MARK, fontSize: Math.round(size*0.5) }}>
      {S ? "S" : "M"}
    </span>
  );
}

function Evidence({ kind, small }) {
  const size = small ? 11 : 12;
  if (kind === "doc") return <span title="document attached" className="inline-flex items-center gap-0.5" style={{ fontSize: size, color: ACCENT }}><Paperclip s={size}/></span>;
  if (kind === "pdf") return <span title="statement" className="inline-flex items-center gap-0.5" style={{ fontSize: size, color: ACCENT }}><Doc s={size}/></span>;
  if (kind === "self") return <span title="self-declared" className="inline-flex items-center" style={{ fontSize: size, color: MUTE }}><Pencil s={size}/></span>;
  return null;
}

function StatusDot({ status, size = 8 }) {
  const c = status === "agreed" ? ACCENT
        : status === "differs"  ? "#E5B048"
        : status === "new"      ? BLUE_INK
        : status === "missing"  ? PURPLE_INK
        : GAP_INK;
  return <span className="inline-block rounded-full flex-shrink-0" style={{ width: size, height: size, background: c }}/>;
}

function StatusChip({ status }) {
  const m = {
    agreed:  { bg: GREEN_BG, fg: GREEN_INK, label: "Agreed" },
    differs: { bg: AMBER_BG, fg: AMBER_INK, label: "Differs" },
    new:     { bg: BLUE_BG,  fg: BLUE_INK,  label: "New" },
    missing: { bg: PURPLE_BG, fg: PURPLE_INK, label: "Missing?" },
    gap:     { bg: GAP_BG,   fg: GAP_INK,   label: "Gap" }
  }[status] || { bg: GAP_BG, fg: GAP_INK, label: status };
  return <span className="chip" style={{ background: m.bg, color: m.fg, fontSize: 9.5, padding: "2px 7px" }}>{m.label}</span>;
}

/* AI badge inline */
function AIBadge({ label = "AI flag" }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full"
          style={{ background: AI_BG, border: `1px solid ${AI_BORDER}`, color: AI_INK, fontSize: 10, padding: "1px 6px", fontWeight: 600, letterSpacing: "0.02em" }}>
      <Sparkle s={9} w={2}/> {label}
    </span>
  );
}

/* AI suggestion card — mediator tone */
function AICard({ flag, onApply, onDismiss, inline }) {
  const label = {
    midpoint: "Suggested resolution",
    cross_ref: "Cross-reference flag",
    sanity: "Sanity check",
    evidence: "Evidence needed",
    evidence_age: "Evidence age",
    comparability: "Comparability",
    prompt: "Missing asset?"
  }[flag.kind] || "AI observation";
  return (
    <div className="rounded-lg p-3" style={{
      background: AI_BG, border: `1px solid ${AI_BORDER}`,
      marginTop: inline ? 0 : 4
    }}>
      <div className="flex items-center gap-1.5 mb-1.5">
        <Sparkle s={12} c={AI_INK} w={2}/>
        <span style={{ fontSize: 10.5, fontWeight: 700, color: AI_INK, letterSpacing: "0.04em", textTransform: "uppercase" }}>{label}</span>
      </div>
      <div style={{ fontSize: 12.5, color: "#3D2E7A", lineHeight: 1.5 }}>{flag.text}</div>
      {(onApply || onDismiss) && (
        <div className="mt-2 flex items-center gap-1.5">
          {onApply && (
            <button onClick={onApply}
              className="h-6.5 px-2 rounded text-[11px] font-semibold"
              style={{ background: AI_INK, color: "#FFFFFF", padding: "3px 9px" }}>
              {flag.kind === "midpoint" ? "Use midpoint" : "Apply"}
            </button>
          )}
          {onDismiss && (
            <button onClick={onDismiss}
              className="h-6.5 px-2 rounded text-[11px] font-medium bg-white"
              style={{ border: `1px solid ${AI_BORDER}`, color: AI_INK, padding: "3px 9px" }}>
              Dismiss
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/* Wordmark for variants that need it */
function RWordmark() {
  return (
    <span className="inline-flex items-baseline gap-0.5" style={{ fontWeight: 700, letterSpacing: "-0.01em", fontSize: 15, color: INK }}>
      decouple<span style={{ color: "#E5484D" }}>.</span>
    </span>
  );
}

Object.assign(window, {
  ReconIcons: { Check, X, ArrowR, ChevR, ChevD, Doc, Pencil, Paperclip, Sparkle, AlertI, Plus, Eye, Filter, Msg, Hist, Scale },
  Who, Evidence, StatusDot, StatusChip, AIBadge, AICard, RWordmark,
  ReconColors: { INK, SUB, MUTE, LINE, ACCENT, DANGER, AMBER_BG, AMBER_BORDER, AMBER_INK,
                 BLUE_BG, BLUE_BORDER, BLUE_INK, PURPLE_BG, PURPLE_BORDER, PURPLE_INK,
                 GAP_BG, GAP_BORDER, GAP_INK, AI_BG, AI_BORDER, AI_INK, GREEN_BG, GREEN_INK }
});
})();
