/* V2 — Reconciliation Kanban. Cards grouped by state: Agreed / Differs / New / Missing */
(function(){
const { useState, useMemo } = React;
const { RECON_ITEMS, RECON_DISCLOSURE, RECON_ACTIVITY, reconAllFlags, RECON_SARAH, RECON_MARK } = window;
const { Who, Evidence, StatusDot, StatusChip, AIBadge, AICard, ReconIcons: I, ReconColors: C } = window;

function V2_Kanban() {
  const [states, setStates] = useState({});
  const [focus, setFocus] = useState(null);

  const statusOf = (id) => states[id]?.status || RECON_ITEMS.find(x => x.id === id)?.status;
  const setStatus = (id, status) => setStates(s => ({ ...s, [id]: { ...s[id], status } }));

  const groups = useMemo(() => {
    const g = { differs: [], new: [], missing: [], gap: [], agreed: [] };
    RECON_ITEMS.forEach(i => g[statusOf(i.id)].push(i));
    return g;
  }, [states]);

  const counts = {
    differs: groups.differs.length,
    new: groups.new.length,
    missing: groups.missing.length,
    agreed: groups.agreed.length
  };

  return (
    <div className="flex h-full" style={{ background: "#F7F7F6" }}>
      {/* LEFT RAIL */}
      <KanbanLeftRail counts={counts} onJump={(id) => {
        setFocus(id);
        setTimeout(() => {
          const el = document.querySelector(`[data-card="${id}"]`);
          if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
        }, 100);
      }}/>

      {/* CENTER */}
      <div className="flex-1 flex flex-col min-w-0">
        <KanbanHeader counts={counts}/>
        <div className="flex-1 overflow-hidden flex gap-3 p-4">
          <Column kind="differs" title="Values differ" items={groups.differs} focus={focus}
                  statusOf={statusOf} setStatus={setStatus}/>
          <Column kind="new" title="New disclosures" items={groups.new} focus={focus}
                  statusOf={statusOf} setStatus={setStatus}/>
          <Column kind="missing" title="Missing or expected" items={[...groups.missing, ...groups.gap]} focus={focus}
                  statusOf={statusOf} setStatus={setStatus}/>
          <Column kind="agreed" title="Agreed by both" items={groups.agreed} focus={focus}
                  statusOf={statusOf} setStatus={setStatus}/>
        </div>
      </div>
    </div>
  );
}

function KanbanLeftRail({ counts, onJump }) {
  const flags = reconAllFlags();
  return (
    <div style={{ width: 280, background: "#FFFFFF", borderRight: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 flex flex-col overflow-y-auto nice-scroll">
      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-3" style={{ color: C.MUTE }}>Disclosure progress</div>
        <RailDisclosure who="S"/>
        <div className="h-2"/>
        <RailDisclosure who="M"/>
      </div>

      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: C.MUTE }}>Board totals</div>
        <div className="space-y-1">
          <StatLine label="Values differ" n={counts.differs} dot="differs"/>
          <StatLine label="New disclosures" n={counts.new} dot="new"/>
          <StatLine label="Missing / expected" n={counts.missing} dot="missing"/>
          <StatLine label="Agreed" n={counts.agreed} dot="agreed"/>
        </div>
      </div>

      <div className="p-4 flex-1">
        <div className="flex items-center justify-between mb-2">
          <div className="label-xs" style={{ color: C.MUTE }}>AI attention</div>
          <AIBadge label={`${flags.length} flags`}/>
        </div>
        <div className="space-y-1.5">
          {flags.slice(0, 6).map(f => {
            const item = RECON_ITEMS.find(x => x.id === f.itemId);
            return (
              <button key={f.itemId} onClick={() => onJump(f.itemId)}
                className="w-full text-left rounded-md p-2 transition"
                style={{ background: C.AI_BG, border: `1px solid ${C.AI_BORDER}` }}
                onMouseEnter={e => e.currentTarget.style.background = "#F3EAFF"}
                onMouseLeave={e => e.currentTarget.style.background = C.AI_BG}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <I.Sparkle s={10} c={C.AI_INK} w={2}/>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.AI_INK, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                    {f.kind === "cross_ref" ? "Cross-ref" : f.kind === "sanity" ? "Sanity" : f.kind === "evidence_age" ? "Stale" : f.kind === "evidence" ? "Evidence" : f.kind === "comparability" ? "Parity" : f.kind === "midpoint" ? "Midpoint" : "Missing?"}
                  </span>
                </div>
                <div style={{ fontSize: 11, color: C.INK, fontWeight: 600, lineHeight: 1.35 }}>{item.label}</div>
                <div style={{ fontSize: 10.5, color: "#3D2E7A", lineHeight: 1.4, marginTop: 2 }}>{f.text.slice(0, 70)}…</div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function RailDisclosure({ who }) {
  const d = RECON_DISCLOSURE[who];
  const pct = Math.round((d.complete / d.total) * 100);
  return (
    <div>
      <div className="flex items-baseline justify-between mb-1">
        <div className="flex items-center gap-1.5">
          <Who who={who} size={16}/>
          <span style={{ fontSize: 12, fontWeight: 600, color: C.INK }}>{d.name}</span>
        </div>
        <span className="tabular-nums" style={{ fontSize: 11, color: C.SUB, fontWeight: 500 }}>{d.complete}/{d.total}</span>
      </div>
      <div className="h-[4px] rounded-full overflow-hidden" style={{ background: "#EDEDED" }}>
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: d.ink }}/>
      </div>
    </div>
  );
}

function StatLine({ label, n, dot }) {
  return (
    <div className="flex items-center gap-1.5">
      <StatusDot status={dot}/>
      <span style={{ fontSize: 12, color: C.INK, fontWeight: 500 }}>{label}</span>
      <span className="ml-auto tabular-nums" style={{ fontSize: 12, color: C.SUB, fontWeight: 600 }}>{n}</span>
    </div>
  );
}

function KanbanHeader({ counts }) {
  const total = RECON_ITEMS.length;
  const attn = counts.differs + counts.new + counts.missing;
  return (
    <div className="px-5 py-3.5 flex items-center gap-4 flex-shrink-0" style={{ background: "#FFFFFF", borderBottom: `1px solid ${C.LINE}` }}>
      <div>
        <h1 style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em", color: C.INK }}>Reconciliation Board</h1>
        <div style={{ fontSize: 11.5, color: C.SUB, marginTop: 1 }}>{attn} items need attention · {counts.agreed} of {total} agreed</div>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <button className="h-8 px-3 rounded-md bg-white inline-flex items-center gap-1.5 text-[12px] font-medium" style={{ border: `1px solid ${C.LINE}`, color: C.INK }}>
          <I.Hist s={12}/> Versions
        </button>
        <button className="h-8 px-3 rounded-md inline-flex items-center gap-1.5 text-[12px] font-semibold text-white" style={{ background: attn === 0 ? C.ACCENT : "#BDBDBD", cursor: attn === 0 ? "pointer" : "not-allowed" }}>
          Start a proposal →
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   COLUMN
   ============================================================ */
function Column({ kind, title, items, focus, statusOf, setStatus }) {
  const tone = {
    differs: { bg: C.AMBER_BG, border: C.AMBER_BORDER, ink: C.AMBER_INK, headBg: "#FFEED6" },
    new:     { bg: C.BLUE_BG,  border: C.BLUE_BORDER,  ink: C.BLUE_INK,  headBg: "#DDEBFE" },
    missing: { bg: C.PURPLE_BG,border: C.PURPLE_BORDER,ink: C.PURPLE_INK,headBg: "#EAE3FC" },
    agreed:  { bg: C.GREEN_BG, border: "#C7E4D1",      ink: C.GREEN_INK, headBg: "#D9EEDF" }
  }[kind];

  return (
    <div className="flex-1 min-w-0 flex flex-col rounded-xl overflow-hidden"
         style={{ background: tone.bg, border: `1px solid ${tone.border}`, minWidth: 260 }}>
      <div className="px-3 py-2.5 flex items-center gap-2" style={{ background: tone.headBg, borderBottom: `1px solid ${tone.border}` }}>
        <StatusDot status={kind === "missing" ? "missing" : kind}/>
        <span style={{ fontSize: 12.5, fontWeight: 700, color: tone.ink }}>{title}</span>
        <span className="tabular-nums ml-auto rounded-full px-2 py-0.5" style={{ fontSize: 11, color: tone.ink, background: "#FFFFFF66", fontWeight: 600 }}>{items.length}</span>
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll p-2 space-y-2">
        {items.map(item => (
          <KanbanCard key={item.id} item={item} focus={focus === item.id}
                      status={statusOf(item.id)} setStatus={(s) => setStatus(item.id, s)}/>
        ))}
        {kind === "missing" && (
          <button className="w-full py-2.5 rounded-lg text-[11.5px] font-medium flex items-center justify-center gap-1.5"
                  style={{ background: "#FFFFFF", border: `1px dashed ${tone.border}`, color: tone.ink }}>
            <I.Plus s={11}/> Add expected item
          </button>
        )}
      </div>
    </div>
  );
}

function KanbanCard({ item, status, setStatus, focus }) {
  const [expanded, setExpanded] = useState(false);
  const tone = {
    differs: { border: C.AMBER_BORDER, ring: "#FDE9B9" },
    new:     { border: C.BLUE_BORDER, ring: "#D0DEF6" },
    missing: { border: C.PURPLE_BORDER, ring: "#DFD3FA" },
    gap:     { border: C.GAP_BORDER, ring: "#E5E7EB" },
    agreed:  { border: "#C7E4D1", ring: "#C7E4D1" }
  }[status];

  return (
    <div data-card={item.id}
         className="rounded-lg bg-white p-2.5 transition"
         style={{ border: `1px solid ${tone.border}`, boxShadow: focus ? `0 0 0 3px ${tone.ring}` : "none" }}>
      <button onClick={() => setExpanded(!expanded)}
              className="w-full text-left">
        <div className="flex items-start gap-2">
          <div className="flex-1 min-w-0">
            <div style={{ fontSize: 12, fontWeight: 600, color: C.INK, lineHeight: 1.35 }}>{item.label}</div>
            {status === "differs" && (
              <div className="mt-1.5 flex items-center gap-3 text-[11.5px]">
                <span className="flex items-center gap-1 tabular-nums">
                  <Who who="S" size={14}/><span className="font-semibold">{item.sarah.label}</span>
                </span>
                <span style={{ color: C.MUTE }}>vs</span>
                <span className="flex items-center gap-1 tabular-nums">
                  <Who who="M" size={14}/><span className="font-semibold">{item.mark.label}</span>
                </span>
              </div>
            )}
            {status === "new" && (
              <div className="mt-1.5 flex items-center gap-1.5 text-[11.5px]">
                <Who who={item.contributedBy} size={14}/>
                <span style={{ color: C.MUTE }}>disclosed</span>
                {item.evidence && <Evidence kind={item.evidence} small/>}
                <span className="tabular-nums font-semibold">{item.value}</span>
              </div>
            )}
            {status === "missing" && item.ai && (
              <div className="mt-1.5 flex items-start gap-1.5" style={{ fontSize: 10.5, color: C.PURPLE_INK, lineHeight: 1.4 }}>
                <I.Sparkle s={10} c={C.PURPLE_INK} w={2}/>
                <span>{item.ai.text.slice(0, 80)}…</span>
              </div>
            )}
            {status === "gap" && (
              <div className="mt-1.5" style={{ fontSize: 11, color: C.MUTE }}>Gap — evidence needed</div>
            )}
            {status === "agreed" && (
              <div className="mt-1 tabular-nums" style={{ fontSize: 11.5, color: C.SUB, fontWeight: 500 }}>
                {item.value && <span>{item.value}</span>}
              </div>
            )}
          </div>
          {item.ai && status !== "agreed" && <AIBadge label=""/>}
        </div>
      </button>

      {expanded && status !== "agreed" && (
        <div className="mt-2.5 pt-2.5" style={{ borderTop: `1px dashed ${C.LINE}` }}>
          {item.ai && <AICard flag={item.ai} inline onApply={() => setStatus("agreed")} onDismiss={() => {}}/>}
          <div className="mt-2 flex flex-wrap gap-1">
            <MiniBtn kind="accept" onClick={() => setStatus("agreed")}>Accept</MiniBtn>
            <MiniBtn kind="challenge">Challenge</MiniBtn>
            <MiniBtn kind="evidence">Request evidence</MiniBtn>
            <MiniBtn kind="counter">Counter</MiniBtn>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniBtn({ kind, children, onClick }) {
  const styles = {
    accept:    { bg: C.ACCENT,    fg: "#FFFFFF", border: C.ACCENT },
    challenge: { bg: "#FFFFFF",   fg: C.AMBER_INK, border: C.AMBER_BORDER },
    evidence:  { bg: "#FFFFFF",   fg: C.BLUE_INK, border: C.BLUE_BORDER },
    counter:   { bg: "#FFFFFF",   fg: C.INK, border: C.LINE }
  }[kind];
  return (
    <button onClick={onClick}
      className="rounded text-[10.5px] font-semibold" style={{ background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}`, padding: "3px 7px" }}>
      {children}
    </button>
  );
}

Object.assign(window, { V2_Kanban });
})();
