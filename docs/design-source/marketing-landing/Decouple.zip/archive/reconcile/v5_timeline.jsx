/* V5 — Timeline-first. Version history is the primary nav; doc is the viewer. */
(function(){
const { useState, useMemo } = React;
const { RECON_ITEMS, RECON_VERSIONS, RECON_ACTIVITY, RECON_DISCLOSURE, RECON_SARAH, RECON_MARK } = window;
const { Who, Evidence, StatusDot, StatusChip, AIBadge, AICard, ReconIcons: I, ReconColors: C } = window;

const CHAPTERS = [
  { n: 1, title: "The children" },
  { n: 2, title: "The home" },
  { n: 3, title: "Pensions" },
  { n: 4, title: "Savings & investments" },
  { n: 5, title: "Vehicles & other" },
  { n: 6, title: "Debts" },
  { n: 7, title: "Income" },
  { n: 8, title: "Monthly spending" },
  { n: 9, title: "Open items" }
];

/* simulated per-version visible item-ids: earlier versions don't have Mark's disclosures */
const VERSION_VISIBILITY = {
  "v2.0": RECON_ITEMS.map(i => i.id),
  "v1.8": RECON_ITEMS.map(i => i.id),
  "v1.5": RECON_ITEMS.filter(i => !i.disclosedOn || i.disclosedOn === "16 Apr").map(i => i.id),
  "v1.0": RECON_ITEMS.filter(i => i.contributedBy !== "M" && !i.disclosedOn).map(i => i.id),
  "v0.8": RECON_ITEMS.filter(i => i.contributedBy !== "M" && !i.disclosedOn).map(i => i.id),
  "v0.5": RECON_ITEMS.filter(i => i.contributedBy !== "M" && !i.disclosedOn && i.chapter <= 6).map(i => i.id),
  "v0.1": RECON_ITEMS.filter(i => i.chapter === 1).map(i => i.id)
};

function V5_Timeline() {
  const [selected, setSelected] = useState("v2.0");
  const [compareTo, setCompareTo] = useState(null);
  const [states, setStates] = useState({});
  const statusOf = (id) => states[id]?.status || RECON_ITEMS.find(x => x.id === id)?.status;
  const setStatus = (id, s) => setStates(st => ({ ...st, [id]: { ...st[id], status: s } }));

  const version = RECON_VERSIONS.find(v => v.id === selected);
  const isCurrent = selected === "v2.0";
  const visibleIds = VERSION_VISIBILITY[selected] || [];

  return (
    <div className="flex flex-col h-full" style={{ background: "#0F1115" }}>
      {/* TOP scrubber */}
      <TimelineScrubber selected={selected} setSelected={setSelected} compareTo={compareTo} setCompareTo={setCompareTo}/>

      <div className="flex-1 flex min-h-0">
        {/* LEFT — version details */}
        <VersionDetails version={version} isCurrent={isCurrent} visibleCount={visibleIds.length}
                        compareTo={compareTo}/>

        {/* CENTER — doc viewer */}
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFFFFF" }}>
          {!isCurrent && (
            <div className="sticky top-0 z-10 px-6 py-2.5 flex items-center gap-3"
                 style={{ background: "#FFF7ED", borderBottom: `1px solid #FBD3A5` }}>
              <I.Hist s={14} c={C.AMBER_INK}/>
              <div className="flex-1 text-[12.5px]" style={{ color: C.AMBER_INK }}>
                Viewing <b>{selected}</b> — a snapshot from {version.date}. Read-only.
              </div>
              <button onClick={() => setSelected("v2.0")}
                      className="h-7 px-2.5 rounded-md text-[11.5px] font-semibold text-white"
                      style={{ background: C.AMBER_INK }}>
                Return to current
              </button>
            </div>
          )}
          <DocView visibleIds={visibleIds} statusOf={statusOf} setStatus={setStatus} readonly={!isCurrent} compareTo={compareTo}/>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   SCRUBBER — horizontal timeline bar across the top
   ============================================================ */
function TimelineScrubber({ selected, setSelected, compareTo, setCompareTo }) {
  const versions = [...RECON_VERSIONS].reverse(); /* oldest → newest */
  return (
    <div className="flex-shrink-0 px-6 py-4" style={{ background: "#0F1115", borderBottom: "1px solid #2A2D33" }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <I.Hist s={14} c="#9BA1AD"/>
          <span style={{ fontSize: 12.5, fontWeight: 600, color: "#FFFFFF", letterSpacing: "-0.005em" }}>Version timeline</span>
          <span className="chip" style={{ background: "#1F232B", color: "#9BA1AD", fontSize: 9.5 }}>7 snapshots</span>
        </div>
        <div className="flex items-center gap-2">
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium inline-flex items-center gap-1.5"
                  style={{ background: compareTo ? "#2A2D33" : "transparent", color: "#D0D4DB", border: "1px solid #2A2D33" }}
                  onClick={() => setCompareTo(compareTo ? null : (selected === "v2.0" ? "v1.0" : "v2.0"))}>
            <I.Scale s={12}/> {compareTo ? `Comparing to ${compareTo}` : "Compare versions"}
          </button>
          {compareTo && (
            <button onClick={() => setCompareTo(null)} className="w-7 h-7 rounded-md flex items-center justify-center" style={{ color: "#D0D4DB" }}>
              <I.X s={12}/>
            </button>
          )}
        </div>
      </div>

      {/* Scrubber track */}
      <div className="relative">
        <div className="absolute left-0 right-0 top-1/2" style={{ height: 2, background: "#2A2D33", transform: "translateY(-50%)" }}/>
        <div className="relative flex items-center justify-between">
          {versions.map(v => {
            const isSel = selected === v.id;
            const isCmp = compareTo === v.id;
            return (
              <button key={v.id} onClick={() => setSelected(v.id)}
                className="relative group flex flex-col items-center"
                style={{ width: `${100/versions.length}%` }}>
                <div className="relative z-10 flex flex-col items-center">
                  {/* Version node */}
                  <div className="rounded-full flex items-center justify-center transition"
                       style={{
                         width: isSel ? 32 : 22, height: isSel ? 32 : 22,
                         background: isSel ? "#FFFFFF" : v.who === "S" ? RECON_SARAH : v.who === "M" ? RECON_MARK : "#6B7280",
                         border: isCmp ? `2px solid #FFB74D` : "none",
                         color: isSel ? "#0F1115" : "#FFFFFF", fontSize: isSel ? 11 : 9.5, fontWeight: 700
                       }}>
                    {v.who === "Both" ? "⇌" : v.who}
                  </div>
                  <div className="mt-2 text-center">
                    <div className="tabular-nums" style={{ fontSize: 11, color: isSel ? "#FFFFFF" : "#D0D4DB", fontWeight: 700 }}>{v.id}</div>
                    <div style={{ fontSize: 9.5, color: "#8A8F99", marginTop: 1 }}>{v.date}</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   LEFT — version details + activity during this version
   ============================================================ */
function VersionDetails({ version, isCurrent, visibleCount, compareTo }) {
  const versionActivity = RECON_ACTIVITY.filter(a => a.v === version.id);
  const flags = RECON_ITEMS.filter(i => i.ai && (VERSION_VISIBILITY[version.id] || []).includes(i.id));

  return (
    <div style={{ width: 320, background: "#F7F7F6", borderRight: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 flex flex-col overflow-y-auto nice-scroll">
      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="flex items-center gap-2 mb-2">
          <span className="tabular-nums" style={{ fontSize: 18, fontWeight: 700, color: C.INK, letterSpacing: "-0.01em" }}>{version.id}</span>
          <span className="chip" style={{
            background: version.label === "UNIFIED" ? C.GREEN_BG : version.label === "SHARED" || version.label === "MARK SHARED" ? "#D1FAE5"
              : version.label === "IN PROGRESS" ? C.BLUE_BG : "#FEF3C7",
            color: version.label === "UNIFIED" ? C.GREEN_INK : version.label === "SHARED" || version.label === "MARK SHARED" ? "#065F46"
              : version.label === "IN PROGRESS" ? C.BLUE_INK : "#92400E",
            fontSize: 9.5
          }}>{version.label}</span>
          {isCurrent && <span style={{ fontSize: 10.5, color: C.ACCENT, fontWeight: 700, letterSpacing: "0.04em", textTransform: "uppercase" }}>Current</span>}
        </div>
        <div style={{ fontSize: 12.5, color: C.INK, fontWeight: 500, lineHeight: 1.5 }}>{version.note}</div>
        <div className="mt-2 flex items-center gap-2" style={{ fontSize: 11.5, color: C.SUB }}>
          <Who who={version.who === "Both" ? "S" : version.who} size={16}/>
          {version.who === "Both" ? "Sarah & Mark" : version.who === "S" ? "Sarah" : "Mark"} · {version.date}
        </div>
        <div className="mt-2 tabular-nums" style={{ fontSize: 11.5, color: C.MUTE }}>
          {visibleCount} items in this snapshot
        </div>
      </div>

      {versionActivity.length > 0 && (
        <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
          <div className="label-xs mb-2" style={{ color: C.MUTE }}>What changed</div>
          <div className="space-y-2">
            {versionActivity.map((a, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="mt-0.5 flex-shrink-0"><Who who={a.who} size={16}/></span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <KindPill kind={a.kind}/>
                    <span style={{ fontSize: 11.5, color: C.INK, fontWeight: 500 }}>{a.text}</span>
                  </div>
                  {a.detail && <div className="tabular-nums" style={{ fontSize: 11, color: C.SUB, fontWeight: 500, marginTop: 1 }}>{a.detail}</div>}
                  <div style={{ fontSize: 10, color: C.MUTE }}>{a.time.split(" · ")[1]}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {flags.length > 0 && (
        <div className="p-4 flex-1">
          <div className="flex items-center justify-between mb-2">
            <div className="label-xs" style={{ color: C.MUTE }}>AI flags in this version</div>
            <AIBadge label={`${flags.length}`}/>
          </div>
          <div className="space-y-1.5">
            {flags.map(f => (
              <div key={f.id} className="rounded-md p-2" style={{ background: C.AI_BG, border: `1px solid ${C.AI_BORDER}` }}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <StatusDot status={f.status} size={6}/>
                  <span style={{ fontSize: 11, color: C.INK, fontWeight: 600 }}>{f.label}</span>
                </div>
                <div style={{ fontSize: 10.5, color: "#3D2E7A", lineHeight: 1.4 }}>{f.ai.text.slice(0, 80)}…</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function KindPill({ kind }) {
  const m = {
    added:     { bg: C.BLUE_BG, fg: C.BLUE_INK, label: "+ added" },
    confirmed: { bg: C.GREEN_BG, fg: C.GREEN_INK, label: "✓ confirmed" },
    queried:   { bg: C.AMBER_BG, fg: C.AMBER_INK, label: "? queried" },
    shared:    { bg: "#F1F1EE", fg: C.INK, label: "→ shared" },
    open:      { bg: "#F1F1EE", fg: C.MUTE, label: "opened" },
    connected: { bg: C.BLUE_BG, fg: C.BLUE_INK, label: "connected" },
    created:   { bg: "#F1F1EE", fg: C.INK, label: "created" }
  }[kind] || { bg: "#F1F1EE", fg: C.MUTE, label: kind };
  return <span style={{ fontSize: 9.5, color: m.fg, background: m.bg, padding: "1px 5px", borderRadius: 3, fontWeight: 700, letterSpacing: "0.02em" }}>{m.label}</span>;
}

/* ============================================================
   DOC VIEWER
   ============================================================ */
function DocView({ visibleIds, statusOf, setStatus, readonly, compareTo }) {
  return (
    <div className="px-8 py-6 max-w-[900px]">
      <div className="mb-6 pb-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <h1 style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.015em" }}>Our Household Picture</h1>
        <div style={{ fontSize: 12.5, color: C.SUB, marginTop: 2 }}>Sarah Johnson & Mark Johnson · {visibleIds.length} items</div>
      </div>

      {CHAPTERS.map(ch => {
        const items = RECON_ITEMS.filter(i => i.chapter === ch.n && visibleIds.includes(i.id));
        if (items.length === 0) return null;
        return (
          <section key={ch.n} className="mb-5">
            <div className="flex items-baseline gap-2 mb-1.5 pb-1.5" style={{ borderBottom: `1px solid ${C.LINE}` }}>
              <span className="tabular-nums" style={{ fontSize: 10.5, color: C.MUTE, fontWeight: 700, letterSpacing: "0.1em" }}>§{ch.n}</span>
              <h2 style={{ fontSize: 14, fontWeight: 700, color: C.INK }}>{ch.title}</h2>
            </div>
            {items.map(item => (
              <DocItemRow key={item.id} item={item} status={statusOf(item.id)}
                          setStatus={(s) => setStatus(item.id, s)} readonly={readonly}/>
            ))}
          </section>
        );
      })}
    </div>
  );
}

function DocItemRow({ item, status, setStatus, readonly }) {
  const tint = status === "differs" ? "rgba(251, 211, 165, 0.1)"
    : status === "new" ? "rgba(191, 215, 247, 0.12)"
    : status === "missing" ? "rgba(216, 207, 251, 0.12)"
    : status === "gap" ? "rgba(229, 231, 235, 0.3)"
    : "transparent";
  const val = status === "differs" ? `${item.sarah.label} / ${item.mark.label}`
    : status === "missing" ? "— not listed"
    : status === "gap" ? "— evidence needed"
    : item.value || "—";

  return (
    <div className="flex items-center gap-3 py-2 px-2 rounded-md"
         style={{ background: tint, borderBottom: `1px dashed ${C.LINE}` }}>
      <StatusDot status={status}/>
      <span className="flex-1 min-w-0" style={{ fontSize: 13, color: C.INK, fontWeight: 500 }}>{item.label}</span>
      {item.ai && !readonly && <AIBadge label=""/>}
      <span className="tabular-nums text-right whitespace-nowrap" style={{ fontSize: 13, color: status === "agreed" ? C.INK : C.SUB, fontWeight: 500 }}>{val}</span>
      {!readonly && status !== "agreed" && (
        <button onClick={() => setStatus("agreed")}
                className="h-6.5 px-2 rounded text-[10.5px] font-semibold text-white flex-shrink-0"
                style={{ background: C.ACCENT, padding: "3px 8px" }}>
          Accept
        </button>
      )}
    </div>
  );
}

Object.assign(window, { V5_Timeline });
})();
