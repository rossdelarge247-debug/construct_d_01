/* V1 — ES2 Schedule ledger. Formal two-column UK mediation form, each row challengeable. */
(function(){
const { useState, useMemo } = React;
const { RECON_ITEMS, RECON_DISCLOSURE, reconAllFlags, RECON_SARAH, RECON_MARK } = window;
const { Who, Evidence, StatusDot, StatusChip, AIBadge, AICard, ReconIcons: I, ReconColors: C } = window;

const CHAPTERS = [
  { n: 1, title: "The children", mandate: "Schedule 1" },
  { n: 2, title: "Real property", mandate: "Schedule 2" },
  { n: 3, title: "Pensions", mandate: "Schedule 3" },
  { n: 4, title: "Capital — savings & investments", mandate: "Schedule 4" },
  { n: 5, title: "Vehicles & other assets", mandate: "Schedule 5" },
  { n: 6, title: "Liabilities", mandate: "Schedule 6" },
  { n: 7, title: "Income", mandate: "Schedule 7" },
  { n: 8, title: "Expenditure", mandate: "Schedule 8" },
  { n: 9, title: "Open items", mandate: "Schedule 9" }
];

function V1_ES2Schedule() {
  const [filter, setFilter] = useState("all");
  const [openRow, setOpenRow] = useState(null);
  const [states, setStates] = useState({});
  const [chapter, setChapter] = useState(2);

  const items = RECON_ITEMS.filter(i => {
    const s = states[i.id]?.status || i.status;
    if (filter === "all") return true;
    if (filter === "attention") return ["differs","new","missing","gap"].includes(s);
    return s === filter;
  });

  const statusOf = (id) => states[id]?.status || RECON_ITEMS.find(x => x.id === id)?.status;
  const setStatus = (id, status) => setStates(s => ({ ...s, [id]: { ...s[id], status } }));

  const counts = useMemo(() => {
    const c = { differs: 0, new: 0, missing: 0, gap: 0, agreed: 0 };
    RECON_ITEMS.forEach(i => c[statusOf(i.id)] = (c[statusOf(i.id)] || 0) + 1);
    return c;
  }, [states]);

  const byChapter = chapter === "all" ? items : items.filter(i => i.chapter === chapter);
  const attentionItems = RECON_ITEMS.filter(i => ["differs","new","missing","gap"].includes(statusOf(i.id)));

  return (
    <div className="flex h-full" style={{ background: "#FAFAF7" }}>
      {/* LEFT RAIL */}
      <LeftRail counts={counts} chapter={chapter} setChapter={setChapter}
                filter={filter} setFilter={setFilter}
                attentionItems={attentionItems} onJump={(id) => {
                  const it = RECON_ITEMS.find(x => x.id === id);
                  setChapter(it.chapter);
                  setOpenRow(id);
                  setTimeout(() => {
                    const el = document.querySelector(`[data-row="${id}"]`);
                    if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
                  }, 100);
                }}/>

      {/* CENTER — schedule */}
      <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFFEF9" }}>
        <ScheduleHeader chapter={chapter}/>
        <div className="max-w-[1100px] mx-auto px-8 pb-16">
          {chapter === "all" ? (
            CHAPTERS.map(c => (
              <ChapterBlock key={c.n} chapter={c}
                items={byChapter.filter(i => i.chapter === c.n)}
                statusOf={statusOf} setStatus={setStatus}
                openRow={openRow} setOpenRow={setOpenRow}/>
            ))
          ) : (
            <ChapterBlock chapter={CHAPTERS[chapter-1]}
              items={byChapter}
              statusOf={statusOf} setStatus={setStatus}
              openRow={openRow} setOpenRow={setOpenRow}/>
          )}
          <ScheduleFooter counts={counts}/>
        </div>
      </div>

      {/* RIGHT RAIL — version timeline compact */}
      <RightRail/>
    </div>
  );
}

/* ============================================================
   LEFT RAIL — disclosure, filters, AI attention, chapter nav
   ============================================================ */
function LeftRail({ counts, chapter, setChapter, filter, setFilter, attentionItems, onJump }) {
  return (
    <div style={{ width: 288, background: "#F6F4ED", borderRight: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 flex flex-col overflow-y-auto nice-scroll">
      {/* Disclosure */}
      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-3" style={{ color: C.MUTE }}>Disclosure progress</div>
        <DisclosureBar who="S"/>
        <div className="h-2"/>
        <DisclosureBar who="M"/>
      </div>

      {/* Filters */}
      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: C.MUTE }}>Show only</div>
        <div className="space-y-0.5">
          <FilterRow label="All items" n={Object.values(counts).reduce((a,b)=>a+b,0)} on={filter==="all"} onClick={() => setFilter("all")}/>
          <FilterRow label="Needs attention" n={counts.differs + counts.new + counts.missing + counts.gap} on={filter==="attention"} dot="attn" onClick={() => setFilter("attention")}/>
          <FilterRow label="Differs" n={counts.differs} on={filter==="differs"} dot="differs" onClick={() => setFilter("differs")}/>
          <FilterRow label="New" n={counts.new} on={filter==="new"} dot="new" onClick={() => setFilter("new")}/>
          <FilterRow label="Missing?" n={counts.missing} on={filter==="missing"} dot="missing" onClick={() => setFilter("missing")}/>
          <FilterRow label="Agreed" n={counts.agreed} on={filter==="agreed"} dot="agreed" onClick={() => setFilter("agreed")}/>
        </div>
      </div>

      {/* Chapters */}
      <div className="p-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: C.MUTE }}>Schedules</div>
        <div className="space-y-0.5">
          <ChapterRow n="All" title="Full schedule" active={chapter === "all"} onClick={() => setChapter("all")}/>
          {CHAPTERS.map(c => (
            <ChapterRow key={c.n} n={c.n} title={c.title} active={chapter === c.n} onClick={() => setChapter(c.n)}/>
          ))}
        </div>
      </div>

      {/* Next to resolve — AI queue */}
      <div className="p-4 flex-1">
        <div className="flex items-center justify-between mb-2">
          <div className="label-xs" style={{ color: C.MUTE }}>Next to resolve</div>
          <AIBadge label="AI queue"/>
        </div>
        <div className="space-y-1.5">
          {attentionItems.slice(0, 5).map(i => (
            <button key={i.id} onClick={() => onJump(i.id)}
              className="w-full text-left rounded-md p-2 bg-white hover:bg-[#FFFBF0] transition"
              style={{ border: `1px solid ${C.LINE}` }}>
              <div className="flex items-center gap-1.5 mb-0.5">
                <StatusDot status={i.status}/>
                <span style={{ fontSize: 11.5, fontWeight: 600, color: C.INK, lineHeight: 1.3 }}>{i.label}</span>
              </div>
              {i.ai && (
                <div style={{ fontSize: 10.5, color: C.AI_INK, lineHeight: 1.4, marginTop: 2 }}>
                  <I.Sparkle s={9} c={C.AI_INK} w={2}/> {i.ai.text.slice(0, 54)}…
                </div>
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function DisclosureBar({ who }) {
  const d = RECON_DISCLOSURE[who];
  const pct = Math.round((d.complete / d.total) * 100);
  return (
    <div>
      <div className="flex items-baseline justify-between mb-1">
        <div className="flex items-center gap-1.5">
          <Who who={who} size={16}/>
          <span style={{ fontSize: 12, fontWeight: 600, color: C.INK }}>{d.name}</span>
        </div>
        <span className="tabular-nums" style={{ fontSize: 11, color: C.SUB, fontWeight: 500 }}>{d.complete}/{d.total}</span>
      </div>
      <div className="h-[4px] rounded-full overflow-hidden" style={{ background: "#E8E4D6" }}>
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: d.ink }}/>
      </div>
      <div style={{ fontSize: 10.5, color: C.MUTE, marginTop: 2 }}>
        {pct === 100 ? `shared ${d.shared}` : `${d.total - d.complete} items pending`}
      </div>
    </div>
  );
}

function FilterRow({ label, n, on, dot, onClick }) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-1.5 px-2 py-1.5 rounded-md text-left transition"
      style={{ background: on ? "#FFFFFF" : "transparent",
               boxShadow: on ? `0 1px 2px rgba(0,0,0,0.04)` : "none",
               fontSize: 12, color: C.INK,
               fontWeight: on ? 600 : 500 }}
      onMouseEnter={e => { if (!on) e.currentTarget.style.background = "#EFECDF"; }}
      onMouseLeave={e => { if (!on) e.currentTarget.style.background = "transparent"; }}>
      {dot && dot !== "attn" && <StatusDot status={dot}/>}
      {dot === "attn" && <I.AlertI s={11} c={C.AMBER_INK} w={2}/>}
      <span className="flex-1">{label}</span>
      <span className="tabular-nums" style={{ fontSize: 11, color: C.MUTE, fontWeight: 500 }}>{n}</span>
    </button>
  );
}

function ChapterRow({ n, title, active, onClick }) {
  return (
    <button onClick={onClick}
      className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition"
      style={{ background: active ? "#FFFFFF" : "transparent",
               boxShadow: active ? `0 1px 2px rgba(0,0,0,0.04)` : "none",
               fontSize: 12, color: C.INK,
               fontWeight: active ? 600 : 500 }}
      onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#EFECDF"; }}
      onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      <span className="tabular-nums flex-shrink-0" style={{ fontSize: 10.5, color: C.MUTE, width: 22, letterSpacing: "0.04em", fontWeight: 600 }}>§{n === "all" ? "—" : n}</span>
      <span className="flex-1 truncate">{title}</span>
    </button>
  );
}

/* ============================================================
   SCHEDULE HEADER — ES2 pastiche
   ============================================================ */
function ScheduleHeader({ chapter }) {
  return (
    <div className="max-w-[1100px] mx-auto px-8 pt-8 pb-4" style={{ borderBottom: `1px solid ${C.LINE}` }}>
      <div className="flex items-baseline justify-between">
        <div>
          <div style={{ fontSize: 10.5, letterSpacing: "0.18em", color: C.MUTE, textTransform: "uppercase", fontWeight: 600 }}>
            In the matter of the Family Proceedings of · Johnson & Johnson
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.015em", marginTop: 4, color: C.INK, fontFamily: "'Inter', serif" }}>
            Joint Schedule of Assets, Liabilities, Pensions and Income
          </h1>
          <div style={{ fontSize: 12.5, color: C.SUB, marginTop: 3 }}>
            Reconciliation of disclosure · 17 April 2026 · Parties: Sarah Johnson (Applicant) and Mark Johnson (Respondent)
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <span className="chip" style={{ background: "#F5EEDC", color: "#7A5A1A", fontSize: 9.5 }}>v2.0 · reconciled</span>
        </div>
      </div>

      {chapter !== "all" && (
        <div className="mt-4 flex items-baseline gap-3">
          <div style={{ fontSize: 10.5, color: C.MUTE, letterSpacing: "0.12em", textTransform: "uppercase", fontWeight: 600 }}>Schedule {chapter}</div>
          <h2 style={{ fontSize: 18, fontWeight: 600, color: C.INK }}>{CHAPTERS[chapter-1].title}</h2>
        </div>
      )}
    </div>
  );
}

function ScheduleFooter({ counts }) {
  const total = Object.values(counts).reduce((a,b)=>a+b,0);
  return (
    <div className="mt-10 pt-4" style={{ borderTop: `1px solid ${C.LINE}` }}>
      <div className="flex items-baseline justify-between" style={{ fontSize: 11, color: C.MUTE }}>
        <div>
          Statement of position prepared by Decouple on behalf of both parties. Each line item represents either agreement or a point requiring resolution between the parties.
        </div>
        <div className="flex-shrink-0 tabular-nums" style={{ marginLeft: 24 }}>
          {counts.agreed} of {total} items agreed
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   CHAPTER BLOCK + ROWS
   ============================================================ */
function ChapterBlock({ chapter, items, statusOf, setStatus, openRow, setOpenRow }) {
  return (
    <section className="mt-6">
      <div className="flex items-baseline gap-3 mb-2 pb-2" style={{ borderBottom: `1px solid ${C.INK}` }}>
        <span className="tabular-nums" style={{ fontSize: 11, color: C.MUTE, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 700 }}>§{chapter.n}</span>
        <h3 style={{ fontSize: 15, fontWeight: 700, color: C.INK, letterSpacing: "-0.005em" }}>{chapter.title}</h3>
        <span style={{ fontSize: 10.5, color: C.MUTE, letterSpacing: "0.05em", fontStyle: "italic" }}>{chapter.mandate}</span>
      </div>

      {/* column header */}
      <div className="grid grid-cols-[26px_1fr_200px_200px_140px] gap-3 py-2" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div/>
        <div style={{ fontSize: 10.5, color: C.MUTE, letterSpacing: "0.08em", fontWeight: 700, textTransform: "uppercase" }}>Item</div>
        <div className="flex items-center gap-1.5" style={{ fontSize: 10.5, color: C.MUTE, letterSpacing: "0.08em", fontWeight: 700, textTransform: "uppercase" }}>
          <Who who="S" size={14}/> Sarah's disclosure
        </div>
        <div className="flex items-center gap-1.5" style={{ fontSize: 10.5, color: C.MUTE, letterSpacing: "0.08em", fontWeight: 700, textTransform: "uppercase" }}>
          <Who who="M" size={14}/> Mark's disclosure
        </div>
        <div className="text-right" style={{ fontSize: 10.5, color: C.MUTE, letterSpacing: "0.08em", fontWeight: 700, textTransform: "uppercase" }}>Status</div>
      </div>

      {items.map((item, idx) => (
        <ScheduleRow key={item.id} item={item} idx={idx+1}
                     status={statusOf(item.id)} setStatus={(s) => setStatus(item.id, s)}
                     open={openRow === item.id} setOpen={(v) => setOpenRow(v ? item.id : null)}/>
      ))}

      {/* Add missing prompt at the end of each chapter */}
      <AddMissingRow chapterNum={chapter.n}/>
    </section>
  );
}

function ScheduleRow({ item, idx, status, setStatus, open, setOpen }) {
  const sarahValue = item.sarah?.label || (item.contributedBy === "S" || item.both ? item.value : (item.status === "missing" ? "—" : item.status === "new" ? "—" : item.value || "—"));
  const markValue  = item.mark?.label  || (item.contributedBy === "M" || item.both ? item.value : (item.status === "missing" ? "—" : item.status === "new" ? "—" : item.value || "—"));

  /* for agreed "both" items, both columns show same value */
  const sVal = item.both ? item.value : (item.sarah?.label || (item.contributedBy === "S" ? item.value : "—"));
  const mVal = item.both ? item.value : (item.mark?.label || (item.contributedBy === "M" ? item.value : "—"));

  const rowBg = status === "agreed" ? "transparent"
              : status === "differs" ? "rgba(253, 186, 116, 0.05)"
              : status === "new" ? "rgba(147, 197, 253, 0.05)"
              : status === "missing" ? "rgba(196, 181, 253, 0.06)"
              : "rgba(229, 231, 235, 0.3)";

  return (
    <>
      <div data-row={item.id}
           onClick={() => setOpen(!open)}
           className="grid grid-cols-[26px_1fr_200px_200px_140px] gap-3 py-2.5 cursor-pointer transition items-baseline"
           style={{ borderBottom: `1px dashed ${C.LINE}`, background: rowBg }}
           onMouseEnter={e => { if (status === "agreed") e.currentTarget.style.background = "#FAFAF7"; }}
           onMouseLeave={e => { if (status === "agreed") e.currentTarget.style.background = "transparent"; }}>
        <div className="tabular-nums" style={{ fontSize: 11, color: C.MUTE, fontWeight: 500 }}>{idx}.</div>
        <div className="flex items-center gap-1.5 min-w-0">
          <I.ChevR s={10} c={C.MUTE} w={2}
            {...(open ? { style: { transform: "rotate(90deg)", transition: "transform 0.15s" } } : { style: { transition: "transform 0.15s" } })}/>
          <span style={{ fontSize: 13, color: C.INK, fontWeight: status === "agreed" ? 400 : 500 }}>{item.label}</span>
          {item.ai && <AIBadge label={flagLabelShort(item.ai.kind)}/>}
        </div>
        <div className="tabular-nums flex items-center gap-1.5" style={{ fontSize: 13, color: sVal === "—" ? C.MUTE : C.INK }}>
          {item.sarah?.evidence && <Evidence kind={item.sarah.evidence} small/>}
          {item.both && item.evidence && <Evidence kind={item.evidence} small/>}
          <span>{sVal}</span>
        </div>
        <div className="tabular-nums flex items-center gap-1.5" style={{ fontSize: 13, color: mVal === "—" ? C.MUTE : C.INK }}>
          {item.mark?.evidence && <Evidence kind={item.mark.evidence} small/>}
          {item.both && item.evidence && !item.contributedBy && <Evidence kind={item.evidence} small/>}
          <span>{mVal}</span>
        </div>
        <div className="text-right flex items-center justify-end">
          <StatusChip status={status}/>
        </div>
      </div>

      {open && (
        <RowDrawer item={item} status={status} setStatus={setStatus} onClose={() => setOpen(false)}/>
      )}
    </>
  );
}

function flagLabelShort(kind) {
  return {
    midpoint: "AI · suggest midpoint",
    cross_ref: "AI · cross-ref",
    sanity: "AI · sanity",
    evidence: "AI · evidence",
    evidence_age: "AI · stale",
    comparability: "AI · parity",
    prompt: "AI · missing?"
  }[kind] || "AI flag";
}

/* ============================================================
   ROW DRAWER — discussion + mediation buttons
   ============================================================ */
function RowDrawer({ item, status, setStatus, onClose }) {
  const isContested = status === "differs";
  const midpointValue = item.sarah?.value && item.mark?.value ? Math.round((item.sarah.value + item.mark.value) / 2) : null;
  const fmt = (n) => "£" + n.toLocaleString();

  return (
    <div className="px-7 pb-4 -mt-[1px]" style={{ background: "#FBFAF3", borderBottom: `1px solid ${C.LINE}` }}>
      <div className="grid grid-cols-[1fr_340px] gap-5 pt-3">
        {/* Left: claim details */}
        <div>
          {isContested && (
            <div className="grid grid-cols-2 gap-3 mb-3">
              <ClaimDetail who="S" claim={item.sarah}/>
              <ClaimDetail who="M" claim={item.mark}/>
            </div>
          )}

          {status === "new" && (
            <div className="rounded-md p-3" style={{ background: "#FFFFFF", border: `1px solid ${C.BLUE_BORDER}` }}>
              <div className="flex items-center gap-1.5 mb-1">
                <Who who={item.contributedBy} size={16}/>
                <span style={{ fontSize: 12, fontWeight: 600, color: C.INK }}>{item.contributedBy === "M" ? "Mark" : "Sarah"} disclosed on {item.disclosedOn}</span>
              </div>
              <div className="tabular-nums flex items-center gap-1.5" style={{ fontSize: 15, fontWeight: 600, color: C.INK }}>
                {item.evidence && <Evidence kind={item.evidence}/>}
                {item.value}
              </div>
              {item.note && <div style={{ fontSize: 12, color: C.SUB, marginTop: 4, lineHeight: 1.5, fontStyle: "italic" }}>"{item.note}"</div>}
            </div>
          )}

          {status === "missing" && (
            <div className="rounded-md p-3" style={{ background: "#FFFFFF", border: `1px dashed ${C.PURPLE_BORDER}` }}>
              <div style={{ fontSize: 12, color: C.PURPLE_INK, fontWeight: 600, marginBottom: 4 }}>
                Not currently listed — flagged by AI
              </div>
              <div style={{ fontSize: 12, color: C.SUB, lineHeight: 1.5 }}>
                Either party can add this item, or confirm it isn't applicable.
              </div>
            </div>
          )}

          {status === "agreed" && (
            <div className="flex items-center gap-2 text-[12.5px]" style={{ color: C.GREEN_INK }}>
              <I.Check s={13} c={C.GREEN_INK} w={2.5}/>
              Both parties have confirmed this item. {item.value && <span style={{ color: C.INK, marginLeft: 6 }}>{item.value}</span>}
            </div>
          )}

          {/* Mediation formal buttons */}
          {status !== "agreed" && (
            <div className="mt-3 flex items-center gap-1.5 flex-wrap">
              <FormalButton kind="accept" onClick={() => setStatus("agreed")}>
                {status === "differs" ? "Accept other party's figure" : "Accept as stated"}
              </FormalButton>
              <FormalButton kind="challenge">Challenge</FormalButton>
              <FormalButton kind="evidence">Request evidence</FormalButton>
              <FormalButton kind="counter">Counter-propose</FormalButton>
              {status === "missing" && (
                <FormalButton kind="add">Add this item</FormalButton>
              )}
            </div>
          )}
        </div>

        {/* Right: AI suggestion + thread preview */}
        <div>
          {item.ai && (
            <AICard flag={item.ai}
              onApply={item.ai.kind === "midpoint" && midpointValue ? () => { setStatus("agreed"); } : undefined}
              onDismiss={() => {}}/>
          )}
          {item.ai && midpointValue && item.ai.kind === "midpoint" && (
            <div className="mt-2 flex items-center gap-2 text-[11.5px]" style={{ color: C.SUB }}>
              <I.Scale s={11}/>
              Midpoint: <span className="tabular-nums font-semibold" style={{ color: C.INK }}>{fmt(midpointValue)}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ClaimDetail({ who, claim }) {
  if (!claim) return null;
  return (
    <div className="rounded-md p-3 bg-white" style={{ border: `1px solid ${C.LINE}` }}>
      <div className="flex items-center justify-between mb-1.5">
        <div className="flex items-center gap-1.5">
          <Who who={who} size={16}/>
          <span style={{ fontSize: 12, fontWeight: 600, color: C.INK }}>{who === "S" ? "Sarah" : "Mark"}'s position</span>
        </div>
        <Evidence kind={claim.evidence}/>
      </div>
      <div className="tabular-nums" style={{ fontSize: 17, fontWeight: 600, color: C.INK }}>{claim.label}</div>
      {claim.note && <div style={{ fontSize: 11.5, color: C.SUB, marginTop: 3, lineHeight: 1.45, fontStyle: "italic" }}>"{claim.note}"</div>}
    </div>
  );
}

function FormalButton({ kind, children, onClick }) {
  const styles = {
    accept:    { bg: C.ACCENT, fg: "#FFFFFF", border: C.ACCENT },
    challenge: { bg: "#FFFFFF", fg: C.AMBER_INK, border: C.AMBER_BORDER },
    evidence:  { bg: "#FFFFFF", fg: C.BLUE_INK, border: C.BLUE_BORDER },
    counter:   { bg: "#FFFFFF", fg: C.INK, border: C.LINE },
    add:       { bg: C.PURPLE_INK, fg: "#FFFFFF", border: C.PURPLE_INK }
  }[kind];
  return (
    <button onClick={onClick}
      className="h-7 px-2.5 rounded-md transition"
      style={{ background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}`,
               fontSize: 11.5, fontWeight: 600 }}>
      {children}
    </button>
  );
}

function AddMissingRow({ chapterNum }) {
  return (
    <button className="w-full flex items-center gap-2 py-2.5 px-1 text-left transition rounded-md hover:bg-[#FAFAF7]"
            style={{ color: C.MUTE }}>
      <I.Plus s={11} c={C.MUTE} w={2}/>
      <span style={{ fontSize: 12, fontStyle: "italic" }}>Add an item you expected to see in this schedule…</span>
    </button>
  );
}

/* ============================================================
   RIGHT RAIL — compact timeline & activity log
   ============================================================ */
function RightRail() {
  const { RECON_VERSIONS, RECON_ACTIVITY } = window;
  return (
    <div style={{ width: 264, background: "#F6F4ED", borderLeft: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 overflow-y-auto nice-scroll">
      <div className="p-4">
        <div className="label-xs mb-3" style={{ color: C.MUTE }}>Versions</div>
        <div style={{ position: "relative" }}>
          <div style={{ position: "absolute", left: 10, top: 8, bottom: 8, width: 1, background: "#D4CFBE" }}/>
          {RECON_VERSIONS.map(v => (
            <div key={v.id} className="flex items-start gap-2.5 py-1.5 relative">
              <span className="rounded-full flex items-center justify-center flex-shrink-0 relative z-10 mt-0.5"
                    style={{ width: 20, height: 20, background: v.who === "S" ? RECON_SARAH : v.who === "M" ? RECON_MARK : "#111", color: "#FFFFFF", fontSize: 9.5, fontWeight: 600,
                             boxShadow: `0 0 0 3px #F6F4ED` }}>
                {v.who === "Both" ? "⇌" : v.who}
              </span>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="tabular-nums" style={{ fontSize: 12, fontWeight: 700, color: C.INK }}>{v.id}</span>
                  <span style={{ fontSize: 9.5, color: C.MUTE }}>{v.date}</span>
                </div>
                <div style={{ fontSize: 11, color: C.SUB, lineHeight: 1.4 }}>{v.note}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4" style={{ borderTop: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: C.MUTE }}>Recent activity</div>
        <div className="space-y-1.5">
          {RECON_ACTIVITY.slice(0, 6).map((a, i) => (
            <div key={i} className="flex items-start gap-2">
              <Who who={a.who} size={16}/>
              <div className="min-w-0 flex-1">
                <div style={{ fontSize: 11.5, color: C.INK, lineHeight: 1.4 }}>{a.text}</div>
                {a.detail && <div className="tabular-nums" style={{ fontSize: 10.5, color: C.MUTE }}>{a.detail}</div>}
                <div style={{ fontSize: 10, color: C.MUTE }}>{a.time.split(" · ")[1]}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { V1_ES2Schedule });
})();
