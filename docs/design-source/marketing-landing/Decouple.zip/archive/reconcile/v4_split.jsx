/* V4 — Split-screen deliberation. Doc on the left; per-item discussion panel on the right expanding per-row. */
(function(){
const { useState, useMemo, useRef, useEffect } = React;
const { RECON_ITEMS, RECON_DISCLOSURE, RECON_ACTIVITY, RECON_VERSIONS, RECON_SARAH, RECON_MARK, reconAllFlags } = window;
const { Who, Evidence, StatusDot, StatusChip, AIBadge, AICard, ReconIcons: I, ReconColors: C } = window;

const CHAPTERS = [
  { n: 1, title: "The children" },
  { n: 2, title: "The home" },
  { n: 3, title: "Pensions" },
  { n: 4, title: "Savings & investments" },
  { n: 5, title: "Vehicles & other" },
  { n: 6, title: "Debts" },
  { n: 7, title: "Income" },
  { n: 8, title: "Monthly spending" },
  { n: 9, title: "Open items" }
];

function V4_SplitScreen() {
  const [selected, setSelected] = useState("home_value");
  const [states, setStates] = useState({});
  const statusOf = (id) => states[id]?.status || RECON_ITEMS.find(x => x.id === id)?.status;
  const setStatus = (id, s) => setStates(st => ({ ...st, [id]: { ...st[id], status: s } }));

  const attention = RECON_ITEMS.filter(i => ["differs","new","missing","gap"].includes(statusOf(i.id)));
  const nextIdx = attention.findIndex(i => i.id === selected);
  const goNext = () => { if (nextIdx >= 0 && nextIdx < attention.length - 1) setSelected(attention[nextIdx+1].id); };
  const goPrev = () => { if (nextIdx > 0) setSelected(attention[nextIdx-1].id); };

  return (
    <div className="flex h-full" style={{ background: "#F7F7F6" }}>
      <SplitLeftRail selected={selected} setSelected={setSelected} statusOf={statusOf}/>

      {/* center column — doc */}
      <div className="flex-1 flex flex-col min-w-0" style={{ background: "#FFFFFF" }}>
        <div className="px-6 py-3 flex items-center gap-3 flex-shrink-0" style={{ borderBottom: `1px solid ${C.LINE}` }}>
          <h1 style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em" }}>Our Household Picture</h1>
          <span className="chip" style={{ background: C.GREEN_BG, color: C.GREEN_INK, fontSize: 9.5 }}>v2.0 · unified</span>
          <span className="ml-auto flex items-center gap-2 text-[12px]" style={{ color: C.SUB }}>
            <Who who="S" size={18}/> Sarah <span style={{ color: C.MUTE }}>·</span> <Who who="M" size={18}/> Mark <span style={{ color: C.MUTE }}>are both viewing</span>
          </span>
        </div>
        <div className="flex-1 overflow-y-auto nice-scroll">
          {CHAPTERS.map(ch => {
            const items = RECON_ITEMS.filter(i => i.chapter === ch.n);
            return (
              <section key={ch.n} className="px-6 py-4">
                <div className="flex items-baseline gap-2 mb-2 pb-1.5" style={{ borderBottom: `1px solid ${C.LINE}` }}>
                  <span className="tabular-nums" style={{ fontSize: 10.5, color: C.MUTE, fontWeight: 700, letterSpacing: "0.1em" }}>§{ch.n}</span>
                  <h2 style={{ fontSize: 14, fontWeight: 700, color: C.INK }}>{ch.title}</h2>
                </div>
                {items.map(item => (
                  <DocRow key={item.id} item={item} status={statusOf(item.id)}
                          selected={selected === item.id}
                          onClick={() => setSelected(item.id)}/>
                ))}
              </section>
            );
          })}
        </div>
      </div>

      {/* RIGHT panel — deliberation */}
      <DeliberationPanel
        item={RECON_ITEMS.find(i => i.id === selected)}
        status={statusOf(selected)}
        setStatus={(s) => setStatus(selected, s)}
        goNext={goNext}
        goPrev={goPrev}
        position={{ idx: nextIdx + 1, total: attention.length }}
      />
    </div>
  );
}

function SplitLeftRail({ selected, setSelected, statusOf }) {
  const attention = RECON_ITEMS.filter(i => ["differs","new","missing","gap"].includes(statusOf(i.id)));
  return (
    <div style={{ width: 248, background: "#FAFAFA", borderRight: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 flex flex-col overflow-y-auto nice-scroll">
      <div className="p-3.5" style={{ borderBottom: `1px solid ${C.LINE}` }}>
        <div className="label-xs mb-2" style={{ color: C.MUTE }}>Disclosure</div>
        <MiniDisclose who="S"/>
        <div className="h-1.5"/>
        <MiniDisclose who="M"/>
      </div>
      <div className="p-3.5 flex-1">
        <div className="flex items-center justify-between mb-2">
          <div className="label-xs" style={{ color: C.MUTE }}>Queue — {attention.length}</div>
          <AIBadge label="AI ordered"/>
        </div>
        <div className="space-y-1">
          {attention.map((item, idx) => {
            const on = selected === item.id;
            return (
              <button key={item.id} onClick={() => setSelected(item.id)}
                className="w-full text-left rounded-md p-2 transition"
                style={{ background: on ? "#111" : "#FFFFFF", border: `1px solid ${on ? "#111" : C.LINE}`, color: on ? "#FFFFFF" : C.INK }}
                onMouseEnter={e => { if (!on) e.currentTarget.style.background = "#F4F4F2"; }}
                onMouseLeave={e => { if (!on) e.currentTarget.style.background = "#FFFFFF"; }}>
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="tabular-nums" style={{ fontSize: 10, color: on ? "#FFFFFF99" : C.MUTE, fontWeight: 600, width: 14 }}>{idx+1}.</span>
                  <StatusDot status={statusOf(item.id)} size={6}/>
                  <span style={{ fontSize: 11.5, fontWeight: 600, lineHeight: 1.3 }}>{item.label}</span>
                </div>
                {item.ai && (
                  <div style={{ fontSize: 10, color: on ? "#FFFFFFB3" : C.SUB, lineHeight: 1.4, paddingLeft: 20 }}>
                    {item.ai.text.slice(0, 60)}…
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function MiniDisclose({ who }) {
  const d = RECON_DISCLOSURE[who];
  const pct = Math.round((d.complete / d.total) * 100);
  return (
    <div>
      <div className="flex items-baseline justify-between mb-0.5">
        <div className="flex items-center gap-1.5"><Who who={who} size={14}/><span style={{ fontSize: 11.5, fontWeight: 600 }}>{d.name}</span></div>
        <span className="tabular-nums" style={{ fontSize: 10.5, color: C.SUB }}>{pct}%</span>
      </div>
      <div className="h-[3px] rounded-full overflow-hidden" style={{ background: "#EDEDED" }}>
        <div className="h-full" style={{ width: `${pct}%`, background: d.ink }}/>
      </div>
    </div>
  );
}

function DocRow({ item, status, selected, onClick }) {
  const tint = status === "agreed" ? "transparent"
    : status === "differs" ? "rgba(251, 211, 165, 0.15)"
    : status === "new" ? "rgba(191, 215, 247, 0.2)"
    : status === "missing" ? "rgba(216, 207, 251, 0.2)"
    : "rgba(229, 231, 235, 0.3)";
  return (
    <button onClick={onClick}
      className="w-full text-left flex items-center gap-2 py-1.5 px-2 rounded-md transition"
      style={{ background: selected ? "#FFF7D6" : tint,
               boxShadow: selected ? `inset 3px 0 0 #111` : "none",
               borderBottom: `1px dashed ${C.LINE}` }}>
      <StatusDot status={status}/>
      <span className="flex-1 min-w-0 truncate" style={{ fontSize: 12.5, color: C.INK, fontWeight: selected ? 600 : 500 }}>{item.label}</span>
      {item.ai && status !== "agreed" && <AIBadge label=""/>}
      <span className="tabular-nums whitespace-nowrap text-right flex-shrink-0 flex items-center gap-1" style={{ fontSize: 12.5, color: C.SUB, fontWeight: 500, minWidth: 120 }}>
        {status === "differs" ? `${item.sarah.label} / ${item.mark.label}`
          : status === "missing" ? <span style={{ color: C.PURPLE_INK, fontStyle: "italic" }}>not listed</span>
          : status === "gap" ? <span style={{ color: C.MUTE, fontStyle: "italic" }}>evidence needed</span>
          : item.value || "—"}
      </span>
    </button>
  );
}

/* ============================================================
   DELIBERATION PANEL
   ============================================================ */
function DeliberationPanel({ item, status, setStatus, goNext, goPrev, position }) {
  if (!item) return null;
  const isAgreed = status === "agreed";

  return (
    <div style={{ width: 440, background: "#FFFFFF", borderLeft: `1px solid ${C.LINE}` }}
         className="flex-shrink-0 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 flex items-center gap-2 flex-shrink-0" style={{ borderBottom: `1px solid ${C.LINE}`, background: "#FAFAFA" }}>
        <StatusChip status={status}/>
        <span style={{ fontSize: 11, color: C.MUTE }}>Item {position.idx} of {position.total}</span>
        <div className="ml-auto flex items-center gap-1">
          <button onClick={goPrev} className="w-7 h-7 rounded-md bg-white flex items-center justify-center" style={{ border: `1px solid ${C.LINE}` }}>
            <I.ChevR s={12} style={{ transform: "rotate(180deg)" }}/>
          </button>
          <button onClick={goNext} className="w-7 h-7 rounded-md bg-white flex items-center justify-center" style={{ border: `1px solid ${C.LINE}` }}>
            <I.ChevR s={12}/>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto nice-scroll p-4">
        <h2 style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em", color: C.INK, lineHeight: 1.25 }}>{item.label}</h2>
        <div style={{ fontSize: 12, color: C.SUB, marginTop: 2 }}>§{item.chapter} · {CHAPTERS[item.chapter-1].title}</div>

        {/* Positions */}
        {status === "differs" && (
          <div className="mt-4">
            <div className="label-xs mb-2" style={{ color: C.MUTE }}>Positions</div>
            <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${C.LINE}` }}>
              <PositionRow who="S" claim={item.sarah}/>
              <div style={{ height: 1, background: C.LINE }}/>
              <PositionRow who="M" claim={item.mark}/>
            </div>
            <div className="mt-2 flex items-center justify-between text-[11.5px]" style={{ color: C.AMBER_INK }}>
              <span>Gap of <b className="tabular-nums">£{item.diff.toLocaleString()}</b></span>
              <span>Midpoint <b className="tabular-nums">£{Math.round((item.sarah.value + item.mark.value)/2).toLocaleString()}</b></span>
            </div>
          </div>
        )}

        {status === "new" && (
          <div className="mt-4 rounded-lg p-3" style={{ background: C.BLUE_BG, border: `1px solid ${C.BLUE_BORDER}` }}>
            <div className="flex items-center gap-2 mb-2">
              <Who who={item.contributedBy} size={18}/>
              <span style={{ fontSize: 12.5, fontWeight: 600 }}>Disclosed by {item.contributedBy === "M" ? "Mark" : "Sarah"}</span>
              <span className="ml-auto" style={{ fontSize: 11, color: C.BLUE_INK }}>{item.disclosedOn}</span>
            </div>
            <div className="flex items-center gap-1.5 tabular-nums" style={{ fontSize: 20, fontWeight: 600, color: C.INK }}>
              {item.evidence && <Evidence kind={item.evidence}/>}
              {item.value}
            </div>
            {item.note && <div style={{ fontSize: 12, color: C.SUB, marginTop: 4, fontStyle: "italic", lineHeight: 1.5 }}>"{item.note}"</div>}
          </div>
        )}

        {status === "missing" && (
          <div className="mt-4 rounded-lg p-3" style={{ background: C.PURPLE_BG, border: `1px dashed ${C.PURPLE_BORDER}` }}>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: C.PURPLE_INK, marginBottom: 4, letterSpacing: "0.04em", textTransform: "uppercase" }}>
              Not currently listed
            </div>
            <div style={{ fontSize: 12.5, color: C.INK, lineHeight: 1.5 }}>
              This item was flagged by AI as something you may have overlooked. Either party can add it, or confirm it's not applicable.
            </div>
          </div>
        )}

        {status === "agreed" && (
          <div className="mt-4 rounded-lg p-3" style={{ background: C.GREEN_BG, border: `1px solid #C7E4D1` }}>
            <div className="flex items-center gap-2">
              <I.Check s={14} c={C.GREEN_INK} w={2.5}/>
              <span style={{ fontSize: 13, fontWeight: 600, color: C.GREEN_INK }}>Agreed by both</span>
            </div>
            {item.value && <div className="mt-1 tabular-nums" style={{ fontSize: 17, fontWeight: 600 }}>{item.value}</div>}
          </div>
        )}

        {/* AI mediator suggestion */}
        {item.ai && !isAgreed && (
          <div className="mt-3">
            <AICard flag={item.ai} inline
                    onApply={() => setStatus("agreed")}
                    onDismiss={() => {}}/>
          </div>
        )}

        {/* Mediation buttons */}
        {!isAgreed && (
          <div className="mt-4">
            <div className="label-xs mb-2" style={{ color: C.MUTE }}>Respond</div>
            <div className="grid grid-cols-2 gap-1.5">
              <BigBtn kind="accept" onClick={() => setStatus("agreed")}>
                <I.Check s={12}/> {status === "differs" ? "Accept theirs" : status === "missing" ? "Add this" : "Accept"}
              </BigBtn>
              <BigBtn kind="challenge">
                <I.AlertI s={12}/> Challenge
              </BigBtn>
              <BigBtn kind="evidence">
                <I.Doc s={12}/> Request evidence
              </BigBtn>
              <BigBtn kind="counter">
                <I.Scale s={12}/> Counter-propose
              </BigBtn>
            </div>
          </div>
        )}

        {/* Comments */}
        <div className="mt-4 pt-4" style={{ borderTop: `1px solid ${C.LINE}` }}>
          <div className="label-xs mb-2" style={{ color: C.MUTE }}>Discussion</div>
          {status === "differs" && item.id === "home_value" && (
            <div className="space-y-2.5 mb-2.5">
              <Bubble who="S" time="31 Mar">My estimate came from Rightmove comps for similar houses on Oak Road.</Bubble>
              <Bubble who="M" time="1 Apr">I got a formal valuation from Wilkinson Grant — they came in at £480k. I'll upload the note.</Bubble>
            </div>
          )}
          <textarea rows={2} placeholder="Add a reply…"
            className="w-full rounded-md px-2.5 py-1.5 resize-none"
            style={{ fontSize: 12.5, border: `1px solid ${C.LINE}`, background: "#FAFAFA" }}/>
        </div>
      </div>
    </div>
  );
}

function PositionRow({ who, claim }) {
  return (
    <div className="p-3 flex items-center gap-3" style={{ background: who === "S" ? "rgba(47, 109, 95, 0.04)" : "rgba(126, 90, 78, 0.04)" }}>
      <Who who={who} size={28}/>
      <div className="flex-1 min-w-0">
        <div style={{ fontSize: 12, fontWeight: 600 }}>{who === "S" ? "Sarah" : "Mark"}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <Evidence kind={claim.evidence}/>
          <span style={{ fontSize: 11.5, color: C.SUB }}>{claim.evidence === "doc" ? "Document" : claim.evidence === "pdf" ? "Statement" : "Self-declared"}</span>
        </div>
        {claim.note && <div style={{ fontSize: 11, color: C.SUB, marginTop: 3, fontStyle: "italic", lineHeight: 1.4 }}>"{claim.note}"</div>}
      </div>
      <div className="tabular-nums text-right" style={{ fontSize: 18, fontWeight: 700, color: C.INK }}>{claim.label}</div>
    </div>
  );
}

function BigBtn({ kind, children, onClick }) {
  const styles = {
    accept:    { bg: C.ACCENT,    fg: "#FFFFFF", border: C.ACCENT },
    challenge: { bg: "#FFFFFF",   fg: C.AMBER_INK, border: C.AMBER_BORDER },
    evidence:  { bg: "#FFFFFF",   fg: C.BLUE_INK, border: C.BLUE_BORDER },
    counter:   { bg: "#FFFFFF",   fg: C.INK, border: C.LINE }
  }[kind];
  return (
    <button onClick={onClick}
      className="h-9 rounded-md inline-flex items-center justify-center gap-1.5 text-[12px] font-semibold"
      style={{ background: styles.bg, color: styles.fg, border: `1px solid ${styles.border}` }}>
      {children}
    </button>
  );
}

function Bubble({ who, time, children }) {
  return (
    <div className="flex items-start gap-2">
      <Who who={who} size={22}/>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-1.5">
          <span style={{ fontSize: 11.5, fontWeight: 600 }}>{who === "S" ? "Sarah" : "Mark"}</span>
          <span style={{ fontSize: 10.5, color: C.MUTE }}>· {time}</span>
        </div>
        <div style={{ fontSize: 12.5, color: C.INK, lineHeight: 1.5, marginTop: 1 }}>{children}</div>
      </div>
    </div>
  );
}

Object.assign(window, { V4_SplitScreen });
})();
