/* Shared data model for reconciliation variants — items, AI flags, versions, activity */
(function(){

const SARAH = "#2F6D5F", MARK = "#7E5A4E";

/* ============================================================
   ITEMS — each has sarah/mark claims, status, evidence, AI flags
   ============================================================ */
const ITEMS = [
  /* §1 Children */
  { id: "children",       chapter: 1, label: "Emma (7) and Jake (4)",     status: "agreed",
    value: "primary care: Sarah", both: true },
  { id: "nursery",        chapter: 1, label: "Bright Horizons Nursery",  status: "agreed",
    value: "£600 / mo", both: true, evidence: "doc" },

  /* §2 Home */
  { id: "home_value",     chapter: 2, label: "Property value — 12 Oak Road",  status: "differs",
    sarah: { value: 450000, label: "£450,000", evidence: "self", note: "Rightmove comps for Oak Road" },
    mark:  { value: 480000, label: "£480,000", evidence: "self", note: "Wilkinson Grant valuation, 28 Mar" },
    diff: 30000,
    ai: { kind: "midpoint", text: "A midpoint of £465,000 is within both estimates. Instruct a joint RICS valuation (~£500) if you want a definitive figure." }
  },
  { id: "mortgage",       chapter: 2, label: "Mortgage balance — Halifax",    status: "agreed",
    value: "£220,000", both: true, evidence: "doc" },
  { id: "ownership",      chapter: 2, label: "Ownership — joint tenants",      status: "agreed", both: true },
  { id: "occupation",     chapter: 2, label: "Occupation — Sarah + children",  status: "agreed", both: true },

  /* §3 Pensions */
  { id: "sarah_nhs",      chapter: 3, label: "Sarah's NHS Pension — CETV",    status: "agreed",
    value: "£180,412", evidence: "doc", contributedBy: "S", both: true },
  { id: "mark_nest",      chapter: 3, label: "Mark's NEST Pension — CETV",    status: "new",
    value: "£12,000", evidence: "self", contributedBy: "M",
    disclosedOn: "16 Apr",
    ai: { kind: "evidence", text: "Self-declared. Request a CETV statement from NEST (free, 3-day turnaround) before accepting." }
  },
  { id: "mark_sipp",      chapter: 3, label: "Mark's SIPP", status: "missing",
    ai: { kind: "cross_ref", text: "In Phase 1, Mark mentioned a SIPP with Vanguard started in 2020. It isn't listed here — ask Mark to add it or confirm it was closed." },
    prompt: true
  },

  /* §4 Savings & investments */
  { id: "joint_barclays", chapter: 4, label: "Joint savings — Barclays",     status: "differs",
    sarah: { value: 12000, label: "£12,000", evidence: "doc", note: "Statement 31 March" },
    mark:  { value: 8000,  label: "£8,000",  evidence: "self", note: "Barclays app when I checked" },
    diff: 4000,
    ai: { kind: "cross_ref", text: "Sarah's statement is dated 31 March. £4,000 was transferred to HMRC on 2 April (tax bill). Using £8,000 post-tax is consistent with both views." }
  },
  { id: "sarah_monzo",    chapter: 4, label: "Sarah's Monzo",               status: "agreed",
    value: "£1,240", evidence: "doc", contributedBy: "S", both: true },
  { id: "sarah_hl_isa",   chapter: 4, label: "Sarah's Hargreaves ISA",     status: "agreed",
    value: "£6,000", evidence: "self", contributedBy: "S", both: true,
    ai: { kind: "comparability", text: "Self-declared. Mark provided a statement for his ISA — consider asking Sarah for one too for consistency." }
  },
  { id: "mark_hsbc",      chapter: 4, label: "Mark's HSBC current",         status: "new",
    value: "£3,800", evidence: "doc", contributedBy: "M", disclosedOn: "16 Apr" },
  { id: "mark_hl_isa",    chapter: 4, label: "Mark's Hargreaves ISA",      status: "new",
    value: "£15,000", evidence: "doc", contributedBy: "M", disclosedOn: "16 Apr",
    note: "Stocks & shares ISA, opened 2022" },
  { id: "savings_gap",    chapter: 4, label: "Unexplained savings shortfall", status: "missing",
    ai: { kind: "sanity", text: "Mark's £4,800/mo salary minus stated needs (£2,455) and known contributions leaves ~£9,400 unaccounted over 12 months. Could there be another account or investment?" },
    prompt: true
  },

  /* §5 Vehicles */
  { id: "sarah_car",      chapter: 5, label: "Sarah's Ford Escort (2019)", status: "agreed",
    value: "net £3,800 (£8,000 − £4,200 finance)", both: true },
  { id: "mark_car",       chapter: 5, label: "Mark's BMW 3 Series (2021)",  status: "agreed",
    value: "net £6,000 (£18,000 − £12,000 finance)", both: true },
  { id: "life_insurance", chapter: 5, label: "L&G life insurance",          status: "agreed",
    value: "£4,500 surrender", both: true },

  /* §6 Debts */
  { id: "sarah_barclaycard", chapter: 6, label: "Sarah's Barclaycard",     status: "agreed",
    value: "(£3,200)", evidence: "self", both: true },
  { id: "sarah_klarna",   chapter: 6, label: "Sarah's Klarna",            status: "agreed",
    value: "(£280)", evidence: "doc", both: true },
  { id: "mark_amex",      chapter: 6, label: "Mark's Amex",               status: "new",
    value: "(£5,800)", evidence: "self", contributedBy: "M", disclosedOn: "16 Apr",
    note: "Rolling balance, paid down monthly" },
  { id: "mark_slc",       chapter: 6, label: "Mark's Student Loan",       status: "agreed",
    value: "(£18,000)", evidence: "self", both: true },

  /* §7 Income */
  { id: "sarah_salary",   chapter: 7, label: "Sarah · NHS salary",         status: "agreed",
    value: "£2,400 / mo", evidence: "doc", both: true },
  { id: "sarah_cb",       chapter: 7, label: "Sarah · Child Benefit",      status: "agreed",
    value: "£96 / 4-weekly", evidence: "doc", both: true },
  { id: "mark_salary",    chapter: 7, label: "Mark · HSBC salary",         status: "agreed",
    value: "£4,800 / mo", evidence: "doc", both: true,
    ai: { kind: "evidence_age", text: "Payslip on file dates from September 2025 (7 months old). A recent payslip or P60 would refresh this." }
  },

  /* §8 Spending */
  { id: "sarah_needs",    chapter: 8, label: "Sarah's monthly needs",      status: "agreed",
    value: "£3,388 / mo", evidence: "doc", both: true },
  { id: "mark_needs",     chapter: 8, label: "Mark's monthly needs",       status: "agreed",
    value: "£2,455 / mo", evidence: "doc", both: true },
  { id: "sarah_transfer", chapter: 8, label: "Unidentified monthly transfer", status: "missing",
    ai: { kind: "cross_ref", text: "Sarah's Barclays statement shows £1,400/mo going to account ending 7723. Not listed in either picture — may be a savings account, rental, or family support. Worth confirming." },
    prompt: true
  },

  /* §9 Summary items */
  { id: "mark_p60",       chapter: 9, label: "Mark's P60 for 2025/26",    status: "gap",
    ai: { kind: "evidence", text: "Needed to confirm annual gross income for the record. HMRC portal download is fastest." }
  }
];

/* party disclosure progress */
const DISCLOSURE = {
  S: { name: "Sarah", complete: 14, total: 14, shared: "14 Apr", ink: SARAH },
  M: { name: "Mark",  complete: 13, total: 16, shared: "16 Apr", ink: MARK }
};

/* AI flag summary — aggregated across items */
function allFlags() {
  return ITEMS.filter(i => i.ai).map(i => ({ ...i.ai, itemId: i.id, label: i.label, chapter: i.chapter }));
}

/* Version history */
const VERSIONS = [
  { id: "v2.0", label: "UNIFIED",     date: "17 Apr",    who: "Both", note: "Joined view opened — Sarah & Mark" },
  { id: "v1.8", label: "MARK SHARED", date: "16 Apr",    who: "M",    note: "Mark completed disclosure, shared back" },
  { id: "v1.5", label: "IN PROGRESS", date: "15 Apr",    who: "M",    note: "Mark started building" },
  { id: "v1.0", label: "SHARED",      date: "14 Apr",    who: "S",    note: "Sarah shared picture with Mark" },
  { id: "v0.8", label: "DRAFT",       date: "13 Apr",    who: "S",    note: "Spending review added" },
  { id: "v0.5", label: "DRAFT",       date: "12 Apr",    who: "S",    note: "Bank accounts linked" },
  { id: "v0.1", label: "DRAFT",       date: "12 Apr",    who: "S",    note: "Sarah started" }
];

/* Activity (diff events, sortable) */
const ACTIVITY = [
  { v: "v2.0", time: "17 Apr · 09:14", who: "M", kind: "open",     text: "Mark opened joined view" },
  { v: "v2.0", time: "17 Apr · 09:14", who: "S", kind: "open",     text: "Sarah opened joined view" },
  { v: "v1.8", time: "16 Apr · 14:22", who: "M", kind: "added",    text: "Added HL ISA",     detail: "£15,000" },
  { v: "v1.8", time: "16 Apr · 14:18", who: "M", kind: "added",    text: "Added Amex",       detail: "(£5,800)" },
  { v: "v1.8", time: "16 Apr · 14:12", who: "M", kind: "added",    text: "Added NEST pension", detail: "£12,000" },
  { v: "v1.8", time: "16 Apr · 14:05", who: "M", kind: "confirmed", text: "Confirmed mortgage balance", detail: "£220,000" },
  { v: "v1.8", time: "16 Apr · 13:58", who: "M", kind: "queried",  text: "Queried joint savings", detail: "says £8k, not £12k" },
  { v: "v1.8", time: "16 Apr · 13:45", who: "M", kind: "queried",  text: "Queried property value", detail: "says £480k, not £450k" },
  { v: "v1.0", time: "14 Apr · 09:00", who: "S", kind: "shared",   text: "Shared picture with Mark" },
  { v: "v0.8", time: "13 Apr · 17:30", who: "S", kind: "added",    text: "Added spending review" },
  { v: "v0.5", time: "12 Apr · 10:22", who: "S", kind: "connected", text: "Connected Barclays, Monzo, Halifax" },
  { v: "v0.1", time: "12 Apr · 09:00", who: "S", kind: "created",  text: "Started picture" }
];

Object.assign(window, {
  RECON_ITEMS: ITEMS,
  RECON_DISCLOSURE: DISCLOSURE,
  RECON_VERSIONS: VERSIONS,
  RECON_ACTIVITY: ACTIVITY,
  reconAllFlags: allFlags,
  RECON_SARAH: SARAH,
  RECON_MARK: MARK
});
})();
