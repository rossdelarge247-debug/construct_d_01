/* =========================================================================
   HERO EXPLORATION · shared shell
   Each concept is a fixed-size artboard rendering a hero section in a
   miniature browser chrome. Concepts share tokens and primitives so the
   exploration feels like a single system, not 8 unrelated marketing pages.
   ========================================================================= */

const HX_INK   = "#1A1A1A";
const HX_SUB   = "#57534E";
const HX_MUTE  = "#78716C";
const HX_LINE  = "#E5E3DC";
const HX_BG    = "#F5F5F4";
const HX_PANEL = "#FFFFFF";
const HX_CANVAS= "#FAFAF7";

const HX_PHASE = {
  build:    { ink: "#4338CA", soft: "#EEF2FF" },
  reconcile:{ ink: "#9D174D", soft: "#FCE7F3" },
  settle:   { ink: "#0369A1", soft: "#E0F2FE" },
  finalise: { ink: "#166534", soft: "#DCFCE7" },
};

/* --- Inline icon helper --- */
function HxIc({ d, size = 14, sw = 1.75, style }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style} aria-hidden="true"
         dangerouslySetInnerHTML={{ __html: d }}/>
  );
}

const HX_ICONS = {
  arrow:   '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/>',
  check:   '<polyline points="5 12 10 17 19 7"/>',
  shield:  '<path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z"/>',
  lock:    '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  play:    '<polygon points="6 4 20 12 6 20 6 4" fill="currentColor"/>',
  spark:   '<path d="M12 3l1.5 5L18 9.5 13.5 11 12 16l-1.5-5L6 9.5 10.5 8z"/>',
};

/* --- Wordmark --- */
function HxWordmark({ size = 14 }) {
  return (
    <div className="flex items-center gap-1.5">
      <div className="relative" style={{ width: size+4, height: size+4 }}>
        <div className="absolute inset-0 rounded-full" style={{ background: "#111" }}/>
        <div className="absolute rounded-full" style={{ left:"42%", top:0, width:"58%", height:"100%", background: HX_BG }}/>
        <div className="absolute rounded-full" style={{ left:"45%", top:"12%", width:"10%", height:"76%", background:"#111" }}/>
      </div>
      <span style={{ fontSize: size, letterSpacing: "-0.01em", fontWeight: 600, color: "#111" }}>
        decouple
      </span>
    </div>
  );
}

/* --- Browser chrome (subtle, just a bar with dots + url) --- */
function HxChrome({ children, bg = HX_BG }) {
  return (
    <div style={{
      width: "100%", height: "100%", background: bg,
      display: "flex", flexDirection: "column", overflow: "hidden",
      fontFamily: "'Inter', -apple-system, sans-serif", color: HX_INK
    }}>
      <div className="flex items-center gap-2 px-4"
           style={{ height: 30, background: "#EAE6DE", borderBottom: `1px solid ${HX_LINE}`, flexShrink: 0 }}>
        <div className="flex gap-1.5">
          <span style={{ width: 9, height: 9, borderRadius: 99, background: "#E5E3DC" }}/>
          <span style={{ width: 9, height: 9, borderRadius: 99, background: "#E5E3DC" }}/>
          <span style={{ width: 9, height: 9, borderRadius: 99, background: "#E5E3DC" }}/>
        </div>
        <div className="flex-1 flex justify-center">
          <span className="rounded-md px-3 py-0.5"
                style={{ background: "rgba(255,255,255,0.6)", fontSize: 10, color: HX_MUTE, letterSpacing: "0.01em" }}>
            decouple.com
          </span>
        </div>
      </div>
      <div style={{ flex: 1, overflow: "hidden" }}>{children}</div>
    </div>
  );
}

/* --- Top nav (consistent across all concepts) --- */
function HxNav({ light = false }) {
  const fg = light ? "rgba(255,255,255,0.85)" : HX_SUB;
  const inkFg = light ? "#FFFFFF" : HX_INK;
  return (
    <nav className="flex items-center justify-between px-8"
         style={{
           height: 48,
           borderBottom: light ? "1px solid rgba(255,255,255,0.08)" : `1px solid ${HX_LINE}`
         }}>
      <div style={{ filter: light ? "invert(1)" : "none" }}>
        <HxWordmark size={13}/>
      </div>
      <div className="flex items-center gap-5" style={{ fontSize: 11, color: fg }}>
        <span>How it works</span>
        <span>Why us</span>
        <span>Pricing</span>
      </div>
      <div className="flex items-center gap-3">
        <span style={{ fontSize: 11, color: fg }}>Sign in</span>
        <span className="rounded-full"
              style={{
                padding: "5px 11px",
                background: light ? "#FFFFFF" : HX_INK,
                color: light ? HX_INK : "#FFFFFF",
                fontSize: 11, fontWeight: 500
              }}>
          Start free
        </span>
      </div>
    </nav>
  );
}

/* --- Reusable: small CTA --- */
function HxCTA({ label = "Start your free plan", time = "~3 minutes · no account needed", inverse = false, size = "lg" }) {
  const padY = size === "lg" ? 13 : 10;
  const padX = size === "lg" ? 22 : 18;
  const fs = size === "lg" ? 13 : 12;
  return (
    <div className="inline-flex flex-col items-start gap-1.5">
      <span className="inline-flex items-center gap-2 rounded-full font-medium"
            style={{
              padding: `${padY}px ${padX}px`,
              background: inverse ? "#FFFFFF" : HX_INK,
              color: inverse ? HX_INK : "#FFFFFF",
              border: `1px solid ${inverse ? HX_INK : HX_INK}`,
              fontSize: fs, letterSpacing: "-0.005em"
            }}>
        {label}
        <HxIc d={HX_ICONS.arrow} size={fs+1} sw={2}/>
      </span>
      {time && (
        <span className="mono" style={{ fontSize: 10, color: HX_MUTE, letterSpacing: "0.02em", paddingLeft: 4 }}>
          {time}
        </span>
      )}
    </div>
  );
}

/* --- Trust band (used in some concepts) --- */
function HxTrust({ inline = false, dim = false }) {
  const items = [
    [HX_ICONS.shield, "FCA-regulated via TrueLayer"],
    [HX_ICONS.lock,   "Read-only · we can't move money"],
    [HX_ICONS.check,  "Free until you sign up"],
  ];
  return (
    <div className="flex items-center gap-x-4 gap-y-1.5 flex-wrap"
         style={{ fontSize: 10.5, color: dim ? HX_MUTE : HX_SUB }}>
      {items.map(([d, t], i) => (
        <span key={i} className="flex items-center gap-1.5">
          <HxIc d={d} size={11} sw={1.8} style={{ color: HX_MUTE }}/>
          {t}
          {i < items.length-1 && <span style={{ width: 2, height: 2, borderRadius: 99, background: "#D6D3CC", marginLeft: 12 }}/>}
        </span>
      ))}
    </div>
  );
}

/* --- Eyebrow --- */
function HxEyebrow({ children, color = HX_MUTE }) {
  return (
    <span style={{
      fontSize: 9.5, letterSpacing: "0.14em", textTransform: "uppercase",
      fontWeight: 600, color
    }}>{children}</span>
  );
}

Object.assign(window, {
  HX_INK, HX_SUB, HX_MUTE, HX_LINE, HX_BG, HX_PANEL, HX_CANVAS, HX_PHASE,
  HxIc, HX_ICONS, HxWordmark, HxChrome, HxNav, HxCTA, HxTrust, HxEyebrow
});
