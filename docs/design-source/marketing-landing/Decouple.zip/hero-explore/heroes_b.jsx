/* =========================================================================
   HERO 06 · Two-column "his and hers" picture metaphor
   ========================================================================= */
function Hero06_TwoColumn() {
  const Side = ({ label, accent, items, you = false }) => (
    <div style={{ flex: 1, padding: "20px 18px", display: "flex", flexDirection: "column", gap: 10,
                  background: you ? "#FFFFFF" : "#FAFAF7",
                  borderRight: you ? `1px solid ${HX_LINE}` : "none" }}>
      <div className="flex items-center justify-between">
        <span style={{ fontSize: 10, color: HX_INK, fontWeight: 600 }}>{label}</span>
        <span className="rounded-full"
              style={{ padding: "2px 7px", background: accent.soft, color: accent.ink,
                       fontSize: 8.5, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>
          {you ? "Yours" : "Theirs"}
        </span>
      </div>
      {items.map((it, i) => (
        <div key={i} className="flex items-center justify-between"
             style={{ padding: "7px 9px", background: you ? HX_CANVAS : "#FFFFFF",
                      border: `1px solid ${HX_LINE}`, borderRadius: 6 }}>
          <span style={{ fontSize: 9.5, color: HX_INK }}>{it.k}</span>
          <span className="mono" style={{ fontSize: 9.5, color: HX_INK, fontWeight: 500 }}>{it.v}</span>
        </div>
      ))}
    </div>
  );

  return (
    <HxChrome>
      <HxNav/>
      <div style={{ padding: "44px 56px 0", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
        <div>
          <HxEyebrow>Two pictures, finally reconciled</HxEyebrow>
          <h1 className="serif"
              style={{ fontSize: 46, fontWeight: 600, letterSpacing: "-0.032em", lineHeight: 1.02,
                       marginTop: 16, color: HX_INK, textWrap: "balance" }}>
            You and them.{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>One workspace.</span>
          </h1>
          <p className="serif italic"
             style={{ fontSize: 15, lineHeight: 1.45, color: HX_SUB, marginTop: 16, maxWidth: 380 }}>
            You build privately. They build privately.
            Decouple reconciles the differences in plain language.
          </p>
          <div style={{ marginTop: 26 }}>
            <HxCTA/>
          </div>
        </div>

        {/* Reconciliation diagram */}
        <div style={{
          background: "#FFFFFF", border: `1px solid ${HX_LINE}`, borderRadius: 12,
          boxShadow: "0 16px 40px rgba(0,0,0,0.06)", overflow: "hidden",
          display: "flex", marginTop: 4
        }}>
          <Side
            label="Sarah"
            accent={HX_PHASE.build}
            you
            items={[
              { k: "Family home", v: "£510,000" },
              { k: "Joint savings", v: "£42,000" },
              { k: "Aviva pension", v: "£82,400" },
              { k: "Estimated debts", v: "£7,200" },
            ]}/>
          <Side
            label="Mark"
            accent={HX_PHASE.reconcile}
            items={[
              { k: "Family home", v: "£485,000" },
              { k: "Joint savings", v: "£42,000" },
              { k: "Aviva pension", v: "—" },
              { k: "Estimated debts", v: "£11,400" },
            ]}/>
          {/* Reconciliation tags down the middle */}
          <div style={{ position: "absolute" }}/>
        </div>
      </div>

      {/* Reconciliation strip below */}
      <div style={{ padding: "16px 56px 0" }}>
        <div className="flex items-center gap-2 flex-wrap" style={{ fontSize: 10, color: HX_SUB }}>
          <span className="rounded-full" style={{ padding: "2px 8px", background: "#FEF7E7", color: "#92400E", fontWeight: 600 }}>
            ▲ Differs · Family home
          </span>
          <span className="rounded-full" style={{ padding: "2px 8px", background: "#DCFCE7", color: "#166534", fontWeight: 600 }}>
            ✓ Agreed · Joint savings
          </span>
          <span className="rounded-full" style={{ padding: "2px 8px", background: "#EEF2FF", color: "#4338CA", fontWeight: 600 }}>
            ◇ Mark missing · Aviva pension
          </span>
          <span className="rounded-full" style={{ padding: "2px 8px", background: "#FEF7E7", color: "#92400E", fontWeight: 600 }}>
            ▲ Differs · Debts
          </span>
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 07 · Empathetic / human · testimonial-led, real voice
   ========================================================================= */
function Hero07_Empathetic() {
  return (
    <HxChrome>
      <HxNav/>
      <div className="grid h-full" style={{ gridTemplateColumns: "1.05fr 0.95fr", padding: "44px 56px 0", gap: 48 }}>
        <div>
          <HxEyebrow>You don't have to figure this out alone</HxEyebrow>
          <h1 className="serif"
              style={{ fontSize: 46, fontWeight: 600, letterSpacing: "-0.032em", lineHeight: 1.04,
                       marginTop: 18, color: HX_INK, textWrap: "balance" }}>
            A calmer way to{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>separate</span>.
          </h1>
          <p className="serif italic"
             style={{ fontSize: 16, lineHeight: 1.5, color: HX_SUB, marginTop: 16, maxWidth: 380 }}>
            Built with people who've been through it.
            For under £1,000, in three months — not £15,000 over eighteen.
          </p>
          <div style={{ marginTop: 26 }}>
            <HxCTA/>
          </div>
        </div>

        {/* Testimonial card */}
        <div style={{ alignSelf: "center", paddingTop: 8 }}>
          <div style={{
            background: "#FFFFFF", border: `1px solid ${HX_LINE}`, borderRadius: 14,
            padding: "22px 24px 20px", boxShadow: "0 14px 36px rgba(0,0,0,0.06)",
            position: "relative"
          }}>
            <div className="serif"
                 style={{ fontSize: 64, lineHeight: 0.6, color: "#E5E3DC",
                          position: "absolute", top: 18, left: 22, fontStyle: "italic" }}>
              “
            </div>
            <p className="serif"
               style={{ fontSize: 17, lineHeight: 1.42, color: HX_INK, paddingLeft: 26, marginTop: 4,
                        letterSpacing: "-0.005em", textWrap: "pretty" }}>
              We spent two months avoiding the conversation.
              Decouple gave us a place to actually have it —
              calmly, in writing, without anyone going first.
            </p>
            <div style={{ marginTop: 16, paddingTop: 14, borderTop: `1px solid ${HX_LINE}`,
                          display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 30, height: 30, borderRadius: 99, background: HX_PHASE.reconcile.soft,
                            color: HX_PHASE.reconcile.ink, display: "flex", alignItems: "center", justifyContent: "center",
                            fontSize: 11, fontWeight: 600 }}>
                R
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11.5, fontWeight: 600, color: HX_INK }}>Rachel · Manchester</div>
                <div style={{ fontSize: 10.5, color: HX_MUTE, marginTop: 1 }}>
                  Settled in 11 weeks · saved an estimated £11,800
                </div>
              </div>
              <span className="mono" style={{ fontSize: 10, color: HX_MUTE, letterSpacing: "0.04em" }}>
                Mar '26
              </span>
            </div>
          </div>

          {/* Two more compact bylines beneath */}
          <div style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
            {[
              { who: "James, Bristol",  detail: "Settled in 9 weeks · 2 children" },
              { who: "Priya, London",    detail: "Pension share, no court hearing" },
            ].map((t, i) => (
              <div key={i}
                   style={{ flex: "1 1 0", background: HX_CANVAS, border: `1px solid ${HX_LINE}`,
                            borderRadius: 10, padding: "10px 12px" }}>
                <div style={{ fontSize: 10.5, fontWeight: 600, color: HX_INK }}>{t.who}</div>
                <div style={{ fontSize: 10, color: HX_MUTE, marginTop: 2 }}>{t.detail}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 08 · Atmospheric · soft orb, dark background, ambient
   ========================================================================= */
function Hero08_Atmospheric() {
  return (
    <HxChrome bg="#0F0E0C">
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: "radial-gradient(circle at 70% 35%, rgba(99,76,180,0.28), transparent 50%), radial-gradient(circle at 30% 70%, rgba(45,80,140,0.22), transparent 55%), radial-gradient(circle at 80% 80%, rgba(160,80,120,0.16), transparent 60%)",
        filter: "blur(20px)"
      }}/>
      <div style={{ position: "relative", height: "100%", color: "#FFFFFF" }}>
        <HxNav light/>
        <div style={{ padding: "70px 64px 0", maxWidth: 1100, position: "relative" }}>
          <span style={{ fontSize: 9.5, letterSpacing: "0.16em", textTransform: "uppercase",
                         fontWeight: 600, color: "rgba(255,255,255,0.55)" }}>
            The complete settlement workspace
          </span>
          <h1 className="serif"
              style={{ fontSize: 80, fontWeight: 600, letterSpacing: "-0.04em", lineHeight: 1.0,
                       marginTop: 20, color: "#FFFFFF", textWrap: "balance" }}>
            Untangle{" "}
            <span style={{ fontStyle: "italic", color: "rgba(255,255,255,0.7)" }}>everything</span>.<br/>
            Move forward.
          </h1>
          <p className="serif italic"
             style={{ fontSize: 17, lineHeight: 1.5, color: "rgba(255,255,255,0.65)",
                      marginTop: 22, maxWidth: 480 }}>
            Finances, children, housing — and the agreement that holds it all.
            Under £1,000. Three months. One calm workspace.
          </p>
          <div style={{ marginTop: 36, display: "flex", alignItems: "flex-end", gap: 22 }}>
            <span className="inline-flex items-center gap-2 rounded-full font-medium"
                  style={{ padding: "13px 22px", background: "#FFFFFF", color: HX_INK,
                           fontSize: 13, letterSpacing: "-0.005em" }}>
              Start your free plan
              <HxIc d={HX_ICONS.arrow} size={14} sw={2}/>
            </span>
            <span className="mono" style={{ fontSize: 10, color: "rgba(255,255,255,0.45)",
                                            letterSpacing: "0.02em", paddingBottom: 8 }}>
              ~3 minutes · no account needed
            </span>
          </div>

          <div style={{ marginTop: 44, paddingTop: 18, borderTop: "1px solid rgba(255,255,255,0.12)",
                        maxWidth: 540, display: "flex", gap: 16, flexWrap: "wrap",
                        fontSize: 10.5, color: "rgba(255,255,255,0.55)" }}>
            <span className="flex items-center gap-1.5">
              <HxIc d={HX_ICONS.shield} size={11} sw={1.8}/>
              FCA-regulated via TrueLayer
            </span>
            <span style={{ width: 2, height: 2, borderRadius: 99, background: "rgba(255,255,255,0.3)" }}/>
            <span className="flex items-center gap-1.5">
              <HxIc d={HX_ICONS.lock} size={11} sw={1.8}/>
              Read-only access
            </span>
            <span style={{ width: 2, height: 2, borderRadius: 99, background: "rgba(255,255,255,0.3)" }}/>
            <span className="flex items-center gap-1.5">
              <HxIc d={HX_ICONS.check} size={11} sw={2.1}/>
              Free until you sign up
            </span>
          </div>
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 09 · Diagrammatic · journey-as-system illustration
   ========================================================================= */
function Hero09_Diagrammatic() {
  const phases = [
    { n: "1", k: "Start",     accent: { ink: "#1A1A1A", soft: "#F5F3EE" } },
    { n: "2", k: "Build",     accent: HX_PHASE.build },
    { n: "3", k: "Reconcile", accent: HX_PHASE.reconcile },
    { n: "4", k: "Settle",    accent: HX_PHASE.settle },
    { n: "5", k: "Finalise",  accent: HX_PHASE.finalise },
  ];
  return (
    <HxChrome>
      <HxNav/>
      <div style={{ padding: "44px 56px 0" }}>
        <div style={{ maxWidth: 720 }}>
          <HxEyebrow>From first question to court-sealed</HxEyebrow>
          <h1 className="serif"
              style={{ fontSize: 50, fontWeight: 600, letterSpacing: "-0.034em", lineHeight: 1.02,
                       marginTop: 16, color: HX_INK, textWrap: "balance" }}>
            One workspace.{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>Five phases.</span>
          </h1>
          <p style={{ fontSize: 13.5, lineHeight: 1.55, color: HX_SUB, marginTop: 14, maxWidth: 460 }}>
            Decouple takes you from the first awkward conversation to the agreement
            sealed by a court — in a fraction of the time, for a fraction of the cost.
          </p>
        </div>

        {/* Diagram */}
        <div style={{ marginTop: 32, position: "relative" }}>
          {/* connecting line */}
          <div style={{ position: "absolute", left: 36, right: 36, top: 18, height: 2,
                        background: `linear-gradient(90deg, ${HX_LINE} 0%, ${HX_INK} 100%)`,
                        borderRadius: 2 }}/>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 14 }}>
            {phases.map((p, i) => (
              <div key={p.k} style={{ position: "relative" }}>
                <div style={{
                  width: 38, height: 38, borderRadius: 99,
                  background: p.accent.soft, color: p.accent.ink,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 14, fontWeight: 700, fontFamily: "'Source Serif Pro', serif",
                  border: `1.5px solid ${p.accent.ink}`,
                  position: "relative", zIndex: 2, background: "#FFFFFF"
                }}>
                  {p.n}
                </div>
                <div style={{ marginTop: 14, paddingRight: 12 }}>
                  <div style={{ fontSize: 9, letterSpacing: "0.14em", textTransform: "uppercase",
                                fontWeight: 600, color: p.accent.ink }}>
                    {p.k}
                  </div>
                  <div className="serif italic"
                       style={{ fontSize: 13, color: HX_INK, marginTop: 4, lineHeight: 1.25 }}>
                    {i === 0 && "Free orientation"}
                    {i === 1 && "Sarah's Picture"}
                    {i === 2 && "Household Picture"}
                    {i === 3 && "Settlement Proposal"}
                    {i === 4 && "Court-ready package"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 32, display: "flex", alignItems: "flex-end", gap: 22 }}>
          <HxCTA/>
          <span style={{ fontSize: 12, color: HX_MUTE, paddingBottom: 8 }}>
            Free until phase 2 · pay once.
          </span>
        </div>
      </div>
    </HxChrome>
  );
}

Object.assign(window, {
  Hero06_TwoColumn, Hero07_Empathetic, Hero08_Atmospheric, Hero09_Diagrammatic
});
