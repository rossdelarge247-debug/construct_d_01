/* =========================================================================
   HERO 01 · Calm editorial (close to current)
   Two-col, italic accent, picture composition mini, trust band.
   ========================================================================= */
function Hero01_Editorial() {
  return (
    <HxChrome>
      <HxNav/>
      <div className="grid h-full" style={{ gridTemplateColumns: "1.1fr 0.9fr", padding: "44px 56px 0", gap: 48 }}>
        <div>
          <HxEyebrow>The complete settlement workspace</HxEyebrow>
          <h1 className="serif"
              style={{ fontSize: 48, fontWeight: 600, letterSpacing: "-0.034em", lineHeight: 1.02, marginTop: 18, color: HX_INK, textWrap: "balance" }}>
            Sort out your<br/>complete separation —{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>together</span>.
          </h1>
          <p className="serif italic"
             style={{ fontSize: 16, lineHeight: 1.45, color: HX_SUB, marginTop: 18, maxWidth: 380, fontWeight: 400 }}>
            Finances, children, housing — for under £1,000 and in 3 months.
            Instead of £15,000 and 18 months.
          </p>
          <div style={{ marginTop: 28 }}>
            <HxCTA/>
          </div>
          <div style={{ marginTop: 30, paddingTop: 18, borderTop: `1px solid ${HX_LINE}`, maxWidth: 460 }}>
            <HxTrust/>
          </div>
        </div>

        {/* Picture composition mini */}
        <div className="relative">
          <div className="absolute"
               style={{ left: "50%", top: 30, transform: "translateX(-50%)", width: 120, height: 240,
                        background: "#FFF", border: `1px solid ${HX_LINE}`, borderRadius: 8,
                        boxShadow: "0 12px 30px rgba(0,0,0,0.07)", padding: 12 }}>
            <div style={{ fontSize: 7.5, color: HX_MUTE, letterSpacing: "0.14em", textTransform: "uppercase", fontWeight: 600 }}>One document</div>
            <div className="serif" style={{ fontSize: 11.5, fontWeight: 600, marginTop: 4, letterSpacing: "-0.01em" }}>The Settlement</div>
            <div className="mt-2 space-y-1">
              {[["§1","Finances","#4338CA"],["§2","Children","#9D174D"],["§3","Housing","#0369A1"],["§4","Future","#166534"]].map(([n,t,c]) => (
                <div key={t} className="flex items-center gap-1.5"
                     style={{ background: HX_CANVAS, padding: "4px 6px", borderRadius: 4, border: `1px solid ${HX_LINE}` }}>
                  <span style={{ fontSize: 7, color: c, fontWeight: 700 }}>{n}</span>
                  <span style={{ fontSize: 8.5, flex: 1 }}>{t}</span>
                  <HxIc d={HX_ICONS.check} size={8} sw={2.5} style={{ color: c }}/>
                </div>
              ))}
            </div>
          </div>
          {[
            { x: -8, y: 0,    rot: -5, c: "#4338CA", t: "Finances",  v: "£612,400" },
            { x: 180, y: -6,  rot: 4,  c: "#9D174D", t: "Children",  v: "Shared 60/40" },
            { x: -2, y: 230,  rot: 3,  c: "#0369A1", t: "Housing",   v: "Sarah stays" },
            { x: 178, y: 245, rot: -3, c: "#166534", t: "Future",    v: "£1,200/mo" },
          ].map((card, i) => (
            <div key={i} className="absolute"
                 style={{ left: card.x, top: card.y, width: 110, transform: `rotate(${card.rot}deg)`,
                          background: "#FFF", border: `1px solid ${HX_LINE}`, borderRadius: 7,
                          padding: 9, boxShadow: "0 8px 18px rgba(0,0,0,0.05)" }}>
              <div className="flex items-center gap-1.5">
                <span style={{ width: 5, height: 5, borderRadius: 99, background: card.c }}/>
                <span style={{ fontSize: 7, color: HX_MUTE, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600 }}>0{i+1}</span>
              </div>
              <div className="serif" style={{ fontSize: 10, fontWeight: 600, marginTop: 4 }}>{card.t}</div>
              <div className="mono" style={{ fontSize: 9, color: HX_INK, marginTop: 3, fontWeight: 500 }}>{card.v}</div>
            </div>
          ))}
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 02 · Confident / declarative · big type, minimal furniture
   ========================================================================= */
function Hero02_Declarative() {
  return (
    <HxChrome>
      <HxNav/>
      <div style={{ padding: "70px 64px 0", maxWidth: 1100 }}>
        <HxEyebrow>Decouple · for separating couples</HxEyebrow>
        <h1 className="serif"
            style={{ fontSize: 96, fontWeight: 600, letterSpacing: "-0.045em", lineHeight: 0.98,
                     marginTop: 24, color: HX_INK, textWrap: "balance" }}>
          The complete<br/>
          <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>separation</span>,<br/>
          finally settled.
        </h1>
        <div style={{ marginTop: 40, display: "flex", alignItems: "center", gap: 28 }}>
          <HxCTA/>
          <span className="serif italic" style={{ fontSize: 15, color: HX_SUB }}>
            Under £1,000. Three months. One workspace.
          </span>
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 03 · Typographic · let the headline carry it (most minimal)
   ========================================================================= */
function Hero03_Typographic() {
  return (
    <HxChrome bg="#F5F5F4">
      <HxNav/>
      <div style={{ height: "calc(100% - 48px)", display: "flex", flexDirection: "column",
                    justifyContent: "center", alignItems: "center", padding: "0 64px" }}>
        <HxEyebrow>The complete settlement workspace</HxEyebrow>
        <h1 className="serif text-center"
            style={{ fontSize: 110, fontWeight: 600, letterSpacing: "-0.05em", lineHeight: 0.95,
                     marginTop: 24, color: HX_INK, maxWidth: 1000, textWrap: "balance" }}>
          Decouple,<br/>
          <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>together</span>.
        </h1>
        <p className="serif italic text-center"
           style={{ fontSize: 18, color: HX_SUB, marginTop: 30, maxWidth: 580, lineHeight: 1.45 }}>
          A single workspace for finances, children, housing —
          and the agreement that holds it all.
        </p>
        <div style={{ marginTop: 40 }}>
          <HxCTA/>
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 04 · Product-forward · real UI fragment in the hero
   ========================================================================= */
function Hero04_ProductForward() {
  return (
    <HxChrome>
      <HxNav/>
      <div className="grid h-full" style={{ gridTemplateColumns: "0.85fr 1.15fr", padding: "44px 56px 0", gap: 36 }}>
        <div>
          <HxEyebrow>What you actually get</HxEyebrow>
          <h1 className="serif"
              style={{ fontSize: 44, fontWeight: 600, letterSpacing: "-0.032em", lineHeight: 1.02,
                       marginTop: 16, color: HX_INK, textWrap: "balance" }}>
            Your full picture.{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>In 15 minutes.</span>
          </h1>
          <p style={{ fontSize: 13.5, lineHeight: 1.55, color: HX_SUB, marginTop: 18, maxWidth: 320 }}>
            Connect your bank, confirm what we found, share with your ex.
            One workspace from first question to court-sealed agreement.
          </p>
          <div style={{ marginTop: 26 }}>
            <HxCTA size="lg"/>
          </div>
        </div>

        {/* Product surface — reconciliation row sample */}
        <div style={{
          background: "#FFFFFF", border: `1px solid ${HX_LINE}`, borderRadius: 12,
          boxShadow: "0 24px 60px rgba(0,0,0,0.08), 0 4px 12px rgba(0,0,0,0.04)",
          overflow: "hidden", alignSelf: "start", marginTop: 4
        }}>
          <div className="flex items-center justify-between px-4"
               style={{ height: 32, borderBottom: `1px solid ${HX_LINE}`, background: "#FAFAF7" }}>
            <span style={{ fontSize: 10.5, color: HX_INK, fontWeight: 600 }}>Sarah's picture · Pensions</span>
            <span className="rounded-full"
                  style={{ padding: "2px 8px", background: HX_PHASE.build.soft, color: HX_PHASE.build.ink,
                           fontSize: 9, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>
              Private
            </span>
          </div>
          <div className="px-4 py-3 space-y-2">
            {[
              { name: "Aviva workplace pension", v: "£82,400", state: "agreed" },
              { name: "NHS pension (10y)",        v: "£41,200", state: "evidence" },
              { name: "Nest auto-enrol",          v: "£24,600", state: "gap" },
              { name: "Old Standard Life",        v: "—",        state: "ask" },
            ].map((r, i) => (
              <div key={i} className="flex items-center gap-3"
                   style={{ padding: "10px 12px", background: HX_CANVAS, borderRadius: 8,
                            border: `1px solid ${HX_LINE}`, position: "relative" }}>
                {r.state === "gap" && (
                  <span style={{ position: "absolute", left: 4, top: "50%", transform: "translateY(-50%)",
                                 width: 4, height: 4, borderRadius: 99, background: "#B45309" }}/>
                )}
                <span style={{ fontSize: 11, flex: 1, color: HX_INK, fontWeight: 500 }}>{r.name}</span>
                <span className="mono" style={{ fontSize: 10.5, color: HX_INK }}>{r.v}</span>
                <span className="rounded-full"
                      style={{ padding: "2px 7px", fontSize: 8.5, fontWeight: 600, letterSpacing: "0.04em",
                               textTransform: "uppercase",
                               background: r.state === "agreed" ? "#DCFCE7" :
                                          r.state === "evidence" ? "#EEF2FF" :
                                          r.state === "gap" ? "#FEF7E7" : "#F5F3EE",
                               color: r.state === "agreed" ? "#166534" :
                                     r.state === "evidence" ? "#4338CA" :
                                     r.state === "gap" ? "#92400E" : HX_MUTE }}>
                  {r.state === "agreed" ? "Agreed" :
                   r.state === "evidence" ? "Add evidence" :
                   r.state === "gap" ? "Gap" : "Ask later"}
                </span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between px-4 py-2.5"
               style={{ borderTop: `1px solid ${HX_LINE}`, background: "#FAFAF7" }}>
            <span style={{ fontSize: 10, color: HX_MUTE }}>23 of 127 transactions reviewed</span>
            <span style={{ fontSize: 10, color: HX_INK, fontWeight: 500 }}>Continue →</span>
          </div>
        </div>
      </div>
    </HxChrome>
  );
}

/* =========================================================================
   HERO 05 · Outcome-led · the court-sealed agreement as anchor
   ========================================================================= */
function Hero05_OutcomeLed() {
  return (
    <HxChrome>
      <HxNav/>
      <div className="grid h-full" style={{ gridTemplateColumns: "1fr 1fr", padding: "44px 56px 0", gap: 56 }}>
        <div>
          <HxEyebrow>The end you're working toward</HxEyebrow>
          <h1 className="serif"
              style={{ fontSize: 50, fontWeight: 600, letterSpacing: "-0.034em", lineHeight: 1.0,
                       marginTop: 18, color: HX_INK, textWrap: "balance" }}>
            A consent order,{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>sealed</span> by the court.
          </h1>
          <p style={{ fontSize: 14, lineHeight: 1.55, color: HX_SUB, marginTop: 18, maxWidth: 360 }}>
            Decouple takes you the whole way — from the first awkward conversation
            to the court-sealed agreement that legally ends your financial ties.
            Under £1,000. Three months.
          </p>
          <div style={{ marginTop: 28 }}>
            <HxCTA/>
          </div>
        </div>

        {/* Document mock */}
        <div className="relative" style={{ paddingTop: 8 }}>
          <div style={{
            width: "100%", maxWidth: 360, aspectRatio: "1 / 1.32",
            background: "#FFFFFF", border: `1px solid ${HX_LINE}`, borderRadius: 4,
            boxShadow: "0 30px 60px rgba(0,0,0,0.10), 0 4px 12px rgba(0,0,0,0.04)",
            padding: "30px 32px", position: "relative", margin: "0 auto"
          }}>
            <div style={{ textAlign: "center" }}>
              <div className="mono" style={{ fontSize: 7.5, color: HX_MUTE, letterSpacing: "0.18em" }}>FORM A · CONSENT ORDER</div>
              <div className="serif" style={{ fontSize: 14, fontWeight: 600, marginTop: 10, letterSpacing: "-0.005em" }}>
                In the Family Court at London
              </div>
              <div className="serif italic" style={{ fontSize: 9, color: HX_SUB, marginTop: 4 }}>
                Between Sarah Hayes &amp; Mark Hayes
              </div>
            </div>

            <div style={{ marginTop: 22 }}>
              {[
                "1. The applicant's claims for financial provision are dismissed save as below.",
                "2. The respondent shall transfer to the applicant the property at 14 Linden Road…",
                "3. Pension sharing order over the respondent's Aviva pension at 32%.",
                "4. Periodical payments to the applicant of £1,200 pcm for 60 months.",
                "5. Lump sum of £24,000 in two tranches…",
              ].map((line, i) => (
                <div key={i} style={{ fontSize: 7.5, color: HX_SUB, lineHeight: 1.6, marginTop: i === 0 ? 0 : 6 }}>
                  {line}
                </div>
              ))}
            </div>

            {/* Sealed stamp */}
            <div style={{
              position: "absolute", right: -14, top: 100, transform: "rotate(8deg)",
              width: 84, height: 84, borderRadius: 99,
              border: "2px solid #B91C1C", color: "#B91C1C",
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              background: "rgba(255,255,255,0.92)"
            }}>
              <span className="serif" style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.06em" }}>SEALED</span>
              <span className="mono" style={{ fontSize: 7, marginTop: 2 }}>14 · APR · 2026</span>
              <span className="mono" style={{ fontSize: 6.5, marginTop: 1, color: "#B91C1C", opacity: 0.8 }}>FAMILY COURT</span>
            </div>

            <div style={{ position: "absolute", bottom: 24, left: 32, right: 32,
                          display: "flex", justifyContent: "space-between", fontSize: 8, color: HX_MUTE }}>
              <span>Issued via Decouple</span>
              <span className="mono">Case No. FA-26-0418</span>
            </div>
          </div>
          <div style={{ textAlign: "center", marginTop: 12 }}>
            <span className="serif italic" style={{ fontSize: 12, color: HX_MUTE }}>
              The end you're working toward.
            </span>
          </div>
        </div>
      </div>
    </HxChrome>
  );
}

Object.assign(window, {
  Hero01_Editorial, Hero02_Declarative, Hero03_Typographic, Hero04_ProductForward, Hero05_OutcomeLed
});
