/* Phase 4 — shared data
   Settlement proposal state: Sarah's v1, Mark's counter v2, Sarah's response v3, agreed v5
   All figures tie back to the agreed household picture */
(function(){

const SARAH = "#2F6D5F", MARK = "#7E5A4E";

/* ============================================================
   AGREED FACTS — from Household Picture v2.0 UNIFIED
   ============================================================ */
const FACTS = {
  home: {
    value: 450000, mortgage: 220000, equity: 230000,
    monthlyMortgage: 1150,
    address: "12 Oak Road, Exeter"
  },
  pensions: {
    sarah: { value: 180412, type: "NHS · defined benefit" },
    mark:  { value: 12000,  type: "NEST · defined contribution" }
  },
  savings: {
    joint: 8000,
    sarah: 1240 + 6000,   /* Monzo + HL ISA */
    mark:  3800 + 15000   /* HSBC + HL ISA */
  },
  vehicles: {
    sarah: { model: "Ford Escort (2019)", net: 3800 },
    mark:  { model: "BMW 3 Series (2021)", net: 6000 }
  },
  other: {
    lifeInsurance: 4500
  },
  debts: {
    sarah: 3480,    /* Barclaycard + Klarna */
    mark: 23800     /* Amex + student loan */
  },
  income: {
    sarah: 2496, mark: 4800
  },
  spending: {
    sarah: 3388, mark: 2455
  },
  children: [
    { name: "Emma", age: 7 },
    { name: "Jake", age: 4 }
  ],
  cms: 576   /* indicative child maintenance */
};

/* Total net household wealth — used across every view */
function totalNet() {
  const F = FACTS;
  return F.home.equity + F.pensions.sarah.value + F.pensions.mark.value
    + F.savings.joint + F.savings.sarah + F.savings.mark
    + F.vehicles.sarah.net + F.vehicles.mark.net + F.other.lifeInsurance
    - F.debts.sarah - F.debts.mark;
}
/* = 230,000 + 192,412 + 8,000 + 7,240 + 18,800 + 3,800 + 6,000 + 4,500 - 3,480 - 23,800
   = 443,472 */

/* ============================================================
   PROPOSAL VERSIONS
   Each version records: who sent it, when, per-section choices,
   overall Sarah%/Mark% split, £ gap to the other's last position
   ============================================================ */
const PROPOSALS = {
  v1: {
    id: "v1", author: "S", sentOn: "3 May", state: "sent",
    title: "Sarah's proposal",
    sections: {
      home:       { choice: "sell_split_50_50", label: "Sell, split 50/50", impact: "£115,000 each" },
      pensions:   { choice: "no_share",         label: "No pension sharing", impact: "Sarah £180k · Mark £12k" },
      savings:    { choice: "each_keeps_own",   label: "Each keeps own accounts", impact: "Sarah £7,240 · Mark £18,800" },
      vehicles:   { choice: "each_keeps_own",   label: "Each keeps the car they drive", impact: "Sarah £3,800 · Mark £6,000" },
      debts:      { choice: "each_own",         label: "Each responsible for own", impact: "Sarah (£3,480) · Mark (£23,800)" },
      children:   { choice: "primary_eow_mid",  label: "Primary with Sarah · EOW + midweek · £576/mo CMS", impact: "" },
      spousal:    { choice: "400_3y",           label: "£400/mo for 3 years", impact: "£14,400 total" }
    },
    sarahPct: 54, markPct: 46,
    gapToOther: 72000,
    reasoningShown: true
  },
  v2: {
    id: "v2", author: "M", sentOn: "7 May", state: "sent",
    title: "Mark's counter",
    changes: ["pensions", "debts", "spousal"],
    sections: {
      pensions:   { choice: "share_40",         label: "40% share of Sarah's NHS pension", impact: "£72,165 transfer to Mark" },
      debts:      { choice: "share_half_amex",  label: "Share Amex 50/50, each own the rest", impact: "Sarah (£6,380) · Mark (£20,900)" },
      spousal:    { choice: "clean_break",      label: "Clean break · no ongoing maintenance", impact: "No transfer" }
    },
    sarahPct: 48, markPct: 52,
    gapToOther: 36000
  },
  v3: {
    id: "v3", author: "S", sentOn: "11 May", state: "sent",
    title: "Sarah's response",
    changes: ["pensions", "spousal"],
    sections: {
      pensions:   { choice: "share_20",         label: "20% share of Sarah's NHS pension", impact: "£36,082 transfer to Mark" },
      spousal:    { choice: "400_2y",           label: "£400/mo for 2 years", impact: "£9,600 total" }
    },
    sarahPct: 52, markPct: 48,
    gapToOther: 18000
  },
  v4: {
    id: "v4", author: "M", sentOn: "13 May", state: "sent",
    title: "Mark's final points",
    changes: ["debts"],
    sections: {
      debts:      { choice: "each_own",         label: "Each responsible for own (accepted Sarah's original)", impact: "Sarah (£3,480) · Mark (£23,800)" }
    },
    sarahPct: 52, markPct: 48,
    gapToOther: 0
  },
  v5: {
    id: "v5", author: "both", sentOn: "14 May", state: "agreed",
    title: "Agreed",
    sections: {
      home:       { label: "Sell, split 50/50",                    impact: "£115,000 each" },
      pensions:   { label: "20% share to Mark (£36,082)",          impact: "Sarah retains £144,330 · Mark receives £48,082" },
      savings:    { label: "Each keeps own accounts · split joint 50/50", impact: "Sarah £11,240 · Mark £22,800" },
      vehicles:   { label: "Each keeps the car they drive",        impact: "Sarah £3,800 · Mark £6,000" },
      debts:      { label: "Each responsible for own",             impact: "Sarah (£3,480) · Mark (£23,800)" },
      children:   { label: "Primary with Sarah · EOW + midweek · £576/mo CMS", impact: "" },
      spousal:    { label: "£400/mo for 2 years",                  impact: "£9,600 total" }
    },
    sarahPct: 52, markPct: 48,
    gapToOther: 0
  }
};

/* Convergence — £ gap per version (used for sparkline) */
const CONVERGENCE = [
  { v: "v1", author: "S", date: "3 May",  gap: 72000 },
  { v: "v2", author: "M", date: "7 May",  gap: 36000 },
  { v: "v3", author: "S", date: "11 May", gap: 18000 },
  { v: "v4", author: "M", date: "13 May", gap: 0 }
];

/* Section metadata — used across proposal builder + redline */
const SECTIONS = [
  { key: "home",      title: "The home",         n: 1,
    subject: "Net equity £230,000" },
  { key: "pensions",  title: "Pensions",         n: 2,
    subject: "Sarah £180,412 · Mark £12,000 · Gap £168,412" },
  { key: "savings",   title: "Savings",          n: 3,
    subject: "Joint £8k · Sarah £7,240 · Mark £18,800" },
  { key: "vehicles",  title: "Vehicles",         n: 4,
    subject: "Sarah £3,800 · Mark £6,000" },
  { key: "debts",     title: "Debts",            n: 5,
    subject: "Sarah (£3,480) · Mark (£23,800)" },
  { key: "children",  title: "Children",         n: 6,
    subject: "Emma (7) · Jake (4)" },
  { key: "spousal",   title: "Spousal maintenance", n: 7,
    subject: "Sarah shortfall £892/mo · Mark surplus £2,345/mo" }
];

Object.assign(window, {
  P4_FACTS: FACTS,
  P4_PROPOSALS: PROPOSALS,
  P4_CONVERGENCE: CONVERGENCE,
  P4_SECTIONS: SECTIONS,
  P4_TOTAL_NET: totalNet(),
  P4_SARAH: SARAH, P4_MARK: MARK
});
})();
