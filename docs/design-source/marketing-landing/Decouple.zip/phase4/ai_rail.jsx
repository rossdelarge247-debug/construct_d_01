/* Phase 4 — AI + Collaboration Rail
   Shared 320px right-side panel used across all 5 settlement views.
   3 tabs: Comments · AI coach · Activity

   Each view passes its own `aiInsights`, `comments`, `activity`, and optional
   `onApplyFallback(payload)` to accept an AI-suggested fallback position.
*/
(function(){
const { useState, useEffect, useMemo, useRef } = React;
const { P4_TOK: T, P4_Ic: I, P4_Avatar, P4_StatusChip, P4_money } = window;

/* ============================================================
   AI INSIGHT CARD
   insight: {
     id, kind: "court_risk" | "fairness" | "fallback" | "comment_analysis" | "tip",
     severity: "info" | "notice" | "warn",
     title, body,
     sectionKey?,              // which section this belongs to
     citation?,                 // e.g. "MCA 1973, s.25" or "Cafcass guidance"
     fallbacks?: [{            // alternative positions user can one-click apply
       label, sub, payload      // payload passed back to onApplyFallback
     }]
   }
   ============================================================ */
function SeverityDot({ severity }) {
  const c = severity === "warn" ? T.CONTESTED : severity === "notice" ? T.PENDING : T.AGREED;
  return <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: c }}/>;
}

function KindLabel({ kind }) {
  const map = {
    court_risk:       { label: "Court reasonableness", icon: "gavel" },
    fairness:         { label: "Fairness check",       icon: "scale" },
    fallback:         { label: "Fallback position",    icon: "route" },
    comment_analysis: { label: "On this comment",      icon: "msg"   },
    tip:              { label: "Coaching",             icon: "spark" }
  };
  const m = map[kind] || map.tip;
  const Icon = m.icon === "gavel" ? I.Gavel
    : m.icon === "msg" ? I.Msg
    : m.icon === "spark" ? I.Spark
    : null;
  return (
    <span className="inline-flex items-center gap-1 label-xs whitespace-nowrap" style={{ color: T.MUTE }}>
      {Icon && <Icon size={10.5} stroke={T.MUTE}/>}
      {m.label}
    </span>
  );
}

function AIInsightCard({ insight, onApplyFallback, onJumpTo }) {
  const [expanded, setExpanded] = useState(false);
  const sevBorder = insight.severity === "warn" ? "#FCA5A5"
    : insight.severity === "notice" ? "#F9D89D" : T.HAIR;
  const sevTint = insight.severity === "warn" ? "#FFF5F5"
    : insight.severity === "notice" ? "#FFFBEB" : "#FFFFFF";
  return (
    <div className="rounded-lg overflow-hidden transition"
         style={{ background: sevTint, border: `1px solid ${sevBorder}` }}>
      <div className="px-3 pt-2.5 pb-2">
        <div className="flex items-center justify-between mb-1">
          <KindLabel kind={insight.kind}/>
          <SeverityDot severity={insight.severity}/>
        </div>
        <div style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.35, color: T.INK }}>
          {insight.title}
        </div>
        {insight.sectionKey && onJumpTo && (
          <button onClick={() => onJumpTo(insight.sectionKey)}
                  className="mt-1 label-xs inline-flex items-center gap-0.5"
                  style={{ color: T.SUB }}>
            <I.ArrowR size={10} stroke={T.SUB}/> Jump to {insight.sectionKey}
          </button>
        )}
      </div>
      {(insight.body || insight.citation) && (
        <>
          <button onClick={() => setExpanded(x => !x)}
                  className="w-full flex items-center justify-between px-3 py-1.5 text-left"
                  style={{ borderTop: `1px solid ${sevBorder}`, background: "#FFFFFFB0" }}>
            <span className="label-xs whitespace-nowrap" style={{ color: T.SUB }}>
              {expanded ? "Hide reasoning" : "Show reasoning"}
            </span>
            <I.ChevD size={11} stroke={T.SUB}
                     style={{ transform: expanded ? "rotate(180deg)" : "none", transition: "transform 180ms" }}/>
          </button>
          {expanded && (
            <div className="px-3 py-2.5" style={{ background: "#FFFFFF", borderTop: `1px solid ${sevBorder}`, fontSize: 11.5, color: T.SUB, lineHeight: 1.5 }}>
              {insight.body}
              {insight.citation && (
                <div className="mt-2 label-xs" style={{ color: T.MUTE }}>
                  <I.Doc size={10} style={{ display: "inline", marginRight: 3, verticalAlign: "-1px" }}/>
                  {insight.citation}
                </div>
              )}
            </div>
          )}
        </>
      )}
      {insight.fallbacks && insight.fallbacks.length > 0 && (
        <div className="px-3 py-2.5 space-y-1.5" style={{ background: "#FFFFFF", borderTop: `1px solid ${sevBorder}` }}>
          <div className="label-xs whitespace-nowrap" style={{ color: T.MUTE }}>Fallback positions</div>
          {insight.fallbacks.map((fb, i) => (
            <button key={i}
                    onClick={() => onApplyFallback && onApplyFallback(fb.payload, fb)}
                    className="w-full text-left rounded-md px-2.5 py-1.5 transition group"
                    style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}` }}
                    onMouseEnter={e => { e.currentTarget.style.background = "#F0EFEC"; }}
                    onMouseLeave={e => { e.currentTarget.style.background = "#FAFAF7"; }}>
              <div className="flex items-center justify-between gap-2">
                <div className="flex-1 min-w-0" style={{ fontSize: 12, fontWeight: 600, color: T.INK, lineHeight: 1.3 }}>{fb.label}</div>
                <I.ArrowR size={11} stroke={T.SUB}/>
              </div>
              {fb.sub && <div className="pr-5" style={{ fontSize: 11, color: T.SUB, marginTop: 2, lineHeight: 1.4 }}>{fb.sub}</div>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   COMMENT THREAD
   comment: { id, who: "S"|"M"|"AI", time, text, sectionKey?, parentId?, aiAnalysis? }
   ============================================================ */
function Comment({ c, replies, onReply }) {
  const isAI = c.who === "AI";
  const bg = isAI ? "#F5F3FF" : c.who === "S" ? "#FFFFFF" : "#FDFAF7";
  const border = isAI ? "#E4DEFD" : T.HAIR;

  return (
    <div className="rounded-lg" style={{ background: bg, border: `1px solid ${border}` }}>
      <div className="px-3 pt-2.5 pb-2">
        <div className="flex items-center gap-2 mb-1.5">
          {isAI ? (
            <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                 style={{ background: "#6D5BD0", color: "#FFF", fontSize: 10, fontWeight: 700 }}>
              <I.Spark size={10} stroke="#FFF"/>
            </div>
          ) : <P4_Avatar who={c.who} size={20}/>}
          <div className="flex-1 min-w-0 flex items-baseline gap-1.5">
            <span className="whitespace-nowrap" style={{ fontSize: 12, fontWeight: 600, color: T.INK }}>
              {isAI ? "Decouple AI" : c.who === "S" ? "Sarah" : "Mark"}
            </span>
            <span className="label-xs" style={{ color: T.MUTE }}>{c.time}</span>
          </div>
          {c.sectionKey && (
            <span className="label-xs" style={{ color: T.MUTE }}>§{c.sectionKey}</span>
          )}
        </div>
        <div style={{ fontSize: 12.5, color: T.INK, lineHeight: 1.5 }}>{c.text}</div>
      </div>
      {c.aiAnalysis && (
        <div className="px-3 py-2" style={{ background: "#F5F3FF", borderTop: `1px solid ${border}` }}>
          <div className="flex items-start gap-1.5">
            <I.Spark size={11} style={{ color: "#6D5BD0", marginTop: 2, flexShrink: 0 }}/>
            <div>
              <div className="label-xs" style={{ color: "#6D5BD0" }}>AI on this comment</div>
              <div style={{ fontSize: 11.5, color: T.SUB, marginTop: 2, lineHeight: 1.5 }}>{c.aiAnalysis}</div>
            </div>
          </div>
        </div>
      )}
      {replies && replies.length > 0 && (
        <div className="pl-6 pr-3 pb-2 space-y-1.5">
          {replies.map(r => <Comment key={r.id} c={r}/>)}
        </div>
      )}
    </div>
  );
}

function CommentsTab({ comments, onPost }) {
  const [draft, setDraft] = useState("");
  const [askAI, setAskAI] = useState(false);
  const roots = comments.filter(c => !c.parentId);
  const repliesByParent = useMemo(() => {
    const m = {};
    comments.filter(c => c.parentId).forEach(c => {
      (m[c.parentId] = m[c.parentId] || []).push(c);
    });
    return m;
  }, [comments]);

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto nice-scroll px-3 py-3 space-y-2">
        {roots.map(c => <Comment key={c.id} c={c} replies={repliesByParent[c.id]}/>)}
        {roots.length === 0 && (
          <div className="text-center py-10" style={{ fontSize: 12, color: T.MUTE }}>
            No comments yet.
          </div>
        )}
      </div>
      <div className="flex-shrink-0 px-3 pt-2 pb-3" style={{ borderTop: `1px solid ${T.HAIR}`, background: "#FFF" }}>
        <textarea value={draft} onChange={e => setDraft(e.target.value)}
                  placeholder="Add a comment…"
                  rows={2}
                  className="w-full px-2.5 py-2 rounded-md resize-none"
                  style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}`, fontSize: 12.5, color: T.INK, fontFamily: "inherit", outline: "none" }}/>
        <div className="flex items-center justify-between mt-2">
          <label className="flex items-center gap-1.5" style={{ fontSize: 11.5, color: T.SUB, cursor: "pointer" }}>
            <input type="checkbox" checked={askAI} onChange={e => setAskAI(e.target.checked)} style={{ accentColor: "#6D5BD0" }}/>
            Ask AI to assess first
          </label>
          <button onClick={() => { if (draft.trim()) { onPost && onPost(draft, askAI); setDraft(""); } }}
                  disabled={!draft.trim()}
                  className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-white"
                  style={{ background: draft.trim() ? T.INK : "#BDBDBD", fontSize: 12, fontWeight: 600, cursor: draft.trim() ? "pointer" : "not-allowed" }}>
            <I.Send size={11} stroke="#FFF"/> Post
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   AI COACH TAB
   Groups insights by: Court risk · Fairness · Fallbacks · Comment analysis
   ============================================================ */
function AICoachTab({ insights, onApplyFallback, onJumpTo, summaryLine }) {
  const ordered = useMemo(() => {
    const order = { court_risk: 0, fairness: 1, comment_analysis: 2, fallback: 3, tip: 4 };
    return [...insights].sort((a, b) => (order[a.kind] ?? 9) - (order[b.kind] ?? 9));
  }, [insights]);

  const warnCount = insights.filter(i => i.severity === "warn").length;
  const noticeCount = insights.filter(i => i.severity === "notice").length;

  return (
    <div className="flex-1 overflow-y-auto nice-scroll">
      {/* Summary */}
      <div className="px-3 py-3" style={{ background: "linear-gradient(180deg, #F5F3FF 0%, #FFFFFF 100%)", borderBottom: `1px solid ${T.HAIR}` }}>
        <div className="flex items-center gap-2 mb-1.5">
          <div className="w-5 h-5 rounded-full flex items-center justify-center"
               style={{ background: "#6D5BD0" }}>
            <I.Spark size={10} stroke="#FFF"/>
          </div>
          <span className="whitespace-nowrap" style={{ fontSize: 12.5, fontWeight: 700, color: "#4C3FB8", letterSpacing: "-0.01em" }}>Decouple AI</span>
        </div>
        {summaryLine && (
          <div style={{ fontSize: 12.5, color: T.INK, lineHeight: 1.5 }}>{summaryLine}</div>
        )}
        <div className="flex items-center gap-3 mt-2.5">
          {warnCount > 0 && (
            <span className="flex items-center gap-1 label-xs" style={{ color: T.CONTESTED }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: T.CONTESTED }}/>
              {warnCount} flag{warnCount === 1 ? "" : "s"}
            </span>
          )}
          {noticeCount > 0 && (
            <span className="flex items-center gap-1 label-xs" style={{ color: T.PENDING }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: T.PENDING }}/>
              {noticeCount} notice{noticeCount === 1 ? "" : "s"}
            </span>
          )}
          {warnCount === 0 && noticeCount === 0 && (
            <span className="flex items-center gap-1 label-xs" style={{ color: T.AGREED }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: T.AGREED }}/>
              Everything looks reasonable
            </span>
          )}
        </div>
      </div>

      {/* Insights */}
      <div className="px-3 py-3 space-y-2">
        {ordered.map(ins => (
          <AIInsightCard key={ins.id} insight={ins}
                         onApplyFallback={onApplyFallback}
                         onJumpTo={onJumpTo}/>
        ))}
        {ordered.length === 0 && (
          <div className="text-center py-10" style={{ fontSize: 12, color: T.MUTE }}>
            No specific feedback at this stage.
          </div>
        )}
      </div>

      {/* Footer disclaimer */}
      <div className="px-3 py-2.5 mx-3 mb-3 rounded-md"
           style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}`, fontSize: 10.5, color: T.MUTE, lineHeight: 1.5 }}>
        AI suggestions are guidance based on typical court outcomes for cases like yours. Not a substitute for legal advice.
      </div>
    </div>
  );
}

/* ============================================================
   ACTIVITY TAB — version log
   ============================================================ */
function ActivityTab({ activity }) {
  return (
    <div className="flex-1 overflow-y-auto nice-scroll px-3 py-3">
      <div className="relative pl-5">
        <div className="absolute left-2 top-1 bottom-1 w-px" style={{ background: T.HAIR }}/>
        {activity.map((a, i) => (
          <div key={i} className="relative mb-3">
            <div className="absolute rounded-full"
                 style={{
                   left: -14, top: 4, width: 9, height: 9,
                   background: a.who === "S" ? T.SARAH : a.who === "M" ? T.MARK : a.who === "AI" ? "#6D5BD0" : T.AGREED,
                   border: "2px solid #FFF",
                   boxShadow: `0 0 0 1px ${T.HAIR}`
                 }}/>
            <div className="label-xs" style={{ color: T.MUTE }}>{a.time}</div>
            <div style={{ fontSize: 12.5, fontWeight: 500, color: T.INK, marginTop: 1, lineHeight: 1.4 }}>
              {a.title}
            </div>
            {a.sub && (
              <div style={{ fontSize: 11.5, color: T.SUB, marginTop: 2, lineHeight: 1.45 }}>{a.sub}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   MAIN AI RAIL — 320px right-side panel with tabs
   ============================================================ */
function AIRail({
  insights = [],
  comments = [],
  activity = [],
  summaryLine,
  defaultTab = "ai",
  onApplyFallback,
  onJumpTo,
  onPostComment
}) {
  const [tab, setTab] = useState(defaultTab);
  const warnCount = insights.filter(i => i.severity === "warn").length;
  const noticeCount = insights.filter(i => i.severity === "notice").length;
  const aiBadge = warnCount + noticeCount;

  return (
    <div className="flex-shrink-0 flex flex-col"
         style={{ width: 320, background: "#FFF", borderLeft: `1px solid ${T.HAIR}` }}>
      {/* Tabs */}
      <div className="flex-shrink-0 flex" style={{ borderBottom: `1px solid ${T.HAIR}` }}>
        {[
          { id: "comments", label: "Comments", count: comments.length },
          { id: "ai",       label: "AI coach", badge: aiBadge, badgeColor: warnCount > 0 ? T.CONTESTED : T.PENDING },
          { id: "activity", label: "Activity", count: activity.length }
        ].map(t => {
          const active = tab === t.id;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2.5 transition relative"
                    style={{
                      background: active ? "#FFF" : "#FAFAF7",
                      color: active ? T.INK : T.SUB,
                      fontSize: 12, fontWeight: active ? 600 : 500,
                      borderBottom: active ? `2px solid ${T.INK}` : "2px solid transparent"
                    }}>
              {t.label}
              {t.badge ? (
                <span className="inline-flex items-center justify-center rounded-full text-white tabular-nums"
                      style={{ minWidth: 16, height: 16, padding: "0 5px", fontSize: 10, fontWeight: 700, background: t.badgeColor }}>
                  {t.badge}
                </span>
              ) : t.count ? (
                <span style={{ fontSize: 11, color: T.MUTE }}>{t.count}</span>
              ) : null}
            </button>
          );
        })}
      </div>

      {/* Panel body */}
      <div className="flex-1 flex flex-col min-h-0">
        {tab === "comments" && <CommentsTab comments={comments} onPost={onPostComment}/>}
        {tab === "ai" && <AICoachTab insights={insights} onApplyFallback={onApplyFallback} onJumpTo={onJumpTo} summaryLine={summaryLine}/>}
        {tab === "activity" && <ActivityTab activity={activity}/>}
      </div>
    </div>
  );
}

Object.assign(window, {
  P4_AIRail: AIRail,
  P4_AIInsightCard: AIInsightCard
});
})();
