/* Phase 4 View E — Agreement (v5)
   Sarah and Mark have signed. This is the moment of arrival.
   Pride tone — not celebratory emoji, but quiet dignity.
   Convergence sparkline shown prominently as a token of what was done.

   Tweak: tone — quiet | formal | warm */
(function(){
const { useState, useEffect } = React;
const { P4_TOK: T, P4_Ic: I, P4_Avatar, P4_StatusChip, P4_TopBar, P4_ChapterRail,
        P4_FloatingRouter, P4_TweakPanel, P4_money, P4_SECTIONS,
        P4_PROPOSALS, P4_CONVERGENCE, P4_FACTS,
        P4_AIRail, P4_AI_AGREEMENT } = window;

const V5 = P4_PROPOSALS.v5;

/* ============================================================
   CONVERGENCE SPARKLINE — the "journey token"
   Slightly more formal than the progress-board version.
   ============================================================ */
function JourneySparkline({ width = 560, height = 120, compact }) {
  const pts = P4_CONVERGENCE;
  const maxGap = Math.max(...pts.map(p => p.gap));
  const w = width, h = height;
  const padL = 40, padR = 40, padT = 24, padB = 30;
  const xs = pts.map((_, i) => padL + (i / (pts.length - 1)) * (w - padL - padR));
  const ys = pts.map(p => h - padB - (p.gap / maxGap) * (h - padT - padB));
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${xs[i].toFixed(1)} ${ys[i].toFixed(1)}`).join(" ");
  const area = `${path} L ${xs[xs.length - 1].toFixed(1)} ${h - padB} L ${xs[0].toFixed(1)} ${h - padB} Z`;

  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
      {/* Zero baseline */}
      <line x1={padL} y1={h - padB} x2={w - padR} y2={h - padB} stroke="#E5E7EB"/>
      <text x={padL - 8} y={h - padB + 3} fontSize="10" textAnchor="end" fill={T.MUTE}>£0</text>
      <text x={padL - 8} y={padT + 4} fontSize="10" textAnchor="end" fill={T.MUTE}>{P4_money(maxGap)}</text>

      {/* Area */}
      <path d={area} fill={T.AGREED} opacity="0.08"/>
      {/* Line */}
      <path d={path} fill="none" stroke={T.AGREED} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>

      {/* Points + labels */}
      {pts.map((p, i) => (
        <g key={p.v}>
          <circle cx={xs[i]} cy={ys[i]} r={5}
                  fill={p.author === "S" ? T.SARAH : T.MARK}
                  stroke="#FFF" strokeWidth="2"/>
          <text x={xs[i]} y={h - 10} fontSize="10.5" textAnchor="middle" fill={T.SUB}
                style={{ fontWeight: 600, letterSpacing: "0.04em" }}>
            {p.v.toUpperCase()}
          </text>
          <text x={xs[i]} y={ys[i] - 12} fontSize="10" textAnchor="middle" fill={T.MUTE}
                className="tabular-nums">
            {p.gap === 0 ? "£0" : `£${(p.gap / 1000).toFixed(0)}k`}
          </text>
        </g>
      ))}

      {/* Final annotation */}
      <g>
        <circle cx={xs[xs.length - 1]} cy={ys[ys.length - 1]} r={9}
                fill="none" stroke={T.AGREED} strokeWidth="1.5"
                style={{ animation: "pulseRing 2.4s ease-out infinite" }}/>
      </g>
    </svg>
  );
}

/* ============================================================
   JOURNEY STRIP — compact v1..v5 narrative
   ============================================================ */
function JourneyStrip() {
  const chapters = [
    { v: "v1", who: "S", gap: "£72k", label: "Sarah's opening" },
    { v: "v2", who: "M", gap: "£36k", label: "Mark's counter" },
    { v: "v3", who: "S", gap: "£18k", label: "Sarah's response" },
    { v: "v4", who: "M", gap: "£0",   label: "Mark accepts" },
    { v: "v5", who: "B", gap: "—",    label: "Agreed & signed", final: true }
  ];
  return (
    <div className="flex items-stretch">
      {chapters.map((c, i) => (
        <div key={c.v} className="flex-1 flex items-center">
          <div className="flex-1 text-center">
            <div className="w-8 h-8 mx-auto rounded-full flex items-center justify-center text-white mb-2"
                 style={{
                   background: c.final ? T.AGREED : c.who === "S" ? T.SARAH : T.MARK,
                   fontSize: 11.5, fontWeight: 700
                 }}>
              {c.final ? <I.Check size={14} stroke="#FFF" strokeWidth={2.5}/> : c.who}
            </div>
            <div className="label-xs" style={{ color: T.MUTE }}>{c.v}</div>
            <div style={{ fontSize: 12, fontWeight: 600, marginTop: 4, lineHeight: 1.2 }}>{c.label}</div>
            <div className="tabular-nums" style={{ fontSize: 11, color: T.SUB, marginTop: 2 }}>gap {c.gap}</div>
          </div>
          {i < chapters.length - 1 && (
            <div className="flex-shrink-0 h-px w-4" style={{ background: T.AGREED }}/>
          )}
        </div>
      ))}
    </div>
  );
}

/* ============================================================
   AGREEMENT SECTION (read-only, signed)
   ============================================================ */
function AgreementSection({ sec, item }) {
  return (
    <div className="mb-7">
      <div className="flex items-baseline gap-2 mb-1.5">
        <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
        <h3 style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em" }}>{sec.title}</h3>
      </div>
      <p style={{ fontSize: 14.5, color: T.INK, lineHeight: 1.6 }}>{item.label}</p>
      {item.impact && (
        <div className="mt-1.5 tabular-nums" style={{ fontSize: 12.5, color: T.SUB }}>{item.impact}</div>
      )}
    </div>
  );
}

/* ============================================================
   SIGNATURE BLOCK — two signatures, dated
   ============================================================ */
function SignatureBlock({ tone }) {
  const script = { fontFamily: "'Brush Script MT', 'Lucida Handwriting', cursive", fontSize: 28, letterSpacing: "0.01em" };
  return (
    <div className="grid grid-cols-2 gap-10 mt-12 pt-8" style={{ borderTop: `1px solid ${T.HAIR}` }}>
      <div>
        <div style={{ ...script, color: T.SARAH, lineHeight: 1 }}>Sarah Mitchell</div>
        <div className="mt-2 h-px" style={{ background: T.SARAH, opacity: 0.5 }}/>
        <div className="flex items-baseline justify-between mt-2">
          <div className="label-xs" style={{ color: T.MUTE }}>Sarah Mitchell</div>
          <div className="tabular-nums" style={{ fontSize: 11.5, color: T.SUB }}>14 May 2025 · 14:22</div>
        </div>
      </div>
      <div>
        <div style={{ ...script, color: T.MARK, lineHeight: 1 }}>Mark Mitchell</div>
        <div className="mt-2 h-px" style={{ background: T.MARK, opacity: 0.5 }}/>
        <div className="flex items-baseline justify-between mt-2">
          <div className="label-xs" style={{ color: T.MUTE }}>Mark Mitchell</div>
          <div className="tabular-nums" style={{ fontSize: 11.5, color: T.SUB }}>14 May 2025 · 14:38</div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   HERO — tone-dependent
   ============================================================ */
function Hero({ tone, split }) {
  if (tone === "formal") {
    return (
      <div className="text-center pt-6">
        <div className="label-xs mb-3" style={{ color: T.AGREED }}>Settlement agreement · v5</div>
        <h1 style={{ fontSize: 40, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.1 }}>
          Mitchell · Settlement Agreement
        </h1>
        <div className="mt-4 tabular-nums" style={{ fontSize: 13, color: T.SUB, letterSpacing: "0.04em" }}>
          EXECUTED ON 14 MAY 2025 · EXETER, DEVON
        </div>
      </div>
    );
  }
  if (tone === "warm") {
    return (
      <div className="text-center pt-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-4"
             style={{ background: T.AGREED_TINT, color: T.AGREED, fontSize: 11.5, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>
          <I.Check size={11} strokeWidth={2.5}/> Signed by both
        </div>
        <h1 style={{ fontSize: 42, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.1 }}>
          You reached an agreement.
        </h1>
        <p className="mt-4 mx-auto" style={{ fontSize: 16, color: T.SUB, lineHeight: 1.55, maxWidth: 560 }}>
          Four rounds. Seven sections. One conversation, kept going until the numbers matched.
          This is a real achievement — most settlements at this size don't arrive here without lawyers.
        </p>
      </div>
    );
  }
  /* quiet (default) */
  return (
    <div>
      <div className="label-xs mb-2" style={{ color: T.AGREED }}>Agreement · v5</div>
      <h1 style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.1 }}>
        You've reached a settlement.
      </h1>
      <p className="mt-3" style={{ fontSize: 15, color: T.SUB, lineHeight: 1.55, maxWidth: 560 }}>
        Both of you have signed. This document now stands as the agreed financial arrangement between Sarah and Mark Mitchell.
      </p>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "tone": "quiet",
  "router": "inline"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => {
      const next = { ...t, [id]: value };
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
      return next;
    });
  };

  const sectionStatus = Object.fromEntries(P4_SECTIONS.map(s => [s.key, "agreed"]));
  const split = { sarahPct: V5.sarahPct, markPct: V5.markPct };

  const topRight = (
    <>
      <span className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md whitespace-nowrap"
            style={{ background: T.AGREED_TINT, color: T.AGREED, fontSize: 11.5, fontWeight: 700, letterSpacing: "0.04em", textTransform: "uppercase" }}>
        <I.Lock size={11} stroke={T.AGREED}/> Signed · Final
      </span>
      <button className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md"
              style={{ background: "#FFF", border: `1px solid ${T.HAIR}`, fontSize: 12.5, color: T.SUB, fontWeight: 500 }}>
        <I.Doc size={12} stroke={T.SUB}/> Download PDF
      </button>
    </>
  );

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar
        viewMeta={{ phase: "Phase 4", title: "Settlement agreement", version: "v5", statusLabel: "AGREED", statusKind: "agreed" }}
        right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={sectionStatus}
                        title="Agreed sections"
                        subtitle="All 7 sections signed by both parties"
                        pct={100}
                        currentRoute="agreed"
                        showInlineRouter={tweaks.router === "inline"}/>
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
          <div className="max-w-[720px] mx-auto px-10 py-12 pb-40">

            {/* Agreement paper */}
            <div className="rounded-xl overflow-hidden"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}`,
                          boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 20px 48px rgba(0,0,0,0.06)" }}>
              <div className="px-12 pt-12 pb-8">
                <Hero tone={tweaks.tone} split={split}/>
              </div>

              {/* Convergence card — the journey token */}
              <div className="mx-12 rounded-xl p-5 mb-10"
                   style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}` }}>
                <div className="flex items-baseline justify-between mb-2">
                  <div className="label-xs" style={{ color: T.MUTE }}>How you got here</div>
                  <div style={{ fontSize: 11.5, color: T.SUB }}>
                    <span className="tabular-nums" style={{ fontWeight: 600, color: T.INK }}>11 days</span> · 4 rounds · closed £72k gap
                  </div>
                </div>
                <div className="flex justify-center my-2">
                  <JourneySparkline width={560} height={120}/>
                </div>
                <div className="mt-2 pt-4" style={{ borderTop: `1px solid ${T.HAIR}` }}>
                  <JourneyStrip/>
                </div>
              </div>

              {/* Final split */}
              <div className="mx-12 mb-10">
                <div className="label-xs mb-3" style={{ color: T.MUTE }}>Agreed overall split</div>
                <div className="flex items-end justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-1.5 mb-1" style={{ fontSize: 12.5, color: T.SARAH, fontWeight: 600 }}>
                      <P4_Avatar who="S" size={16}/> Sarah
                    </div>
                    <div className="tabular-nums" style={{ fontSize: 36, fontWeight: 700, color: T.SARAH, lineHeight: 1 }}>
                      {V5.sarahPct}%
                    </div>
                  </div>
                  <div className="text-center" style={{ fontSize: 11, color: T.MUTE, marginBottom: 4, letterSpacing: "0.06em" }}>
                    of <span className="tabular-nums" style={{ color: T.SUB, fontWeight: 600 }}>{P4_money(window.P4_TOTAL_NET)}</span> net
                  </div>
                  <div className="text-right">
                    <div className="flex items-center justify-end gap-1.5 mb-1" style={{ fontSize: 12.5, color: T.MARK, fontWeight: 600 }}>
                      Mark <P4_Avatar who="M" size={16}/>
                    </div>
                    <div className="tabular-nums" style={{ fontSize: 36, fontWeight: 700, color: T.MARK, lineHeight: 1 }}>
                      {V5.markPct}%
                    </div>
                  </div>
                </div>
                <div className="h-2 rounded-full overflow-hidden flex" style={{ background: "#F3F4F6" }}>
                  <div style={{ width: `${V5.sarahPct}%`, background: T.SARAH }}/>
                  <div style={{ width: `${V5.markPct}%`, background: T.MARK }}/>
                </div>
              </div>

              {/* Divider with ornamental mark */}
              <div className="flex items-center gap-3 mx-12 my-8">
                <div className="flex-1 h-px" style={{ background: T.HAIR }}/>
                <span className="label-xs" style={{ color: T.MUTE }}>Agreed terms</span>
                <div className="flex-1 h-px" style={{ background: T.HAIR }}/>
              </div>

              {/* Agreement terms */}
              <div className="px-12 pb-4">
                {P4_SECTIONS.map(sec => (
                  <AgreementSection key={sec.key} sec={sec} item={V5.sections[sec.key]}/>
                ))}
              </div>

              {/* Signatures */}
              <div className="px-12 pb-12">
                <SignatureBlock tone={tweaks.tone}/>
              </div>

              {/* Footer strip */}
              <div className="px-12 py-4 flex items-center justify-between"
                   style={{ background: "#FAFAF7", borderTop: `1px solid ${T.HAIR}` }}>
                <div className="flex items-center gap-2" style={{ fontSize: 11.5, color: T.SUB }}>
                  <I.Lock size={12} stroke={T.SUB}/>
                  Hash-sealed on Decouple · SHA-256 a7f3…c021
                </div>
                <div style={{ fontSize: 11.5, color: T.MUTE }}>Page 1 of 1</div>
              </div>
            </div>

            {/* Next steps (outside paper) */}
            <div className="mt-10 grid grid-cols-3 gap-3">
              {[
                { k: "Court filing", v: "Submit to court as a consent order", action: "Prepare Form A" },
                { k: "Pension sharing", v: "Send PSO to NHS Pensions", action: "Generate order" },
                { k: "Home sale", v: "Instruct estate agent", action: "Find agents" }
              ].map(n => (
                <div key={n.k} className="rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
                  <div className="label-xs mb-1.5" style={{ color: T.MUTE }}>{n.k}</div>
                  <div style={{ fontSize: 13, lineHeight: 1.4, marginBottom: 8 }}>{n.v}</div>
                  <button className="text-left inline-flex items-center gap-1" style={{ fontSize: 12, color: T.INK, fontWeight: 600 }}>
                    {n.action} <I.ArrowR size={11} stroke={T.INK}/>
                  </button>
                </div>
              ))}
            </div>

            {/* Understated closing */}
            <div className="text-center mt-10" style={{ fontSize: 12.5, color: T.MUTE, lineHeight: 1.6 }}>
              You kept talking to each other.<br/>
              That's what made this possible.
            </div>
          </div>
        </div>
        <P4_AIRail
          insights={P4_AI_AGREEMENT.insights}
          comments={P4_AI_AGREEMENT.comments}
          activity={P4_AI_AGREEMENT.activity}
          summaryLine={P4_AI_AGREEMENT.summaryLine}
          defaultTab="ai"/>
        {tweaks.router !== "inline" && <P4_FloatingRouter current="agreed"/>}
      </div>
      <P4_TweakPanel
        title="Agreement"
        options={[
          { id: "tone", label: "Tone", variants: [
            { value: "quiet",  label: "Quiet",  sub: "Understated · matter-of-fact (default)" },
            { value: "formal", label: "Formal", sub: "Legal document framing" },
            { value: "warm",   label: "Warm",   sub: "Acknowledges the achievement" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
