/* Phase 4 View C — Mark's Redline
   Mark has sent v2. Sarah reviews his counter, item by item.
   Symmetric 2-column: Sarah's v1 (left) vs Mark's v2 (right).
   Unchanged sections collapse. Changed sections demand a response.

   Tweak: comparison layout — symmetric | stacked | redline-inline */
(function(){
const { useState, useEffect, useRef } = React;
const { P4_TOK: T, P4_Ic: I, P4_Avatar, P4_StatusChip, P4_TopBar, P4_ChapterRail,
        P4_FloatingRouter, P4_TweakPanel, P4_money, P4_SECTIONS,
        P4_OPTIONS: OPTIONS, P4_DEFAULT_DRAFT: DEFAULT_DRAFT,
        P4_computeSplit: computeSplit, P4_PROPOSALS,
        P4_AIRail, P4_AI_REDLINE } = window;

/* ============================================================
   STATE: Sarah's v1 + Mark's v2 counter
   ============================================================ */
const SARAH_V1 = { ...DEFAULT_DRAFT }; /* all 7 section choices */
/* Mark changes 3 sections */
const MARK_V2 = {
  pensions: "share_40",       /* was no_share */
  debts:    "share_half_amex", /* was each_own */
  spousal:  "clean_break"     /* was 400_3y */
};
const CHANGED_KEYS = Object.keys(MARK_V2);

/* Mark's rationale per changed section */
const MARK_NOTES = {
  pensions: "Your NHS pension is worth £180k; mine is £12k. A 40% share feels fair given that I worked alongside you for eight years while your scheme accrued. I'd propose we equalise more fully.",
  debts:    "Happy to own the student loan (it's pre-marriage) and my car costs. But the Amex — about £5,800 of that is from the bathroom renovation and family holidays. That feels joint to me.",
  spousal:  "I'd prefer a clean break. You're back to full NHS salary next year. If there's a genuine shortfall in a specific year, let's address it then — I don't want to be sending cheques for three years."
};

const lookup = (key, value) => OPTIONS[key]?.find(o => o.value === value);

/* ============================================================
   RESPONSE STATE per changed section
   null | "accepted" | "countered" | "discussing"
   ============================================================ */

function ResponsePill({ kind }) {
  if (kind === "accepted")  return <P4_StatusChip kind="agreed">Accepted</P4_StatusChip>;
  if (kind === "countered") return <P4_StatusChip kind="sarah">Countered</P4_StatusChip>;
  if (kind === "discussing") return <P4_StatusChip kind="pending">Discussing</P4_StatusChip>;
  return <P4_StatusChip kind="contested">Needs response</P4_StatusChip>;
}

/* ============================================================
   SECTION COMPARISON CARD — symmetric 2 columns
   ============================================================ */
function ChangedSection({ sec, sarahOpt, markOpt, note, response, onRespond }) {
  return (
    <div id={`sec-${sec.key}`} className="rounded-xl overflow-hidden"
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
      {/* Header */}
      <div className="px-5 py-3 flex items-center justify-between"
           style={{ background: "#FAFAF7", borderBottom: `1px solid ${T.HAIR}` }}>
        <div className="flex items-center gap-2">
          <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>{sec.title}</span>
          <span style={{ color: "#E5E7EB" }}>·</span>
          <span className="label-xs" style={{ color: T.CONTESTED }}>Mark changed this</span>
        </div>
        <ResponsePill kind={response}/>
      </div>

      {/* Two columns */}
      <div className="grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
        {/* Sarah's v1 */}
        <div className="p-5" style={{ borderRight: `1px solid ${T.HAIR}` }}>
          <div className="flex items-center gap-1.5 mb-2 label-xs" style={{ color: T.SARAH }}>
            <P4_Avatar who="S" size={14}/> Your v1 · 3 May
          </div>
          <div style={{ fontSize: 13.5, color: T.INK, fontWeight: 500, lineHeight: 1.5 }}>
            {sarahOpt.label}
          </div>
          <div className="mt-2 flex items-center gap-3 flex-wrap">
            <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
              <P4_Avatar who="S" size={13}/> <span style={{ color: T.SUB }}>{sarahOpt.impactS}</span>
            </span>
            <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
              <P4_Avatar who="M" size={13}/> <span style={{ color: T.SUB }}>{sarahOpt.impactM}</span>
            </span>
          </div>
        </div>

        {/* Mark's v2 */}
        <div className="p-5" style={{ background: "#FDFAF7" }}>
          <div className="flex items-center gap-1.5 mb-2 label-xs" style={{ color: T.MARK }}>
            <P4_Avatar who="M" size={14}/> Mark's counter · 7 May
          </div>
          <div style={{ fontSize: 13.5, color: T.INK, fontWeight: 500, lineHeight: 1.5 }}>
            {markOpt.label}
          </div>
          <div className="mt-2 flex items-center gap-3 flex-wrap">
            <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
              <P4_Avatar who="S" size={13}/> <span style={{ color: T.SUB }}>{markOpt.impactS}</span>
            </span>
            <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
              <P4_Avatar who="M" size={13}/> <span style={{ color: T.SUB }}>{markOpt.impactM}</span>
            </span>
          </div>
        </div>
      </div>

      {/* Mark's rationale */}
      <div className="px-5 py-3.5 flex items-start gap-3"
           style={{ background: T.MARK_TINT, borderTop: `1px solid ${T.HAIR}` }}>
        <P4_Avatar who="M" size={22}/>
        <div className="flex-1">
          <div style={{ fontSize: 12, color: T.MARK, fontWeight: 600, marginBottom: 2 }}>Mark's reasoning</div>
          <div style={{ fontSize: 13, color: T.INK, lineHeight: 1.5 }}>{note}</div>
        </div>
      </div>

      {/* Actions */}
      <div className="px-5 py-3 flex items-center gap-2"
           style={{ background: "#FFF", borderTop: `1px solid ${T.HAIR}` }}>
        <div className="flex-1" style={{ fontSize: 11.5, color: T.MUTE }}>
          {response === "accepted" && "You accepted Mark's position on this section."}
          {response === "countered" && "You'll send a counter-proposal in v3."}
          {response === "discussing" && "Mark has been notified you want to discuss this."}
          {!response && "What's your response?"}
        </div>
        <button onClick={() => onRespond("discussing")}
                className="h-8 px-3 rounded-md"
                style={{
                  background: response === "discussing" ? T.PENDING_TINT : "#FFF",
                  border: `1px solid ${response === "discussing" ? T.PENDING : T.HAIR}`,
                  color: response === "discussing" ? T.PENDING : T.SUB,
                  fontSize: 12, fontWeight: 600
                }}>
          <span className="inline-flex items-center gap-1.5">
            <I.Msg size={12}/> Discuss
          </span>
        </button>
        <button onClick={() => onRespond("countered")}
                className="h-8 px-3 rounded-md"
                style={{
                  background: response === "countered" ? T.SARAH_TINT : "#FFF",
                  border: `1px solid ${response === "countered" ? T.SARAH : T.HAIR}`,
                  color: response === "countered" ? T.SARAH : T.SUB,
                  fontSize: 12, fontWeight: 600
                }}>
          <span className="inline-flex items-center gap-1.5">
            <I.Edit size={11}/> Counter
          </span>
        </button>
        <button onClick={() => onRespond("accepted")}
                className="h-8 px-3 rounded-md"
                style={{
                  background: response === "accepted" ? T.AGREED : "#FFF",
                  border: `1px solid ${response === "accepted" ? T.AGREED : T.HAIR}`,
                  color: response === "accepted" ? "#FFF" : T.SUB,
                  fontSize: 12, fontWeight: 600
                }}>
          <span className="inline-flex items-center gap-1.5">
            <I.Check size={12} stroke={response === "accepted" ? "#FFF" : T.SUB} strokeWidth={2.5}/> Accept
          </span>
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   UNCHANGED (collapsed) accordion
   ============================================================ */
function UnchangedSection({ sec, sarahOpt }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="rounded-xl overflow-hidden"
         style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}` }}>
      <button onClick={() => setOpen(o => !o)}
              className="w-full flex items-center gap-3 px-5 py-3 text-left transition"
              onMouseEnter={e => e.currentTarget.style.background = "#F3F3F0"}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
        <span className="label-xs tabular-nums" style={{ color: T.MUTE, width: 22 }}>§{sec.n}</span>
        <span style={{ fontSize: 13.5, fontWeight: 500, color: T.INK }}>{sec.title}</span>
        <P4_StatusChip kind="agreed">Mark agreed</P4_StatusChip>
        <span className="flex-1"/>
        <span style={{ fontSize: 12, color: T.SUB }}>{sarahOpt.label}</span>
        <I.ChevD size={14} stroke={T.MUTE} style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 180ms" }}/>
      </button>
      {open && (
        <div className="px-5 pb-4 pt-0 border-t" style={{ background: "#FFF", borderColor: T.HAIR }}>
          <div className="mt-3 flex items-center gap-4 flex-wrap" style={{ fontSize: 12 }}>
            <span className="flex items-center gap-1.5">
              <P4_Avatar who="S" size={13}/> <span style={{ color: T.SUB }}>{sarahOpt.impactS}</span>
            </span>
            <span className="flex items-center gap-1.5">
              <P4_Avatar who="M" size={13}/> <span style={{ color: T.SUB }}>{sarahOpt.impactM}</span>
            </span>
          </div>
          {sarahOpt.note && (
            <div style={{ fontSize: 12, color: T.MUTE, marginTop: 6, fontStyle: "italic" }}>{sarahOpt.note}</div>
          )}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   STACKED LAYOUT — Sarah's v1 on top, Mark's v2 below (alt tweak)
   ============================================================ */
function StackedSection({ sec, sarahOpt, markOpt, note, response, onRespond }) {
  return (
    <div id={`sec-${sec.key}`} className="rounded-xl overflow-hidden"
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
      <div className="px-5 py-3 flex items-center justify-between"
           style={{ background: "#FAFAF7", borderBottom: `1px solid ${T.HAIR}` }}>
        <div className="flex items-center gap-2">
          <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>{sec.title}</span>
        </div>
        <ResponsePill kind={response}/>
      </div>

      {/* Sarah's row — struck through */}
      <div className="px-5 py-3 flex items-start gap-3" style={{ borderBottom: `1px dashed ${T.HAIR}` }}>
        <P4_Avatar who="S" size={20}/>
        <div className="flex-1">
          <div className="label-xs mb-0.5" style={{ color: T.SARAH }}>Your v1</div>
          <div style={{ fontSize: 13.5, color: T.MUTE, textDecoration: "line-through", lineHeight: 1.4 }}>
            {sarahOpt.label}
          </div>
        </div>
      </div>
      {/* Mark's row — active */}
      <div className="px-5 py-3 flex items-start gap-3" style={{ background: "#FDFAF7" }}>
        <P4_Avatar who="M" size={20}/>
        <div className="flex-1">
          <div className="label-xs mb-0.5" style={{ color: T.MARK }}>Mark's counter</div>
          <div style={{ fontSize: 13.5, color: T.INK, fontWeight: 500, lineHeight: 1.4 }}>{markOpt.label}</div>
          <div className="mt-2" style={{ fontSize: 13, color: T.INK, lineHeight: 1.5 }}>{note}</div>
          <div className="mt-2 flex items-center gap-3 flex-wrap" style={{ fontSize: 11.5 }}>
            <span className="flex items-center gap-1.5"><P4_Avatar who="S" size={13}/> <span style={{ color: T.SUB }}>{markOpt.impactS}</span></span>
            <span className="flex items-center gap-1.5"><P4_Avatar who="M" size={13}/> <span style={{ color: T.SUB }}>{markOpt.impactM}</span></span>
          </div>
        </div>
      </div>

      <div className="px-5 py-3 flex items-center gap-2"
           style={{ background: "#FFF", borderTop: `1px solid ${T.HAIR}` }}>
        <span className="flex-1"/>
        <button onClick={() => onRespond("discussing")} className="h-8 px-3 rounded-md"
                style={{ background: response === "discussing" ? T.PENDING_TINT : "#FFF", border: `1px solid ${response === "discussing" ? T.PENDING : T.HAIR}`, color: response === "discussing" ? T.PENDING : T.SUB, fontSize: 12, fontWeight: 600 }}>
          <span className="inline-flex items-center gap-1.5"><I.Msg size={12}/> Discuss</span>
        </button>
        <button onClick={() => onRespond("countered")} className="h-8 px-3 rounded-md"
                style={{ background: response === "countered" ? T.SARAH_TINT : "#FFF", border: `1px solid ${response === "countered" ? T.SARAH : T.HAIR}`, color: response === "countered" ? T.SARAH : T.SUB, fontSize: 12, fontWeight: 600 }}>
          <span className="inline-flex items-center gap-1.5"><I.Edit size={11}/> Counter</span>
        </button>
        <button onClick={() => onRespond("accepted")} className="h-8 px-3 rounded-md"
                style={{ background: response === "accepted" ? T.AGREED : "#FFF", border: `1px solid ${response === "accepted" ? T.AGREED : T.HAIR}`, color: response === "accepted" ? "#FFF" : T.SUB, fontSize: 12, fontWeight: 600 }}>
          <span className="inline-flex items-center gap-1.5"><I.Check size={12} stroke={response === "accepted" ? "#FFF" : T.SUB} strokeWidth={2.5}/> Accept</span>
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   INLINE REDLINE LAYOUT — a single paragraph with strike-through +
   Mark's replacement text in-line, like a Google Doc redline
   ============================================================ */
function RedlineSection({ sec, sarahOpt, markOpt, note, response, onRespond }) {
  return (
    <div id={`sec-${sec.key}`} className="rounded-xl overflow-hidden"
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
      <div className="px-5 py-3 flex items-center justify-between"
           style={{ background: "#FAFAF7", borderBottom: `1px solid ${T.HAIR}` }}>
        <div className="flex items-center gap-2">
          <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>{sec.title}</span>
        </div>
        <ResponsePill kind={response}/>
      </div>
      <div className="px-5 py-4" style={{ fontSize: 14, lineHeight: 1.65, color: T.INK }}>
        The parties agree to{" "}
        <span style={{ background: "#FEE2E2", color: "#991B1B", textDecoration: "line-through",
                       padding: "1px 4px", borderRadius: 3, textDecorationThickness: 1.5 }}>
          {sarahOpt.label.charAt(0).toLowerCase() + sarahOpt.label.slice(1)}
        </span>
        {" "}
        <span style={{ background: T.MARK_TINT, color: T.MARK,
                       padding: "1px 4px", borderRadius: 3, fontWeight: 600 }}>
          {markOpt.label.charAt(0).toLowerCase() + markOpt.label.slice(1)}
        </span>
        .
      </div>
      <div className="px-5 pb-4 flex items-start gap-2" style={{ fontSize: 12.5, color: T.SUB, lineHeight: 1.5 }}>
        <P4_Avatar who="M" size={16}/>
        <div><span style={{ fontWeight: 600, color: T.MARK }}>Mark:</span> {note}</div>
      </div>
      <div className="px-5 py-3 flex items-center gap-2"
           style={{ background: "#FAFAF7", borderTop: `1px solid ${T.HAIR}` }}>
        <span className="flex-1"/>
        <button onClick={() => onRespond("discussing")} className="h-8 px-3 rounded-md"
                style={{ background: response === "discussing" ? T.PENDING_TINT : "#FFF", border: `1px solid ${response === "discussing" ? T.PENDING : T.HAIR}`, color: response === "discussing" ? T.PENDING : T.SUB, fontSize: 12, fontWeight: 600 }}>
          <span className="inline-flex items-center gap-1.5"><I.Msg size={12}/> Discuss</span>
        </button>
        <button onClick={() => onRespond("countered")} className="h-8 px-3 rounded-md"
                style={{ background: response === "countered" ? T.SARAH_TINT : "#FFF", border: `1px solid ${response === "countered" ? T.SARAH : T.HAIR}`, color: response === "countered" ? T.SARAH : T.SUB, fontSize: 12, fontWeight: 600 }}>
          <span className="inline-flex items-center gap-1.5"><I.Edit size={11}/> Counter</span>
        </button>
        <button onClick={() => onRespond("accepted")} className="h-8 px-3 rounded-md"
                style={{ background: response === "accepted" ? T.AGREED : "#FFF", border: `1px solid ${response === "accepted" ? T.AGREED : T.HAIR}`, color: response === "accepted" ? "#FFF" : T.SUB, fontSize: 12, fontWeight: 600 }}>
          <span className="inline-flex items-center gap-1.5"><I.Check size={12} stroke={response === "accepted" ? "#FFF" : T.SUB} strokeWidth={2.5}/> Accept</span>
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "layout": "symmetric",
  "router": "inline"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const [responses, setResponses] = useState({}); /* key -> "accepted"|"countered"|"discussing" */

  const setTweak = (id, value) => {
    setTweaks(t => {
      const next = { ...t, [id]: value };
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
      return next;
    });
  };

  const respond = (key, kind) => setResponses(r => ({ ...r, [key]: r[key] === kind ? null : kind }));

  const resolvedCount = CHANGED_KEYS.filter(k => responses[k]).length;

  const sectionStatus = Object.fromEntries(P4_SECTIONS.map(s => {
    if (!CHANGED_KEYS.includes(s.key)) return [s.key, "agreed"];
    const r = responses[s.key];
    if (r === "accepted") return [s.key, "agreed"];
    if (r === "countered" || r === "discussing") return [s.key, "pending"];
    return [s.key, "contested"];
  }));

  const topRight = (
    <>
      <span className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md whitespace-nowrap" style={{ background: T.MARK_TINT, border: `1px solid ${T.HAIR}`, fontSize: 11.5, color: T.MARK, fontWeight: 600 }}>
        <P4_Avatar who="M" size={14}/> Mark sent this 2 days ago
      </span>
      <button
        disabled={resolvedCount < CHANGED_KEYS.length}
        className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-white"
        style={{
          background: resolvedCount === CHANGED_KEYS.length ? T.SARAH : "#BDBDBD",
          fontSize: 12.5, fontWeight: 600,
          cursor: resolvedCount === CHANGED_KEYS.length ? "pointer" : "not-allowed"
        }}
        onClick={() => { window.location.href = "Settlement - Progress.html"; }}>
        <span className="whitespace-nowrap">Send response (v3)</span> <I.ArrowR size={12} stroke="#FFF"/>
      </button>
    </>
  );

  const changedSections = P4_SECTIONS.filter(s => CHANGED_KEYS.includes(s.key));
  const unchangedSections = P4_SECTIONS.filter(s => !CHANGED_KEYS.includes(s.key));

  const SectionComponent = tweaks.layout === "stacked" ? StackedSection
    : tweaks.layout === "redline" ? RedlineSection
    : ChangedSection;

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar
        viewMeta={{ phase: "Phase 4", title: "Mark's counter-proposal", version: "v2", statusLabel: `${CHANGED_KEYS.length - resolvedCount} TO RESPOND`, statusKind: resolvedCount === CHANGED_KEYS.length ? "agreed" : "contested" }}
        right={topRight}/>

      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={sectionStatus}
                        title="Mark's v2 counter-proposal"
                        subtitle={resolvedCount === CHANGED_KEYS.length
                          ? "All responses drafted"
                          : `${resolvedCount} of ${CHANGED_KEYS.length} changes responded to`}
                        pct={Math.round((resolvedCount / CHANGED_KEYS.length) * 100)}
                        currentRoute="redline"
                        showInlineRouter={tweaks.router === "inline"}/>

        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
          <div className="max-w-[900px] mx-auto px-8 py-10 pb-40">

            {/* Hero banner */}
            <div className="rounded-2xl p-5 flex items-start gap-4 mb-8"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
              <P4_Avatar who="M" size={44}/>
              <div className="flex-1">
                <div className="label-xs mb-1" style={{ color: T.MARK }}>Mark's reply · 7 May · v2</div>
                <h1 style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.015em", lineHeight: 1.25 }}>
                  Mark accepted {P4_SECTIONS.length - CHANGED_KEYS.length} of 7 sections.
                  <br/>
                  <span style={{ color: T.SUB, fontWeight: 500 }}>
                    He'd like to discuss {CHANGED_KEYS.length} — pensions, debts, and spousal maintenance.
                  </span>
                </h1>
                <p className="mt-3" style={{ fontSize: 13.5, color: T.SUB, lineHeight: 1.55 }}>
                  Read each change, then choose how you'd like to respond. Your response becomes v3.
                </p>
              </div>
            </div>

            {/* Changed sections */}
            <div className="label-xs mb-3" style={{ color: T.CONTESTED, letterSpacing: "0.08em" }}>
              {CHANGED_KEYS.length} changes · require your response
            </div>
            <div className="space-y-4">
              {changedSections.map(sec => (
                <SectionComponent key={sec.key}
                  sec={sec}
                  sarahOpt={lookup(sec.key, SARAH_V1[sec.key])}
                  markOpt={lookup(sec.key, MARK_V2[sec.key])}
                  note={MARK_NOTES[sec.key]}
                  response={responses[sec.key]}
                  onRespond={(r) => respond(sec.key, r)}/>
              ))}
            </div>

            {/* Unchanged sections */}
            <div className="label-xs mb-3 mt-10" style={{ color: T.AGREED, letterSpacing: "0.08em" }}>
              {unchangedSections.length} sections · Mark accepted as-is
            </div>
            <div className="space-y-2">
              {unchangedSections.map(sec => (
                <UnchangedSection key={sec.key} sec={sec}
                                  sarahOpt={lookup(sec.key, SARAH_V1[sec.key])}/>
              ))}
            </div>

            {/* Send v3 cta */}
            <div className="mt-10 rounded-2xl p-6 flex items-center gap-4"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
              <div className="flex-1">
                <div style={{ fontSize: 15, fontWeight: 600 }}>
                  {resolvedCount === CHANGED_KEYS.length
                    ? "All responses drafted — ready to send v3."
                    : `${CHANGED_KEYS.length - resolvedCount} change${CHANGED_KEYS.length - resolvedCount === 1 ? "" : "s"} still need your response.`}
                </div>
                <div style={{ fontSize: 13, color: T.SUB, marginTop: 4 }}>
                  Mark will be notified once v3 is sent.
                </div>
              </div>
              <button
                disabled={resolvedCount < CHANGED_KEYS.length}
                onClick={() => { window.location.href = "Settlement - Progress.html"; }}
                className="inline-flex items-center gap-2 h-10 px-4 rounded-md text-white"
                style={{
                  background: resolvedCount === CHANGED_KEYS.length ? T.SARAH : "#BDBDBD",
                  fontSize: 13, fontWeight: 600,
                  cursor: resolvedCount === CHANGED_KEYS.length ? "pointer" : "not-allowed"
                }}>
                <I.Send size={13} stroke="#FFF"/> Send response (v3)
              </button>
            </div>
          </div>
        </div>

        <P4_AIRail
          insights={P4_AI_REDLINE.insights}
          comments={P4_AI_REDLINE.comments}
          activity={P4_AI_REDLINE.activity}
          summaryLine={P4_AI_REDLINE.summaryLine}
          defaultTab="ai"
          onApplyFallback={(payload, fb) => {
            /* Auto-respond "countered" on the section the fallback targets */
            const k = Object.keys(payload)[0];
            if (k) respond(k, "countered");
            const el = document.getElementById(`sec-${k}`);
            if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
          }}
          onJumpTo={(k) => {
            const el = document.getElementById(`sec-${k}`);
            if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
          }}/>
        {tweaks.router !== "inline" && <P4_FloatingRouter current="redline"/>}
      </div>

      <P4_TweakPanel
        title="Redline"
        options={[
          { id: "layout", label: "Comparison layout", variants: [
            { value: "symmetric", label: "Symmetric columns", sub: "Sarah's v1 | Mark's v2" },
            { value: "stacked",   label: "Stacked + strike", sub: "v1 above, v2 below" },
            { value: "redline",   label: "Inline redline",   sub: "Prose with redlines" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
