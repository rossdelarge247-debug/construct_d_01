/* Phase 4 — per-view AI insight bank + collaboration seed data
   One export per view: BUILD, REVIEW, REDLINE, PROGRESS, AGREEMENT
   Each contains { insights, comments, activity, summaryLine } for P4_AIRail
*/
(function(){

/* ============================================================
   BUILD — Sarah is drafting v1
   AI coaches on court-reasonableness, surfaces fallback positions
   ============================================================ */
const BUILD = {
  summaryLine: "Your draft sits at 54/46 to you. That's within normal court range, but two items will likely be challenged — here's what to expect.",
  insights: [
    {
      id: "b1", kind: "court_risk", severity: "warn",
      sectionKey: "pensions",
      title: "\"No pension sharing\" is unusually weak",
      body: "Courts almost always equalise matrimonial pension accrual. Your NHS pension grew by ~£168k during the marriage; Mark's by ~£12k. Starting from no-share will read as opening-position theatre and Mark (or his lawyer) will push back hard.",
      citation: "White v White [2001] · MCA 1973 s.25(2)(h)",
      fallbacks: [
        { label: "Open with 20% share", sub: "£36,082 to Mark · likely middle ground", payload: { pensions: "share_20" } },
        { label: "Offset against home equity", sub: "Keep pension, Mark takes more of home", payload: { pensions: "offset" } }
      ]
    },
    {
      id: "b2", kind: "fairness", severity: "notice",
      sectionKey: "spousal",
      title: "3-year spousal is on the longer end",
      body: "Given you return to full NHS salary next year, a 2-year bridge is more defensible. Mark's surplus of £2,345/mo makes any figure affordable for him; the question is duration.",
      fallbacks: [
        { label: "£400/mo for 2 years", sub: "Matches Emma's school milestone", payload: { spousal: "400_2y" } }
      ]
    },
    {
      id: "b3", kind: "court_risk", severity: "info",
      sectionKey: "debts",
      title: "Mark's student loan is pre-marriage",
      body: "Courts typically ring-fence pre-marital debt. \"Each owns their own\" is well-supported on this — Mark may push back on the Amex specifically, which is recent joint spending.",
      citation: "Miller; McFarlane [2006]"
    },
    {
      id: "b4", kind: "tip", severity: "info",
      title: "Your home split is clean",
      body: "Sell-and-split 50/50 with young children is unusual but workable given your joint preference to each start fresh. Courts respect voluntary agreement here."
    }
  ],
  comments: [
    {
      id: "bc1", who: "AI", time: "just now",
      text: "Would you like me to draft an opening statement that explains your reasoning to Mark? I can keep it neutral and focused on the children."
    }
  ],
  activity: [
    { time: "just now",  who: "S", title: "Started v1 draft",  sub: "6 of 7 sections completed" },
    { time: "2 min ago", who: "AI", title: "Flagged 2 sections for review", sub: "Pensions, spousal maintenance" },
    { time: "15 min ago", who: "S", title: "Opened settlement proposal", sub: "From household picture v2.0" }
  ]
};

/* ============================================================
   REVIEW — Sarah is about to send v1
   AI gives court-readiness check
   ============================================================ */
const REVIEW = {
  summaryLine: "Before sending, here's how your v1 will likely land with Mark and with a court. Two items carry real risk.",
  insights: [
    {
      id: "r1", kind: "court_risk", severity: "warn",
      sectionKey: "pensions",
      title: "Expect a strong counter on pensions",
      body: "Your 0% share position gives you no negotiating room. If Mark rejects this, you'll need to concede — and that concession is visible as weakness. Starting at 15-20% would be more strategic.",
      citation: "Edgar v Edgar [1980]"
    },
    {
      id: "r2", kind: "comment_analysis", severity: "info",
      title: "Your opening note reads as reasonable",
      body: "You framed this as \"a starting point for discussion\" which matches collaborative norms. Mark will be more likely to respond constructively than if this were presented as final."
    },
    {
      id: "r3", kind: "fairness", severity: "notice",
      sectionKey: "spousal",
      title: "Spousal duration may compress",
      body: "£400 × 3 years = £14,400. A court would ask why 3 years, not 2. Be ready for Mark to counter with clean break or 2-year term."
    },
    {
      id: "r4", kind: "tip", severity: "info",
      title: "Everything else is unlikely to move",
      body: "Home, savings, vehicles, debts, and children arrangements match typical outcomes. These 5 sections will almost certainly be accepted as drafted."
    }
  ],
  comments: [
    {
      id: "rc1", who: "AI", time: "now",
      text: "I've reviewed your v1. 5 of 7 sections should be accepted quickly. Pensions and spousal will drive the negotiation. Expect v2 back within a week."
    }
  ],
  activity: [
    { time: "now", who: "S", title: "Opened review before send", sub: "All 7 sections drafted" },
    { time: "8 min ago", who: "AI", title: "Generated court-risk summary" },
    { time: "23 min ago", who: "S", title: "Completed spousal section", sub: "£400/mo for 3 years" }
  ]
};

/* ============================================================
   REDLINE — Mark has sent v2, Sarah responds
   AI analyses each of Mark's changes + suggests fallback responses
   ============================================================ */
const REDLINE = {
  summaryLine: "Mark accepted 4 sections and pushed back on 3. His pension ask is stronger than yours — here's the realistic middle ground.",
  insights: [
    {
      id: "rl1", kind: "court_risk", severity: "warn",
      sectionKey: "pensions",
      title: "Mark's 40% pension ask is well-supported",
      body: "An 8-year marriage with this pension disparity typically yields 30-50% sharing. His 40% figure is within that range. Fighting to zero will fail in court; settling at 20-25% is the realistic path.",
      citation: "WS v HS [2018] · MCA 1973 s.25(2)(h)",
      fallbacks: [
        { label: "Counter with 20% share", sub: "£36,082 transfer · splits the difference", payload: { pensions: "share_20" } },
        { label: "Counter with 25% share", sub: "£45,103 transfer · closer to his position", payload: { pensions: "share_25" } }
      ]
    },
    {
      id: "rl2", kind: "fairness", severity: "notice",
      sectionKey: "debts",
      title: "Mark's Amex claim has merit",
      body: "£5,800 of the Amex is from shared renovation and holidays. Treating it as joint is consistent with how courts view matrimonial spending. Consider splitting just that portion rather than the whole card.",
      fallbacks: [
        { label: "Share renovation portion only", sub: "£2,900 each · holds line on the rest", payload: { debts: "share_half_amex" } },
        { label: "Hold firm — each own", sub: "Defensible but expect further push", payload: { debts: "each_own" } }
      ]
    },
    {
      id: "rl3", kind: "comment_analysis", severity: "info",
      title: "Mark's rationale on spousal is reasonable",
      body: "His framing — \"address shortfall in a specific year if it arises\" — is constructive. A clean break with a review clause might satisfy both of you without locking in 3 years of cheques.",
      fallbacks: [
        { label: "Clean break + review clause", sub: "Revisit if NHS salary drops", payload: { spousal: "review_clause" } },
        { label: "£400/mo for 2 years", sub: "Shorter bridge, no review", payload: { spousal: "400_2y" } }
      ]
    },
    {
      id: "rl4", kind: "tip", severity: "info",
      title: "You've closed the gap by 50%",
      body: "Your v1 and his v2 are now £36k apart (down from £72k). One more round at this pace and you'll converge."
    }
  ],
  comments: [
    {
      id: "c1", who: "M", time: "7 May · 14:22", sectionKey: "pensions",
      text: "Sarah — I know the pension feels like yours alone, but I worked alongside you for 8 of those years. 40% reflects what actually accrued during the marriage, not the starting balance. Open to discussing the number but not the principle."
    },
    {
      id: "c1a", who: "AI", time: "7 May · 14:25", parentId: "c1",
      text: "Mark's framing — separating principle from number — is constructive. Courts treat pension accrual during marriage as matrimonial regardless of the holder.",
      aiAnalysis: "Mark's position matches case law well. A counter at 20-25% would be seen as reasonable; 0% would not."
    },
    {
      id: "c2", who: "S", time: "9 May · 08:41", sectionKey: "pensions",
      text: "I hear you. I need to sit with this. Can we talk tonight?"
    },
    {
      id: "c3", who: "M", time: "7 May · 14:40", sectionKey: "spousal",
      text: "I genuinely want you to land OK. I just don't want this to be a monthly bill for 3 years — if you need help in a specific year, let's handle it then."
    },
    {
      id: "c3a", who: "AI", time: "7 May · 14:42", parentId: "c3",
      text: "This sounds fair. A clean break with a review clause is a recognised middle ground — it preserves flexibility without ongoing maintenance.",
      aiAnalysis: "Offering to \"handle it then\" is generous but unenforceable. A written review clause captures the same intent."
    }
  ],
  activity: [
    { time: "just now", who: "AI", title: "Analysed Mark's v2 counter", sub: "3 flags raised · fallback positions suggested" },
    { time: "2 hr ago", who: "M", title: "Sent v2 counter-proposal", sub: "Changed: pensions, debts, spousal" },
    { time: "4 days ago", who: "S", title: "Sent v1 proposal to Mark" },
    { time: "4 days ago", who: "AI", title: "Pre-send review complete" }
  ]
};

/* ============================================================
   PROGRESS — 6 of 7 agreed, spousal pending Mark
   AI narrates convergence, suggests next moves
   ============================================================ */
const PROGRESS = {
  summaryLine: "You've converged in 4 rounds on 6 sections. Spousal is the last mile — here's what typically resolves it.",
  insights: [
    {
      id: "p1", kind: "tip", severity: "info",
      title: "Your convergence rate is strong",
      body: "£72k gap → £0 in 11 days is faster than most mediated settlements. You're averaging £18k closed per round."
    },
    {
      id: "p2", kind: "court_risk", severity: "info",
      sectionKey: "spousal",
      title: "£400/mo for 2 years will likely hold",
      body: "This is a defensible figure: short duration, modest amount, tied to Sarah's return to full income. A court would approve this without a hearing.",
      citation: "SS v NS [2014]"
    },
    {
      id: "p3", kind: "fairness", severity: "notice",
      sectionKey: "spousal",
      title: "If Mark wants clean break, here are paths forward",
      body: "Two options if he pushes back: (1) trade spousal for a larger share of savings, or (2) clean break with a reviewable clause tied to your NHS return date.",
      fallbacks: [
        { label: "Trade: clean break + £9,600 from savings", sub: "Same £ value, no ongoing payment", payload: { spousal: "offset_savings" } },
        { label: "Clean break + review in 12 months", sub: "Only triggers if salary doesn't restore", payload: { spousal: "review_clause" } }
      ]
    },
    {
      id: "p4", kind: "tip", severity: "info",
      title: "You're in court-approvable territory",
      body: "The 52/48 split and all 6 agreed sections would be rubber-stamped as a consent order. You're not negotiating from a position of risk."
    }
  ],
  comments: [
    {
      id: "pc1", who: "AI", time: "today · 09:00",
      text: "Mark was last active yesterday. Give it another 24-36 hours before following up — pressure at this stage can reopen settled items."
    },
    {
      id: "pc2", who: "M", time: "13 May · 17:30", sectionKey: "spousal",
      text: "Looking at your £400 × 2y. Thinking about it. Can I come back to you tomorrow?"
    },
    {
      id: "pc3", who: "S", time: "13 May · 17:45", parentId: "pc2",
      text: "Of course. No rush."
    }
  ],
  activity: [
    { time: "today",    who: "AI", title: "Spousal is the only open item", sub: "6 sections sealed" },
    { time: "13 May",   who: "M", title: "Sent v4 · accepted on debts", sub: "Closed gap to £0 on 5 of 7" },
    { time: "11 May",   who: "S", title: "Sent v3 · pensions at 20%", sub: "Spousal at £400/mo × 2y" },
    { time: "7 May",    who: "M", title: "Sent v2 counter" },
    { time: "3 May",    who: "S", title: "Sent v1 proposal" }
  ]
};

/* ============================================================
   AGREEMENT — v5 signed
   AI confirms court-readiness, next legal steps
   ============================================================ */
const AGREEMENT = {
  summaryLine: "Your signed agreement is court-ready. Here's what to do next to formalise it legally.",
  insights: [
    {
      id: "a1", kind: "court_risk", severity: "info",
      title: "This would pass as a consent order",
      body: "A district judge would approve this without a hearing. All 7 sections are within normal outcome ranges, the split is defensible, and both parties had opportunity to take advice.",
      citation: "FPR 2010 Part 9"
    },
    {
      id: "a2", kind: "tip", severity: "info",
      title: "Pension sharing needs a PSO",
      body: "The £36,082 transfer to Mark requires a Pension Sharing Order (Form P1). NHS Pensions will take 4-6 months to implement after the court issues it."
    },
    {
      id: "a3", kind: "tip", severity: "info",
      title: "Home sale — 3 actions this week",
      body: "Instruct 2-3 estate agents for valuation, confirm with Halifax on early repayment charges, open new Monzo joint to hold sale proceeds temporarily."
    },
    {
      id: "a4", kind: "fairness", severity: "info",
      title: "What you did well",
      body: "You kept direct communication throughout 4 rounds. Most settlements of this size involve solicitors on both sides — you saved roughly £6,000-£9,000 in fees."
    }
  ],
  comments: [
    {
      id: "ac1", who: "AI", time: "2 min ago",
      text: "Congratulations. Would you like me to generate the Form A and draft consent order from this agreement? That's the last administrative step."
    },
    {
      id: "ac2", who: "M", time: "14 May · 14:42",
      text: "Thank you for working through this with me. I know it wasn't easy on either of us."
    },
    {
      id: "ac3", who: "S", time: "14 May · 15:10", parentId: "ac2",
      text: "Same. We did OK."
    }
  ],
  activity: [
    { time: "just now",   who: "AI", title: "Generated court-readiness report", sub: "Agreement validated for consent order" },
    { time: "14:38",      who: "M", title: "Mark signed v5" },
    { time: "14:22",      who: "S", title: "Sarah signed v5" },
    { time: "14 May",     who: "both", title: "Agreement finalised · v5" },
    { time: "13 May",     who: "M", title: "Accepted final terms" }
  ]
};

Object.assign(window, {
  P4_AI_BUILD: BUILD,
  P4_AI_REVIEW: REVIEW,
  P4_AI_REDLINE: REDLINE,
  P4_AI_PROGRESS: PROGRESS,
  P4_AI_AGREEMENT: AGREEMENT
});
})();
