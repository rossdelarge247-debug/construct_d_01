/* Phase 4 View D — Progress board
   After v3 and v4 exchange, this shows where Sarah & Mark have converged.
   Tweak: layout — dedicated board (default) | doc + right rail | top strip on doc */
(function(){
const { useState, useEffect } = React;
const { P4_TOK: T, P4_Ic: I, P4_Avatar, P4_StatusChip, P4_TopBar, P4_ChapterRail,
        P4_FloatingRouter, P4_TweakPanel, P4_money, P4_SECTIONS,
        P4_OPTIONS: OPTIONS, P4_DEFAULT_DRAFT: DEFAULT_DRAFT,
        P4_computeSplit: computeSplit, P4_CONVERGENCE,
        P4_AIRail, P4_AI_PROGRESS } = window;

/* ============================================================
   SECTION-LEVEL PROGRESS
   For each section: history of who proposed what, current state
   ============================================================ */
const PROGRESS = {
  home:     { status: "agreed",    agreedOn: "3 May", choice: "sell_split_50_50",
              history: [{ who: "S", v: "v1", label: "Sell, split 50/50" }] },
  pensions: { status: "agreed",    agreedOn: "13 May", choice: "share_20",
              history: [
                { who: "S", v: "v1", label: "No pension sharing" },
                { who: "M", v: "v2", label: "40% share" },
                { who: "S", v: "v3", label: "20% share", accepted: true }
              ] },
  savings:  { status: "agreed",    agreedOn: "3 May", choice: "each_keeps_own",
              history: [{ who: "S", v: "v1", label: "Each keeps own" }] },
  vehicles: { status: "agreed",    agreedOn: "3 May", choice: "each_keeps_own",
              history: [{ who: "S", v: "v1", label: "Each keeps own car" }] },
  debts:    { status: "agreed",    agreedOn: "13 May", choice: "each_own",
              history: [
                { who: "S", v: "v1", label: "Each own" },
                { who: "M", v: "v2", label: "Share Amex" },
                { who: "M", v: "v4", label: "Each own (accepted Sarah's)", accepted: true }
              ] },
  children: { status: "agreed",    agreedOn: "3 May", choice: "primary_eow_mid",
              history: [{ who: "S", v: "v1", label: "Primary with Sarah · EOW + midweek" }] },
  spousal:  { status: "pending",   choice: "400_2y",
              history: [
                { who: "S", v: "v1", label: "£400/mo for 3y" },
                { who: "M", v: "v2", label: "Clean break" },
                { who: "S", v: "v3", label: "£400/mo for 2y — pending Mark" }
              ] }
};

const AGREED_KEYS = P4_SECTIONS.filter(s => PROGRESS[s.key].status === "agreed").map(s => s.key);
const PENDING_KEYS = P4_SECTIONS.filter(s => PROGRESS[s.key].status === "pending").map(s => s.key);

const lookup = (key, value) => OPTIONS[key]?.find(o => o.value === value);

/* ============================================================
   CONVERGENCE SPARKLINE — £ gap per round
   ============================================================ */
function ConvergenceSparkline({ width = 260, height = 80, compact }) {
  const pts = P4_CONVERGENCE;
  const maxGap = Math.max(...pts.map(p => p.gap));
  const w = width, h = height;
  const pad = 16;
  const xs = pts.map((_, i) => pad + (i / (pts.length - 1)) * (w - pad * 2));
  const ys = pts.map(p => h - pad - (p.gap / maxGap) * (h - pad * 2));
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${xs[i].toFixed(1)} ${ys[i].toFixed(1)}`).join(" ");
  /* area fill */
  const area = `${path} L ${xs[xs.length - 1].toFixed(1)} ${h - pad} L ${xs[0].toFixed(1)} ${h - pad} Z`;

  return (
    <div>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
        {/* baseline */}
        <line x1={pad} y1={h - pad} x2={w - pad} y2={h - pad} stroke="#E5E7EB" strokeDasharray="2 3"/>
        {/* area */}
        <path d={area} fill={T.AGREED} opacity="0.08"/>
        {/* line */}
        <path d={path} fill="none" stroke={T.AGREED} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        {/* points */}
        {pts.map((p, i) => (
          <g key={p.v}>
            <circle cx={xs[i]} cy={ys[i]} r={i === pts.length - 1 ? 5 : 3.5}
                    fill={p.author === "S" ? T.SARAH : T.MARK}
                    stroke="#FFF" strokeWidth="1.5"/>
            {!compact && (
              <text x={xs[i]} y={h - 2} fontSize="9" textAnchor="middle" fill={T.MUTE}
                    style={{ fontWeight: 600, letterSpacing: "0.05em" }}>
                {p.v}
              </text>
            )}
          </g>
        ))}
      </svg>
      {!compact && (
        <div className="flex justify-between mt-1" style={{ fontSize: 10.5, color: T.MUTE }}>
          <span>{P4_money(pts[0].gap)} gap</span>
          <span style={{ color: T.AGREED, fontWeight: 600 }}>£0 gap · converged</span>
        </div>
      )}
    </div>
  );
}

/* ============================================================
   SECTION TILE (agreed or pending)
   ============================================================ */
function SectionTile({ sec, onClick }) {
  const p = PROGRESS[sec.key];
  const agreed = p.status === "agreed";
  const choice = lookup(sec.key, p.choice);
  const lastBy = p.history[p.history.length - 1].who;

  return (
    <button onClick={onClick}
      className="text-left rounded-xl overflow-hidden transition"
      style={{
        background: "#FFF",
        border: `1px solid ${agreed ? T.HAIR : "#FACAA2"}`,
        boxShadow: agreed ? "none" : "0 0 0 3px #FEF3C7"
      }}>
      {/* Top bar */}
      <div className="px-4 pt-3.5 flex items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-1.5 mb-1">
            <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
            <span style={{ fontSize: 13.5, fontWeight: 600 }}>{sec.title}</span>
          </div>
          <div style={{ fontSize: 12, color: T.SUB, lineHeight: 1.4 }}>{choice?.label}</div>
        </div>
        <div className="flex-shrink-0">
          {agreed ? (
            <div className="w-6 h-6 rounded-full flex items-center justify-center" style={{ background: T.AGREED }}>
              <I.Check size={13} stroke="#FFF" strokeWidth={2.5}/>
            </div>
          ) : (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded" style={{ background: T.PENDING_TINT, color: T.PENDING, fontSize: 10, letterSpacing: "0.06em", textTransform: "uppercase", fontWeight: 700 }}>
              Pending {lastBy === "S" ? "Mark" : "Sarah"}
            </span>
          )}
        </div>
      </div>
      {/* History trail */}
      <div className="px-4 pb-3 pt-3">
        <div className="flex items-center gap-0.5 flex-wrap">
          {p.history.map((h, i) => (
            <React.Fragment key={i}>
              <div className="flex items-center gap-1 px-1.5 py-0.5 rounded"
                   style={{
                     background: i === p.history.length - 1
                       ? (h.who === "S" ? T.SARAH_TINT : T.MARK_TINT)
                       : "#FAFAF7",
                     opacity: i === p.history.length - 1 ? 1 : 0.65
                   }}>
                <P4_Avatar who={h.who} size={12}/>
                <span className="tabular-nums" style={{ fontSize: 10.5, color: T.SUB, fontWeight: 600, letterSpacing: "0.04em" }}>{h.v}</span>
              </div>
              {i < p.history.length - 1 && <I.Chev size={10} stroke="#D1D5DB" style={{ marginLeft: -1, marginRight: -1 }}/>}
            </React.Fragment>
          ))}
        </div>
      </div>
      {/* Agreed footer */}
      {agreed && (
        <div className="px-4 py-2" style={{ background: T.AGREED_TINT, borderTop: `1px solid ${T.HAIR}`, fontSize: 11, color: T.AGREED, fontWeight: 600, letterSpacing: "0.04em" }}>
          Agreed {p.agreedOn} · after {p.history.length} round{p.history.length === 1 ? "" : "s"}
        </div>
      )}
    </button>
  );
}

/* ============================================================
   VERSION TIMELINE (horizontal pills)
   ============================================================ */
function VersionTimeline() {
  const versions = [
    { v: "v1", who: "S", date: "3 May",  label: "Sarah's opening",  done: true },
    { v: "v2", who: "M", date: "7 May",  label: "Mark's counter",   done: true },
    { v: "v3", who: "S", date: "11 May", label: "Sarah's response", done: true },
    { v: "v4", who: "M", date: "13 May", label: "Mark's response",  done: true },
    { v: "—",  who: "?", date: "today",  label: "Resolve spousal",  done: false, pending: true }
  ];
  return (
    <div className="flex items-stretch gap-0">
      {versions.map((v, i) => (
        <div key={i} className="flex items-center flex-1">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1.5">
              <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 text-white"
                   style={{
                     background: v.pending ? T.PENDING : (v.who === "S" ? T.SARAH : v.who === "M" ? T.MARK : "#D1D5DB"),
                     fontSize: 11, fontWeight: 700
                   }}>
                {v.who}
              </div>
              <div>
                <div className="tabular-nums" style={{ fontSize: 11, color: T.MUTE, letterSpacing: "0.06em", fontWeight: 600 }}>
                  {v.v.toUpperCase()} · {v.date.toUpperCase()}
                </div>
                <div style={{ fontSize: 12.5, fontWeight: 600, lineHeight: 1.2 }}>{v.label}</div>
              </div>
            </div>
          </div>
          {i < versions.length - 1 && (
            <div className="flex-shrink-0 h-px" style={{ width: 24, background: v.pending ? "#E5E7EB" : T.AGREED }}/>
          )}
        </div>
      ))}
    </div>
  );
}

/* ============================================================
   BOARD LAYOUT — the default, full-page progress board
   ============================================================ */
function BoardLayout({ split }) {
  return (
    <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
      <div className="max-w-[920px] mx-auto px-8 py-10 pb-40">

        {/* Hero */}
        <div>
          <div>
            <div className="label-xs mb-1.5" style={{ color: T.AGREED }}>Settlement progress</div>
            <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
              Six of seven sections agreed.
            </h1>
            <p className="mt-3" style={{ fontSize: 14, color: T.SUB, lineHeight: 1.55 }}>
              You've worked through four rounds. Only spousal maintenance is still open — Mark's response is expected within 48 hours.
            </p>
            <div className="mt-5 flex items-center gap-2">
              <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "#E5E7EB", maxWidth: 400 }}>
                <div className="h-full" style={{ width: `${(AGREED_KEYS.length / P4_SECTIONS.length) * 100}%`, background: T.AGREED }}/>
              </div>
              <span className="tabular-nums" style={{ fontSize: 13, color: T.AGREED, fontWeight: 700 }}>
                {AGREED_KEYS.length}/{P4_SECTIONS.length}
              </span>
            </div>
          </div>

          {/* Convergence sparkline card — full width below hero */}
          <div className="mt-6 rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
            <div className="flex items-center justify-between mb-2">
              <div className="label-xs whitespace-nowrap" style={{ color: T.MUTE }}>Gap between positions</div>
              <P4_StatusChip kind="agreed">Converged</P4_StatusChip>
            </div>
            <ConvergenceSparkline width={560} height={72}/>
            <div style={{ fontSize: 11.5, color: T.SUB, marginTop: 6, lineHeight: 1.4 }}>
              Started £72,000 apart. Closed to zero across four rounds.
            </div>
          </div>
        </div>

        {/* Version timeline */}
        <div className="mt-9 rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
          <div className="label-xs mb-4" style={{ color: T.MUTE }}>Version history</div>
          <VersionTimeline/>
        </div>

        {/* Pending first */}
        {PENDING_KEYS.length > 0 && (
          <>
            <div className="mt-10 flex items-center gap-2 label-xs" style={{ color: T.PENDING }}>
              <span className="w-2 h-2 rounded-full" style={{ background: T.PENDING }}/>
              Still open · {PENDING_KEYS.length} section
            </div>
            <div className="grid gap-3 mt-3" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))" }}>
              {PENDING_KEYS.map(k => {
                const sec = P4_SECTIONS.find(s => s.key === k);
                return <SectionTile key={k} sec={sec}/>;
              })}
            </div>
          </>
        )}

        {/* Agreed */}
        <div className="mt-10 flex items-center gap-2 label-xs" style={{ color: T.AGREED }}>
          <I.Check size={11} stroke={T.AGREED} strokeWidth={2.5}/>
          Agreed · {AGREED_KEYS.length} sections
        </div>
        <div className="grid gap-3 mt-3" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))" }}>
          {AGREED_KEYS.map(k => {
            const sec = P4_SECTIONS.find(s => s.key === k);
            return <SectionTile key={k} sec={sec}/>;
          })}
        </div>

        {/* Current split + next step */}
        <div className="mt-10 grid gap-4" style={{ gridTemplateColumns: "minmax(0, 1fr) 320px" }}>
          <div className="rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
            <div className="label-xs mb-2" style={{ color: T.MUTE }}>Current agreed split</div>
            <div className="flex items-end justify-between">
              <div>
                <div className="flex items-center gap-1.5 mb-1" style={{ fontSize: 12, color: T.SARAH }}>
                  <P4_Avatar who="S" size={14}/> Sarah
                </div>
                <div className="tabular-nums" style={{ fontSize: 32, fontWeight: 700, color: T.SARAH, lineHeight: 1 }}>{split.sarahPct}%</div>
                <div className="tabular-nums" style={{ fontSize: 13, color: T.SUB, marginTop: 4 }}>{P4_money(split.sarahNet)}</div>
              </div>
              <div className="text-right">
                <div className="flex items-center justify-end gap-1.5 mb-1" style={{ fontSize: 12, color: T.MARK }}>
                  Mark <P4_Avatar who="M" size={14}/>
                </div>
                <div className="tabular-nums" style={{ fontSize: 32, fontWeight: 700, color: T.MARK, lineHeight: 1 }}>{split.markPct}%</div>
                <div className="tabular-nums" style={{ fontSize: 13, color: T.SUB, marginTop: 4 }}>{P4_money(split.markNet)}</div>
              </div>
            </div>
            <div className="mt-4 h-2 rounded-full overflow-hidden flex" style={{ background: "#F3F4F6" }}>
              <div style={{ width: `${split.sarahPct}%`, background: T.SARAH }}/>
              <div style={{ width: `${split.markPct}%`, background: T.MARK }}/>
            </div>
            <div style={{ fontSize: 11.5, color: T.MUTE, marginTop: 6, lineHeight: 1.4 }}>
              Based on 6 agreed sections · spousal excluded (pending)
            </div>
          </div>

          <div className="rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
            <div className="label-xs mb-2" style={{ color: T.MUTE }}>Next step</div>
            <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.4 }}>Mark responds to v3</div>
            <div style={{ fontSize: 12.5, color: T.SUB, marginTop: 4, lineHeight: 1.5 }}>
              You proposed £400/mo for 2 years on spousal maintenance. Waiting on Mark.
            </div>
            <div className="mt-3 flex items-center gap-2" style={{ fontSize: 11.5, color: T.PENDING }}>
              <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: T.PENDING }}/>
              <span>Response expected within 48h</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}

/* ============================================================
   DOC + RIGHT RAIL LAYOUT
   ============================================================ */
function DocRightRailLayout({ split }) {
  return (
    <>
      <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFF" }}>
        <div className="max-w-[640px] mx-auto px-8 py-10 pb-40">
          <div className="label-xs mb-1.5" style={{ color: T.AGREED }}>Settlement · v4</div>
          <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
            Where we've landed so far
          </h1>
          <p className="mt-3" style={{ fontSize: 14.5, color: T.SUB, lineHeight: 1.6 }}>
            After four rounds, Sarah and Mark have agreed on six of seven sections. Only spousal maintenance remains open.
          </p>
          <div className="mt-8 space-y-5">
            {P4_SECTIONS.map(sec => {
              const p = PROGRESS[sec.key];
              const choice = lookup(sec.key, p.choice);
              return (
                <div key={sec.key}>
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
                    <span style={{ fontSize: 16, fontWeight: 600 }}>{sec.title}</span>
                    {p.status === "agreed"
                      ? <P4_StatusChip kind="agreed">Agreed</P4_StatusChip>
                      : <P4_StatusChip kind="pending">Pending Mark</P4_StatusChip>}
                  </div>
                  <div style={{ fontSize: 14, color: "#1A1A1A", lineHeight: 1.6 }}>{choice?.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {/* Right rail */}
      <div className="flex-shrink-0 overflow-y-auto nice-scroll"
           style={{ width: 320, background: "#FAFAFA", borderLeft: `1px solid ${T.HAIR}` }}>
        <div className="p-5 space-y-4">
          <div className="rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
            <div className="label-xs mb-2" style={{ color: T.MUTE }}>Progress</div>
            <div className="flex items-end gap-3">
              <div className="tabular-nums" style={{ fontSize: 30, fontWeight: 700, color: T.AGREED, lineHeight: 1 }}>
                {AGREED_KEYS.length}/{P4_SECTIONS.length}
              </div>
              <div style={{ fontSize: 11.5, color: T.SUB, marginBottom: 4 }}>sections agreed</div>
            </div>
            <div className="mt-3 h-1.5 rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
              <div className="h-full" style={{ width: `${(AGREED_KEYS.length / P4_SECTIONS.length) * 100}%`, background: T.AGREED }}/>
            </div>
          </div>
          <div className="rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
            <div className="label-xs mb-2" style={{ color: T.MUTE }}>Gap between positions</div>
            <ConvergenceSparkline width={272} height={68}/>
          </div>
          <div className="rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
            <div className="label-xs mb-2" style={{ color: T.MUTE }}>Current split</div>
            <div className="flex items-center justify-between">
              <div className="tabular-nums" style={{ fontSize: 18, fontWeight: 700, color: T.SARAH }}>{split.sarahPct}%</div>
              <div className="tabular-nums" style={{ fontSize: 18, fontWeight: 700, color: T.MARK }}>{split.markPct}%</div>
            </div>
            <div className="mt-2 h-1.5 rounded-full overflow-hidden flex" style={{ background: "#F3F4F6" }}>
              <div style={{ width: `${split.sarahPct}%`, background: T.SARAH }}/>
              <div style={{ width: `${split.markPct}%`, background: T.MARK }}/>
            </div>
          </div>
          <div className="rounded-xl p-4" style={{ background: T.PENDING_TINT, border: `1px solid #F9D89D` }}>
            <div className="label-xs mb-1" style={{ color: T.PENDING }}>Pending</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: T.INK, lineHeight: 1.3 }}>Spousal maintenance</div>
            <div style={{ fontSize: 12, color: T.SUB, marginTop: 4, lineHeight: 1.45 }}>
              Awaiting Mark's response to v3. Expected within 48h.
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

/* ============================================================
   TOP STRIP LAYOUT — slim overview bar pinned to top of the doc
   ============================================================ */
function TopStripLayout({ split }) {
  return (
    <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFF" }}>
      {/* Sticky top strip */}
      <div className="sticky top-0 z-10 flex items-stretch"
           style={{ background: "#FAFAF7", borderBottom: `1px solid ${T.HAIR}`, minHeight: 88 }}>
        <div className="flex-shrink-0 px-5 py-4" style={{ borderRight: `1px solid ${T.HAIR}` }}>
          <div className="label-xs mb-1" style={{ color: T.MUTE }}>Progress</div>
          <div className="flex items-end gap-2">
            <div className="tabular-nums" style={{ fontSize: 24, fontWeight: 700, color: T.AGREED, lineHeight: 1 }}>
              {AGREED_KEYS.length}/{P4_SECTIONS.length}
            </div>
            <div style={{ fontSize: 11, color: T.SUB, marginBottom: 2 }}>agreed</div>
          </div>
        </div>

        <div className="flex-1 flex items-center gap-1 px-5 py-3 overflow-x-auto">
          {P4_SECTIONS.map(sec => {
            const p = PROGRESS[sec.key];
            const agreed = p.status === "agreed";
            return (
              <div key={sec.key}
                   className="flex flex-col items-center gap-1 px-2 py-1 rounded-md flex-shrink-0"
                   style={{ background: agreed ? T.AGREED_TINT : T.PENDING_TINT, minWidth: 88 }}
                   title={sec.title}>
                <span style={{ fontSize: 10, color: agreed ? T.AGREED : T.PENDING, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  {agreed ? "Agreed" : "Pending"}
                </span>
                <span className="truncate" style={{ fontSize: 11, fontWeight: 500, maxWidth: 100 }}>{sec.title}</span>
              </div>
            );
          })}
        </div>

        <div className="flex-shrink-0 px-5 py-3 flex items-center gap-4" style={{ borderLeft: `1px solid ${T.HAIR}` }}>
          <div>
            <div className="label-xs mb-1" style={{ color: T.MUTE }}>Convergence</div>
            <ConvergenceSparkline width={120} height={44} compact/>
          </div>
          <div>
            <div className="label-xs mb-1" style={{ color: T.MUTE }}>Split</div>
            <div className="tabular-nums flex items-baseline gap-1" style={{ fontSize: 14, fontWeight: 600 }}>
              <span style={{ color: T.SARAH }}>{split.sarahPct}%</span>
              <span style={{ color: T.MUTE }}>·</span>
              <span style={{ color: T.MARK }}>{split.markPct}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Doc body */}
      <div className="max-w-[640px] mx-auto px-8 py-10 pb-40">
        <div className="label-xs mb-1.5" style={{ color: T.AGREED }}>Settlement · v4</div>
        <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
          Where we've landed so far
        </h1>
        <p className="mt-3" style={{ fontSize: 14.5, color: T.SUB, lineHeight: 1.6 }}>
          After four rounds, Sarah and Mark have agreed on six of seven sections.
        </p>
        <div className="mt-8 space-y-5">
          {P4_SECTIONS.map(sec => {
            const p = PROGRESS[sec.key];
            const choice = lookup(sec.key, p.choice);
            return (
              <div key={sec.key}>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
                  <span style={{ fontSize: 16, fontWeight: 600 }}>{sec.title}</span>
                  {p.status === "agreed"
                    ? <P4_StatusChip kind="agreed">Agreed</P4_StatusChip>
                    : <P4_StatusChip kind="pending">Pending</P4_StatusChip>}
                </div>
                <div style={{ fontSize: 14, color: "#1A1A1A", lineHeight: 1.6 }}>{choice?.label}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "layout": "board",
  "router": "inline"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => {
      const next = { ...t, [id]: value };
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
      return next;
    });
  };

  /* Split is based on v3/v4 (current agreed positions) */
  const split = computeSplit({
    home: "sell_split_50_50",
    pensions: "share_20",
    savings: "each_keeps_own",
    vehicles: "each_keeps_own",
    debts: "each_own",
    children: "primary_eow_mid",
    spousal: "400_2y"
  });

  const sectionStatus = Object.fromEntries(P4_SECTIONS.map(s => {
    const st = PROGRESS[s.key].status;
    return [s.key, st === "agreed" ? "agreed" : "pending"];
  }));

  const topRight = (
    <>
      <span className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md whitespace-nowrap" style={{ background: T.PENDING_TINT, color: T.PENDING, fontSize: 11.5, fontWeight: 600 }}>
        <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: T.PENDING }}/>
        Waiting on Mark · 48h
      </span>
      <a href="Settlement - Agreement.html"
         className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md"
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}`, fontSize: 12.5, color: T.SUB, fontWeight: 500, textDecoration: "none" }}>
        Preview agreement <I.ArrowR size={12} stroke={T.SUB}/>
      </a>
    </>
  );

  const Layout = tweaks.layout === "doc_rail" ? DocRightRailLayout
    : tweaks.layout === "top_strip" ? TopStripLayout
    : BoardLayout;

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar
        viewMeta={{ phase: "Phase 4", title: "Settlement progress", version: "v4", statusLabel: "6 OF 7 AGREED", statusKind: "agreed" }}
        right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={sectionStatus}
                        title="Settlement sections"
                        subtitle={`${AGREED_KEYS.length} of ${P4_SECTIONS.length} agreed · 1 pending`}
                        pct={Math.round((AGREED_KEYS.length / P4_SECTIONS.length) * 100)}
                        currentRoute="progress"
                        showInlineRouter={tweaks.router === "inline"}/>
        <Layout split={split}/>
        <P4_AIRail
          insights={P4_AI_PROGRESS.insights}
          comments={P4_AI_PROGRESS.comments}
          activity={P4_AI_PROGRESS.activity}
          summaryLine={P4_AI_PROGRESS.summaryLine}
          defaultTab="ai"/>
        {tweaks.router !== "inline" && <P4_FloatingRouter current="progress"/>}
      </div>
      <P4_TweakPanel
        title="Progress"
        options={[
          { id: "layout", label: "Layout", variants: [
            { value: "board",     label: "Dedicated board",  sub: "Full-page dashboard (default)" },
            { value: "doc_rail",  label: "Doc + right rail", sub: "Document with progress sidebar" },
            { value: "top_strip", label: "Top strip on doc", sub: "Sticky overview bar" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
