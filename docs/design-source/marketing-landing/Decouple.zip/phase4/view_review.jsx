/* Phase 4 View B — Review & Send
   Sarah has drafted v1. This view is the final read-over before sending.
   Key moment: the Send button is a deliberate 3-second hold, not a click.

   Tweak: the "deliberation depth" — casual click | confirmation modal |
   3s hold | 3s hold + checklist */
(function(){
const { useState, useEffect, useRef } = React;
const { P4_TOK: T, P4_Ic: I, P4_Avatar, P4_StatusChip, P4_TopBar, P4_ChapterRail,
        P4_FloatingRouter, P4_TweakPanel, P4_money, P4_FACTS, P4_SECTIONS,
        P4_OPTIONS: OPTIONS, P4_SECTION_INFO: SECTION_INFO,
        P4_DEFAULT_DRAFT: DEFAULT_DRAFT, P4_computeSplit: computeSplit,
        P4_AIRail, P4_AI_REVIEW } = window;

/* ============================================================
   CHOSEN DRAFT (final v1 from Build step)
   Assume Sarah has made all 7 choices — the "typical opening".
   ============================================================ */
const FINAL_DRAFT = { ...DEFAULT_DRAFT };  /* already includes spousal: 400_3y */

const IMPACT_TAG = (draft, key) => {
  const o = OPTIONS[key].find(o => o.value === draft[key]);
  return o ? o : null;
};

/* ============================================================
   SECTION REVIEW CARD — read-only summary card for the review page
   ============================================================ */
function ReviewSection({ sec, draft, onEdit }) {
  const o = IMPACT_TAG(draft, sec.key);
  return (
    <div className="rounded-xl bg-white" style={{ border: `1px solid ${T.HAIR}` }}>
      <div className="px-5 py-4">
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
              <span style={{ fontSize: 13.5, fontWeight: 600 }}>{sec.title}</span>
              <P4_StatusChip kind="sarah">Sarah's position</P4_StatusChip>
            </div>
            <div style={{ fontSize: 14, color: T.INK, lineHeight: 1.5, fontWeight: 500 }}>
              {o.label}
            </div>
            <div className="mt-2 flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
                <P4_Avatar who="S" size={14}/>
                <span style={{ color: T.SUB }}>{o.impactS}</span>
              </span>
              <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
                <P4_Avatar who="M" size={14}/>
                <span style={{ color: T.SUB }}>{o.impactM}</span>
              </span>
            </div>
            {o.note && (
              <div style={{ fontSize: 11.5, color: T.MUTE, marginTop: 6, lineHeight: 1.45, fontStyle: "italic" }}>{o.note}</div>
            )}
          </div>
          <button onClick={onEdit}
                  className="flex-shrink-0 inline-flex items-center gap-1 h-7 px-2.5 rounded-md"
                  style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}`, fontSize: 11.5, color: T.SUB, fontWeight: 500 }}>
            <I.Edit size={11}/> Edit
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   DELIBERATE SEND BUTTON — 3 second hold
   ============================================================ */
function HoldToSendButton({ onComplete, label = "Hold to send to Mark", duration = 3000 }) {
  const [progress, setProgress] = useState(0); /* 0..1 */
  const [sent, setSent] = useState(false);
  const rafRef = useRef(null);
  const startRef = useRef(null);
  const holdingRef = useRef(false);

  const tick = (ts) => {
    if (!holdingRef.current) return;
    if (!startRef.current) startRef.current = ts;
    const elapsed = ts - startRef.current;
    const p = Math.min(1, elapsed / duration);
    setProgress(p);
    if (p >= 1) {
      holdingRef.current = false;
      setSent(true);
      setTimeout(() => onComplete && onComplete(), 220);
      return;
    }
    rafRef.current = requestAnimationFrame(tick);
  };

  const start = () => {
    if (sent) return;
    holdingRef.current = true;
    startRef.current = null;
    rafRef.current = requestAnimationFrame(tick);
  };
  const stop = () => {
    if (sent) return;
    holdingRef.current = false;
    cancelAnimationFrame(rafRef.current);
    setProgress(0);
  };

  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  const pct = Math.round(progress * 100);

  return (
    <button
      onMouseDown={start}
      onMouseUp={stop}
      onMouseLeave={stop}
      onTouchStart={start}
      onTouchEnd={stop}
      disabled={sent}
      className="relative overflow-hidden h-12 px-6 rounded-lg select-none"
      style={{
        background: sent ? T.AGREED : T.SARAH,
        border: `1.5px solid ${sent ? T.AGREED : T.SARAH}`,
        color: "#FFF",
        minWidth: 240, fontSize: 14, fontWeight: 600,
        cursor: sent ? "default" : "pointer",
        transition: "background 200ms, border 200ms"
      }}>
      {/* progress fill */}
      <span className="absolute inset-0"
            style={{
              background: "rgba(255,255,255,0.22)",
              width: `${pct}%`,
              transition: progress === 0 ? "width 140ms ease-out" : "none"
            }}/>
      <span className="relative flex items-center justify-center gap-2">
        {sent ? (
          <>
            <I.Check size={16} stroke="#FFF" strokeWidth={2.5}/>
            Sent to Mark
          </>
        ) : progress > 0 ? (
          <>
            <span className="tabular-nums" style={{ fontVariantNumeric: "tabular-nums" }}>{pct}%</span>
            <span style={{ opacity: 0.8 }}>· Keep holding…</span>
          </>
        ) : (
          <>
            <I.Send size={14} stroke="#FFF"/> {label}
          </>
        )}
      </span>
    </button>
  );
}

/* ============================================================
   CONFIRMATION MODAL variant
   ============================================================ */
function ConfirmModal({ open, onClose, onConfirm }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ animation: "fadeIn 160ms" }}>
      <div onClick={onClose} className="absolute inset-0" style={{ background: "rgba(0,0,0,0.28)" }}/>
      <div className="relative bg-white rounded-2xl p-7 w-full"
           style={{ maxWidth: 460, boxShadow: "0 28px 60px rgba(0,0,0,0.22)", animation: "riseIn 200ms cubic-bezier(.2,.9,.2,1)" }}>
        <div className="flex items-center gap-2 mb-1 label-xs" style={{ color: T.SARAH }}>
          <I.Send size={12}/> Sending v1
        </div>
        <h3 style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-0.015em", lineHeight: 1.25 }}>
          Send your proposal to Mark?
        </h3>
        <p style={{ fontSize: 13.5, color: T.SUB, lineHeight: 1.55, marginTop: 8 }}>
          Mark will see all seven sections. You'll be able to revise and send further rounds after he responds.
        </p>
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onClose}
                  className="h-10 px-4 rounded-md"
                  style={{ background: "#FFF", border: `1px solid ${T.HAIR}`, fontSize: 13, fontWeight: 600, color: T.INK }}>
            Keep editing
          </button>
          <button onClick={onConfirm}
                  className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md text-white"
                  style={{ background: T.SARAH, fontSize: 13, fontWeight: 600 }}>
            <I.Send size={13} stroke="#FFF"/> Send to Mark
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   CHECKLIST variant — 3 acknowledgements before button unlocks
   ============================================================ */
function Checklist({ checks, setChecks }) {
  const items = [
    { id: "ack1", label: "I've reviewed all seven sections" },
    { id: "ack2", label: "I understand this is my opening position — Mark will counter" },
    { id: "ack3", label: "I've saved a copy I can share with my advisor if needed" }
  ];
  return (
    <div className="rounded-xl p-4 mb-4" style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}` }}>
      <div className="label-xs mb-2.5" style={{ color: T.MUTE }}>Before sending</div>
      <div className="space-y-2">
        {items.map(it => (
          <label key={it.id} className="flex items-start gap-2.5 cursor-pointer">
            <span className="flex-shrink-0 mt-0.5"
                  style={{
                    width: 16, height: 16, borderRadius: 4,
                    border: `1.5px solid ${checks[it.id] ? T.SARAH : "#D1D5DB"}`,
                    background: checks[it.id] ? T.SARAH : "transparent",
                    display: "flex", alignItems: "center", justifyContent: "center"
                  }}>
              {checks[it.id] && <I.Check size={11} stroke="#FFF" strokeWidth={3}/>}
            </span>
            <input type="checkbox"
                   checked={!!checks[it.id]}
                   onChange={e => setChecks(c => ({ ...c, [it.id]: e.target.checked }))}
                   className="sr-only"/>
            <span style={{ fontSize: 13, color: T.INK, lineHeight: 1.4 }}>{it.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "send_mode": "hold",
  "router": "inline"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const [draft] = useState(FINAL_DRAFT);
  const [showModal, setShowModal] = useState(false);
  const [sent, setSent] = useState(false);
  const [checks, setChecks] = useState({});

  const setTweak = (id, value) => {
    setTweaks(t => {
      const next = { ...t, [id]: value };
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
      return next;
    });
  };

  const sectionStatus = Object.fromEntries(P4_SECTIONS.map(s => [s.key, "agreed"]));
  const split = computeSplit(draft);
  const allChecked = Object.keys(checks).filter(k => checks[k]).length >= 3;

  const handleSent = () => {
    setSent(true);
    setTimeout(() => { window.location.href = "Settlement - Redline.html"; }, 1400);
  };

  const topRight = (
    <>
      <a href="Settlement - Build.html"
         className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md"
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}`, fontSize: 12.5, color: T.SUB, fontWeight: 500, textDecoration: "none" }}>
        <I.ChevL size={12}/> Back to editing
      </a>
    </>
  );

  /* Choose send control by tweak */
  let SendControl;
  if (sent) {
    SendControl = <HoldToSendButton label="Already sent" onComplete={() => {}} duration={1}/>;
  } else if (tweaks.send_mode === "click") {
    SendControl = (
      <button onClick={handleSent}
              className="inline-flex items-center gap-2 h-12 px-6 rounded-lg text-white"
              style={{ background: T.SARAH, fontSize: 14, fontWeight: 600, minWidth: 240 }}>
        <I.Send size={14} stroke="#FFF"/> Send to Mark
      </button>
    );
  } else if (tweaks.send_mode === "modal") {
    SendControl = (
      <button onClick={() => setShowModal(true)}
              className="inline-flex items-center gap-2 h-12 px-6 rounded-lg text-white"
              style={{ background: T.SARAH, fontSize: 14, fontWeight: 600, minWidth: 240 }}>
        <I.Send size={14} stroke="#FFF"/> Send to Mark
      </button>
    );
  } else if (tweaks.send_mode === "checklist") {
    SendControl = (
      <div>
        <Checklist checks={checks} setChecks={setChecks}/>
        <div className="flex justify-center">
          {allChecked ? (
            <HoldToSendButton onComplete={handleSent}/>
          ) : (
            <button disabled
                    className="h-12 px-6 rounded-lg"
                    style={{ background: "#E5E7EB", color: "#9CA3AF", fontSize: 14, fontWeight: 600, minWidth: 240, cursor: "not-allowed" }}>
              Complete checklist to send
            </button>
          )}
        </div>
      </div>
    );
  } else {
    /* hold (default) */
    SendControl = <HoldToSendButton onComplete={handleSent}/>;
  }

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar
        viewMeta={{ phase: "Phase 4", title: "Your settlement proposal", version: "v1", statusLabel: sent ? "SENT" : "READY TO SEND", statusKind: sent ? "agreed" : "sarah" }}
        right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={sectionStatus}
                        title="Your draft proposal"
                        subtitle="All 7 sections completed"
                        pct={100}
                        currentRoute="review"
                        showInlineRouter={tweaks.router === "inline"}/>
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
          <div className="max-w-[780px] mx-auto px-8 py-10 pb-40">

            {/* Hero */}
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <span className="label-xs" style={{ color: T.SARAH }}>Final review · v1</span>
              </div>
              <h1 style={{ fontSize: 34, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.1 }}>
                Read over your proposal.
                <br/>
                <span style={{ color: T.SUB }}>Then send it when you're ready.</span>
              </h1>
              <p className="mt-3" style={{ fontSize: 14.5, color: T.SUB, lineHeight: 1.55, maxWidth: 620 }}>
                Mark will see these seven sections exactly as written. This is your opening position — he'll reply with a counter-proposal. You can revise before sending.
              </p>
            </div>

            {/* Running split callout */}
            <div className="mt-7 rounded-xl overflow-hidden"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
              <div className="px-5 py-4 flex items-center justify-between">
                <div>
                  <div className="label-xs whitespace-nowrap" style={{ color: T.MUTE }}>Under this proposal</div>
                  <div className="mt-1 tabular-nums" style={{ fontSize: 15, fontWeight: 600 }}>
                    Sarah {split.sarahPct}% · Mark {split.markPct}%
                  </div>
                </div>
                <div className="text-right">
                  <div className="label-xs whitespace-nowrap" style={{ color: T.MUTE }}>Total net household</div>
                  <div className="mt-1 tabular-nums" style={{ fontSize: 15, fontWeight: 600, color: T.INK }}>
                    {P4_money(split.sarahNet + split.markNet)}
                  </div>
                </div>
              </div>
              <div className="h-2 flex">
                <div style={{ width: `${split.sarahPct}%`, background: T.SARAH }}/>
                <div style={{ width: `${split.markPct}%`, background: T.MARK }}/>
              </div>
              <div className="px-5 py-3 flex items-center justify-between" style={{ background: "#FAFAF7", borderTop: `1px solid ${T.HAIR}` }}>
                <span className="flex items-center gap-1.5" style={{ fontSize: 12 }}>
                  <P4_Avatar who="S" size={14}/> <span style={{ color: T.SARAH, fontWeight: 600 }} className="tabular-nums">{P4_money(split.sarahNet)}</span>
                </span>
                <span className="flex items-center gap-1.5" style={{ fontSize: 12 }}>
                  <span style={{ color: T.MARK, fontWeight: 600 }} className="tabular-nums">{P4_money(split.markNet)}</span> <P4_Avatar who="M" size={14}/>
                </span>
              </div>
            </div>

            {/* Sections */}
            <div className="mt-8 space-y-3">
              {P4_SECTIONS.map(sec => (
                <ReviewSection key={sec.key} sec={sec} draft={draft}
                               onEdit={() => { window.location.href = "Settlement - Build.html"; }}/>
              ))}
            </div>

            {/* Bottom callout + send */}
            <div className="mt-10 rounded-2xl p-6"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center"
                     style={{ background: T.SARAH_TINT }}>
                  <I.Gavel size={18} stroke={T.SARAH}/>
                </div>
                <div className="flex-1">
                  <div style={{ fontSize: 15, fontWeight: 600 }}>A proposal is a considered act.</div>
                  <div style={{ fontSize: 13, color: T.SUB, lineHeight: 1.55, marginTop: 4, maxWidth: 520 }}>
                    Once sent, Mark will review every section.
                    {tweaks.send_mode === "hold" && " Take your time — hold the button for three seconds to confirm."}
                    {tweaks.send_mode === "checklist" && " Confirm the three items below, then hold the button to send."}
                    {tweaks.send_mode === "modal" && " You'll be asked to confirm in a moment."}
                  </div>
                </div>
              </div>
              <div className="mt-5 flex justify-center">
                {SendControl}
              </div>
              {tweaks.send_mode === "hold" && !sent && (
                <div className="mt-3 text-center" style={{ fontSize: 11.5, color: T.MUTE, letterSpacing: "0.04em" }}>
                  Press and hold · 3 seconds
                </div>
              )}
            </div>
          </div>
        </div>
        <P4_AIRail
          insights={P4_AI_REVIEW.insights}
          comments={P4_AI_REVIEW.comments}
          activity={P4_AI_REVIEW.activity}
          summaryLine={P4_AI_REVIEW.summaryLine}
          defaultTab="ai"/>
        {tweaks.router !== "inline" && <P4_FloatingRouter current="review"/>}
      </div>

      <ConfirmModal open={showModal}
                    onClose={() => setShowModal(false)}
                    onConfirm={() => { setShowModal(false); handleSent(); }}/>

      <P4_TweakPanel
        title="Review"
        options={[
          { id: "send_mode", label: "Send control", variants: [
            { value: "hold", label: "Hold to send · 3s", sub: "Deliberate, weighted moment" },
            { value: "checklist", label: "Checklist + hold", sub: "Three acknowledgements first" },
            { value: "modal", label: "Confirmation modal", sub: "Standard two-step confirm" },
            { value: "click", label: "Simple click", sub: "No friction — for comparison" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
