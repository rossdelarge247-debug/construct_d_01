/* Phase 4 — shared options/decisions data + computeSplit
   Used by Build (Sarah drafts), Review, Redline, Progress, Agreement views */
(function(){

const OPTIONS = {
  home: [
    { value: "sell_split_50_50", label: "Sell the home, split equity 50/50",
      impactS: "+£115,000", impactM: "+£115,000",
      note: "Clean break · neither keeps the family home" },
    { value: "sarah_keeps_buys_out", label: "Sarah keeps the home, buys out Mark's share",
      impactS: "Home (−£115k cash to raise)", impactM: "+£115,000",
      note: "Requires Sarah to refinance · £230k mortgage capacity" },
    { value: "mark_keeps_buys_out", label: "Mark keeps the home, buys out Sarah's share",
      impactS: "+£115,000", impactM: "Home (−£115k cash to raise)",
      note: "Requires Mark to refinance" },
    { value: "defer_sale", label: "Defer sale until youngest child is 18",
      impactS: "£115,000 deferred", impactM: "£115,000 deferred",
      note: "Mesher order · both remain on title for ~14 years" }
  ],
  pensions: [
    { value: "no_share", label: "No pension sharing — each keeps their own",
      impactS: "Sarah retains £180,412", impactM: "Mark retains £12,000",
      note: "Large disparity remains (£168k gap)" },
    { value: "share_20", label: "20% pension sharing order",
      impactS: "Sarah retains £144,330", impactM: "+£36,082",
      note: "Partial rebalance" },
    { value: "share_40", label: "40% pension sharing order",
      impactS: "Sarah retains £108,247", impactM: "+£72,165",
      note: "Equalises pensions more fully" },
    { value: "offset", label: "Offset pensions against other assets",
      impactS: "Retains full pension, less of home equity", impactM: "More cash / home equity instead",
      note: "Keeps pensions intact but complicates home split" }
  ],
  savings: [
    { value: "each_keeps_own", label: "Each keeps their own accounts",
      impactS: "Sarah £7,240", impactM: "Mark £18,800",
      note: "Joint account split 50/50" },
    { value: "pool_split_equal", label: "Pool all savings, split equally",
      impactS: "£17,020", impactM: "£17,020",
      note: "Treats all cash as matrimonial" }
  ],
  vehicles: [
    { value: "each_keeps_own", label: "Each keeps the car they drive",
      impactS: "Ford Escort (£3,800)", impactM: "BMW 3 Series (£6,000)",
      note: "Simplest option" },
    { value: "balance_cash", label: "Each keeps car, balance £1,100 cash to Sarah",
      impactS: "Ford + £1,100", impactM: "BMW − £1,100",
      note: "Equalises vehicle value" }
  ],
  debts: [
    { value: "each_own", label: "Each responsible for their own debts",
      impactS: "−£3,480 (Barclaycard + Klarna)", impactM: "−£23,800 (Amex + student loan)",
      note: "Simplest · Mark's student loan is pre-marriage" },
    { value: "share_half_amex", label: "Share Amex 50/50, each own the rest",
      impactS: "−£6,380", impactM: "−£20,900",
      note: "Amex (£5,800) treated as joint spending" },
    { value: "pool_split", label: "Pool all debts, split equally",
      impactS: "−£13,640", impactM: "−£13,640",
      note: "Unusual · student loan typically excluded" }
  ],
  children: [
    { value: "primary_eow_mid", label: "Primary with Sarah · EOW + one midweek · £576/mo CMS",
      impactS: "Primary carer", impactM: "EOW + Wed eves",
      note: "CMS calculator figure at Mark's income" },
    { value: "shared_5050", label: "Shared care 50/50 · no maintenance",
      impactS: "Week on / week off", impactM: "Week on / week off",
      note: "Both households need full setup for children" },
    { value: "primary_every_weekend", label: "Primary with Sarah · every weekend with Mark",
      impactS: "Weekdays", impactM: "Every weekend",
      note: "" }
  ],
  spousal: [
    { value: "clean_break", label: "Clean break — no ongoing maintenance",
      impactS: "£892/mo shortfall persists", impactM: "No ongoing liability",
      note: "Financial severance · Sarah lives within NHS salary alone" },
    { value: "400_2y", label: "£400/mo for 2 years",
      impactS: "+£9,600 total", impactM: "−£9,600 total",
      note: "Short bridge while Sarah considers hours" },
    { value: "400_3y", label: "£400/mo for 3 years",
      impactS: "+£14,400 total", impactM: "−£14,400 total",
      note: "Matches Emma starting secondary school" },
    { value: "600_5y", label: "£600/mo for 5 years",
      impactS: "+£36,000 total", impactM: "−£36,000 total",
      note: "Larger transfer · closes shortfall more fully" }
  ]
};

const SECTION_INFO = {
  home:     { subject: "Net equity £230,000", fact: "Halifax mortgage £220k on £450k valuation" },
  pensions: { subject: "Sarah £180,412 · Mark £12,000",  fact: "Gap: £168,412 · NHS DB is the largest asset after the home" },
  savings:  { subject: "Joint £8k · Sarah £7,240 · Mark £18,800", fact: "Joint First Direct + individual accounts" },
  vehicles: { subject: "Sarah £3,800 · Mark £6,000", fact: "Both owned outright" },
  debts:    { subject: "Sarah £3,480 · Mark £23,800", fact: "Mark's student loan (£18k) is pre-marriage" },
  children: { subject: "Emma (7) · Jake (4)", fact: "Both at Exeter Primary · current arrangement: Sarah primary" },
  spousal:  { subject: "Sarah shortfall £892/mo · Mark surplus £2,345/mo", fact: "NHS salary £36k · Mark's salary £78k" }
};

const DEFAULT_DRAFT = {
  home: "sell_split_50_50",
  pensions: "no_share",
  savings: "each_keeps_own",
  vehicles: "each_keeps_own",
  debts: "each_own",
  children: "primary_eow_mid",
  spousal: "400_3y"
};

function computeSplit(draft) {
  let sarah = 0, mark = 0;
  if (draft.home === "sell_split_50_50" || draft.home === "defer_sale") { sarah += 115000; mark += 115000; }
  else if (draft.home === "sarah_keeps_buys_out") { sarah += 230000 - 115000; mark += 115000; }
  else if (draft.home === "mark_keeps_buys_out") { sarah += 115000; mark += 230000 - 115000; }

  if (draft.pensions === "no_share") { sarah += 180412; mark += 12000; }
  else if (draft.pensions === "share_20") { sarah += 144330; mark += 12000 + 36082; }
  else if (draft.pensions === "share_40") { sarah += 108247; mark += 12000 + 72165; }
  else if (draft.pensions === "offset") { sarah += 180412; mark += 12000; }

  if (draft.savings === "each_keeps_own") { sarah += 7240 + 4000; mark += 18800 + 4000; }
  else if (draft.savings === "pool_split_equal") { sarah += 17020; mark += 17020; }

  if (draft.vehicles === "each_keeps_own") { sarah += 3800; mark += 6000; }
  else if (draft.vehicles === "balance_cash") { sarah += 4900; mark += 4900; }

  if (draft.debts === "each_own") { sarah -= 3480; mark -= 23800; }
  else if (draft.debts === "share_half_amex") { sarah -= 6380; mark -= 20900; }
  else if (draft.debts === "pool_split") { sarah -= 13640; mark -= 13640; }

  if (draft.spousal === "400_2y") { sarah += 9600; mark -= 9600; }
  else if (draft.spousal === "400_3y") { sarah += 14400; mark -= 14400; }
  else if (draft.spousal === "600_5y") { sarah += 36000; mark -= 36000; }

  sarah += 4500;
  const total = sarah + mark;
  const sarahPct = total > 0 ? Math.round((sarah / total) * 100) : 50;
  return { sarahNet: sarah, markNet: mark, sarahPct, markPct: 100 - sarahPct };
}

Object.assign(window, {
  P4_OPTIONS: OPTIONS,
  P4_SECTION_INFO: SECTION_INFO,
  P4_DEFAULT_DRAFT: DEFAULT_DRAFT,
  P4_computeSplit: computeSplit
});
})();
