/* Phase 4 — shared shell, tokens, primitives, floating router
   Used across all 5 views (build, review, redline, progress, agreed) */
(function(){
const { useState, useEffect, useRef } = React;

/* ============================================================
   TOKENS
   ============================================================ */
const TOK = {
  INK: "#1A1A1A",
  SUB: "#5F6368",
  MUTE: "#9AA0A6",
  HAIR: "#EAECEF",
  BG: "#F5F5F4",
  CARD: "#FFFFFF",
  SARAH: "#2F6D5F",
  MARK: "#7E5A4E",
  /* Section status accents */
  AGREED: "#0E7A5F",
  PENDING: "#B45309",
  CONTESTED: "#B91C1C",
  /* Subtle tints */
  SARAH_TINT: "#EEF5F2",
  MARK_TINT: "#F5EFEB",
  AGREED_TINT: "#E8F4EF",
  PENDING_TINT: "#FEF3C7",
  CONTESTED_TINT: "#FEE2E2"
};

/* ============================================================
   ICONS (minimal SVG set — no dependencies)
   ============================================================ */
const Ic = ({ children, size = 16, stroke = "currentColor", strokeWidth = 1.75, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={stroke}
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {children}
  </svg>
);
const IChev  = (p) => <Ic {...p}><polyline points="9 6 15 12 9 18"/></Ic>;
const IChevL = (p) => <Ic {...p}><polyline points="15 6 9 12 15 18"/></Ic>;
const IChevD = (p) => <Ic {...p}><polyline points="6 9 12 15 18 9"/></Ic>;
const IChevU = (p) => <Ic {...p}><polyline points="6 15 12 9 18 15"/></Ic>;
const ICheck = (p) => <Ic {...p}><polyline points="5 12 10 17 19 7"/></Ic>;
const IX     = (p) => <Ic {...p}><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></Ic>;
const IPlus  = (p) => <Ic {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const IMinus = (p) => <Ic {...p}><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const IArrowR= (p) => <Ic {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></Ic>;
const IMsg   = (p) => <Ic {...p}><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></Ic>;
const IShare = (p) => <Ic {...p}><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></Ic>;
const ILock  = (p) => <Ic {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></Ic>;
const IEdit  = (p) => <Ic {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></Ic>;
const IHist  = (p) => <Ic {...p}><polyline points="3 8 3 3 8 3"/><path d="M3.5 12a8.5 8.5 0 1 0 2.3-5.8L3 9"/><polyline points="12 7 12 12 15.5 14"/></Ic>;
const IDoc   = (p) => <Ic {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></Ic>;
const IHelp  = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/></Ic>;
const ISpark = (p) => <Ic {...p}><path d="M12 3l1.8 4.8L18 9l-4.2 1.2L12 15l-1.8-4.8L6 9l4.2-1.2z"/><path d="M19 14l.7 1.8L21 16.5l-1.3.7L19 19l-.7-1.8L17 16.5l1.3-.7z"/></Ic>;
const IEye   = (p) => <Ic {...p}><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></Ic>;
const ISend  = (p) => <Ic {...p}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></Ic>;
const IGavel = (p) => <Ic {...p}><path d="M14 12L9 17"/><path d="M9 7l8 8"/><path d="M6 10l4-4"/><path d="M14 6l4 4"/><path d="M4 20h8"/></Ic>;
const ICheckCircle = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><polyline points="8 12 11 15 16 9"/></Ic>;
const ICircle = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/></Ic>;
const IDot = (p) => <Ic {...p}><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none"/></Ic>;
const IGrid = (p) => <Ic {...p}><rect x="4" y="4" width="7" height="7" rx="1"/><rect x="13" y="4" width="7" height="7" rx="1"/><rect x="4" y="13" width="7" height="7" rx="1"/><rect x="13" y="13" width="7" height="7" rx="1"/></Ic>;
const IList = (p) => <Ic {...p}><line x1="8" y1="6" x2="20" y2="6"/><line x1="8" y1="12" x2="20" y2="12"/><line x1="8" y1="18" x2="20" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="12" r="1" fill="currentColor" stroke="none"/><circle cx="4" cy="18" r="1" fill="currentColor" stroke="none"/></Ic>;

/* ============================================================
   WORDMARK (reused)
   ============================================================ */
function Wordmark({ small }) {
  return (
    <div className="flex items-center gap-2 select-none">
      <div className="relative" style={{ width: small ? 18 : 22, height: small ? 18 : 22 }} aria-hidden>
        <div className="absolute inset-0 rounded-full" style={{ background: TOK.INK }}/>
        <div className="absolute rounded-full" style={{ left: "42%", top: 0, width: "58%", height: "100%", background: "#F7F7F5" }}/>
        <div className="absolute rounded-full" style={{ left: "45%", top: "12%", width: "10%", height: "76%", background: TOK.INK }}/>
      </div>
      <span style={{ fontSize: small ? 14 : 16, letterSpacing: "-0.01em", fontWeight: 600, color: TOK.INK }}>decouple</span>
    </div>
  );
}

/* ============================================================
   AVATARS + CHIPS
   ============================================================ */
function Avatar({ who, size = 24, ring }) {
  const bg = who === "S" ? TOK.SARAH : who === "M" ? TOK.MARK : "#BDBDBD";
  return (
    <div className="flex items-center justify-center rounded-full text-white font-semibold flex-shrink-0"
         style={{
           width: size, height: size,
           background: bg,
           fontSize: Math.round(size * 0.42),
           boxShadow: ring ? `0 0 0 2px #FFF, 0 0 0 3px ${bg}` : "none"
         }}>
      {who}
    </div>
  );
}

function StatusChip({ kind, children }) {
  const map = {
    agreed:    { bg: TOK.AGREED_TINT,    fg: TOK.AGREED },
    pending:   { bg: TOK.PENDING_TINT,   fg: TOK.PENDING },
    contested: { bg: TOK.CONTESTED_TINT, fg: TOK.CONTESTED },
    neutral:   { bg: "#F3F4F6",          fg: TOK.SUB },
    sarah:     { bg: TOK.SARAH_TINT,     fg: TOK.SARAH },
    mark:      { bg: TOK.MARK_TINT,      fg: TOK.MARK }
  };
  const c = map[kind] || map.neutral;
  return (
    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded whitespace-nowrap"
          style={{ background: c.bg, color: c.fg, fontSize: 10.5, letterSpacing: "0.06em", textTransform: "uppercase", fontWeight: 700 }}>
      {children}
    </span>
  );
}

/* ============================================================
   TOP BAR — phase chip, document title, version chip, S/M presence
   viewMeta: { phase, title, version, statusLabel, statusKind }
   ============================================================ */
function TopBar({ viewMeta, right }) {
  return (
    <div className="flex items-center justify-between px-5 flex-shrink-0"
         style={{ height: 56, borderBottom: `1px solid ${TOK.HAIR}`, background: TOK.CARD }}>
      <div className="flex items-center gap-3 min-w-0">
        <Wordmark small/>
        <span style={{ color: "#E5E7EB" }}>/</span>
        <div className="flex items-center gap-1.5 text-[12.5px] min-w-0" style={{ color: TOK.SUB }}>
          <span>{viewMeta.phase || "Phase 4"}</span>
          <IChev size={11} style={{ color: "#D4D4D4" }}/>
          <span className="whitespace-nowrap" style={{ color: TOK.INK, fontWeight: 600 }}>{viewMeta.title}</span>
          {viewMeta.version && (
            <StatusChip kind={viewMeta.statusKind || "pending"}>
              {viewMeta.version} · {viewMeta.statusLabel}
            </StatusChip>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        {right}
        <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
        <div className="flex items-center -space-x-1.5">
          <Avatar who="S" size={26} ring/>
          <Avatar who="M" size={26} ring/>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   LEFT CHAPTER RAIL — 7 Phase 4 sections + status per section
   sectionStatus: { home: "agreed"|"contested"|"pending", ... }
   ============================================================ */
function ChapterRail({ active, setActive, sectionStatus, title = "Settlement proposal", subtitle, pct, currentRoute, showInlineRouter }) {
  const { P4_SECTIONS } = window;
  return (
    <div style={{ width: 232, background: "#FAFAFA", borderRight: `1px solid ${TOK.HAIR}` }}
         className="flex flex-col flex-shrink-0">
      <div className="px-4 py-3.5" style={{ borderBottom: `1px solid ${TOK.HAIR}` }}>
        <div className="label-xs mb-2" style={{ color: TOK.MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: TOK.INK, lineHeight: 1.25 }}>{title}</div>
        {typeof pct === "number" && (
          <div className="mt-2 flex items-center gap-2">
            <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
              <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: TOK.AGREED }}/>
            </div>
            <span className="tabular-nums" style={{ fontSize: 11, color: TOK.AGREED, fontWeight: 600 }}>{pct}%</span>
          </div>
        )}
        {subtitle && (
          <div style={{ fontSize: 10.5, color: TOK.MUTE, marginTop: 4, letterSpacing: "0.02em" }}>{subtitle}</div>
        )}
      </div>
      <div className="px-2 py-2 flex-1 overflow-y-auto nice-scroll">
        {P4_SECTIONS.map(s => {
          const st = sectionStatus?.[s.key] || "pending";
          const isActive = active === s.key;
          const dot = st === "agreed" ? TOK.AGREED : st === "contested" ? TOK.CONTESTED : TOK.PENDING;
          return (
            <button key={s.key} onClick={() => setActive && setActive(s.key)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{
                background: isActive ? "#EEF1F0" : "transparent",
                color: TOK.INK, fontSize: 12.5,
                fontWeight: isActive ? 600 : 500
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "#F1F1F0"; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = isActive ? "#EEF1F0" : "transparent"; }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: TOK.MUTE, width: 14 }}>{s.n}</span>
              <span className="flex-1 truncate">{s.title}</span>
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: dot }}/>
            </button>
          );
        })}
      </div>
      {showInlineRouter && currentRoute && (
        <InlineRouter current={currentRoute}/>
      )}
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
           style={{ color: TOK.SUB, borderTop: `1px solid ${TOK.HAIR}` }}>
        <IHelp size={12}/> Get support
      </div>
    </div>
  );
}

/* Inline router — journey lives inside the left column, under sections */
function InlineRouter({ current }) {
  const [open, setOpen] = useState(false);
  const cur = ROUTES.find(r => r.key === current) || ROUTES[0];
  const idx = ROUTES.findIndex(r => r.key === current);
  return (
    <div style={{ borderTop: `1px solid ${TOK.HAIR}`, background: "#FFF" }}>
      {open && (
        <div className="px-2 py-2"
             style={{ borderBottom: `1px solid ${TOK.HAIR}`, animation: "riseIn 160ms cubic-bezier(.2,.9,.2,1)" }}>
          <div className="px-1.5 pb-1.5 label-xs" style={{ color: TOK.MUTE }}>The settlement journey</div>
          {ROUTES.map((r, i) => {
            const active = r.key === current;
            const done = i < idx;
            return (
              <a key={r.key} href={r.href}
                 className="flex items-center gap-2 px-1.5 py-1.5 rounded-md transition"
                 style={{ background: active ? "#F3F4F6" : "transparent", textDecoration: "none", color: TOK.INK }}
                 onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#F7F7F6"; }}
                 onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
                <span className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{
                        background: done ? TOK.AGREED : active ? TOK.INK : "#E5E7EB",
                        color: done || active ? "#FFF" : TOK.SUB,
                        fontSize: 10, fontWeight: 700
                      }}>
                  {done ? <ICheck size={10} strokeWidth={2.5}/> : (i + 1)}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="whitespace-nowrap truncate" style={{ fontSize: 12, fontWeight: active ? 600 : 500 }}>{r.label}</div>
                </div>
                <span className="label-xs tabular-nums flex-shrink-0" style={{ color: TOK.MUTE }}>{r.phase}</span>
              </a>
            );
          })}
        </div>
      )}
      <button onClick={() => setOpen(o => !o)}
              className="w-full flex items-center gap-2 px-3 py-2.5 transition"
              style={{ background: open ? "#FAFAF7" : "#FFF" }}
              onMouseEnter={e => { if (!open) e.currentTarget.style.background = "#FAFAF7"; }}
              onMouseLeave={e => { if (!open) e.currentTarget.style.background = "#FFF"; }}>
        <span className="flex items-center -space-x-1 flex-shrink-0">
          {ROUTES.map((r, i) => {
            const active = r.key === current;
            const done = i < idx;
            return (
              <span key={r.key} className="w-1.5 h-1.5 rounded-full ring-2 ring-white"
                    style={{ background: active ? TOK.INK : done ? TOK.AGREED : "#D1D5DB" }}/>
            );
          })}
        </span>
        <span className="flex-1 text-left whitespace-nowrap truncate" style={{ fontSize: 12, fontWeight: 600 }}>{cur.label}</span>
        <span className="label-xs tabular-nums flex-shrink-0" style={{ color: TOK.MUTE }}>{idx + 1}/{ROUTES.length}</span>
        <IChevU size={11} stroke={TOK.SUB} style={{ transform: open ? "none" : "rotate(180deg)", transition: "transform 160ms" }}/>
      </button>
    </div>
  );
}

/* ============================================================
   FLOATING PILL ROUTER
   Links each view file to every other view in the journey.
   ============================================================ */
const ROUTES = [
  { key: "build",    label: "Build proposal",  sub: "Sarah drafts her offer",    href: "Settlement - Build.html",     phase: "v1" },
  { key: "review",   label: "Review & send",   sub: "Sarah reviews before sending", href: "Settlement - Review.html",  phase: "v1" },
  { key: "redline",  label: "Mark's redline",  sub: "Counter-proposal arrives",  href: "Settlement - Redline.html",    phase: "v2" },
  { key: "progress", label: "Progress board",  sub: "Where we've converged",     href: "Settlement - Progress.html",   phase: "v3" },
  { key: "agreed",   label: "Agreement",       sub: "Final settlement reached",  href: "Settlement - Agreement.html",  phase: "v5" },
  { key: "fin-generate",  label: "Generate docs",  sub: "Turn agreement into legal papers", href: "Settlement - Generate.html",   phase: "v5" },
  { key: "fin-preview",   label: "Preview docs",   sub: "Read the consent order",           href: "Settlement - Preview.html",    phase: "v5" },
  { key: "fin-preflight", label: "Pre-flight",     sub: "Quality-check before submission",  href: "Settlement - Pre-flight.html", phase: "v5" },
  { key: "fin-decision",  label: "Your path",      sub: "Submit direct or get review",      href: "Settlement - Decision.html",   phase: "v5" },
  { key: "fin-submit",    label: "Submit & track", sub: "Waiting for the court seal",       href: "Settlement - Submit.html",     phase: "v6" }
];

function FloatingRouter({ current }) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);
  useEffect(() => {
    const h = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    window.addEventListener("mousedown", h);
    return () => window.removeEventListener("mousedown", h);
  }, []);
  const cur = ROUTES.find(r => r.key === current) || ROUTES[0];
  const idx = ROUTES.findIndex(r => r.key === current);

  return (
    <div ref={wrapRef}
         className="absolute left-1/2 pointer-events-none"
         style={{ bottom: 20, transform: "translateX(-50%)", zIndex: 40 }}>
      <div className="pointer-events-auto flex flex-col items-center">
        {open && (
          <div className="mb-2 bg-white rounded-2xl p-1.5"
               style={{
                 border: `1px solid ${TOK.HAIR}`,
                 boxShadow: "0 14px 40px rgba(0,0,0,0.14), 0 2px 6px rgba(0,0,0,0.05)",
                 minWidth: 420,
                 animation: "riseIn 180ms cubic-bezier(.2,.9,.2,1)"
               }}>
            <div className="px-3 py-1.5 label-xs" style={{ color: TOK.MUTE }}>The settlement journey</div>
            <div className="px-1 pb-1">
              {ROUTES.map((r, i) => {
                const active = r.key === current;
                const done = i < idx;
                return (
                  <a key={r.key} href={r.href}
                     className="flex items-center gap-3 px-2 py-2 rounded-lg transition"
                     style={{
                       background: active ? "#F3F4F6" : "transparent",
                       textDecoration: "none",
                       color: TOK.INK
                     }}
                     onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#F7F7F6"; }}
                     onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
                    <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
                          style={{
                            background: done ? TOK.AGREED : active ? TOK.INK : "#E5E7EB",
                            color: done || active ? "#FFF" : TOK.SUB,
                            fontSize: 10.5, fontWeight: 700
                          }}>
                      {done ? <ICheck size={11} strokeWidth={2.5}/> : (i + 1)}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="whitespace-nowrap" style={{ fontSize: 12.5, fontWeight: active ? 600 : 500 }}>{r.label}</div>
                      <div className="whitespace-nowrap" style={{ fontSize: 11, color: TOK.SUB, marginTop: 1 }}>{r.sub}</div>
                    </div>
                    <span className="label-xs tabular-nums" style={{ color: TOK.MUTE }}>{r.phase}</span>
                  </a>
                );
              })}
            </div>
          </div>
        )}
        <button onClick={() => setOpen(o => !o)}
          className="flex items-center gap-2 h-10 px-3.5 rounded-full bg-white transition"
          style={{
            border: `1px solid ${TOK.HAIR}`,
            boxShadow: "0 10px 30px rgba(0,0,0,0.08), 0 1px 3px rgba(0,0,0,0.04)"
          }}>
          <span className="flex items-center -space-x-1">
            {ROUTES.map((r, i) => {
              const active = r.key === current;
              const done = i < idx;
              return (
                <span key={r.key} className="w-2 h-2 rounded-full ring-2 ring-white"
                      style={{ background: active ? TOK.INK : done ? TOK.AGREED : "#D1D5DB" }}/>
              );
            })}
          </span>
          <span className="whitespace-nowrap" style={{ fontSize: 12.5, fontWeight: 600 }}>{cur.label}</span>
          <span className="label-xs tabular-nums" style={{ color: TOK.MUTE }}>
            {idx + 1}/{ROUTES.length}
          </span>
          <IChevU size={12} stroke={TOK.SUB}
                  style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 180ms" }}/>
        </button>
      </div>
    </div>
  );
}

/* ============================================================
   TWEAK PANEL
   spec: { title, options: [{ id, label, variants: [{ value, label, sub? }] }] }
   values: current selection object
   onChange: (id, value) => void
   ============================================================ */
function TweakPanel({ title, options, values, onChange }) {
  const [on, setOn] = useState(false);
  const [open, setOpen] = useState(true);
  useEffect(() => {
    const h = (m) => {
      if (!m.data || typeof m.data !== "object") return;
      if (m.data.type === "__activate_edit_mode") setOn(true);
      if (m.data.type === "__deactivate_edit_mode") setOn(false);
    };
    window.addEventListener("message", h);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", h);
  }, []);
  if (!on) return null;
  return (
    <div className="fixed bg-white rounded-xl overflow-hidden"
         style={{
           bottom: 80, right: 20, width: 280, zIndex: 60,
           border: `1px solid ${TOK.HAIR}`,
           boxShadow: "0 18px 40px rgba(0,0,0,0.14)"
         }}>
      <button onClick={() => setOpen(o => !o)}
              className="w-full flex items-center justify-between px-3 py-2.5"
              style={{ background: "#FAFAFA", borderBottom: open ? `1px solid ${TOK.HAIR}` : "none" }}>
        <div className="flex items-center gap-2">
          <ISpark size={13}/>
          <span style={{ fontSize: 12.5, fontWeight: 700, letterSpacing: "-0.01em" }}>Tweaks · {title}</span>
        </div>
        <IChevD size={12} stroke={TOK.SUB} style={{ transform: open ? "none" : "rotate(-90deg)", transition: "transform 180ms" }}/>
      </button>
      {open && (
        <div className="px-3 py-3 space-y-3 max-h-[60vh] overflow-y-auto nice-scroll">
          {options.map(o => (
            <div key={o.id}>
              <div className="label-xs mb-1.5" style={{ color: TOK.MUTE }}>{o.label}</div>
              <div className="flex flex-col gap-1">
                {o.variants.map(v => {
                  const active = values[o.id] === v.value;
                  return (
                    <button key={v.value} onClick={() => onChange(o.id, v.value)}
                      className="text-left px-2.5 py-1.5 rounded-md transition"
                      style={{
                        background: active ? TOK.INK : "#F7F7F6",
                        color: active ? "#FFF" : TOK.INK,
                        border: active ? `1px solid ${TOK.INK}` : `1px solid ${TOK.HAIR}`
                      }}>
                      <div style={{ fontSize: 12, fontWeight: 600 }}>{v.label}</div>
                      {v.sub && <div style={{ fontSize: 10.5, opacity: 0.7, marginTop: 1 }}>{v.sub}</div>}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   Money formatter (shared)
   ============================================================ */
function money(n, { sign = false, approx = false } = {}) {
  if (n === 0) return "£0";
  const s = Math.abs(n).toLocaleString("en-GB");
  const prefix = n < 0 ? "−£" : (sign ? "+£" : "£");
  return (approx ? "≈ " : "") + prefix + s;
}

/* ============================================================
   EXPORT
   ============================================================ */
Object.assign(window, {
  P4_TOK: TOK,
  P4_IcBase: Ic,
  P4_Ic: {
    Chev: IChev, ChevL: IChevL, ChevD: IChevD, ChevU: IChevU,
    Check: ICheck, X: IX, Plus: IPlus, Minus: IMinus, ArrowR: IArrowR,
    Msg: IMsg, Share: IShare, Lock: ILock, Edit: IEdit, Hist: IHist,
    Doc: IDoc, Help: IHelp, Spark: ISpark, Eye: IEye, Send: ISend,
    Gavel: IGavel, CheckCircle: ICheckCircle, Circle: ICircle, Dot: IDot,
    Grid: IGrid, List: IList
  },
  P4_Wordmark: Wordmark,
  P4_Avatar: Avatar,
  P4_StatusChip: StatusChip,
  P4_TopBar: TopBar,
  P4_ChapterRail: ChapterRail,
  P4_FloatingRouter: FloatingRouter,
  P4_TweakPanel: TweakPanel,
  P4_money: money,
  P4_ROUTES: ROUTES
});
})();
