/* Phase 4 View A — Build Proposal
   Sarah is drafting her first settlement proposal (v1).
   Tweak: 3 step patterns — focused, scroll, guided */
(function(){
const { useState, useEffect, useMemo } = React;
const { P4_TOK: T, P4_Ic: I, P4_Avatar, P4_StatusChip, P4_TopBar, P4_ChapterRail,
        P4_FloatingRouter, P4_TweakPanel, P4_money, P4_FACTS, P4_SECTIONS,
        P4_OPTIONS: OPTIONS, P4_SECTION_INFO: SECTION_INFO,
        P4_DEFAULT_DRAFT: DEFAULT_DRAFT, P4_computeSplit: computeSplit,
        P4_AIRail, P4_AI_BUILD } = window;

/* ============================================================
   DECISION OPTIONS per section — sourced from phase4/options.jsx
   ============================================================ */
/* (OPTIONS and SECTION_INFO moved to phase4/options.jsx) */

/* ============================================================
   DECISION CARD — the reusable per-section UI
   used by all three step patterns (focused / scroll / guided)
   ============================================================ */
function DecisionCard({ sec, chosen, setChosen, compact, hideHeader }) {
  const info = SECTION_INFO[sec.key];
  const opts = OPTIONS[sec.key] || [];
  return (
    <div className="rounded-xl bg-white" style={{ border: `1px solid ${T.HAIR}` }}>
      {!hideHeader && (
        <div className="px-5 pt-5 pb-3">
          <div className="flex items-center gap-2 mb-1">
            <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>§{sec.n}</span>
            <P4_StatusChip kind={chosen ? "sarah" : "neutral"}>{chosen ? "Draft" : "Not set"}</P4_StatusChip>
          </div>
          <h3 style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.015em", lineHeight: 1.2 }}>{sec.title}</h3>
          <div style={{ fontSize: 12.5, color: T.SUB, marginTop: 4 }}>{info.subject}</div>
          <div className="mt-2.5 flex items-start gap-2 px-3 py-2 rounded-md" style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}` }}>
            <I.Spark size={13} style={{ color: T.SUB, marginTop: 2, flexShrink: 0 }}/>
            <div style={{ fontSize: 12, color: T.SUB, lineHeight: 1.4 }}>{info.fact}</div>
          </div>
        </div>
      )}
      <div className={`px-5 pb-5 ${!hideHeader ? "pt-1" : "pt-4"} space-y-2`}>
        {opts.map(o => {
          const active = chosen === o.value;
          return (
            <button key={o.value} onClick={() => setChosen(o.value)}
              className="w-full text-left p-3 rounded-lg transition"
              style={{
                background: active ? T.SARAH_TINT : "#FFFFFF",
                border: `1.5px solid ${active ? T.SARAH : T.HAIR}`,
                outline: "none"
              }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#FAFAF7"; }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = "#FFFFFF"; }}>
              <div className="flex items-start gap-3">
                <span className="w-4 h-4 rounded-full flex-shrink-0 mt-0.5"
                      style={{
                        border: `1.5px solid ${active ? T.SARAH : "#D1D5DB"}`,
                        background: active ? T.SARAH : "transparent"
                      }}>
                  {active && <I.Check size={11} stroke="#FFF" strokeWidth={3} style={{ margin: 0.5 }}/>}
                </span>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 13.5, fontWeight: 600, color: T.INK }}>{o.label}</div>
                  <div className="mt-1.5 flex items-center gap-3 flex-wrap">
                    <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
                      <P4_Avatar who="S" size={14}/>
                      <span style={{ color: T.SUB }}>{o.impactS}</span>
                    </span>
                    <span className="flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
                      <P4_Avatar who="M" size={14}/>
                      <span style={{ color: T.SUB }}>{o.impactM}</span>
                    </span>
                  </div>
                  {o.note && !compact && (
                    <div style={{ fontSize: 11.5, color: T.MUTE, marginTop: 6, lineHeight: 1.45 }}>{o.note}</div>
                  )}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* Starting point for this view: Sarah has drafted most but not spousal yet */
const BUILD_START_DRAFT = { ...DEFAULT_DRAFT, spousal: null };

/* ============================================================
   STEP PATTERN A — FOCUSED
   One section fills the canvas. Prev/next controls.
   ============================================================ */
function FocusedPattern({ draft, setDraft }) {
  const [idx, setIdx] = useState(() => {
    const unset = P4_SECTIONS.findIndex(s => !draft[s.key]);
    return unset >= 0 ? unset : 0;
  });
  const sec = P4_SECTIONS[idx];
  const total = P4_SECTIONS.length;
  const completed = P4_SECTIONS.filter(s => draft[s.key]).length;

  return (
    <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
      <div className="max-w-[640px] mx-auto px-6 py-10 pb-32">
        {/* progress header */}
        <div className="flex items-center gap-2 mb-6">
          <span className="label-xs tabular-nums" style={{ color: T.MUTE }}>Section {idx + 1} of {total}</span>
          <span className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <span className="block h-full" style={{ width: `${(completed / total) * 100}%`, background: T.SARAH, transition: "width 300ms" }}/>
          </span>
          <span className="label-xs tabular-nums" style={{ color: T.SUB }}>{completed}/{total} drafted</span>
        </div>

        <DecisionCard sec={sec}
                      chosen={draft[sec.key]}
                      setChosen={(v) => setDraft(d => ({ ...d, [sec.key]: v }))}/>

        {/* nav */}
        <div className="mt-6 flex items-center justify-between">
          <button onClick={() => setIdx(i => Math.max(0, i - 1))}
                  disabled={idx === 0}
                  className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md"
                  style={{
                    background: "#FFFFFF",
                    color: idx === 0 ? T.MUTE : T.INK,
                    border: `1px solid ${T.HAIR}`,
                    fontSize: 13, fontWeight: 600,
                    cursor: idx === 0 ? "not-allowed" : "pointer"
                  }}>
            <I.ChevL size={14}/> Back
          </button>
          <div className="flex items-center gap-1">
            {P4_SECTIONS.map((s, i) => (
              <button key={s.key} onClick={() => setIdx(i)}
                className="rounded-full transition"
                style={{
                  width: i === idx ? 22 : 8, height: 8,
                  background: i === idx ? T.INK : draft[s.key] ? T.SARAH : "#D1D5DB"
                }}/>
            ))}
          </div>
          {idx < total - 1 ? (
            <button onClick={() => setIdx(i => Math.min(total - 1, i + 1))}
                    className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md text-white"
                    style={{ background: T.INK, fontSize: 13, fontWeight: 600 }}>
              Continue <I.Chev size={14} stroke="#FFF"/>
            </button>
          ) : (
            <a href="Settlement - Review.html"
               className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md text-white"
               style={{ background: T.SARAH, fontSize: 13, fontWeight: 600, textDecoration: "none" }}>
              Review draft <I.ArrowR size={14} stroke="#FFF"/>
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   STEP PATTERN B — SCROLL
   Long document-like page with every section inline.
   Sticky sidebar summary on the right.
   ============================================================ */
function ScrollPattern({ draft, setDraft }) {
  const completed = P4_SECTIONS.filter(s => draft[s.key]).length;
  const total = P4_SECTIONS.length;

  /* compute running £ split */
  const split = useMemo(() => computeSplit(draft), [draft]);

  return (
    <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
      <div className="max-w-[720px] mx-auto px-8 py-10 pb-32">

        <div>
          {/* doc header */}
          <div>
            <div className="label-xs mb-1.5" style={{ color: T.MUTE }}>Phase 4 · Settlement proposal · v1</div>
            <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
              My opening position
            </h1>
            <p className="mt-2" style={{ fontSize: 14.5, color: T.SUB, lineHeight: 1.55 }}>
              You're drafting a settlement proposal for Mark. Seven sections. Nothing is sent until you review and confirm.
            </p>
          </div>

          {/* Running split strip — replaces the old sticky side card */}
          <div className="mt-6 rounded-xl p-4" style={{ background: T.CARD, border: `1px solid ${T.HAIR}` }}>
            <div className="flex items-center justify-between mb-2">
              <div className="label-xs" style={{ color: T.MUTE }}>Running split · draft</div>
              <div style={{ fontSize: 11, color: T.MUTE }}>
                {completed}/{total} drafted · Total net £{((split.sarahNet + split.markNet) / 1000).toFixed(0)}k
              </div>
            </div>
            <div className="flex items-end justify-between gap-4">
              <div className="flex items-center gap-2">
                <P4_Avatar who="S" size={14}/>
                <div className="tabular-nums" style={{ fontSize: 20, fontWeight: 700, color: T.SARAH, lineHeight: 1 }}>
                  {split.sarahPct}%
                </div>
                <div className="tabular-nums" style={{ fontSize: 11.5, color: T.SUB }}>{P4_money(split.sarahNet)}</div>
              </div>
              <div className="flex items-center gap-2">
                <div className="tabular-nums" style={{ fontSize: 11.5, color: T.SUB }}>{P4_money(split.markNet)}</div>
                <div className="tabular-nums" style={{ fontSize: 20, fontWeight: 700, color: T.MARK, lineHeight: 1 }}>
                  {split.markPct}%
                </div>
                <P4_Avatar who="M" size={14}/>
              </div>
            </div>
            <div className="mt-3 h-2 rounded-full overflow-hidden flex" style={{ background: "#F3F4F6" }}>
              <div style={{ width: `${split.sarahPct}%`, background: T.SARAH, transition: "width 300ms" }}/>
              <div style={{ width: `${split.markPct}%`, background: T.MARK, transition: "width 300ms" }}/>
            </div>
          </div>

          <div className="mt-8 space-y-6">
            {P4_SECTIONS.map(sec => (
              <DecisionCard key={sec.key}
                            sec={sec}
                            chosen={draft[sec.key]}
                            setChosen={(v) => setDraft(d => ({ ...d, [sec.key]: v }))}/>
            ))}
          </div>

          <div className="mt-10 p-5 rounded-xl flex items-center gap-4"
               style={{ background: T.CARD, border: `1px solid ${T.HAIR}` }}>
            <div className="flex-1">
              <div style={{ fontSize: 13, fontWeight: 600 }}>
                {completed === total ? "All seven sections drafted" : `${completed} of ${total} sections drafted`}
              </div>
              <div style={{ fontSize: 12, color: T.SUB, marginTop: 2 }}>
                {completed === total
                  ? "Review your draft before sending to Mark."
                  : "Finish the remaining sections before reviewing."}
              </div>
            </div>
            <a href="Settlement - Review.html"
               className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md"
               style={{
                 background: completed === total ? T.SARAH : "#BDBDBD",
                 color: "#FFF", fontSize: 13, fontWeight: 600, textDecoration: "none",
                 pointerEvents: completed === total ? "auto" : "none"
               }}>
              Review draft <I.ArrowR size={14} stroke="#FFF"/>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

/* compute rough split based on draft selections */
function computeSplit_LOCAL_UNUSED(draft) {
  const F = P4_FACTS;
  let sarah = 0, mark = 0;
  /* home */
  if (draft.home === "sell_split_50_50" || draft.home === "defer_sale") { sarah += 115000; mark += 115000; }
  else if (draft.home === "sarah_keeps_buys_out") { sarah += 230000 - 115000; mark += 115000; }
  else if (draft.home === "mark_keeps_buys_out") { sarah += 115000; mark += 230000 - 115000; }
  /* pensions */
  if (draft.pensions === "no_share") { sarah += 180412; mark += 12000; }
  else if (draft.pensions === "share_20") { sarah += 144330; mark += 12000 + 36082; }
  else if (draft.pensions === "share_40") { sarah += 108247; mark += 12000 + 72165; }
  else if (draft.pensions === "offset") { sarah += 180412; mark += 12000; } /* simplification */
  /* savings */
  if (draft.savings === "each_keeps_own") { sarah += 7240 + 4000; mark += 18800 + 4000; }
  else if (draft.savings === "pool_split_equal") { sarah += 17020; mark += 17020; }
  /* vehicles */
  if (draft.vehicles === "each_keeps_own") { sarah += 3800; mark += 6000; }
  else if (draft.vehicles === "balance_cash") { sarah += 4900; mark += 4900; }
  /* debts */
  if (draft.debts === "each_own") { sarah -= 3480; mark -= 23800; }
  else if (draft.debts === "share_half_amex") { sarah -= 6380; mark -= 20900; }
  else if (draft.debts === "pool_split") { sarah -= 13640; mark -= 13640; }
  /* spousal */
  if (draft.spousal === "400_2y") { sarah += 9600; mark -= 9600; }
  else if (draft.spousal === "400_3y") { sarah += 14400; mark -= 14400; }
  else if (draft.spousal === "600_5y") { sarah += 36000; mark -= 36000; }
  /* life insurance — stays with Sarah */
  sarah += 4500;
  const total = sarah + mark;
  const sarahPct = total > 0 ? Math.round((sarah / total) * 100) : 50;
  return { sarahNet: sarah, markNet: mark, sarahPct, markPct: 100 - sarahPct };
}

/* ============================================================
   STEP PATTERN C — GUIDED
   Left steps column + decision in middle + reasoning on right.
   Feels like a wizard with breathing room.
   ============================================================ */
function GuidedPattern({ draft, setDraft }) {
  const [idx, setIdx] = useState(() => {
    const unset = P4_SECTIONS.findIndex(s => !draft[s.key]);
    return unset >= 0 ? unset : 0;
  });
  const sec = P4_SECTIONS[idx];
  const total = P4_SECTIONS.length;
  const completed = P4_SECTIONS.filter(s => draft[s.key]).length;

  return (
    <div className="flex-1 flex min-h-0" style={{ background: T.BG }}>

      {/* steps column */}
      <div className="flex-shrink-0 overflow-y-auto nice-scroll py-8 px-5"
           style={{ width: 260, borderRight: `1px solid ${T.HAIR}` }}>
        <div className="label-xs mb-3" style={{ color: T.MUTE }}>Your draft proposal</div>
        <div className="space-y-1">
          {P4_SECTIONS.map((s, i) => {
            const active = i === idx;
            const done = !!draft[s.key];
            return (
              <button key={s.key} onClick={() => setIdx(i)}
                      className="w-full flex items-start gap-3 text-left px-2.5 py-2 rounded-lg transition"
                      style={{ background: active ? "#FFFFFF" : "transparent", border: active ? `1px solid ${T.HAIR}` : "1px solid transparent" }}
                      onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#FAFAF7"; }}
                      onMouseLeave={e => { if (!active) e.currentTarget.style.background = active ? "#FFFFFF" : "transparent"; }}>
                <span className="flex-shrink-0 mt-0.5"
                      style={{
                        width: 18, height: 18, borderRadius: 999,
                        background: done ? T.SARAH : active ? T.CARD : "transparent",
                        border: done ? `1.5px solid ${T.SARAH}` : active ? `1.5px solid ${T.INK}` : `1.5px solid #D1D5DB`,
                        color: "#FFF",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 9.5, fontWeight: 700
                      }}>
                  {done ? <I.Check size={10} stroke="#FFF" strokeWidth={3}/> : (i + 1)}
                </span>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 12.5, fontWeight: active ? 600 : 500, color: T.INK }}>{s.title}</div>
                  {done && (
                    <div className="truncate" style={{ fontSize: 11, color: T.SARAH, marginTop: 2, fontWeight: 500 }}>
                      {OPTIONS[s.key].find(o => o.value === draft[s.key])?.label}
                    </div>
                  )}
                  {!done && active && (
                    <div style={{ fontSize: 11, color: T.SUB, marginTop: 2 }}>In progress…</div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
        <div className="mt-6 px-2 pt-4" style={{ borderTop: `1px solid ${T.HAIR}` }}>
          <div className="label-xs mb-1" style={{ color: T.MUTE }}>Progress</div>
          <div className="flex items-center gap-2">
            <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
              <div className="h-full" style={{ width: `${(completed / total) * 100}%`, background: T.SARAH, transition: "width 300ms" }}/>
            </div>
            <span className="tabular-nums" style={{ fontSize: 11, color: T.SARAH, fontWeight: 600 }}>
              {completed}/{total}
            </span>
          </div>
        </div>
      </div>

      {/* main column */}
      <div className="flex-1 overflow-y-auto nice-scroll">
        <div className="max-w-[640px] mx-auto px-8 py-10 pb-32">
          <div className="label-xs mb-1.5" style={{ color: T.MUTE }}>Section {idx + 1} · {sec.title}</div>
          <DecisionCard sec={sec}
                        chosen={draft[sec.key]}
                        setChosen={(v) => setDraft(d => ({ ...d, [sec.key]: v }))}
                        hideHeader/>

          <div className="mt-6 flex items-center justify-between">
            <button onClick={() => setIdx(i => Math.max(0, i - 1))}
                    disabled={idx === 0}
                    className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md"
                    style={{
                      background: "transparent",
                      color: idx === 0 ? T.MUTE : T.SUB,
                      fontSize: 12.5, fontWeight: 500,
                      cursor: idx === 0 ? "not-allowed" : "pointer"
                    }}>
              <I.ChevL size={13}/> Previous section
            </button>
            {idx < total - 1 ? (
              <button onClick={() => setIdx(i => Math.min(total - 1, i + 1))}
                      className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md text-white"
                      style={{ background: draft[sec.key] ? T.INK : "#BDBDBD", fontSize: 13, fontWeight: 600 }}>
                Next: {P4_SECTIONS[idx + 1].title} <I.Chev size={14} stroke="#FFF"/>
              </button>
            ) : (
              <a href="Settlement - Review.html"
                 className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md text-white"
                 style={{ background: T.SARAH, fontSize: 13, fontWeight: 600, textDecoration: "none" }}>
                Review draft <I.ArrowR size={14} stroke="#FFF"/>
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "pattern": "scroll",
  "router": "inline"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const [draft, setDraft] = useState(BUILD_START_DRAFT);
  const setTweak = (id, value) => {
    setTweaks(t => {
      const next = { ...t, [id]: value };
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
      return next;
    });
  };

  const sectionStatus = Object.fromEntries(
    P4_SECTIONS.map(s => [s.key, draft[s.key] ? "agreed" : "pending"])
  );
  const completed = P4_SECTIONS.filter(s => draft[s.key]).length;
  const pct = Math.round((completed / P4_SECTIONS.length) * 100);

  const topRight = (
    <>
      <span className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md" style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}`, fontSize: 11.5, color: T.SUB }}>
        <I.Edit size={12}/> Autosaved · 2 min ago
      </span>
      <a href="Settlement - Review.html"
         className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-white"
         style={{
           background: completed === P4_SECTIONS.length ? T.SARAH : "#BDBDBD",
           fontSize: 12.5, fontWeight: 600, textDecoration: "none",
           cursor: completed === P4_SECTIONS.length ? "pointer" : "not-allowed"
         }}>
        Review draft <I.ArrowR size={12} stroke="#FFF"/>
      </a>
    </>
  );

  const Pattern = tweaks.pattern === "focused" ? FocusedPattern
    : tweaks.pattern === "guided" ? GuidedPattern : ScrollPattern;

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar
        viewMeta={{ phase: "Phase 4", title: "Your settlement proposal", version: "v1", statusLabel: "DRAFT", statusKind: "sarah" }}
        right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        {tweaks.pattern !== "guided" && (
          <P4_ChapterRail sectionStatus={sectionStatus}
                          title="Your draft proposal"
                          subtitle={`${completed} of ${P4_SECTIONS.length} sections drafted`}
                          pct={pct}
                          currentRoute="build"
                          showInlineRouter={tweaks.router === "inline"}/>
        )}
        <Pattern draft={draft} setDraft={setDraft}/>
        <P4_AIRail
          insights={P4_AI_BUILD.insights}
          comments={P4_AI_BUILD.comments}
          activity={P4_AI_BUILD.activity}
          summaryLine={P4_AI_BUILD.summaryLine}
          defaultTab="ai"
          onApplyFallback={(payload) => setDraft(d => ({ ...d, ...payload }))}
          onPostComment={(text) => { /* stub */ }}/>
        {tweaks.router !== "inline" && <P4_FloatingRouter current="build"/>}
      </div>
      <P4_TweakPanel
        title="Build"
        options={[
          { id: "pattern", label: "Step pattern", variants: [
            { value: "scroll",  label: "Scroll",  sub: "All sections inline, sticky summary" },
            { value: "focused", label: "Focused", sub: "One section at a time, full focus" },
            { value: "guided",  label: "Guided",  sub: "Wizard with left steps column" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
