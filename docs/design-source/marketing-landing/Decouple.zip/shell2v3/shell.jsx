/* Household Picture Shell v3 — Deliberation panel replaces tabbed Collab column */
(function(){
const { useState, useEffect } = React;
const { HouseholdDoc, computeStats } = window;
const { DeliberationColumn } = window;
const { Wordmark, ChevronRight, Check, Edit, FileText, LifeBuoy, MessageSquare } = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F";
const SARAH = "#2F6D5F", MARK = "#7E5A4E";

function TopBar({ mode, setMode, viewingVersion, onExitVersion, stats }) {
  const allAgreed = (stats.contested + stats.newItems + stats.gaps) === 0;
  return (
    <div className="flex items-center justify-between px-5 flex-shrink-0"
         style={{ height: 56, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
      <div className="flex items-center gap-3 min-w-0">
        <Wordmark small/>
        <span style={{ color: "#E5E7EB" }}>/</span>
        <div className="flex items-center gap-1.5 text-[12.5px] min-w-0" style={{ color: SUB }}>
          <span>Phase 3</span>
          <ChevronRight size={12} style={{ color: "#D4D4D4" }}/>
          <span className="whitespace-nowrap" style={{ color: INK, fontWeight: 600 }}>Our Household Picture</span>
          {viewingVersion ? (
            <span className="chip ml-1 whitespace-nowrap" style={{ background: "#FEF3C7", color: "#92400E" }}>
              {viewingVersion} · READ-ONLY
            </span>
          ) : (
            <span className="chip ml-1 whitespace-nowrap"
                  style={{ background: allAgreed ? "#D1FAE5" : "#FEF3C7", color: allAgreed ? "#065F46" : "#92400E" }}>
              v2.0 · {allAgreed ? "COMPLETE" : "UNIFIED"}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        {viewingVersion ? (
          <button onClick={onExitVersion}
                  className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-semibold text-white"
                  style={{ background: INK }}>
            ← Back to current
          </button>
        ) : (
          <>
            <div className="inline-flex items-center rounded-md p-0.5"
                 style={{ background: "#F3F4F6", border: `1px solid ${LINE}` }}>
              {[
                { k: "doc",  label: "Read", icon: <FileText size={12}/> },
                { k: "edit", label: "Edit", icon: <Edit size={12}/> }
              ].map(t => {
                const on = mode === t.k;
                return (
                  <button key={t.k} onClick={() => setMode(t.k)}
                    className="inline-flex items-center gap-1.5 h-6.5 px-2.5 py-1 rounded text-[11.5px] font-medium transition"
                    style={{
                      background: on ? "#FFFFFF" : "transparent",
                      color: on ? INK : SUB,
                      boxShadow: on ? "0 1px 2px rgba(0,0,0,0.06)" : "none"
                    }}>
                    {t.icon}{t.label}
                  </button>
                );
              })}
            </div>

            <button className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-semibold text-white"
                    style={{ background: allAgreed ? ACCENT : "#BDBDBD", cursor: allAgreed ? "pointer" : "not-allowed" }}>
              Start a proposal →
            </button>
          </>
        )}

        <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
        <div className="flex items-center -space-x-1.5">
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold ring-2 ring-white"
               style={{ background: SARAH }}>S</div>
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold ring-2 ring-white"
               style={{ background: MARK }}>M</div>
        </div>
      </div>
    </div>
  );
}

function Rail({ active, setActive, itemStates }) {
  const resolved = (id) => !!itemStates[id]?.resolved;
  const chapterAttention = {
    2: (resolved("home_value") ? 0 : 1),
    3: (resolved("mark_nest") ? 0 : 1),
    4: (resolved("joint_barclays") ? 0 : 1) + (resolved("mark_hsbc") ? 0 : 1) + (resolved("mark_hl_isa") ? 0 : 1),
    6: (resolved("mark_amex") ? 0 : 1),
    9: (resolved("mark_p60") ? 0 : 1)
  };
  const CHAPTERS = [
    { n: 1, title: "The children" },
    { n: 2, title: "The home" },
    { n: 3, title: "Pensions" },
    { n: 4, title: "Savings & investments" },
    { n: 5, title: "Vehicles & other" },
    { n: 6, title: "Debts" },
    { n: 7, title: "Income" },
    { n: 8, title: "Monthly spending" },
    { n: 9, title: "Summary" }
  ];
  const totalAttention = Object.values(chapterAttention).reduce((a,b) => a+b, 0);
  const totalItems = 22;
  const pct = Math.round(((totalItems - totalAttention) / totalItems) * 100);

  return (
    <div style={{ width: 224, background: "#FAFAFA", borderRight: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">
      <div className="px-4 py-3.5">
        <div className="label-xs mb-2" style={{ color: MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: INK }}>Our Household Picture</div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: ACCENT }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 11, color: ACCENT, fontWeight: 600 }}>{pct}%</span>
        </div>
        <div style={{ fontSize: 10.5, color: MUTE, marginTop: 4, letterSpacing: "0.02em" }}>
          {totalAttention === 0 ? "All items agreed" : `${totalAttention} item${totalAttention === 1 ? "" : "s"} to resolve`}
        </div>
      </div>
      <div className="px-2 pb-3 flex-1 overflow-y-auto nice-scroll">
        {CHAPTERS.map(c => {
          const attn = chapterAttention[c.n] || 0;
          const isActive = active === c.n;
          return (
            <button key={c.n} onClick={() => setActive(c.n)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{
                background: isActive ? "#EEF1F0" : "transparent",
                color: INK, fontSize: 12.5,
                fontWeight: isActive ? 600 : 500
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "#F1F1F0"; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: MUTE, width: 14 }}>{c.n}</span>
              <span className="flex-1 truncate">{c.title}</span>
              {attn > 0 ? (
                <span className="inline-flex items-center justify-center rounded-full flex-shrink-0 tabular-nums"
                      style={{ minWidth: 16, height: 16, padding: "0 4px", background: "#FEF3C7",
                               color: "#92400E", fontSize: 10, fontWeight: 700 }}>{attn}</span>
              ) : (
                <Check size={11} style={{ color: ACCENT }} strokeWidth={2.5}/>
              )}
            </button>
          );
        })}
      </div>
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
           style={{ color: SUB, borderTop: `1px solid ${LINE}` }}>
        <LifeBuoy size={12}/> Get support
      </div>
    </div>
  );
}

function App() {
  const [mode, setMode] = useState(() => localStorage.getItem("household_v3_mode") || "edit");
  const [active, setActive] = useState(1);
  const [itemStates, setItemStates] = useState({});
  const [activeItemId, setActiveItemId] = useState(null);
  const [selectedVersion, setSelectedVersion] = useState(null);
  const [showCallout, setShowCallout] = useState(true);
  const [panelOpen, setPanelOpen] = useState(true);

  useEffect(() => { localStorage.setItem("household_v3_mode", mode); }, [mode]);

  const onDiscuss = (id) => {
    setActiveItemId(id);
    setPanelOpen(true);
    setItemStates(s => ({ ...s, [id]: { ...s[id], highlight: true } }));
    setTimeout(() => {
      setItemStates(s => ({ ...s, [id]: { ...s[id], highlight: false } }));
    }, 1400);
  };

  const onResolveAll = () => {
    const order = ["home_value", "joint_barclays", "mark_nest", "mark_hsbc", "mark_hl_isa", "mark_amex", "mark_p60"];
    const next = order.find(id => !itemStates[id]?.resolved);
    if (next) onDiscuss(next);
  };

  const stats = computeStats(itemStates);
  const viewingVersion = selectedVersion && selectedVersion !== "v2.0" ? selectedVersion : null;

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: "#F5F5F4" }}>
      <TopBar mode={mode} setMode={setMode}
              viewingVersion={viewingVersion}
              onExitVersion={() => setSelectedVersion(null)}
              stats={stats}/>
      <div className="flex-1 flex min-h-0 relative">
        <Rail active={active} setActive={setActive} itemStates={itemStates}/>
        <div className="flex-1 overflow-y-auto nice-scroll relative"
             style={{ background: "#FFFFFF" }}>
          {viewingVersion && (
            <div className="sticky top-0 z-20 px-6 py-2.5 flex items-center gap-3"
                 style={{ background: "#FFF7ED", borderBottom: `1px solid #FBD3A5` }}>
              <span style={{ fontSize: 13 }}>🕐</span>
              <div className="flex-1 text-[12.5px]" style={{ color: "#9A4E0A" }}>
                You're viewing <b>{viewingVersion}</b> — a snapshot from earlier. Changes are disabled here.
              </div>
              <button onClick={() => setSelectedVersion(null)}
                      className="h-7 px-2.5 rounded-md text-[11.5px] font-semibold text-white"
                      style={{ background: "#9A4E0A" }}>
                Back to v2.0
              </button>
            </div>
          )}
          <HouseholdDoc
            itemStates={viewingVersion ? {} : itemStates}
            setItemStates={viewingVersion ? () => {} : setItemStates}
            onDiscuss={onDiscuss}
            readonly={!!viewingVersion || mode === "doc"}
            showCallout={showCallout && !viewingVersion}
            onDismissCallout={() => setShowCallout(false)}
            onResolveAll={onResolveAll}
            activeItemId={activeItemId}
          />
        </div>

        {panelOpen && !viewingVersion && (
          <DeliberationColumn
            itemStates={itemStates}
            setItemStates={setItemStates}
            activeItemId={activeItemId}
            setActiveItemId={setActiveItemId}
            selectedVersion={selectedVersion}
            onSelectVersion={setSelectedVersion}
            onClose={() => setPanelOpen(false)}
          />
        )}

        {!panelOpen && !viewingVersion && (
          <button onClick={() => setPanelOpen(true)}
                  className="absolute right-4 top-4 h-9 px-3 rounded-md bg-white inline-flex items-center gap-1.5 text-[12.5px] font-semibold z-10"
                  style={{ border: `1px solid ${LINE}`, color: INK, boxShadow: "0 2px 8px rgba(0,0,0,0.06)" }}>
            <MessageSquare size={13}/> Deliberate
          </button>
        )}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
