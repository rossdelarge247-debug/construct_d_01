/* Deliberation Panel — replaces the right collab column with a per-item discussion view
   Pattern borrowed from Reconciliation Split-Screen, styled to Household Picture */
(function(){
const { useState, useEffect, useRef } = React;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";
const AMBER_BG = "#FFF7ED", AMBER_BORDER = "#FBD3A5", AMBER_INK = "#9A4E0A";
const BLUE_BG  = "#EFF6FF", BLUE_BORDER  = "#BFD7F7", BLUE_INK  = "#1E4080";
const GAP_BG   = "#F9FAFB", GAP_BORDER   = "#E5E7EB", GAP_INK   = "#6B7280";
const AI_BG    = "#FAF5FF", AI_BORDER    = "#E4D4FB", AI_INK    = "#6B4EE8";
const GREEN_BG = "#ECF6F0", GREEN_INK    = "#0A6B39";
const SARAH = "#2F6D5F", MARK = "#7E5A4E";

/* Tiny icons */
const Svg = (ch, p={}) => (
  <svg width={p.s||14} height={p.s||14} viewBox="0 0 24 24" fill="none"
       stroke={p.c||"currentColor"} strokeWidth={p.w||1.8}
       strokeLinecap="round" strokeLinejoin="round">{ch}</svg>
);
const Chev     = (p) => Svg(<polyline points="9 6 15 12 9 18"/>, p);
const Check    = (p) => Svg(<polyline points="5 12 10 17 19 7"/>, p);
const XIco     = (p) => Svg(<><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></>, p);
const AlertI   = (p) => Svg(<><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><circle cx="12" cy="16" r="0.5" fill="currentColor"/></>, p);
const DocI     = (p) => Svg(<><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="14 3 14 9 20 9"/></>, p);
const Scale    = (p) => Svg(<><path d="M12 3v18M3 7h18M7 7l-3 7a5 5 0 0 0 6 0zM17 7l-3 7a5 5 0 0 0 6 0z"/></>, p);
const Sparkle  = (p) => Svg(<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>, p);
const MoreH    = (p) => Svg(<><circle cx="5" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="19" cy="12" r="1.5" fill="currentColor"/></>, p);
const History  = (p) => Svg(<><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></>, p);
const Activity = (p) => Svg(<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>, p);

function Avatar({ who, size = 22 }) {
  const isS = who === "Sarah" || who === "S";
  const dim = typeof size === "number" ? size : 22;
  return (
    <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
          style={{ width: dim, height: dim, background: isS ? SARAH : MARK, fontSize: Math.round(dim * 0.48) }}>
      {isS ? "S" : "M"}
    </span>
  );
}

/* ============================================================
   ITEM MODEL — all attention items + resolve paths
   ============================================================ */
/* Order that AI prioritises — biggest £ impact → disclosure → evidence gap */
const ATTENTION_ORDER = [
  "home_value",
  "joint_barclays",
  "mark_hl_isa",
  "mark_nest",
  "mark_hsbc",
  "mark_amex",
  "mark_p60"
];

const ITEM_MODEL = {
  home_value: {
    label: "Property value",
    chapter: 2, chapterTitle: "The home",
    state: "contested",
    sarah: { value: "£450,000", evidence: "self", note: "Rightmove comps for Oak Road" },
    mark:  { value: "£480,000", evidence: "self", note: "Wilkinson Grant valuation, 28 Mar" },
    diff: "£30,000",
    midpoint: "£465,000",
    ai: {
      kind: "midpoint",
      text: "A midpoint of £465,000 sits within both estimates. If you want a definitive figure, a joint RICS valuation runs about £500 and takes a week.",
      applyLabel: "Resolve at £465,000",
      applyValue: "£465,000"
    },
    messages: [
      { who: "Sarah", time: "31 Mar", text: "My estimate came from Rightmove comps for similar houses on Oak Road." },
      { who: "Mark",  time: "1 Apr",  text: "I got a formal valuation from Wilkinson Grant — they came in at £480k. I'll upload the note." }
    ],
    resolveOptions: [
      { label: "Accept £450,000", value: "£450,000" },
      { label: "Resolve at £465,000 (midpoint)", value: "£465,000", primary: true },
      { label: "Accept £480,000", value: "£480,000" }
    ]
  },
  joint_barclays: {
    label: "Joint savings — Barclays",
    chapter: 4, chapterTitle: "Savings & investments",
    state: "contested",
    sarah: { value: "£12,000", evidence: "doc",  note: "Statement 31 March" },
    mark:  { value: "£8,000",  evidence: "self", note: "Barclays app when I checked" },
    diff: "£4,000",
    ai: {
      kind: "cross_ref",
      text: "Sarah's statement is dated 31 March. £4,000 was transferred to HMRC on 2 April (tax bill). Using £8,000 post-tax is consistent with both views.",
      applyLabel: "Resolve at £8,000",
      applyValue: "£8,000"
    },
    messages: [
      { who: "Sarah", time: "31 Mar", text: "Statement shows £12,000 as of 31 March.", attachment: "barclays-march.pdf" },
      { who: "Mark",  time: "1 Apr",  text: "The Barclays app showed £8k when I checked. Maybe the £4k was the tax bill?" },
      { who: "Sarah", time: "2 Apr",  text: "You're right — I moved £4k to HMRC on 2 April. Let's use £8,000." }
    ],
    resolveOptions: [
      { label: "Resolve at £8,000 (post-tax)", value: "£8,000", primary: true },
      { label: "Resolve at £12,000 (pre-tax)", value: "£12,000" }
    ]
  },
  mark_nest: {
    label: "Mark's NEST Pension",
    chapter: 3, chapterTitle: "Pensions",
    state: "new",
    disclosedBy: "Mark",
    value: "£12,000",
    evidence: "self",
    note: "Workplace defined contribution, opened 2019",
    ai: {
      kind: "evidence",
      text: "Self-declared. A CETV statement from NEST is free and comes through in about three days — worth requesting before finalising."
    }
  },
  mark_hsbc: {
    label: "Mark's HSBC current account",
    chapter: 4, chapterTitle: "Savings & investments",
    state: "new",
    disclosedBy: "Mark",
    value: "£3,800",
    evidence: "doc"
  },
  mark_hl_isa: {
    label: "Mark's Hargreaves Lansdown ISA",
    chapter: 4, chapterTitle: "Savings & investments",
    state: "new",
    disclosedBy: "Mark",
    value: "£15,000",
    evidence: "doc",
    note: "Stocks & shares ISA, opened 2022",
    ai: {
      kind: "comparability",
      text: "Mark provided a statement for his ISA. Sarah's ISA (£6,000) is self-declared — consider asking for a statement too for consistency."
    }
  },
  mark_amex: {
    label: "Mark's Amex",
    chapter: 6, chapterTitle: "Debts",
    state: "new",
    disclosedBy: "Mark",
    value: "(£5,800)",
    evidence: "self",
    note: "Rolling balance, paid down monthly"
  },
  mark_p60: {
    label: "Mark's P60 for 2025/26",
    chapter: 9, chapterTitle: "Summary",
    state: "gap",
    ai: {
      kind: "evidence",
      text: "Needed to confirm annual gross income for the record. HMRC portal download is fastest — under a minute."
    }
  }
};

function isResolved(itemStates, id) { return !!itemStates[id]?.resolved; }

/* ============================================================
   PANEL
   ============================================================ */
function DeliberationColumn({ itemStates, setItemStates, activeItemId, setActiveItemId,
                              selectedVersion, onSelectVersion, onClose }) {
  const [overlay, setOverlay] = useState(null); /* null | "activity" | "versions" */
  const replyRefs = useRef({});

  /* Unresolved attention queue */
  const queue = ATTENTION_ORDER.filter(id => !isResolved(itemStates, id));
  const queueIdx = queue.indexOf(activeItemId);
  const positionIdx = queueIdx >= 0 ? queueIdx : queue.findIndex(id => id === activeItemId);

  const goNext = () => {
    const idx = queue.indexOf(activeItemId);
    if (idx >= 0 && idx < queue.length - 1) setActiveItemId(queue[idx + 1]);
    else if (queue.length > 0 && idx === -1) setActiveItemId(queue[0]);
  };
  const goPrev = () => {
    const idx = queue.indexOf(activeItemId);
    if (idx > 0) setActiveItemId(queue[idx - 1]);
  };

  const item = activeItemId ? ITEM_MODEL[activeItemId] : null;
  const resolvedHere = activeItemId ? isResolved(itemStates, activeItemId) : false;

  /* Item looks resolved if user confirmed it this session */
  const displayState = resolvedHere ? "agreed" : item?.state;

  const applyResolve = (value) => {
    setItemStates(s => ({ ...s, [activeItemId]: { resolved: true, resolvedValue: value } }));
  };

  return (
    <div className="flex flex-col h-full relative" style={{ width: 420, background: "#FFFFFF", borderLeft: `1px solid ${LINE}` }}>
      <PanelHeader
        activeItemId={activeItemId}
        queueLength={queue.length}
        positionIdx={positionIdx}
        goNext={goNext}
        goPrev={goPrev}
        onClose={onClose}
        onOpenOverlay={setOverlay}
      />

      {overlay === "activity" && <ActivityOverlay onClose={() => setOverlay(null)}/>}
      {overlay === "versions" && <VersionsOverlay onClose={() => setOverlay(null)} selected={selectedVersion} onSelect={(v) => { onSelectVersion(v); setOverlay(null); }}/>}

      {!item ? (
        <QueueView queue={queue} setActive={setActiveItemId} itemStates={itemStates}/>
      ) : (
        <ItemView
          id={activeItemId}
          item={item}
          state={displayState}
          resolvedValue={itemStates[activeItemId]?.resolvedValue}
          applyResolve={applyResolve}
          setItemStates={setItemStates}
          onNext={goNext}
          hasNext={queueIdx >= 0 && queueIdx < queue.length - 1}
        />
      )}
    </div>
  );
}

/* ============================================================
   PANEL HEADER — queue position + nav + overflow menu
   ============================================================ */
function PanelHeader({ activeItemId, queueLength, positionIdx, goNext, goPrev, onClose, onOpenOverlay }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="px-3 py-2 flex items-center gap-2 flex-shrink-0"
         style={{ borderBottom: `1px solid ${LINE}`, background: "#FAFAFA" }}>
      {activeItemId ? (
        <>
          <span className="inline-flex items-center gap-1.5 chip"
                style={{ background: "#FFFFFF", color: INK, border: `1px solid ${LINE}`, fontSize: 9.5, padding: "2px 7px" }}>
            <Sparkle s={9} c={AI_INK} w={2}/> Attention {positionIdx >= 0 ? positionIdx + 1 : "·"} of {queueLength}
          </span>
          <div className="ml-auto flex items-center gap-1">
            <button onClick={goPrev}
              className="w-7 h-7 rounded-md bg-white flex items-center justify-center"
              style={{ border: `1px solid ${LINE}` }}
              title="Previous">
              <Chev s={12} style={{ transform: "rotate(180deg)" }}/>
            </button>
            <button onClick={goNext}
              className="w-7 h-7 rounded-md bg-white flex items-center justify-center"
              style={{ border: `1px solid ${LINE}` }}
              title="Next">
              <Chev s={12}/>
            </button>
          </div>
        </>
      ) : (
        <>
          <span className="label-xs" style={{ color: MUTE }}>Deliberation</span>
          <div className="ml-auto"/>
        </>
      )}
      <div className="relative">
        <button onClick={() => setMenuOpen(v => !v)}
          className="w-7 h-7 rounded-md bg-white flex items-center justify-center"
          style={{ border: `1px solid ${LINE}` }}
          title="More">
          <MoreH s={14} c={SUB}/>
        </button>
        {menuOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)}/>
            <div className="absolute right-0 top-8 z-20 rounded-lg py-1 bg-white"
                 style={{ border: `1px solid ${LINE}`, boxShadow: "0 6px 20px rgba(0,0,0,0.08)", width: 180 }}>
              <button onClick={() => { onOpenOverlay("activity"); setMenuOpen(false); }}
                className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-[#F5F5F4]"
                style={{ fontSize: 12.5, color: INK }}>
                <Activity s={13} c={SUB}/> Activity log
              </button>
              <button onClick={() => { onOpenOverlay("versions"); setMenuOpen(false); }}
                className="w-full flex items-center gap-2 px-3 py-2 text-left hover:bg-[#F5F5F4]"
                style={{ fontSize: 12.5, color: INK }}>
                <History s={13} c={SUB}/> Version history
              </button>
            </div>
          </>
        )}
      </div>
      <button onClick={onClose} className="w-7 h-7 rounded-md hover:bg-[#F1F1EE] flex items-center justify-center" title="Close">
        <XIco s={13} c={SUB}/>
      </button>
    </div>
  );
}

/* ============================================================
   QUEUE VIEW (nothing selected)
   ============================================================ */
function QueueView({ queue, setActive, itemStates }) {
  if (queue.length === 0) {
    return (
      <div className="flex-1 p-6 flex flex-col items-center justify-center text-center">
        <div className="w-12 h-12 rounded-full flex items-center justify-center mb-3"
             style={{ background: GREEN_BG }}>
          <Check s={22} c={GREEN_INK} w={2.5}/>
        </div>
        <div style={{ fontSize: 15, fontWeight: 600, color: INK }}>All items agreed</div>
        <div style={{ fontSize: 12.5, color: SUB, marginTop: 4, lineHeight: 1.5, maxWidth: 260 }}>
          Your facts are aligned. You're ready to start a settlement proposal.
        </div>
      </div>
    );
  }
  return (
    <div className="flex-1 overflow-y-auto nice-scroll p-4">
      <div className="flex items-center gap-2 mb-2">
        <span className="label-xs" style={{ color: MUTE }}>AI-ordered queue</span>
        <span className="inline-flex items-center gap-1 rounded-full ml-auto"
              style={{ background: AI_BG, border: `1px solid ${AI_BORDER}`, color: AI_INK,
                       fontSize: 10, padding: "1px 6px", fontWeight: 600, letterSpacing: "0.02em" }}>
          <Sparkle s={9} w={2}/> {queue.length} to resolve
        </span>
      </div>
      <div style={{ fontSize: 12.5, color: SUB, lineHeight: 1.5, marginBottom: 12 }}>
        Pick an item from the document, or walk through them in the order we suggest. Biggest-impact items first.
      </div>
      <div className="space-y-1.5">
        {queue.map((id, idx) => {
          const it = ITEM_MODEL[id];
          return (
            <button key={id} onClick={() => setActive(id)}
              className="w-full text-left rounded-md p-2.5 bg-white transition"
              style={{ border: `1px solid ${LINE}` }}
              onMouseEnter={e => e.currentTarget.style.background = "#FAFAFA"}
              onMouseLeave={e => e.currentTarget.style.background = "#FFFFFF"}>
              <div className="flex items-center gap-2 mb-1">
                <span className="tabular-nums" style={{ fontSize: 10.5, color: MUTE, fontWeight: 700, width: 14 }}>{idx + 1}.</span>
                <StateDot state={it.state}/>
                <span style={{ fontSize: 12.5, fontWeight: 600, color: INK }}>{it.label}</span>
                <span className="ml-auto" style={{ fontSize: 10.5, color: MUTE }}>§{it.chapter}</span>
              </div>
              {it.ai && (
                <div style={{ fontSize: 11.5, color: SUB, lineHeight: 1.45, paddingLeft: 20 }}>
                  {it.ai.text.length > 88 ? it.ai.text.slice(0, 86) + "…" : it.ai.text}
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   ITEM VIEW — positions, AI, respond, discussion
   ============================================================ */
function ItemView({ id, item, state, resolvedValue, applyResolve, setItemStates, onNext, hasNext }) {
  const [justResolved, setJustResolved] = useState(false);
  const [showResolveChoices, setShowResolveChoices] = useState(false);

  useEffect(() => {
    setJustResolved(false);
    setShowResolveChoices(false);
  }, [id]);

  const handleAccept = (value) => {
    applyResolve(value);
    setJustResolved(true);
  };

  const chipMap = {
    agreed:    { bg: GREEN_BG, fg: GREEN_INK, label: "Agreed" },
    contested: { bg: AMBER_BG, fg: AMBER_INK, label: "Values differ" },
    new:       { bg: BLUE_BG,  fg: BLUE_INK,  label: "New disclosure" },
    gap:       { bg: GAP_BG,   fg: GAP_INK,   label: "Evidence needed" }
  };
  const chip = chipMap[state];

  return (
    <div className="flex-1 overflow-y-auto nice-scroll">
      <div className="px-4 pt-4 pb-3">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="chip whitespace-nowrap"
                style={{ background: chip.bg, color: chip.fg, fontSize: 9.5, padding: "2px 7px" }}>
            {chip.label}
          </span>
          <span style={{ fontSize: 11, color: MUTE }}>§{item.chapter} · {item.chapterTitle}</span>
        </div>
        <h2 style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em", color: INK, marginTop: 6, lineHeight: 1.25 }}>
          {item.label}
        </h2>
      </div>

      {/* Resolved banner */}
      {state === "agreed" && (
        <div className="mx-4 mb-3 rounded-lg p-3" style={{ background: GREEN_BG, border: `1px solid #C7E4D1` }}>
          <div className="flex items-center gap-2">
            <Check s={14} c={GREEN_INK} w={2.5}/>
            <span style={{ fontSize: 13, fontWeight: 600, color: GREEN_INK }}>
              {justResolved ? "Just resolved" : "Agreed by both"}
            </span>
          </div>
          {(resolvedValue || item.value) && (
            <div className="mt-1 tabular-nums" style={{ fontSize: 18, fontWeight: 700, color: INK }}>
              {resolvedValue || item.value}
            </div>
          )}
          {hasNext && (
            <button onClick={onNext}
              className="mt-2 h-7 px-2.5 rounded-md inline-flex items-center gap-1.5 text-[11.5px] font-semibold text-white"
              style={{ background: GREEN_INK }}>
              Next item <Chev s={11} c="#FFFFFF"/>
            </button>
          )}
        </div>
      )}

      {/* CONTESTED — positions */}
      {state === "contested" && (
        <div className="mx-4 mb-3">
          <div className="label-xs mb-1.5" style={{ color: MUTE }}>Positions</div>
          <div className="rounded-lg overflow-hidden" style={{ border: `1px solid ${LINE}` }}>
            <PositionRow who="Sarah" claim={item.sarah}/>
            <div style={{ height: 1, background: LINE }}/>
            <PositionRow who="Mark" claim={item.mark}/>
          </div>
          <div className="mt-2 flex items-center justify-between text-[11.5px]" style={{ color: AMBER_INK }}>
            <span>Gap of <b className="tabular-nums">{item.diff}</b></span>
            {item.midpoint && <span>Midpoint <b className="tabular-nums">{item.midpoint}</b></span>}
          </div>
        </div>
      )}

      {/* NEW — disclosure */}
      {state === "new" && (
        <div className="mx-4 mb-3 rounded-lg p-3" style={{ background: BLUE_BG, border: `1px solid ${BLUE_BORDER}` }}>
          <div className="flex items-center gap-2 mb-2">
            <Avatar who={item.disclosedBy} size={22}/>
            <span style={{ fontSize: 12.5, fontWeight: 600, color: INK }}>Disclosed by {item.disclosedBy}</span>
            <span className="ml-auto" style={{ fontSize: 11, color: BLUE_INK }}>16 Apr</span>
          </div>
          <div className="flex items-center gap-1.5 tabular-nums" style={{ fontSize: 22, fontWeight: 700, color: INK }}>
            {item.value}
          </div>
          {item.evidence === "doc" && (
            <div className="mt-1 inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-white"
                 style={{ fontSize: 11, color: BLUE_INK, border: `1px solid ${BLUE_BORDER}` }}>
              <DocI s={10}/> statement attached
            </div>
          )}
          {item.note && (
            <div style={{ fontSize: 12, color: SUB, marginTop: 6, fontStyle: "italic", lineHeight: 1.5 }}>
              "{item.note}"
            </div>
          )}
        </div>
      )}

      {/* GAP */}
      {state === "gap" && (
        <div className="mx-4 mb-3 rounded-lg p-3" style={{ background: GAP_BG, border: `1px dashed ${GAP_BORDER}` }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: GAP_INK, letterSpacing: "0.04em", textTransform: "uppercase", marginBottom: 4 }}>
            Not yet provided
          </div>
          <div style={{ fontSize: 12.5, color: INK, lineHeight: 1.5 }}>
            AI flagged this as needed before the record is complete. Either party can upload.
          </div>
        </div>
      )}

      {/* AI MEDIATOR */}
      {item.ai && state !== "agreed" && (
        <div className="mx-4 mb-3 rounded-lg p-3" style={{ background: AI_BG, border: `1px solid ${AI_BORDER}` }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <Sparkle s={12} c={AI_INK} w={2}/>
            <span style={{ fontSize: 10.5, fontWeight: 700, color: AI_INK, letterSpacing: "0.04em", textTransform: "uppercase" }}>
              {aiLabel(item.ai.kind)}
            </span>
          </div>
          <div style={{ fontSize: 12.5, color: "#3D2E7A", lineHeight: 1.5 }}>{item.ai.text}</div>
          {item.ai.applyLabel && (
            <div className="mt-2 flex items-center gap-1.5">
              <button onClick={() => handleAccept(item.ai.applyValue)}
                className="h-7 rounded text-[11.5px] font-semibold inline-flex items-center gap-1.5 px-2.5"
                style={{ background: AI_INK, color: "#FFFFFF" }}>
                <Check s={11} c="#FFFFFF" w={2.5}/> {item.ai.applyLabel}
              </button>
              <button
                className="h-7 rounded text-[11.5px] font-medium bg-white px-2.5"
                style={{ border: `1px solid ${AI_BORDER}`, color: AI_INK }}>
                Dismiss
              </button>
            </div>
          )}
        </div>
      )}

      {/* RESPOND */}
      {state !== "agreed" && (
        <div className="mx-4 mb-3">
          <div className="label-xs mb-1.5" style={{ color: MUTE }}>Respond</div>
          {state === "contested" && (
            <div className="grid grid-cols-2 gap-1.5">
              <BigBtn kind="accept" onClick={() => setShowResolveChoices(v => !v)}>
                <Check s={12}/> Resolve
              </BigBtn>
              <BigBtn kind="challenge"><AlertI s={12}/> Challenge</BigBtn>
              <BigBtn kind="evidence"><DocI s={12}/> Request evidence</BigBtn>
              <BigBtn kind="counter"><Scale s={12}/> Counter-propose</BigBtn>
            </div>
          )}
          {state === "new" && (
            <div className="grid grid-cols-2 gap-1.5">
              <BigBtn kind="accept" onClick={() => handleAccept(item.value)}>
                <Check s={12}/> Confirm I knew
              </BigBtn>
              <BigBtn kind="challenge"><AlertI s={12}/> Query</BigBtn>
              <BigBtn kind="evidence"><DocI s={12}/> Request evidence</BigBtn>
              <BigBtn kind="counter">Flag for lawyer</BigBtn>
            </div>
          )}
          {state === "gap" && (
            <div className="grid grid-cols-2 gap-1.5">
              <BigBtn kind="accept" onClick={() => handleAccept("provided")}>
                <Check s={12}/> Upload now
              </BigBtn>
              <BigBtn kind="evidence"><DocI s={12}/> Remind Mark</BigBtn>
            </div>
          )}

          {showResolveChoices && item.resolveOptions && (
            <div className="mt-2 p-2 rounded-md space-y-1" style={{ background: "#FAFAFA", border: `1px dashed ${LINE}` }}>
              <div className="label-xs px-1" style={{ color: MUTE }}>Choose a resolution</div>
              {item.resolveOptions.map((o, i) => (
                <button key={i} onClick={() => handleAccept(o.value)}
                  className="w-full text-left rounded-md px-2.5 py-1.5 transition flex items-center justify-between"
                  style={{
                    background: o.primary ? INK : "#FFFFFF",
                    color: o.primary ? "#FFFFFF" : INK,
                    fontSize: 12, fontWeight: o.primary ? 600 : 500,
                    border: `1px solid ${o.primary ? INK : LINE}`
                  }}>
                  <span>{o.label}</span>
                  <Check s={11} c={o.primary ? "#FFFFFF" : SUB} w={2.5}/>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* DISCUSSION */}
      <div className="mx-4 mt-4 pt-4" style={{ borderTop: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Discussion</div>
        {item.messages && item.messages.length > 0 ? (
          <div className="space-y-2.5 mb-2.5">
            {item.messages.map((m, i) => <Bubble key={i} {...m}/>)}
          </div>
        ) : (
          <div style={{ fontSize: 12, color: MUTE, fontStyle: "italic", marginBottom: 8 }}>
            No discussion yet — start the conversation.
          </div>
        )}
        <textarea rows={2} placeholder="Add a reply…"
          className="w-full rounded-md px-2.5 py-1.5 resize-none"
          style={{ fontSize: 12.5, border: `1px solid ${LINE}`, background: "#FAFAFA" }}/>
        <div className="h-4"/>
      </div>
    </div>
  );
}

function aiLabel(kind) {
  return {
    midpoint: "Suggested resolution",
    cross_ref: "Cross-reference",
    sanity: "Sanity check",
    evidence: "Evidence needed",
    evidence_age: "Evidence age",
    comparability: "Consistency"
  }[kind] || "AI observation";
}

function StateDot({ state }) {
  const c = state === "contested" ? "#E5B048"
          : state === "new" ? BLUE_INK
          : state === "gap" ? GAP_INK
          : ACCENT;
  return <span className="inline-block rounded-full flex-shrink-0" style={{ width: 7, height: 7, background: c }}/>;
}

function PositionRow({ who, claim }) {
  const isS = who === "Sarah";
  return (
    <div className="p-3 flex items-center gap-3" style={{ background: isS ? "rgba(47, 109, 95, 0.04)" : "rgba(126, 90, 78, 0.04)" }}>
      <Avatar who={who} size={28}/>
      <div className="flex-1 min-w-0">
        <div style={{ fontSize: 12, fontWeight: 600, color: INK }}>{who}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span style={{ fontSize: 11 }}>
            {claim.evidence === "doc" ? <DocI s={11} c={ACCENT}/> : <span style={{ color: MUTE, fontSize: 10.5 }}>self-declared</span>}
          </span>
          {claim.evidence === "doc" && <span style={{ fontSize: 11, color: SUB }}>Document</span>}
        </div>
        {claim.note && (
          <div style={{ fontSize: 11, color: SUB, marginTop: 3, fontStyle: "italic", lineHeight: 1.4 }}>
            "{claim.note}"
          </div>
        )}
      </div>
      <div className="tabular-nums text-right" style={{ fontSize: 18, fontWeight: 700, color: INK }}>{claim.value}</div>
    </div>
  );
}

function BigBtn({ kind, children, onClick }) {
  const m = {
    accept:    { bg: ACCENT,    fg: "#FFFFFF",   bd: ACCENT },
    challenge: { bg: "#FFFFFF", fg: AMBER_INK,   bd: AMBER_BORDER },
    evidence:  { bg: "#FFFFFF", fg: BLUE_INK,    bd: BLUE_BORDER },
    counter:   { bg: "#FFFFFF", fg: INK,         bd: LINE }
  }[kind];
  return (
    <button onClick={onClick}
      className="h-9 rounded-md inline-flex items-center justify-center gap-1.5 text-[12px] font-semibold transition"
      style={{ background: m.bg, color: m.fg, border: `1px solid ${m.bd}` }}
      onMouseEnter={e => { if (kind === "accept") e.currentTarget.style.filter = "brightness(1.08)"; else e.currentTarget.style.background = "#F9F9F8"; }}
      onMouseLeave={e => { e.currentTarget.style.filter = "none"; if (kind !== "accept") e.currentTarget.style.background = m.bg; }}>
      {children}
    </button>
  );
}

function Bubble({ who, time, text, attachment }) {
  return (
    <div className="flex items-start gap-2">
      <Avatar who={who} size={22}/>
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline gap-1.5">
          <span style={{ fontSize: 11.5, fontWeight: 600 }}>{who}</span>
          <span style={{ fontSize: 10.5, color: MUTE }}>· {time}</span>
        </div>
        <div style={{ fontSize: 12.5, color: INK, lineHeight: 1.5, marginTop: 1 }}>{text}</div>
        {attachment && (
          <div className="mt-1.5 inline-flex items-center gap-1.5 px-2 py-1 rounded"
               style={{ background: "#F4F7FB", fontSize: 11, color: BLUE_INK }}>
            <DocI s={10}/> {attachment}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================
   OVERLAYS — Activity log, Version history
   ============================================================ */
function ActivityOverlay({ onClose }) {
  const feed = [
    { time: "17 Apr · 09:14", who: "M", text: "Mark opened Our Household Picture" },
    { time: "17 Apr · 09:14", who: "S", text: "Sarah opened Our Household Picture" },
    { time: "16 Apr · 14:22", who: "M", text: "Mark added his HL ISA (£15,000)" },
    { time: "16 Apr · 14:18", who: "M", text: "Mark added his Amex (£5,800)" },
    { time: "16 Apr · 14:05", who: "M", text: "Mark confirmed Sarah's mortgage balance" },
    { time: "16 Apr · 13:58", who: "M", text: "Mark queried joint savings (says £8k)" },
    { time: "15 Apr · 09:00", who: "S", text: "Sarah shared her picture with Mark" },
    { time: "14 Apr · 16:30", who: "S", text: "Sarah finalised her picture v1.0" }
  ];
  let lastDay = "";
  return (
    <OverlayShell title="Activity log" onClose={onClose}>
      <div className="p-3">
        {feed.map((a, i) => {
          const day = a.time.split(" · ")[0];
          const showDay = day !== lastDay;
          lastDay = day;
          return (
            <React.Fragment key={i}>
              {showDay && (
                <div className="label-xs mt-3 mb-2 first:mt-0" style={{ color: MUTE }}>{day}</div>
              )}
              <div className="flex items-start gap-2 py-1.5">
                <Avatar who={a.who} size={20}/>
                <div className="flex-1 min-w-0">
                  <div style={{ fontSize: 12.5, color: INK, lineHeight: 1.45 }}>{a.text}</div>
                  <div style={{ fontSize: 10.5, color: MUTE, marginTop: 1 }}>{a.time.split(" · ")[1]}</div>
                </div>
              </div>
            </React.Fragment>
          );
        })}
      </div>
    </OverlayShell>
  );
}

function VersionsOverlay({ onClose, selected, onSelect }) {
  const VERSIONS = [
    { id: "v2.0", label: "UNIFIED",     date: "16 Apr", note: "Mark completed his side",    who: "M", current: true },
    { id: "v1.5", label: "IN PROGRESS", date: "15 Apr", note: "Mark started building",      who: "M" },
    { id: "v1.0", label: "SHARED",      date: "14 Apr", note: "Sarah shared with Mark",     who: "S" },
    { id: "v0.8", label: "DRAFT",       date: "13 Apr", note: "Sarah added spending review",who: "S" },
    { id: "v0.5", label: "DRAFT",       date: "12 Apr", note: "Sarah connected bank",       who: "S" },
    { id: "v0.1", label: "DRAFT",       date: "12 Apr", note: "Sarah started",              who: "S" }
  ];
  return (
    <OverlayShell title="Version history" onClose={onClose}>
      <div className="p-3">
        <div style={{ position: "relative" }}>
          <div style={{ position: "absolute", left: 11, top: 12, bottom: 12, width: 1, background: "#E5E7EB" }}/>
          {VERSIONS.map(v => {
            const isSelected = selected === v.id;
            const phaseTint = v.label === "UNIFIED" ? { bg: GREEN_BG, fg: GREEN_INK }
              : v.label === "SHARED" ? { bg: "#D1FAE5", fg: "#065F46" }
              : v.label === "IN PROGRESS" ? { bg: BLUE_BG, fg: BLUE_INK }
              : { bg: "#FEF3C7", fg: "#92400E" };
            return (
              <button key={v.id} onClick={() => onSelect(v.current ? null : v.id)}
                className="w-full flex items-start gap-3 py-2.5 px-1.5 rounded-md text-left transition"
                style={{ background: isSelected ? "#F1F1EE" : "transparent" }}>
                <span className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0 relative z-10 mt-0.5"
                      style={{ width: 22, height: 22, background: v.who === "S" ? SARAH : MARK, fontSize: 10.5,
                               boxShadow: `0 0 0 3px #FFFFFF` }}>
                  {v.who}
                </span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-1.5 flex-wrap">
                    <span className="tabular-nums" style={{ fontSize: 12.5, fontWeight: 700, color: INK }}>{v.id}</span>
                    <span className="chip whitespace-nowrap" style={{ background: phaseTint.bg, color: phaseTint.fg, fontSize: 9, padding: "1.5px 5.5px" }}>
                      {v.label}
                    </span>
                    {v.current && <span style={{ fontSize: 10.5, color: ACCENT, fontWeight: 600 }}>current</span>}
                  </div>
                  <div style={{ fontSize: 11.5, color: SUB, marginTop: 1, lineHeight: 1.4 }}>{v.date} · {v.note}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </OverlayShell>
  );
}

function OverlayShell({ title, onClose, children }) {
  return (
    <div className="absolute inset-0 z-30 bg-white flex flex-col" style={{ animation: "fadeIn 0.12s ease" }}>
      <div className="px-3 py-2 flex items-center gap-2 flex-shrink-0"
           style={{ borderBottom: `1px solid ${LINE}`, background: "#FAFAFA" }}>
        <button onClick={onClose}
          className="h-7 px-2 rounded-md bg-white inline-flex items-center gap-1 text-[11.5px] font-semibold"
          style={{ border: `1px solid ${LINE}`, color: INK }}>
          <Chev s={11} style={{ transform: "rotate(180deg)" }}/> Back
        </button>
        <span style={{ fontSize: 13, fontWeight: 600, color: INK, marginLeft: 4 }}>{title}</span>
      </div>
      <div className="flex-1 overflow-y-auto nice-scroll">{children}</div>
    </div>
  );
}

Object.assign(window, { DeliberationColumn });
})();
