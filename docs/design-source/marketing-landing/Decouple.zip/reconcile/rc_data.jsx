/* Reconciliation v2 — data model
   Two scenes:
     03 = initial merge (first landing post-handshake)
     04 = contested focus ("rolling up sleeves" beat, different scenario)
*/
(function(){
const SARAH = "#2F6D5F", MARK = "#7E5A4E";

/* ------------ SCENE 03 — INITIAL MERGE ------------
   Scenario: First look. Lots agreed, a few contested, a few gaps/new/estimated.
*/
const SCENE_03 = {
  id: "03",
  title: "Our household picture",
  subtitle: "Where you and Mark agree, where you disagree, and what's still missing.",
  activeChapter: "property",
  items: [
    /* PROPERTY */
    { id: "home",        ch: "property", label: "Family home — 12 Oak Road",
      state: "contested",
      sarah: { value: "£505,000", evidence: "3 agent valuations", note: "Mid of Foxtons/Winkworth/Savills" },
      mark:  { value: "£560,000", evidence: "Savills only", note: "Spring 2024 peak comparable" },
      delta: "£55,000 apart",
      ai:    "Parity check: Sarah's figure uses 3 current valuations (Feb 2026). Mark's cites a single 2024 valuation. Suggest averaging the 3 current ones." },
    { id: "mortgage",    ch: "property", label: "Halifax mortgage balance",
      state: "agreed",
      agreedValue: "£187,500",
      evidence: "Statement · 1 Feb 2026" },
    { id: "deposit",     ch: "property", label: "Original 2015 deposit source",
      state: "contested",
      sarah: { value: "£40k joint savings · £20k Sarah parents' gift", evidence: "Bank transfers 2015" },
      mark:  { value: "£60k joint savings only", evidence: "Recollection" },
      delta: "Different account of the origin",
      ai:    "Item impact: low financial (≈£20k). Evidence age: 11 years. Might be simpler to agree 'disputed origin, no adjustment'." },
    { id: "contents",    ch: "property", label: "Home contents & furnishings",
      state: "gap",
      missingFrom: "Mark",
      ai:    "Mark hasn't estimated. Low-value items can usually be agreed as 'each keep what's theirs' without formal valuation." },

    /* PENSIONS */
    { id: "nhs",         ch: "pensions", label: "NHS pension (Sarah) — CETV",
      state: "agreed",
      agreedValue: "£214,000",
      evidence: "CETV statement · 4 Feb 2026" },
    { id: "workplace",   ch: "pensions", label: "Aviva workplace (Sarah)",
      state: "agreed",
      agreedValue: "£38,200",
      evidence: "Annual statement · Nov 2025" },
    { id: "mark-sipp",   ch: "pensions", label: "Mark's Hargreaves Lansdown SIPP",
      state: "new",
      who: "Mark",
      newValue: "£84,300",
      newOn: "Mark shared 18 Nov",
      ai: "Added after Mark shared. Sarah hasn't seen this before — worth a quick confirmation request." },

    /* INCOME */
    { id: "sarah-salary",    ch: "income", label: "Sarah — NHS salary",
      state: "agreed",
      agreedValue: "£62,400 / yr",
      evidence: "Dec + Jan payslips" },
    { id: "sarah-freelance", ch: "income", label: "Sarah — freelance (Lancet)",
      state: "estimated",
      value: "£4,200 / yr",
      estBy: "Sarah",
      note: "Self-estimated based on 3 invoices since Oct 2025.",
      ai: "Self-declared estimate. Evidence: 3 invoices attached. Courts typically want a rolling 12-month view — could hold until May for a fuller picture." },
    { id: "mark-salary",     ch: "income", label: "Mark — salary (Acme Ltd)",
      state: "estimated",
      value: "£78,000 / yr",
      estBy: "Mark",
      note: "Self-estimated. No payslip attached.",
      ai: "Self-declared, no evidence. Payslip or P60 would close this. Request from Mark." },

    /* CHILDREN */
    { id: "primary-care",    ch: "children", label: "Primary care arrangement",
      state: "agreed",
      agreedValue: "Shared 60/40 (Sarah lead)",
      evidence: "Verbal agreement · Oct 2025" },
    { id: "nursery",         ch: "children", label: "Nursery fees (Jake)",
      state: "agreed",
      agreedValue: "£720 / mo",
      evidence: "Bright Horizons invoice" },
    { id: "school-fees",     ch: "children", label: "School fees (Emma)",
      state: "gap",
      missingFrom: "Both",
      ai: "Neither of you has entered school-related expenses. Likely £0 for state school — confirm explicitly so it closes." }
  ]
};

/* ------------ SCENE 04 — CONTESTED FOCUS ------------
   Different beat: further into reconciliation, narrowing to the hard items.
*/
const SCENE_04 = {
  id: "04",
  title: "Contested items",
  subtitle: "The pieces we haven't agreed on yet. Work through them one at a time.",
  activeChapter: "property",
  items: [
    /* PROPERTY */
    { id: "home-2",      ch: "property", label: "Family home — 12 Oak Road",
      state: "contested",
      sarah: { value: "£505,000", evidence: "3 agent valuations (avg)", note: "Foxtons £505k · Winkworth £515k · Savills £510k" },
      mark:  { value: "£530,000", evidence: "Updated — Savills re-quote" },
      delta: "£25,000 apart · narrowed from £55k",
      ai: "You're closer. Midpoint £517.5k. Impact on final split: ≈ £12.5k each. If agreed, closes 1 of 3 contested items." },
    { id: "deposit-2",   ch: "property", label: "Original 2015 deposit",
      state: "contested",
      sarah: { value: "£40k joint + £20k parents' gift (Sarah)", evidence: "2015 bank transfers" },
      mark:  { value: "£60k joint", evidence: "Recollection only" },
      delta: "Different account of the origin",
      ai: "Low financial impact (≈£20k, 12 years old). Alternative: 'disputed origin, no adjustment made' — often cleaner than litigating." },
    { id: "improvements", ch: "property", label: "Loft conversion (2019)",
      state: "contested",
      sarah: { value: "£42k (Sarah's bonus paid)", evidence: "Builder invoice · bank transfer" },
      mark:  { value: "£42k joint funds", evidence: "Recollection" },
      delta: "Source of funds disputed",
      ai: "Evidence asymmetry: Sarah has a bank transfer showing the payment came from her bonus account. Mark has no evidence for the counter. Evidence-based merit favours Sarah's version." },

    /* PENSIONS */
    { id: "nhs-split",   ch: "pensions", label: "NHS pension — sharing basis",
      state: "contested",
      sarah: { value: "CETV £214k (defined benefit)", evidence: "CETV statement" },
      mark:  { value: "CETV £214k (defined benefit)", evidence: "CETV statement" },
      delta: "Values match · mechanism disputed",
      ai: "You agree on the value. What's disputed is the sharing mechanism: pension-share order vs. offset against housing. Pension-share is usually more robust for defined-benefit schemes." },

    /* INCOME */
    { id: "mark-income-2", ch: "income", label: "Mark — salary & bonus",
      state: "contested",
      sarah: { value: "£78k + bonus ~£12k (from payslip)", evidence: "Nov 2025 payslip attached" },
      mark:  { value: "£78k base, bonus discretionary", evidence: "Recollection" },
      delta: "£12k bonus disputed as 'expected' vs 'discretionary'",
      ai: "Payslip Sarah attached shows bonus paid Nov 2024 and Nov 2025 at £11–13k. Case law (H v H [2014]) treats regular discretionary bonuses as effectively income." }
  ]
};

const CHAPTERS = [
  { k: "property", label: "Property",  icon: "home" },
  { k: "pensions", label: "Pensions",  icon: "piggy" },
  { k: "income",   label: "Income",    icon: "coin" },
  { k: "children", label: "Children",  icon: "users" }
];

/* Handshake states — what Sarah sees when Mark's participation varies */
const HANDSHAKE_STATES = {
  pre_open:     { label: "Mark hasn't opened yet",        color: "#9AA0A6", note: "Invitation sent 14 Nov · Mark hasn't opened the email" },
  opened:       { label: "Mark has opened, hasn't started", color: "#B45309", note: "Mark opened 15 Nov · Hasn't started building his picture" },
  building:     { label: "Mark is building his picture",   color: "#0369A1", note: "Started 16 Nov · 8 of 14 chapters in progress" },
  shared:       { label: "Mark has shared his picture",    color: "#047857", note: "Shared 18 Nov · Full reconciliation unlocked" }
};

/* COMMENT THREADS per item (demo) */
const THREADS = {
  "home": [
    { who: "Mark",  avatar: "M", time: "2 days ago",
      text: "I'm not sure about the 3-valuation average. Savills was the slowest to come back — their 2024 valuation was £560k. Market's soft but not that soft." },
    { who: "Sarah", avatar: "S", time: "yesterday",
      text: "Happy to share all three reports. The Savills 2024 one was during a spike — the 2026 re-quote they just did came in at £510k. Attaching their email." },
    { who: "Sarah", avatar: "S", time: "yesterday", attachment: "Savills-re-quote-Feb2026.pdf" }
  ],
  "deposit": [
    { who: "Sarah", avatar: "S", time: "3 days ago",
      text: "I've dug out the transfer from Mum & Dad — October 2015, £20k. Marked 'gift — house deposit'. Attaching." },
    { who: "Sarah", avatar: "S", time: "3 days ago", attachment: "Parents-deposit-gift-2015.pdf" }
  ],
  "home-2": [
    { who: "Sarah", avatar: "S", time: "1 day ago",
      text: "Savills reran the valuation at £510k in February. Happy to commit to £510k if you will?" },
    { who: "Mark",  avatar: "M", time: "4 hours ago",
      text: "Let me look at the Feb report first. Would prefer to land on £520k if we're averaging with the 2024 figure." }
  ],
  "deposit-2": [
    { who: "Mark",  avatar: "M", time: "2 days ago",
      text: "Honestly, I don't remember your parents contributing. It was all joint savings as far as I can recall." },
    { who: "Sarah", avatar: "S", time: "2 days ago", attachment: "Parents-deposit-gift-2015.pdf" },
    { who: "Sarah", avatar: "S", time: "2 days ago",
      text: "This is the bank transfer — Oct 2015, marked 'gift'. If we can't agree, I'm happy to call it no-adjustment to keep moving." }
  ]
};

Object.assign(window, {
  RC_SCENE_03: SCENE_03,
  RC_SCENE_04: SCENE_04,
  RC_CHAPTERS: CHAPTERS,
  RC_HANDSHAKES: HANDSHAKE_STATES,
  RC_THREADS: THREADS,
  RC_SARAH: SARAH,
  RC_MARK: MARK
});
})();
