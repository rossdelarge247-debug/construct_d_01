/* Reconciliation v2 — components */
(function(){
const { useState, useMemo, useEffect } = React;

const SARAH = window.RC_SARAH;
const MARK  = window.RC_MARK;

/* ================ ICONS ================ */
const Ic = ({ children, size=18, sw=1.75 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">{children}</svg>
);
const IHome = p => <Ic {...p}><path d="M3 11l9-8 9 8"/><path d="M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/></Ic>;
const IPiggy = p => <Ic {...p}><path d="M19 5c-1.5 0-2.8.8-3.5 2H10a7 7 0 0 0-7 7c0 2 1 3.9 2.6 5L5 21h3l1-2h6l1 2h3l-.6-2A7 7 0 0 0 19 14v-2l2-1v-3l-2-1V5z"/><circle cx="16" cy="12" r="1" fill="currentColor" stroke="none"/></Ic>;
const ICoin = p => <Ic {...p}><ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></Ic>;
const IUsers = p => <Ic {...p}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/></Ic>;
const ICheck = p => <Ic {...p}><polyline points="5 12 10 17 19 7"/></Ic>;
const IChevR = p => <Ic {...p}><polyline points="9 6 15 12 9 18"/></Ic>;
const IChevL = p => <Ic {...p}><polyline points="15 6 9 12 15 18"/></Ic>;
const IX = p => <Ic {...p}><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></Ic>;
const IMsg = p => <Ic {...p}><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></Ic>;
const ISparkle = p => <Ic {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/></Ic>;
const IClock = p => <Ic {...p}><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></Ic>;
const IPaper = p => <Ic {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></Ic>;
const IAlert = p => <Ic {...p}><path d="M10.3 3.9 2.5 18a2 2 0 0 0 1.7 3h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><circle cx="12" cy="17" r="0.8" fill="currentColor" stroke="none"/></Ic>;
const IHelp = p => <Ic {...p}><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4"/><circle cx="12" cy="17" r="0.8" fill="currentColor" stroke="none"/></Ic>;
const IMinus = p => <Ic {...p}><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const IPlus = p => <Ic {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const IDoc = p => <Ic {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/></Ic>;

const ICON_MAP = { home: IHome, piggy: IPiggy, coin: ICoin, users: IUsers };

/* ================ STATE METADATA ================ */
const STATE_META = {
  agreed:     { label: "Agreed",     dot: "#047857", bg: "#ECFDF5", fg: "#065F46",  Icon: ICheck },
  contested:  { label: "Contested",  dot: "#B45309", bg: "#FEF3C7", fg: "#92400E",  Icon: IAlert },
  estimated:  { label: "Estimated",  dot: "#6366F1", bg: "#EEF2FF", fg: "#4338CA",  Icon: IClock },
  gap:        { label: "Missing",    dot: "#94A3B8", bg: "#F1F5F9", fg: "#475569",  Icon: IHelp },
  new:        { label: "Newly added",dot: "#0369A1", bg: "#E0F2FE", fg: "#075985",  Icon: IPlus }
};

/* ================ ATOMS ================ */
function Avatar({ who, size=22 }) {
  const color = who === "Sarah" ? SARAH : MARK;
  const letter = who[0];
  return (
    <span className="inline-flex items-center justify-center rounded-full font-semibold text-white"
          style={{ width: size, height: size, background: color, fontSize: size*0.46 }}>
      {letter}
    </span>
  );
}

function StateBadge({ state, compact }) {
  const m = STATE_META[state];
  if (!m) return null;
  const { Icon } = m;
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full"
      style={{
        padding: compact ? "2px 7px" : "3px 9px",
        background: m.bg, color: m.fg,
        fontSize: 10.5, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase"
      }}>
      <Icon size={11} sw={2.2}/>
      <span>{m.label}</span>
    </span>
  );
}

function SectionLabel({ children }) {
  return (
    <div style={{ fontSize: 10.5, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600, color: "#9CA3AF" }}>
      {children}
    </div>
  );
}

/* ================ TOP BAR ================ */
function TopBar({ scene, handshake, onHandshake, selectedId, onClose }) {
  const h = window.RC_HANDSHAKES[handshake];
  return (
    <div className="flex items-center gap-3 px-6 border-b" style={{ height: 56, borderColor: "#E5E3DC", background: "#FFFFFF" }}>
      {/* Scene title */}
      <div className="flex items-center gap-2">
        <span style={{ fontSize: 10.5, letterSpacing: "0.09em", textTransform: "uppercase", fontWeight: 600, color: "#9CA3AF" }}>
          Phase 3 · Reconcile
        </span>
        <span style={{ color: "#D1D5DB" }}>/</span>
        <span style={{ fontSize: 13.5, fontWeight: 600, letterSpacing: "-0.005em" }}>
          {scene.title}
        </span>
      </div>

      <div className="flex-1"/>

      {/* Handshake chip */}
      <button className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 transition"
        onClick={onHandshake}
        style={{ background: "#FAFAF7", border: "1px solid #E5E3DC", cursor: "pointer" }}
        title="Cycle handshake state (demo)">
        <Avatar who="Mark" size={18}/>
        <span style={{ fontSize: 11.5, fontWeight: 500, color: "#1A1A1A" }}>{h.label}</span>
        <span className="inline-block rounded-full" style={{ width: 6, height: 6, background: h.color }}/>
      </button>

      {/* Close */}
      {selectedId && (
        <button className="rounded-md p-1.5 transition" onClick={onClose}
          style={{ background: "transparent" }} title="Close detail">
          <IX size={16}/>
        </button>
      )}
    </div>
  );
}

/* ================ LEFT RAIL (CHAPTERS) ================ */
function ChapterRail({ scene, active, onPick, counts }) {
  const totalAll = window.RC_CHAPTERS.reduce((s, c) => s + (counts[c.k]?.total || 0), 0);
  const contestedAll = window.RC_CHAPTERS.reduce((s, c) => s + (counts[c.k]?.contested || 0), 0);
  const gapAll = window.RC_CHAPTERS.reduce((s, c) => s + (counts[c.k]?.gap || 0), 0);
  const allActive = active === "all";
  return (
    <div className="flex flex-col gap-0.5 py-4 px-3" style={{ width: 224, borderRight: "1px solid #E5E3DC", background: "#FBFBF8" }}>
      <SectionLabel>Chapters</SectionLabel>
      <div className="mt-2 flex flex-col gap-0.5">
        {/* ALL */}
        <button onClick={() => onPick("all")}
          className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg transition text-left"
          style={{
            background: allActive ? "#FFFFFF" : "transparent",
            border: allActive ? "1px solid #E5E3DC" : "1px solid transparent",
            boxShadow: allActive ? "0 1px 2px rgba(0,0,0,0.03)" : "none"
          }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 22 8.5 12 15 2 8.5 12 2"/>
            <polyline points="2 15.5 12 22 22 15.5"/>
            <polyline points="2 12 12 18.5 22 12" opacity="0.4"/>
          </svg>
          <span style={{ fontSize: 13, fontWeight: allActive ? 600 : 500, color: "#1A1A1A" }}>All chapters</span>
          <span className="ml-auto" style={{ fontSize: 11, color: "#9CA3AF", fontVariantNumeric: "tabular-nums" }}>{totalAll}</span>
          {(contestedAll > 0 || gapAll > 0) && (
            <span className="inline-block rounded-full" style={{
              width: 6, height: 6,
              background: contestedAll > 0 ? "#B45309" : "#94A3B8"
            }}/>
          )}
        </button>

        {/* separator */}
        <div className="my-1 mx-2" style={{ height: 1, background: "#EEEBE2" }}/>

        {window.RC_CHAPTERS.map(c => {
          const Icon = ICON_MAP[c.icon];
          const is = active === c.k;
          const cnt = counts[c.k] || { total: 0, contested: 0, gap: 0 };
          return (
            <button key={c.k} onClick={() => onPick(c.k)}
              className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg transition text-left"
              style={{
                background: is ? "#FFFFFF" : "transparent",
                border: is ? "1px solid #E5E3DC" : "1px solid transparent",
                boxShadow: is ? "0 1px 2px rgba(0,0,0,0.03)" : "none"
              }}>
              <Icon size={15} sw={1.8}/>
              <span style={{ fontSize: 13, fontWeight: is ? 600 : 500, color: "#1A1A1A" }}>{c.label}</span>
              <span className="ml-auto" style={{ fontSize: 11, color: "#9CA3AF", fontVariantNumeric: "tabular-nums" }}>
                {cnt.total}
              </span>
              {(cnt.contested > 0 || cnt.gap > 0) && (
                <span className="inline-block rounded-full" style={{
                  width: 6, height: 6,
                  background: cnt.contested > 0 ? "#B45309" : "#94A3B8"
                }}/>
              )}
            </button>
          );
        })}
      </div>

      <div className="mt-8">
        <SectionLabel>Status filter</SectionLabel>
        <StatusFilterLegend/>
      </div>

      <div className="mt-auto pt-4 border-t" style={{ borderColor: "#EEEBE2" }}>
        <div style={{ fontSize: 11, color: "#57534E", lineHeight: 1.5 }}>
          Items here are auto-merged from both pictures. Nothing is final until you both agree in Phase 4.
        </div>
      </div>
    </div>
  );
}

function StatusFilterLegend() {
  const rows = [
    ["agreed",    "Both agree"],
    ["contested", "You disagree"],
    ["estimated", "Best guess"],
    ["gap",       "Missing data"],
    ["new",       "Just added"]
  ];
  return (
    <div className="mt-2 flex flex-col gap-1">
      {rows.map(([k, l]) => {
        const m = STATE_META[k];
        return (
          <div key={k} className="flex items-center gap-2 px-2 py-1">
            <span className="inline-block rounded-full" style={{ width: 7, height: 7, background: m.dot }}/>
            <span style={{ fontSize: 11.5, color: "#374151" }}>{l}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ================ HANDSHAKE WAITING STATE ================ */
function HandshakeWaiting({ handshake }) {
  const h = window.RC_HANDSHAKES[handshake];
  return (
    <div className="flex-1 flex items-center justify-center px-12" style={{ background: "#FBFBF8" }}>
      <div className="max-w-xl text-center">
        <div className="flex items-center justify-center gap-4 mb-6">
          <Avatar who="Sarah" size={56}/>
          <div className="flex gap-1">
            <span style={{ width: 6, height: 6, background: "#E5E3DC", borderRadius: 999, display: "inline-block" }}/>
            <span style={{ width: 6, height: 6, background: "#E5E3DC", borderRadius: 999, display: "inline-block" }}/>
            <span style={{ width: 6, height: 6, background: "#E5E3DC", borderRadius: 999, display: "inline-block" }}/>
          </div>
          <Avatar who="Mark" size={56}/>
        </div>
        <h2 className="font-semibold mb-2" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>
          {handshake === "pre_open"   && "Waiting for Mark to join"}
          {handshake === "opened"     && "Mark has opened, hasn't started"}
          {handshake === "building"   && "Mark is building his picture"}
        </h2>
        <p style={{ fontSize: 14.5, color: "#57534E", lineHeight: 1.55 }}>
          Reconciliation opens as soon as Mark shares his picture. Until then, you can keep refining yours — nothing is locked, nothing is sent to him.
        </p>

        <div className="mt-6 p-4 rounded-xl text-left" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC" }}>
          <div className="flex items-center gap-2 mb-2">
            <span className="inline-block rounded-full" style={{ width: 8, height: 8, background: h.color }}/>
            <span style={{ fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", color: "#57534E" }}>
              Mark's status
            </span>
          </div>
          <div style={{ fontSize: 13, color: "#1A1A1A", lineHeight: 1.5 }}>{h.note}</div>
          {handshake === "pre_open" && (
            <div className="mt-3 flex gap-2">
              <button className="px-3 py-1.5 rounded-md text-white font-medium" style={{ background: "#1A1A1A", fontSize: 12 }}>Nudge Mark</button>
              <button className="px-3 py-1.5 rounded-md font-medium" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC", fontSize: 12 }}>Resend invite</button>
            </div>
          )}
          {handshake === "building" && (
            <div className="mt-3">
              <div className="flex items-center justify-between mb-1">
                <span style={{ fontSize: 11.5, color: "#57534E" }}>Mark's progress</span>
                <span style={{ fontSize: 11.5, fontWeight: 600 }}>8 / 14</span>
              </div>
              <div className="rounded-full" style={{ height: 6, background: "#F1F5F9", overflow: "hidden" }}>
                <div style={{ width: "57%", height: "100%", background: MARK, borderRadius: 999 }}/>
              </div>
            </div>
          )}
        </div>

        <p className="mt-6" style={{ fontSize: 12, color: "#78716C" }}>
          You'll get a notification when Mark shares.
        </p>
      </div>
    </div>
  );
}

/* ================ ITEM LIST (MIDDLE) ================ */
function ItemList({ items, selectedId, onSelect, chapterLabel }) {
  return (
    <div className="flex-1 flex flex-col min-w-0" style={{ background: "#FBFBF8" }}>
      <div className="px-6 pt-5 pb-3 flex items-center gap-3 border-b" style={{ borderColor: "#EEEBE2" }}>
        <h2 className="font-semibold" style={{ fontSize: 16, letterSpacing: "-0.005em" }}>{chapterLabel}</h2>
        <span style={{ fontSize: 12, color: "#9CA3AF" }}>{items.length} items</span>
      </div>

      <div className="flex-1 overflow-auto nice-scroll">
        <ul className="divide-y" style={{ borderColor: "#EEEBE2" }}>
          {items.map(it => (
            <ItemRow key={it.id} item={it} selected={selectedId === it.id} onSelect={() => onSelect(it.id)}/>
          ))}
        </ul>
      </div>
    </div>
  );
}

function ItemRow({ item, selected, onSelect }) {
  const m = STATE_META[item.state];
  return (
    <li>
      <button onClick={onSelect}
        className="w-full text-left px-6 py-3.5 transition flex items-start gap-4 relative"
        style={{
          background: selected ? "#FFFFFF" : "transparent",
          borderLeft: selected ? `3px solid ${m.dot}` : "3px solid transparent"
        }}>
        {/* Label + meta */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span style={{ fontSize: 13.5, fontWeight: 500, color: "#1A1A1A" }}>{item.label}</span>
            <StateBadge state={item.state} compact/>
          </div>

          {/* State-specific secondary line */}
          <div className="mt-1" style={{ fontSize: 12, color: "#57534E" }}>
            {item.state === "agreed" && (
              <span>
                <span className="font-semibold" style={{ color: "#1A1A1A" }}>{item.agreedValue}</span>
                {item.evidence && <span> · {item.evidence}</span>}
              </span>
            )}
            {item.state === "contested" && (
              <span className="flex items-center gap-2 flex-wrap">
                <span className="inline-flex items-center gap-1">
                  <Avatar who="Sarah" size={14}/>
                  <span style={{ fontWeight: 600, color: SARAH }}>{item.sarah.value}</span>
                </span>
                <span style={{ color: "#D1D5DB" }}>vs</span>
                <span className="inline-flex items-center gap-1">
                  <Avatar who="Mark" size={14}/>
                  <span style={{ fontWeight: 600, color: MARK }}>{item.mark.value}</span>
                </span>
                <span style={{ color: "#9CA3AF" }}>· {item.delta}</span>
              </span>
            )}
            {item.state === "estimated" && (
              <span>
                <span className="font-semibold" style={{ color: "#1A1A1A" }}>{item.value}</span>
                <span> · estimated by {item.estBy}</span>
              </span>
            )}
            {item.state === "gap" && (
              <span>Missing from {item.missingFrom}</span>
            )}
            {item.state === "new" && (
              <span>
                <span className="font-semibold" style={{ color: "#1A1A1A" }}>{item.newValue}</span>
                <span> · {item.newOn}</span>
              </span>
            )}
          </div>

          {/* AI nudge */}
          {item.ai && (
            <div className="mt-2 rounded-md flex gap-2 pl-3 py-1.5 pr-3"
              style={{ borderLeft: "2px solid #6366F1", background: "rgba(99,102,241,0.04)" }}>
              <ISparkle size={12} sw={2}/>
              <span style={{ fontSize: 11.5, color: "#4338CA", lineHeight: 1.45 }}>{item.ai}</span>
            </div>
          )}
        </div>

        <IChevR size={16} sw={1.6} />
      </button>
    </li>
  );
}

/* ================ RIGHT DETAIL PANEL ================ */
function DetailPanel({ item, onOpenThread }) {
  if (!item) return <DetailEmpty/>;
  const threadCount = (window.RC_THREADS[item.id] || []).length;

  return (
    <div className="flex flex-col h-full overflow-auto nice-scroll" style={{ background: "#FFFFFF", borderLeft: "1px solid #E5E3DC" }}>
      {/* Header */}
      <div className="px-6 pt-5 pb-4 border-b" style={{ borderColor: "#EEEBE2" }}>
        <div className="flex items-center gap-2 mb-2">
          <StateBadge state={item.state}/>
          {item.ai && (
            <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5"
              style={{ background: "#EEF2FF", color: "#4338CA", fontSize: 10, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase" }}>
              <ISparkle size={9} sw={2.2}/> AI note
            </span>
          )}
        </div>
        <h3 className="font-semibold" style={{ fontSize: 18, letterSpacing: "-0.01em", lineHeight: 1.25 }}>{item.label}</h3>
      </div>

      {/* Body */}
      <div className="px-6 py-5 flex-1">
        {item.state === "contested" && <ContestedBody item={item}/>}
        {item.state === "agreed"    && <AgreedBody item={item}/>}
        {item.state === "estimated" && <EstimatedBody item={item}/>}
        {item.state === "gap"       && <GapBody item={item}/>}
        {item.state === "new"       && <NewBody item={item}/>}

        {item.ai && (
          <div className="mt-6 rounded-lg p-4" style={{ background: "#FBFBF8", borderLeft: "3px solid #6366F1" }}>
            <div className="flex items-center gap-1.5 mb-1.5">
              <ISparkle size={12} sw={2.2}/>
              <span style={{ fontSize: 10.5, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600, color: "#4338CA" }}>AI parity check</span>
            </div>
            <div style={{ fontSize: 13, color: "#1A1A1A", lineHeight: 1.55 }}>{item.ai}</div>
            <div className="mt-3 flex gap-2">
              <button className="text-white px-2.5 py-1 rounded-md font-medium" style={{ background: "#1A1A1A", fontSize: 11.5 }}>Apply suggestion</button>
              <button className="px-2.5 py-1 rounded-md font-medium" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC", fontSize: 11.5 }}>Dismiss</button>
            </div>
          </div>
        )}
      </div>

      {/* Footer actions */}
      <div className="px-6 py-4 border-t flex items-center gap-2" style={{ borderColor: "#EEEBE2", background: "#FBFBF8" }}>
        <button onClick={onOpenThread} className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium"
          style={{ background: "#FFFFFF", border: "1px solid #E5E3DC", fontSize: 12 }}>
          <IMsg size={13}/>
          Open conversation
          {threadCount > 0 && <span className="ml-1 rounded-full px-1.5 py-px" style={{ background: "#1A1A1A", color: "#FFF", fontSize: 10 }}>{threadCount}</span>}
        </button>
        <div className="flex-1"/>
        {item.state === "contested" && (
          <>
            <button className="px-3 py-1.5 rounded-md font-medium" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC", fontSize: 12 }}>Propose midpoint</button>
            <button className="text-white px-3 py-1.5 rounded-md font-medium" style={{ background: "#1A1A1A", fontSize: 12 }}>Mark agreed</button>
          </>
        )}
        {item.state === "gap" && (
          <button className="text-white px-3 py-1.5 rounded-md font-medium" style={{ background: "#1A1A1A", fontSize: 12 }}>Request from Mark</button>
        )}
        {item.state === "estimated" && (
          <button className="text-white px-3 py-1.5 rounded-md font-medium" style={{ background: "#1A1A1A", fontSize: 12 }}>Attach evidence</button>
        )}
      </div>
    </div>
  );
}

function DetailEmpty() {
  return (
    <div className="h-full flex flex-col items-center justify-center px-10 text-center" style={{ background: "#FFFFFF", borderLeft: "1px solid #E5E3DC" }}>
      <div className="rounded-full p-3 mb-4" style={{ background: "#FBFBF8", border: "1px solid #E5E3DC" }}>
        <IPaper size={20}/>
      </div>
      <div style={{ fontSize: 14, fontWeight: 600, color: "#1A1A1A" }}>Select an item</div>
      <div className="mt-1" style={{ fontSize: 12.5, color: "#78716C", lineHeight: 1.5 }}>
        Pick any row to see both sides, evidence, and the path to agreement.
      </div>
    </div>
  );
}

function Pane({ who, value, evidence, note }) {
  const color = who === "Sarah" ? SARAH : MARK;
  return (
    <div className="rounded-lg p-4 flex-1" style={{ background: "#FBFBF8", border: `1px solid ${color}22`, borderTop: `3px solid ${color}` }}>
      <div className="flex items-center gap-2 mb-2.5">
        <Avatar who={who} size={20}/>
        <span style={{ fontSize: 12, fontWeight: 600, color }}>{who}</span>
      </div>
      <div className="font-semibold" style={{ fontSize: 18, letterSpacing: "-0.005em", color: "#1A1A1A" }}>{value}</div>
      {evidence && (
        <div className="mt-2 inline-flex items-center gap-1.5 rounded-md px-2 py-1" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC" }}>
          <IDoc size={11}/>
          <span style={{ fontSize: 11, color: "#57534E" }}>{evidence}</span>
        </div>
      )}
      {note && <div className="mt-2.5" style={{ fontSize: 12, color: "#57534E", lineHeight: 1.5 }}>{note}</div>}
    </div>
  );
}

function ContestedBody({ item }) {
  return (
    <div>
      <div className="mb-2">
        <SectionLabel>Side-by-side</SectionLabel>
      </div>
      <div className="flex gap-3">
        <Pane who="Sarah" {...item.sarah}/>
        <Pane who="Mark"  {...item.mark}/>
      </div>
      <div className="mt-3 rounded-md p-2.5 flex items-center gap-2" style={{ background: "#FEF3C7" }}>
        <IAlert size={13} sw={2}/>
        <span style={{ fontSize: 12, color: "#92400E", fontWeight: 500 }}>{item.delta}</span>
      </div>
    </div>
  );
}

function AgreedBody({ item }) {
  return (
    <div>
      <div className="mb-2"><SectionLabel>Agreed value</SectionLabel></div>
      <div className="rounded-lg p-4" style={{ background: "#ECFDF5", border: "1px solid #A7F3D0" }}>
        <div className="flex items-center gap-3">
          <div className="flex gap-1">
            <Avatar who="Sarah" size={22}/>
            <Avatar who="Mark"  size={22}/>
          </div>
          <div className="font-semibold" style={{ fontSize: 22, letterSpacing: "-0.01em", color: "#065F46" }}>{item.agreedValue}</div>
        </div>
        {item.evidence && <div className="mt-2" style={{ fontSize: 12, color: "#065F46" }}>{item.evidence}</div>}
      </div>
    </div>
  );
}

function EstimatedBody({ item }) {
  return (
    <div>
      <div className="mb-2"><SectionLabel>Current estimate</SectionLabel></div>
      <div className="rounded-lg p-4" style={{ background: "#FBFBF8", border: "1px solid #E5E3DC" }}>
        <div className="flex items-center gap-2 mb-1">
          <Avatar who={item.estBy} size={18}/>
          <span style={{ fontSize: 11.5, color: "#57534E" }}>Estimated by {item.estBy}</span>
        </div>
        <div className="font-semibold" style={{ fontSize: 22, letterSpacing: "-0.01em" }}>{item.value}</div>
        {item.note && <div className="mt-2" style={{ fontSize: 12.5, color: "#57534E", lineHeight: 1.5 }}>{item.note}</div>}
      </div>
    </div>
  );
}

function GapBody({ item }) {
  return (
    <div>
      <div className="mb-2"><SectionLabel>Missing data</SectionLabel></div>
      <div className="rounded-lg p-4" style={{ background: "#F8FAFC", border: "1px dashed #CBD5E1" }}>
        <div style={{ fontSize: 13.5, color: "#1A1A1A", lineHeight: 1.5 }}>
          {item.missingFrom === "Both"
            ? "Neither of you has entered a value here."
            : <>This item is in your picture but missing from <span style={{ color: MARK, fontWeight: 600 }}>Mark's</span>.</>
          }
        </div>
      </div>
    </div>
  );
}

function NewBody({ item }) {
  return (
    <div>
      <div className="mb-2"><SectionLabel>Newly added by {item.who}</SectionLabel></div>
      <div className="rounded-lg p-4" style={{ background: "#E0F2FE", border: "1px solid #7DD3FC" }}>
        <div className="flex items-center gap-3 mb-1">
          <Avatar who={item.who} size={20}/>
          <span style={{ fontSize: 11.5, color: "#075985" }}>{item.newOn}</span>
        </div>
        <div className="font-semibold" style={{ fontSize: 22, letterSpacing: "-0.01em", color: "#075985" }}>{item.newValue}</div>
        <div className="mt-2" style={{ fontSize: 12.5, color: "#075985", lineHeight: 1.5 }}>
          This wasn't in your picture — confirm whether to include it, and whether you've got your own record.
        </div>
      </div>
    </div>
  );
}

/* ================ COMMENT DRAWER ================ */
function CommentDrawer({ item, onClose }) {
  const [draft, setDraft] = useState("");
  if (!item) return null;
  const thread = window.RC_THREADS[item.id] || [];

  return (
    <>
      <div className="absolute inset-0" style={{ background: "rgba(10,10,10,0.18)", zIndex: 40 }} onClick={onClose}/>
      <aside className="absolute top-0 right-0 bottom-0 flex flex-col"
        style={{ width: 420, background: "#FFFFFF", borderLeft: "1px solid #E5E3DC", zIndex: 50, boxShadow: "-12px 0 32px rgba(0,0,0,0.08)" }}>

        <div className="px-5 pt-4 pb-3 border-b flex items-center gap-2" style={{ borderColor: "#EEEBE2" }}>
          <div className="flex-1 min-w-0">
            <SectionLabel>Conversation on</SectionLabel>
            <div className="truncate mt-0.5" style={{ fontSize: 14, fontWeight: 600 }}>{item.label}</div>
          </div>
          <button onClick={onClose} className="rounded-md p-1.5" style={{ background: "transparent" }}><IX size={16}/></button>
        </div>

        <div className="flex-1 overflow-auto nice-scroll px-5 py-4 flex flex-col gap-3">
          {thread.length === 0 && (
            <div className="rounded-lg p-4 text-center" style={{ background: "#FBFBF8", border: "1px dashed #E5E3DC" }}>
              <div style={{ fontSize: 13, color: "#57534E" }}>No messages yet.</div>
              <div className="mt-1" style={{ fontSize: 12, color: "#9CA3AF" }}>Start a conversation with Mark about this item.</div>
            </div>
          )}
          {thread.map((msg, i) => {
            const color = msg.who === "Sarah" ? SARAH : MARK;
            return (
              <div key={i} className="flex gap-2.5">
                <Avatar who={msg.who} size={28}/>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span style={{ fontSize: 12.5, fontWeight: 600, color }}>{msg.who}</span>
                    <span style={{ fontSize: 11, color: "#9CA3AF" }}>{msg.time}</span>
                  </div>
                  {msg.text && (
                    <div className="rounded-lg px-3 py-2" style={{ background: "#FBFBF8", border: "1px solid #EEEBE2", fontSize: 13, color: "#1A1A1A", lineHeight: 1.5 }}>
                      {msg.text}
                    </div>
                  )}
                  {msg.attachment && (
                    <div className="mt-1.5 inline-flex items-center gap-2 rounded-lg px-3 py-2"
                      style={{ background: "#FFFFFF", border: "1px solid #E5E3DC" }}>
                      <IPaper size={13}/>
                      <span style={{ fontSize: 12, color: "#1A1A1A", fontWeight: 500 }}>{msg.attachment}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="px-5 py-3 border-t" style={{ borderColor: "#EEEBE2" }}>
          <div className="flex gap-2 items-end">
            <textarea
              value={draft} onChange={e => setDraft(e.target.value)}
              placeholder="Write to Mark..."
              rows={2}
              className="flex-1 rounded-lg px-3 py-2 resize-none"
              style={{ background: "#FBFBF8", border: "1px solid #E5E3DC", fontSize: 13, fontFamily: "inherit", outline: "none" }}/>
            <button className="text-white px-3 py-2 rounded-lg font-medium"
              style={{ background: "#1A1A1A", fontSize: 12 }}>Send</button>
          </div>
          <div className="mt-2 flex items-center gap-2 text-[11px]" style={{ color: "#78716C" }}>
            <IMsg size={11}/>
            <span>Mark will see this next time he opens reconciliation.</span>
          </div>
        </div>
      </aside>
    </>
  );
}

/* ================ SUMMARY STRIP (top of list) ================ */
function SummaryStrip({ scene, onFilter, filter, counts }) {
  const all = scene.items;
  const by = {
    agreed:    all.filter(i => i.state === "agreed").length,
    contested: all.filter(i => i.state === "contested").length,
    estimated: all.filter(i => i.state === "estimated").length,
    gap:       all.filter(i => i.state === "gap").length,
    new:       all.filter(i => i.state === "new").length
  };
  const total = all.length;
  const agreedPct = Math.round(100 * by.agreed / total);

  return (
    <div className="px-6 pt-4 pb-3 flex flex-col gap-3" style={{ background: "#FFFFFF", borderBottom: "1px solid #EEEBE2" }}>
      {/* Progress — full row */}
      <div className="flex items-center gap-3">
        <span className="font-semibold" style={{ fontSize: 20, letterSpacing: "-0.01em" }}>{agreedPct}%</span>
        <span style={{ fontSize: 12, color: "#78716C" }}>agreed</span>
        <div className="flex-1 min-w-0 flex rounded-full overflow-hidden" style={{ height: 6, background: "#F1F5F9" }}>
          {["agreed","contested","estimated","new","gap"].map(k => {
            const w = (by[k] / total) * 100;
            if (!w) return null;
            return <div key={k} style={{ width: `${w}%`, background: STATE_META[k].dot }}/>;
          })}
        </div>
      </div>

      {/* Counts — wrap-friendly chips */}
      <div className="flex items-center gap-1.5 flex-wrap">
        {["contested","gap","estimated","new","agreed"].map(k => {
          const m = STATE_META[k];
          const c = by[k];
          const active = filter === k;
          return (
            <button key={k} onClick={() => onFilter(active ? null : k)}
              className="flex items-center gap-1.5 px-2 py-1 rounded-md transition"
              style={{
                background: active ? m.bg : "transparent",
                cursor: c > 0 ? "pointer" : "default",
                opacity: c > 0 ? 1 : 0.4
              }}>
              <span className="inline-block rounded-full" style={{ width: 7, height: 7, background: m.dot }}/>
              <span className="font-semibold" style={{ fontSize: 12.5, color: "#1A1A1A", fontVariantNumeric: "tabular-nums" }}>{c}</span>
              <span style={{ fontSize: 11, color: "#57534E" }}>{m.label.toLowerCase()}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

Object.assign(window, {
  RC_TopBar: TopBar,
  RC_ChapterRail: ChapterRail,
  RC_HandshakeWaiting: HandshakeWaiting,
  RC_ItemList: ItemList,
  RC_DetailPanel: DetailPanel,
  RC_CommentDrawer: CommentDrawer,
  RC_SummaryStrip: SummaryStrip,
  RC_STATE_META: STATE_META
});
})();
