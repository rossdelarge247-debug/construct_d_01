/* Reconciliation v2 — shell (expanded card list, not list/detail) */
(function(){
const { useState, useMemo, useEffect, useRef } = React;
const SARAH = window.RC_SARAH, MARK = window.RC_MARK;

const { RC_TopBar, RC_ChapterRail, RC_HandshakeWaiting, RC_SummaryStrip, RC_STATE_META } = window;

const HANDSHAKE_ORDER = ["pre_open", "opened", "building", "shared"];
const SCENE_KEYS = ["03", "04"];

/* ========== icons ========== */
function Ic({ children, size=14, sw=1.8 }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round">{children}</svg>;
}
const ISpark  = p => <Ic {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M6 18l2.5-2.5M15.5 8.5L18 6"/></Ic>;
const IDoc    = p => <Ic {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></Ic>;
const IAlert  = p => <Ic {...p}><path d="M10.3 3.9 2.5 18a2 2 0 0 0 1.7 3h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><circle cx="12" cy="17" r="0.8" fill="currentColor" stroke="none"/></Ic>;
const IMsg    = p => <Ic {...p}><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></Ic>;

function Avatar({ who, size=22 }) {
  const color = who === "Sarah" ? SARAH : MARK;
  return (
    <span className="inline-flex items-center justify-center rounded-full font-semibold text-white"
          style={{ width: size, height: size, background: color, fontSize: size*0.46 }}>
      {who[0]}
    </span>
  );
}

function StateChip({ state }) {
  const m = window.RC_STATE_META[state];
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full"
      style={{ padding: "2px 8px", background: m.bg, color: m.fg,
               fontSize: 10, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase" }}>
      <span className="inline-block rounded-full" style={{ width: 5, height: 5, background: m.dot }}/>
      {m.label}
    </span>
  );
}

/* ====================================================================
   ITEM CARD — always renders full content. Focused state just highlights.
   ==================================================================== */
function ItemCard({ item, focused, dim, onFocus, threadCount }) {
  const cardRef = useRef(null);
  useEffect(() => {
    if (focused && cardRef.current) {
      cardRef.current.scrollIntoView({ block: "nearest", behavior: "smooth" });
    }
  }, [focused]);

  return (
    <article ref={cardRef}
      onClick={onFocus}
      className="rounded-xl transition cursor-pointer"
      style={{
        background: "#FFFFFF",
        border: focused ? "1px solid #1A1A1A" : "1px solid #EEEBE2",
        boxShadow: focused ? "0 2px 14px rgba(0,0,0,0.07)" : "none",
        opacity: dim ? 0.5 : 1,
        transition: "opacity 180ms, box-shadow 180ms, border-color 180ms"
      }}>
      {/* Header row */}
      <div className="px-5 pt-4 pb-3 flex items-center gap-3 border-b" style={{ borderColor: "#F4F1E9" }}>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-semibold" style={{ fontSize: 15, letterSpacing: "-0.005em", color: "#1A1A1A" }}>{item.label}</h3>
            <StateChip state={item.state}/>
            {item.ai && (
              <span className="inline-flex items-center gap-1 rounded-full px-1.5 py-0.5"
                style={{ background: "#EEF2FF", color: "#4338CA", fontSize: 9.5, fontWeight: 600, letterSpacing: "0.05em", textTransform: "uppercase" }}>
                <ISpark size={8} sw={2.2}/> AI
              </span>
            )}
          </div>
          {item.delta && (
            <div className="mt-1" style={{ fontSize: 11.5, color: "#92400E" }}>{item.delta}</div>
          )}
        </div>
      </div>

      {/* Body — state-specific content */}
      <div className="px-5 py-4">
        {item.state === "contested" && <ContestedBody item={item}/>}
        {item.state === "agreed"    && <AgreedBody item={item}/>}
        {item.state === "estimated" && <EstimatedBody item={item}/>}
        {item.state === "gap"       && <GapBody item={item}/>}
        {item.state === "new"       && <NewBody item={item}/>}
      </div>

      {/* AI nudge (subtle, always visible) */}
      {item.ai && (
        <div className="mx-5 mb-4 rounded-lg p-3" style={{ background: "#FBFBF8", borderLeft: "2px solid #6366F1" }}>
          <div className="flex items-start gap-2">
            <ISpark size={11} sw={2.2}/>
            <div style={{ fontSize: 12, color: "#4338CA", lineHeight: 1.5 }}>{item.ai}</div>
          </div>
        </div>
      )}

      {/* Action row — only on focused card */}
      {focused && (
        <div className="px-5 py-3 border-t flex items-center gap-2 flex-wrap" style={{ borderColor: "#F4F1E9", background: "#FBFBF8" }}>
          <span style={{ fontSize: 10.5, letterSpacing: "0.09em", textTransform: "uppercase", fontWeight: 600, color: "#9CA3AF", marginRight: 4 }}>
            Actions
          </span>
          <ActionButtons state={item.state}/>
          <div className="flex-1"/>
          <span className="inline-flex items-center gap-1" style={{ fontSize: 11.5, color: "#57534E" }}>
            <IMsg size={11}/>
            {threadCount > 0 ? `${threadCount} message${threadCount > 1 ? "s" : ""} →` : "Start conversation →"}
          </span>
        </div>
      )}
    </article>
  );
}

/* state-specific bodies — compact versions for card grid */
function Pane({ who, value, evidence, note, compact }) {
  const color = who === "Sarah" ? SARAH : MARK;
  return (
    <div className="rounded-lg p-3.5 flex-1 min-w-0" style={{ background: "#FBFBF8", border: `1px solid ${color}22`, borderTop: `3px solid ${color}` }}>
      <div className="flex items-center gap-2 mb-2">
        <Avatar who={who} size={18}/>
        <span style={{ fontSize: 11, fontWeight: 600, color }}>{who}</span>
      </div>
      <div className="font-semibold" style={{ fontSize: 16, letterSpacing: "-0.005em", color: "#1A1A1A", lineHeight: 1.25 }}>{value}</div>
      {evidence && (
        <div className="mt-2 inline-flex items-center gap-1.5 rounded-md px-2 py-0.5" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC" }}>
          <IDoc size={10}/>
          <span style={{ fontSize: 10.5, color: "#57534E" }}>{evidence}</span>
        </div>
      )}
      {note && <div className="mt-2" style={{ fontSize: 11.5, color: "#57534E", lineHeight: 1.45 }}>{note}</div>}
    </div>
  );
}
function ContestedBody({ item }) {
  return (
    <div className="flex gap-3">
      <Pane who="Sarah" {...item.sarah}/>
      <Pane who="Mark"  {...item.mark}/>
    </div>
  );
}
function AgreedBody({ item }) {
  return (
    <div className="rounded-lg p-3.5 flex items-center gap-4" style={{ background: "#ECFDF5", border: "1px solid #A7F3D0" }}>
      <div className="flex gap-1">
        <Avatar who="Sarah" size={22}/>
        <Avatar who="Mark" size={22}/>
      </div>
      <div>
        <div className="font-semibold" style={{ fontSize: 20, letterSpacing: "-0.01em", color: "#065F46", lineHeight: 1.1 }}>{item.agreedValue}</div>
        {item.evidence && <div className="mt-1" style={{ fontSize: 11.5, color: "#065F46" }}>{item.evidence}</div>}
      </div>
    </div>
  );
}
function EstimatedBody({ item }) {
  return (
    <div className="rounded-lg p-3.5" style={{ background: "#FBFBF8", border: "1px solid #E5E3DC" }}>
      <div className="flex items-center gap-2 mb-1">
        <Avatar who={item.estBy} size={18}/>
        <span style={{ fontSize: 11, color: "#57534E" }}>Estimated by {item.estBy}</span>
      </div>
      <div className="font-semibold" style={{ fontSize: 20, letterSpacing: "-0.01em", lineHeight: 1.1 }}>{item.value}</div>
      {item.note && <div className="mt-2" style={{ fontSize: 11.5, color: "#57534E", lineHeight: 1.5 }}>{item.note}</div>}
    </div>
  );
}
function GapBody({ item }) {
  return (
    <div className="rounded-lg p-3.5" style={{ background: "#F8FAFC", border: "1px dashed #CBD5E1" }}>
      <div style={{ fontSize: 12.5, color: "#475569", lineHeight: 1.5 }}>
        {item.missingFrom === "Both"
          ? "Neither of you has entered a value here."
          : <>This item is in your picture but missing from <span style={{ color: MARK, fontWeight: 600 }}>Mark's</span>.</>}
      </div>
    </div>
  );
}
function NewBody({ item }) {
  return (
    <div className="rounded-lg p-3.5" style={{ background: "#E0F2FE", border: "1px solid #7DD3FC", borderTop: "3px solid #0369A1" }}>
      <div className="flex items-center gap-2 mb-1">
        <Avatar who={item.who} size={18}/>
        <span style={{ fontSize: 11, color: "#075985" }}>{item.newOn}</span>
      </div>
      <div className="font-semibold" style={{ fontSize: 20, letterSpacing: "-0.01em", color: "#075985", lineHeight: 1.1 }}>{item.newValue}</div>
    </div>
  );
}

function ActionButtons({ state }) {
  const pri = "text-white px-2.5 py-1 rounded-md font-medium";
  const sec = "px-2.5 py-1 rounded-md font-medium";
  const priStyle = { background: "#1A1A1A", fontSize: 11.5 };
  const secStyle = { background: "#FFFFFF", border: "1px solid #E5E3DC", fontSize: 11.5 };
  switch (state) {
    case "contested": return <>
      <button className={pri} style={priStyle} onClick={e=>e.stopPropagation()}>Mark agreed</button>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Propose midpoint</button>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Request evidence</button>
    </>;
    case "agreed": return <>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Reopen</button>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Update evidence</button>
    </>;
    case "estimated": return <>
      <button className={pri} style={priStyle} onClick={e=>e.stopPropagation()}>Attach evidence</button>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Ask Mark to confirm</button>
    </>;
    case "gap": return <>
      <button className={pri} style={priStyle} onClick={e=>e.stopPropagation()}>Request from Mark</button>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Confirm £0 / N/A</button>
    </>;
    case "new": return <>
      <button className={pri} style={priStyle} onClick={e=>e.stopPropagation()}>Add to my picture</button>
      <button className={sec} style={secStyle} onClick={e=>e.stopPropagation()}>Ask for evidence</button>
    </>;
    default: return null;
  }
}

/* ====================================================================
   MAIN CARD LIST (center column)
   ==================================================================== */
function CardList({ items, chapterLabel, groupByChapter, focusedId, onFocus, threadCounts }) {
  // Group by chapter, preserving chapter order from RC_CHAPTERS
  const grouped = useMemo(() => {
    if (!groupByChapter) return null;
    const order = window.RC_CHAPTERS.map(c => c.k);
    const byCh = {};
    items.forEach(it => { (byCh[it.ch] = byCh[it.ch] || []).push(it); });
    return order
      .filter(k => byCh[k] && byCh[k].length)
      .map(k => ({ k, label: window.RC_CHAPTERS.find(c => c.k === k).label, items: byCh[k] }));
  }, [items, groupByChapter]);

  return (
    <div className="flex-1 flex flex-col min-w-0 overflow-hidden" style={{ background: "#FBFBF8" }}>
      <div className="px-6 pt-4 pb-2 flex items-center gap-3" style={{ background: "#FFFFFF", borderBottom: "1px solid #EEEBE2" }}>
        <h2 className="font-semibold" style={{ fontSize: 15, letterSpacing: "-0.005em" }}>{chapterLabel}</h2>
        <span style={{ fontSize: 11.5, color: "#9CA3AF" }}>{items.length} item{items.length !== 1 ? "s" : ""}</span>
      </div>
      <div className="flex-1 overflow-auto nice-scroll">
        <div className="px-5 py-5 flex flex-col gap-3">
          {groupByChapter ? (
            grouped.map((g, gi) => (
              <div key={g.k} className="flex flex-col gap-3" style={{ marginTop: gi === 0 ? 0 : 10 }}>
                <div className="flex items-center gap-2 px-1" style={{ paddingTop: 4 }}>
                  <span style={{ fontSize: 10.5, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600, color: "#78716C" }}>{g.label}</span>
                  <span style={{ fontSize: 11, color: "#A8A29E", fontVariantNumeric: "tabular-nums" }}>{g.items.length}</span>
                  <div className="flex-1" style={{ height: 1, background: "#EEEBE2" }}/>
                </div>
                {g.items.map(it => (
                  <ItemCard key={it.id} item={it}
                    focused={focusedId === it.id}
                    dim={focusedId && focusedId !== it.id}
                    onFocus={() => onFocus(it.id)}
                    threadCount={threadCounts[it.id] || 0}/>
                ))}
              </div>
            ))
          ) : (
            items.map(it => (
              <ItemCard key={it.id} item={it}
                focused={focusedId === it.id}
                dim={focusedId && focusedId !== it.id}
                onFocus={() => onFocus(it.id)}
                threadCount={threadCounts[it.id] || 0}/>
            ))
          )}
          {items.length === 0 && (
            <div className="rounded-lg p-8 text-center" style={{ background: "#FFFFFF", border: "1px dashed #E5E3DC" }}>
              <div style={{ fontSize: 13, color: "#57534E" }}>No items match the current filter.</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ====================================================================
   RIGHT RAIL — default guide vs. focused conversation
   ==================================================================== */
function RightRail({ scene, focusedId, onFocus }) {
  const focused = focusedId ? scene.items.find(i => i.id === focusedId) : null;
  return (
    <aside className="flex flex-col flex-shrink-0"
      style={{ width: 340, background: "#FFFFFF", borderLeft: "1px solid #E5E3DC" }}>
      {focused ? <ConversationRail item={focused}/> : <GuideRail scene={scene} onFocus={onFocus}/>}
    </aside>
  );
}

function GuideRail({ scene, onFocus }) {
  const topContested = scene.items.filter(i => i.state === "contested").slice(0, 2);
  const topGap = scene.items.filter(i => i.state === "gap").slice(0, 1);
  const topNew = scene.items.filter(i => i.state === "new").slice(0, 1);
  const attn = [...topContested, ...topGap, ...topNew];
  const activity = [
    { who: "Mark",  text: "Updated home valuation to £560k", time: "2 hours ago" },
    { who: "Mark",  text: "Shared his picture with you",     time: "2 days ago" },
    { who: "Sarah", text: "Added 3 agent valuations for the home", time: "3 days ago" }
  ];

  return (
    <div className="flex-1 flex flex-col overflow-auto nice-scroll">
      <div className="px-4 pt-4 pb-3 border-b" style={{ borderColor: "#EEEBE2" }}>
        <div className="flex items-center gap-1.5 mb-1">
          <ISpark size={12}/>
          <span style={{ fontSize: 10.5, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600, color: "#4338CA" }}>Reconciliation guide</span>
        </div>
        <div style={{ fontSize: 12.5, color: "#57534E", lineHeight: 1.5 }}>
          Click any card to focus it. You'll see actions and the conversation for that item here.
        </div>
      </div>

      <div className="px-4 pt-4 pb-1.5" style={{ fontSize: 10.5, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600, color: "#9CA3AF" }}>Needs your attention</div>
      <div className="px-3 flex flex-col gap-1.5">
        {attn.map(it => {
          const m = window.RC_STATE_META[it.state];
          return (
            <button key={it.id} onClick={() => onFocus(it.id)}
              className="text-left rounded-lg px-3 py-2.5 transition"
              style={{ background: "#FBFBF8", border: "1px solid #EEEBE2" }}>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="inline-block rounded-full" style={{ width: 6, height: 6, background: m.dot }}/>
                <span style={{ fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600, color: m.fg }}>{m.label}</span>
              </div>
              <div style={{ fontSize: 12.5, fontWeight: 500, color: "#1A1A1A", lineHeight: 1.4 }}>{it.label}</div>
            </button>
          );
        })}
      </div>

      <div className="px-4 pt-5 pb-1.5" style={{ fontSize: 10.5, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600, color: "#9CA3AF" }}>Recent activity</div>
      <div className="px-3 pb-3 flex flex-col gap-0.5">
        {activity.map((a, i) => (
          <div key={i} className="flex gap-2.5 px-2 py-1.5">
            <Avatar who={a.who} size={20}/>
            <div className="flex-1 min-w-0">
              <div style={{ fontSize: 12, color: "#1A1A1A", lineHeight: 1.4 }}>
                <span className="font-semibold">{a.who}</span> {a.text}
              </div>
              <div style={{ fontSize: 10.5, color: "#9CA3AF", marginTop: 1 }}>{a.time}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-auto px-4 py-3 border-t" style={{ borderColor: "#EEEBE2", background: "#FBFBF8" }}>
        <div style={{ fontSize: 11, color: "#78716C", lineHeight: 1.5 }}>
          Nothing here is final. Agreements only lock when you both sign off in Phase 4.
        </div>
      </div>
    </div>
  );
}

function ConversationRail({ item }) {
  const [draft, setDraft] = useState("");
  const thread = window.RC_THREADS[item.id] || [];
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="px-4 pt-4 pb-3 border-b" style={{ borderColor: "#EEEBE2" }}>
        <div className="flex items-center gap-1.5 mb-1">
          <IMsg size={12}/>
          <span style={{ fontSize: 10.5, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600, color: "#57534E" }}>Conversation</span>
        </div>
        <div className="truncate" style={{ fontSize: 12.5, color: "#1A1A1A", fontWeight: 500 }}>{item.label}</div>
      </div>

      <div className="flex-1 overflow-auto nice-scroll px-4 py-4 flex flex-col gap-3">
        {thread.length === 0 && (
          <div className="rounded-lg p-4 text-center" style={{ background: "#FBFBF8", border: "1px dashed #E5E3DC" }}>
            <div style={{ fontSize: 12.5, color: "#57534E" }}>No messages yet.</div>
            <div className="mt-1" style={{ fontSize: 11.5, color: "#9CA3AF" }}>Start a conversation with Mark about this item.</div>
          </div>
        )}
        {thread.map((msg, i) => {
          const color = msg.who === "Sarah" ? SARAH : MARK;
          return (
            <div key={i} className="flex gap-2.5">
              <Avatar who={msg.who} size={26}/>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span style={{ fontSize: 12, fontWeight: 600, color }}>{msg.who}</span>
                  <span style={{ fontSize: 10.5, color: "#9CA3AF" }}>{msg.time}</span>
                </div>
                {msg.text && (
                  <div className="rounded-lg px-3 py-2" style={{ background: "#FBFBF8", border: "1px solid #EEEBE2", fontSize: 12.5, color: "#1A1A1A", lineHeight: 1.5 }}>{msg.text}</div>
                )}
                {msg.attachment && (
                  <div className="mt-1 inline-flex items-center gap-1.5 rounded-md px-2 py-1" style={{ background: "#FFFFFF", border: "1px solid #E5E3DC" }}>
                    <IDoc size={11}/>
                    <span style={{ fontSize: 11.5, color: "#1A1A1A", fontWeight: 500 }}>{msg.attachment}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="px-3 py-3 border-t" style={{ borderColor: "#EEEBE2", background: "#FBFBF8" }}>
        <div className="flex gap-2 items-end">
          <textarea value={draft} onChange={e => setDraft(e.target.value)}
            placeholder="Write to Mark..." rows={2}
            className="flex-1 rounded-lg px-3 py-2 resize-none"
            style={{ background: "#FFFFFF", border: "1px solid #E5E3DC", fontSize: 12.5, fontFamily: "inherit", outline: "none" }}/>
          <button className="text-white px-3 py-2 rounded-lg font-medium" style={{ background: "#1A1A1A", fontSize: 11.5 }}>Send</button>
        </div>
      </div>
    </div>
  );
}

/* ====================================================================
   SHELL
   ==================================================================== */
function Shell() {
  const init = (k, dflt) => { try { return localStorage.getItem("rc2_" + k) || dflt; } catch(e) { return dflt; } };
  const hashScene = (() => {
    const m = (window.location.hash || "").match(/scene=(0[34])/);
    return m ? m[1] : null;
  })();

  const [sceneKey, setSceneKey] = useState(hashScene || init("scene", "03"));
  const [handshake, setHandshake] = useState(init("hs", "shared"));
  const [chapter, setChapter] = useState(init("ch", "all"));
  const [focusedId, setFocusedId] = useState(null);
  const [filter, setFilter] = useState(null);

  useEffect(() => {
    const onHash = () => {
      const m = (window.location.hash || "").match(/scene=(0[34])/);
      if (m && m[1] !== sceneKey) setSceneKey(m[1]);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [sceneKey]);

  useEffect(() => { try { localStorage.setItem("rc2_scene", sceneKey); } catch(e){} }, [sceneKey]);
  useEffect(() => { try { localStorage.setItem("rc2_hs", handshake); } catch(e){} }, [handshake]);
  useEffect(() => { try { localStorage.setItem("rc2_ch", chapter); } catch(e){} }, [chapter]);

  const scene = sceneKey === "03" ? window.RC_SCENE_03 : window.RC_SCENE_04;
  useEffect(() => { setFocusedId(null); setFilter(null); }, [sceneKey, chapter]);

  const counts = useMemo(() => {
    const c = {};
    window.RC_CHAPTERS.forEach(ch => {
      const its = scene.items.filter(i => i.ch === ch.k);
      c[ch.k] = { total: its.length, contested: its.filter(i => i.state === "contested").length, gap: its.filter(i => i.state === "gap").length };
    });
    return c;
  }, [scene]);

  const chapterItems = useMemo(() => {
    let its = chapter === "all" ? [...scene.items] : scene.items.filter(i => i.ch === chapter);
    if (filter) its = its.filter(i => i.state === filter);
    return its;
  }, [scene, chapter, filter]);

  const threadCounts = useMemo(() => {
    const c = {};
    Object.keys(window.RC_THREADS).forEach(id => { c[id] = window.RC_THREADS[id].length; });
    return c;
  }, []);

  const cycleHandshake = () => {
    const i = HANDSHAKE_ORDER.indexOf(handshake);
    setHandshake(HANDSHAKE_ORDER[(i + 1) % HANDSHAKE_ORDER.length]);
  };

  const chapterLabel = chapter === "all"
    ? "All chapters"
    : (window.RC_CHAPTERS.find(c => c.k === chapter) || {}).label || "";
  const showContent = handshake === "shared";

  const handleFocus = id => setFocusedId(id === focusedId ? null : id);

  // clicking outside any card clears focus
  const handleBackgroundClick = (e) => {
    if (e.target === e.currentTarget) setFocusedId(null);
  };

  return (
    <div className="h-full flex flex-col relative" style={{ fontFamily: "Inter, sans-serif" }}>
      <RC_TopBar scene={scene}
        handshake={handshake} onHandshake={cycleHandshake}
        selectedId={null} onClose={() => {}}/>

      <TweakStrip sceneKey={sceneKey} setSceneKey={setSceneKey}
        handshake={handshake} setHandshake={setHandshake}/>

      {showContent ? (
        <div className="flex-1 flex min-h-0">
          <RC_ChapterRail scene={scene} active={chapter} onPick={setChapter} counts={counts}/>

          <div className="flex-1 flex flex-col min-w-0" style={{ background: "#FBFBF8" }}>
            <RC_SummaryStrip scene={scene} onFilter={setFilter} filter={filter}/>
            <CardList items={chapterItems}
              chapterLabel={chapterLabel}
              groupByChapter={chapter === "all"}
              focusedId={focusedId}
              onFocus={handleFocus}
              threadCounts={threadCounts}/>
          </div>

          <RightRail scene={scene} focusedId={focusedId} onFocus={setFocusedId}/>
        </div>
      ) : (
        <div className="flex-1 flex min-h-0">
          <RC_HandshakeWaiting handshake={handshake}/>
          <RightRail scene={scene} focusedId={null} onFocus={()=>{}}/>
        </div>
      )}
    </div>
  );
}

function TweakStrip({ sceneKey, setSceneKey, handshake, setHandshake }) {
  return (
    <div className="flex items-center gap-3 px-6 py-2 border-b"
      style={{ background: "#F5F3EE", borderColor: "#E5E3DC" }}>
      <span style={{ fontSize: 10.5, letterSpacing: "0.09em", textTransform: "uppercase", fontWeight: 600, color: "#9CA3AF" }}>Tweaks</span>
      <div className="flex items-center gap-1">
        <span style={{ fontSize: 11, color: "#57534E" }}>Scene</span>
        {SCENE_KEYS.map(k => (
          <button key={k} onClick={() => setSceneKey(k)}
            className="rounded-md px-2 py-0.5 font-semibold transition"
            style={{ background: sceneKey === k ? "#1A1A1A" : "#FFFFFF",
                     color: sceneKey === k ? "#FFFFFF" : "#1A1A1A",
                     border: sceneKey === k ? "1px solid #1A1A1A" : "1px solid #E5E3DC",
                     fontSize: 11.5 }}>
            {k === "03" ? "03 Initial merge" : "04 Contested focus"}
          </button>
        ))}
      </div>
      <div style={{ width: 1, height: 16, background: "#E5E3DC" }}/>
      <div className="flex items-center gap-1">
        <span style={{ fontSize: 11, color: "#57534E" }}>Mark</span>
        {HANDSHAKE_ORDER.map(k => (
          <button key={k} onClick={() => setHandshake(k)}
            className="rounded-md px-2 py-0.5 font-medium transition"
            style={{ background: handshake === k ? "#1A1A1A" : "#FFFFFF",
                     color: handshake === k ? "#FFFFFF" : "#1A1A1A",
                     border: handshake === k ? "1px solid #1A1A1A" : "1px solid #E5E3DC",
                     fontSize: 11 }}>
            {k === "pre_open"   && "Hasn't opened"}
            {k === "opened"     && "Opened"}
            {k === "building"   && "Building"}
            {k === "shared"     && "Shared"}
          </button>
        ))}
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Shell/>);
})();
