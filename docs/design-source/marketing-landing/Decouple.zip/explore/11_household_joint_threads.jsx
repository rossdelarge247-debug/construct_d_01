/* ============================================================
   11 · Household — Sarah · JOINT · Mark + Comment Threads
   ------------------------------------------------------------
   Mashup of #10 (3-column Sarah/Joint/Mark with AI assumptions)
   and #08 (inline comment threads on conflicts).
   - Most rows sit silently in their column.
   - Disputed rows show split values + thread bubble.
   - Click bubble → fly-out thread on the right with messages,
     AI murmur, and a "proposed resolution" card.
   ============================================================ */

function Household_JointThreads() {
  const [openThread, setOpenThread] = React.useState("hsbc");

  return (
    <div style={{
      width: 1280, height: 920, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Reconcile</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Sarah · Joint · Mark · with threads</span>
            <Chip bg={TOK.magentaSoft} fg={TOK.magenta}>D81 + comments</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Avatar name="S" color={TOK.indigo}/>
          <Avatar name="M" color={TOK.magenta}/>
          <span className="mono" style={{ fontSize: 10, color: TOK.mute, letterSpacing: "0.04em" }}>both online</span>
          <button className="ml-2 h-7 px-2.5 rounded-md text-[11.5px] font-medium" style={{ background: TOK.ink, color: "#FFF" }}>
            Approve & lock
          </button>
        </div>
      </header>

      {/* status strip */}
      <div className="px-6 py-2.5 flex items-center gap-5" style={{ borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <Stat l="Agreed" v="14" c={TOK.green}/>
        <Stat l="Threaded conflicts" v="3" c={TOK.flag}/>
        <Stat l="Open queries" v="1" c={TOK.indigo}/>
        <Stat l="AI assumptions applied" v="14" c={TOK.mute}/>
        <div className="flex-1"/>
        <Pulse size={5}/>
        <span className="mono" style={{ fontSize: 10, color: TOK.sub, letterSpacing: "0.04em" }}>
          DECOUPLE READING · last activity 12s ago
        </span>
      </div>

      {/* body */}
      <div className="flex-1 overflow-hidden flex" style={{ minHeight: 0 }}>
        {/* LEDGER */}
        <div className="flex-1 overflow-y-auto px-10 py-6">
          <Kicker color={TOK.magenta}>Phase 2 · combined picture</Kicker>
          <h1 className="serif mt-1.5" style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.1 }}>
            Yours, <span style={{ fontStyle: "italic", color: TOK.green }}>jointly held</span>, theirs — <span style={{ fontStyle: "italic", color: TOK.magenta }}>and what's still in dispute</span>.
          </h1>

          {/* totals */}
          <div className="mt-4 flex gap-4">
            <ColTotal label="Sarah · sole" value="£298k" color={TOK.indigo}/>
            <ColTotal label="Joint" value="£455k" color={TOK.green} primary/>
            <ColTotal label="Mark · sole" value="£218k" color={TOK.magenta}/>
            <div className="flex-1"/>
            <div className="text-right">
              <Trace>matrimonial pot</Trace>
              <div className="serif tabular" style={{ fontSize: 22, fontWeight: 600, color: TOK.ink, letterSpacing: "-0.02em" }}>£971,380</div>
            </div>
          </div>

          {/* col headers */}
          <div className="mt-5 grid items-center" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr 36px", flexShrink: 0 }}>
            <div/>
            <ColHd who="Sarah" color={TOK.indigo} sub="sole"/>
            <ColHd who="Joint" color={TOK.green} sub="held / used by both" emph/>
            <ColHd who="Mark" color={TOK.magenta} sub="sole"/>
            <div/>
          </div>

          {/* HOME */}
          <Sec title="The home">
            <RowMash
              chapter="Property" name="Family home · Hampstead"
              joint={{ amt: "£860,000", note: "Both names" }}
              assumption="Held jointly. Equity defaulted to 50/50 — but Mark wants a fresh RICS valuation."
              thread="house-val" threadCount={3} open={openThread === "house-val"} onOpen={setOpenThread} flag
              split={{ s: "£223.8k", m: "£223.8k" }}
            />
            <RowMash
              chapter="Mortgage" name="Halifax mortgage outstanding"
              joint={{ amt: "-£412,400", note: "Joint · live", debt: true }}
              assumption="Joint debt against the home."
            />
          </Sec>

          {/* CASH */}
          <Sec title="Cash & savings">
            <RowMash chapter="Account" name="Monzo joint" joint={{ amt: "£8,640", note: "Live" }}
                     assumption="Joint account — sits in the middle."/>
            <RowMash chapter="Account" name="Halifax current (Sarah)" sarah={{ amt: "£14,820", note: "Live" }}
                     assumption="In Sarah's name — kept on her side."/>
            <RowMash chapter="Account" name="Barclays current (Mark)" mark={{ amt: "£11,940", note: "Live" }}
                     assumption="In Mark's name — kept on his side."/>
          </Sec>

          {/* PENSIONS */}
          <Sec title="Pensions" subtle="held individually · divisible at proposal">
            <RowMash chapter="Pension" name="NHS career pension (Sarah)"
                     sarah={{ amt: "£284,000", note: "CETV · 2 Mar" }}
                     assumption="Pensions are personal — kept under each name."/>
            <RowMash chapter="Pension" name="DC pension (Mark)"
                     mark={{ amt: "£218,400", note: "Aviva · 31 Mar" }}
                     assumption="Same — Mark's side."
                     thread="mark-sipp" threadCount={2} open={openThread === "mark-sipp"} onOpen={setOpenThread} flag
                     subRow={{
                       label: "Sarah's value",
                       sarah: { amt: "£196,000", note: "Last year's statement" }
                     }}/>
          </Sec>

          {/* DEBTS */}
          <Sec title="Debts">
            <RowMash chapter="Credit card" name="HSBC Credit Card"
                     mark={{ amt: "?", note: "Sole · in Mark's name", debt: true }}
                     assumption="In Mark's name — but balance is contested. Incurred during the marriage."
                     thread="hsbc" threadCount={5} open={openThread === "hsbc"} onOpen={setOpenThread} flag/>
            <RowMash chapter="Loan" name="John Lewis sofa finance"
                     joint={{ amt: "-£1,820", note: "Both signed", debt: true }}
                     assumption="Both signed — sits in the middle."/>
          </Sec>

          {/* OUTGOINGS */}
          <Sec title="Outgoings · monthly">
            <RowMash chapter="Housing" name="Mortgage, council tax, utilities"
                     joint={{ amt: "-£2,184/mo", note: "From joint Monzo" }}
                     assumption="Paid from joint — middle column."/>
            <RowMash chapter="Children" name="School + activities + clothes"
                     joint={{ amt: "-£1,210/mo", note: "Both contribute" }}
                     assumption="Default-joint — supports both of you raising the kids."
                     thread="afterschool" threadCount={2} open={openThread === "afterschool"} onOpen={setOpenThread} flag/>
            <RowMash chapter="Personal" name="Sarah's personal spend"
                     sarah={{ amt: "-£687/mo", note: "Halifax personal" }}
                     assumption="Personal stays personal."/>
            <RowMash chapter="Personal" name="Mark's personal spend"
                     mark={{ amt: "-£743/mo", note: "Barclays personal" }}
                     assumption="Same."/>
          </Sec>

          <div className="h-12"/>
        </div>

        {/* THREAD PANEL */}
        <ThreadPanel open={openThread} onClose={() => setOpenThread(null)}/>
      </div>

      <footer className="flex items-center justify-between px-6"
              style={{ height: 30, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>auto-saved</Trace><Trace>14 ai assumptions · 0 overrides</Trace><Trace>3 threads open</Trace>
        </div>
        <div className="text-[10.5px]" style={{ color: TOK.mute }}>
          Click any <span style={{ color: TOK.flag, fontWeight: 600 }}>flag</span> to open its thread
        </div>
      </footer>
    </div>
  );
}

/* ----- pieces ----- */

function ColTotal({ label, value, color, primary }) {
  return (
    <div className={primary ? "rounded-lg px-3 py-1.5" : "px-1"}
         style={primary ? { background: "#F0FDF4", border: `1px solid ${TOK.green}` } : {}}>
      <Trace color={color}>{label}</Trace>
      <div className="serif tabular" style={{ fontSize: 22, fontWeight: 600, color, letterSpacing: "-0.02em", lineHeight: 1 }}>
        {value}
      </div>
    </div>
  );
}

function ColHd({ who, color, sub, emph }) {
  return (
    <div className="px-3 py-2 text-center" style={{
      background: emph ? "#F0FDF4" : "transparent",
      borderTop: emph ? `2px solid ${color}` : `1px solid ${TOK.line}`,
      borderLeft: `1px solid ${TOK.line}`,
      borderRight: `1px solid ${TOK.line}`,
      borderBottom: `1px solid ${TOK.line}`,
    }}>
      <div className="flex items-center justify-center gap-2">
        <span className="rounded-full" style={{ width: 7, height: 7, background: color }}/>
        <span style={{ fontSize: 12, fontWeight: 600, color }}>{who}</span>
      </div>
      <Trace color={TOK.mute}>{sub}</Trace>
    </div>
  );
}

function Sec({ title, subtle, children }) {
  return (
    <section className="mt-5">
      <div className="flex items-baseline justify-between mb-1.5 px-1">
        <h2 className="serif" style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-0.015em" }}>{title}</h2>
        {subtle && <Trace>{subtle}</Trace>}
      </div>
      <div className="rounded-xl overflow-hidden" style={{ border: `1px solid ${TOK.line}`, background: "#FFF" }}>
        {children}
      </div>
    </section>
  );
}

function RowMash({ chapter, name, sarah, joint, mark, assumption, flag, thread, threadCount, open, onOpen, split, subRow }) {
  const accent = flag ? TOK.flag : TOK.indigo;
  return (
    <div style={{ borderTop: "1px solid " + TOK.hairline, background: open ? "#FFFAF0" : "transparent" }}>
      <div className="grid items-stretch" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr 36px" }}>
        <div className="px-3.5 py-3">
          <Trace color={TOK.mute}>{chapter}</Trace>
          <div className="text-[12px] font-medium mt-0.5" style={{ color: TOK.ink, lineHeight: 1.3 }}>{name}</div>
        </div>
        <Cell data={sarah} color={TOK.indigo}/>
        <Cell data={joint} color={TOK.green} joint/>
        <Cell data={mark} color={TOK.magenta}/>
        <div className="flex items-center justify-center" style={{ borderLeft: `1px solid ${TOK.hairline}` }}>
          {thread ? (
            <button onClick={() => onOpen(thread)}
                    className="flex items-center justify-center rounded-full"
                    style={{ width: 24, height: 24, background: open ? TOK.flag : "#FFF", border: `1.5px solid ${TOK.flag}` }}
                    title={`${threadCount} comments`}>
              <span className="mono" style={{ fontSize: 10, fontWeight: 700, color: open ? "#FFF" : TOK.flag }}>{threadCount}</span>
            </button>
          ) : (
            <I.check s={11} c={TOK.green} w={2.2}/>
          )}
        </div>
      </div>

      {/* a "Sarah's value" sub-row used when conflict is in a sole column */}
      {subRow && (
        <div className="grid items-center" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr 36px", background: "#FFFAF0" }}>
          <div className="px-3.5 py-1.5"><Trace color={TOK.flag}>↳ {subRow.label}</Trace></div>
          <Cell data={subRow.sarah} color={TOK.indigo} alt/>
          <div/>
          <div/>
          <div/>
        </div>
      )}

      {/* default split (e.g. house equity) */}
      {split && (
        <div className="grid items-center" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr 36px", background: TOK.cream }}>
          <div className="px-3.5 py-1.5"><Trace color={TOK.mute}>↳ default split</Trace></div>
          <div className="px-3.5 py-1.5 text-right">
            <span className="mono tabular" style={{ fontSize: 11.5, color: TOK.indigo }}>{split.s}</span>
          </div>
          <div className="px-3.5 py-1.5 text-center" style={{ borderLeft: `1px solid ${TOK.hairline}`, borderRight: `1px solid ${TOK.hairline}` }}>
            <Trace color={TOK.faint}>50/50</Trace>
          </div>
          <div className="px-3.5 py-1.5 text-left">
            <span className="mono tabular" style={{ fontSize: 11.5, color: TOK.magenta }}>{split.m}</span>
          </div>
          <div/>
        </div>
      )}

      {/* assumption strip */}
      {assumption && (
        <div className="grid" style={{ gridTemplateColumns: "180px 1fr 36px", background: TOK.bg, borderTop: `1px dashed ${TOK.line}` }}>
          <div/>
          <div className="px-3.5 py-1.5 flex items-start gap-2">
            <I.spark s={10} c={accent} style={{ marginTop: 2, flexShrink: 0 }}/>
            <Murmur color={accent}>
              <span className="mono not-italic" style={{ fontSize: 9, letterSpacing: "0.06em", color: TOK.mute, textTransform: "uppercase", marginRight: 5 }}>
                {flag ? "AI · UNDER DISCUSSION" : "AI ASSUMPTION"}
              </span>
              {assumption}
            </Murmur>
          </div>
          <div/>
        </div>
      )}
    </div>
  );
}

function Cell({ data, color, joint, alt }) {
  if (!data) return (
    <div className="px-3.5 py-3" style={{ borderLeft: `1px solid ${TOK.hairline}`, background: joint ? TOK.cream + "66" : "transparent", textAlign: joint ? "center" : (color === TOK.indigo ? "right" : "left") }}>
      <div className="mono" style={{ fontSize: 11, color: TOK.faint, letterSpacing: "0.06em" }}>—</div>
    </div>
  );
  const isDebt = data.debt;
  return (
    <div className="px-3.5 py-3" style={{
      borderLeft: `1px solid ${TOK.hairline}`,
      background: alt ? "transparent" : (joint ? "#F4FBF7" : "transparent"),
      textAlign: joint ? "center" : (color === TOK.indigo ? "right" : "left")
    }}>
      <div className="mono tabular" style={{
        fontSize: 13.5, fontWeight: 500,
        color: isDebt ? TOK.flag : (joint ? TOK.green : TOK.ink),
      }}>{data.amt}</div>
      <Trace color={TOK.mute}>{data.note}</Trace>
    </div>
  );
}

/* Simplified ThreadPanel — distinct from #08's so no name collision */
function ThreadPanel({ open, onClose }) {
  const threads = {
    "hsbc": {
      title: "HSBC Credit Card · balance",
      where: "Mark's sole column",
      messages: [
        { who: "M", color: TOK.magenta, name: "Mark", t: "2d", body: "Filled in £6,200 from my Jan statement." },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "2d", ai: true,
          body: <>Regular outflows from <b>Sarah's</b> Halifax to HSBC since November suggest the balance has moved.</> },
        { who: "S", color: TOK.indigo, name: "Sarah", t: "1d",
          body: "I want this on Mark's side, not joint — but it should reflect today's number." },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "1d", ai: true,
          body: <>Mark to enter today's balance manually. I'll keep it in his sole column but tag it <b>matrimonial debt</b> so the proposal sees it.</> },
        { who: "M", color: TOK.magenta, name: "Mark", t: "now", body: "Will do today." }
      ],
      proposal: {
        body: "Mark enters today's balance. Stays in his column, tagged matrimonial — surfaces in proposal.",
        actions: ["Apply", "Suggest other"]
      }
    },
    "house-val": {
      title: "Family home · valuation",
      where: "Joint column",
      messages: [
        { who: "M", color: TOK.magenta, name: "Mark", t: "3d", body: "Want a RICS valuation before locking the joint figure." },
        { who: "S", color: TOK.indigo, name: "Sarah", t: "3d", body: "Zoopla's been within 3% on this street — feels overkill." },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "2d", ai: true,
          body: <>Zoopla confidence is <b>0.78</b>. Two comparables sold over 4 months ago. RICS ~£500.</> }
      ],
      proposal: {
        body: "Book RICS now (~£500, split). Hold joint figure as Zoopla until verified. Default 50/50 stays — adjust if needed.",
        actions: ["Apply", "Discuss"]
      }
    },
    "mark-sipp": {
      title: "DC pension (Mark) · current value",
      where: "Mark's sole column",
      messages: [
        { who: "S", color: TOK.indigo, name: "Sarah", t: "4d", body: "I had £196,000 from last year." },
        { who: "M", color: TOK.magenta, name: "Mark", t: "4d", body: "Q1 contributions added — £218,400 today." },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "3d", ai: true,
          body: "Mark's figure is current and verifiable. Recommend updating Sarah's view." }
      ],
      proposal: { body: "Use £218,400 (Aviva · 31 Mar). Sarah's older figure archived for audit.", actions: ["Apply", "Hold"] }
    },
    "afterschool": {
      title: "After-school club · £280/mo",
      where: "Joint outgoings",
      messages: [
        { who: "AI", color: TOK.flag, name: "Decouple", t: "now", ai: true,
          body: <>Sarah counts Mark's transfer as her income; Mark counts the same as his outgoing. <b>Same money, double-counted.</b></> }
      ],
      proposal: {
        body: "Fold into joint child cost. Removes from Sarah's income line and Mark's outgoings line.",
        actions: ["Apply", "Keep separate"]
      }
    }
  };

  const t = threads[open];
  if (!t) {
    return (
      <aside style={{ width: 360, borderLeft: `1px solid ${TOK.line}`, background: "#FFF" }}
             className="overflow-y-auto p-7">
        <Kicker color={TOK.magenta}>No thread open</Kicker>
        <Murmur color={TOK.sub}>Click any numbered flag in the ledger to open its thread.</Murmur>

        <HR my={20}/>
        <Kicker>Recently resolved</Kicker>
        <div className="mt-3 space-y-2.5">
          {[
            { t: "British Gas · DD", note: "Resolved · used current figure" },
            { t: "Council tax", note: "Both ledgers matched" },
            { t: "Combined income aggregate", note: "AI summed automatically" },
          ].map((r, i) => (
            <div key={i} className="flex items-start gap-2">
              <I.check s={11} c={TOK.green} w={2.5} style={{ marginTop: 3 }}/>
              <div>
                <div className="text-[12px]" style={{ color: TOK.ink }}>{r.t}</div>
                <Trace>{r.note}</Trace>
              </div>
            </div>
          ))}
        </div>
      </aside>
    );
  }

  return (
    <aside style={{ width: 380, borderLeft: `1px solid ${TOK.line}`, background: "#FFF" }}
           className="overflow-y-auto flex flex-col">
      <div className="flex items-start justify-between px-5 py-4 sticky top-0" style={{ background: "#FFF", borderBottom: `1px solid ${TOK.hairline}` }}>
        <div className="min-w-0 pr-2">
          <Trace color={TOK.flag}>thread · {t.messages.length} messages · {t.where}</Trace>
          <div className="serif mt-1" style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em" }}>{t.title}</div>
        </div>
        <button onClick={onClose} style={{ color: TOK.mute, padding: 2 }}><I.close s={14} c={TOK.mute}/></button>
      </div>

      <div className="flex-1 px-5 py-4 space-y-4">
        {t.messages.map((m, i) => (
          <div key={i} className="flex gap-2.5">
            {m.ai
              ? <div className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
                     style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
                  <I.spark s={13} c={TOK.flag}/>
                </div>
              : <Avatar name={m.who} color={m.color}/>
            }
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-1.5">
                <span className="text-[12px] font-semibold" style={{ color: m.color }}>{m.name}</span>
                {m.ai && <Chip bg={TOK.cream} fg={TOK.sub}>AI</Chip>}
                <Trace>{m.t}</Trace>
              </div>
              {m.ai
                ? <Murmur color={TOK.flag}>{m.body}</Murmur>
                : <div className="mt-0.5 text-[12.5px]" style={{ color: TOK.ink, lineHeight: 1.5 }}>{m.body}</div>}
            </div>
          </div>
        ))}

        {t.proposal && (
          <div className="rounded-lg p-3 mt-1" style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
            <Kicker color={TOK.flag}>Decouple proposes</Kicker>
            <div className="mt-1.5 text-[12.5px]" style={{ color: TOK.ink, lineHeight: 1.5 }}>{t.proposal.body}</div>
            <div className="mt-3 flex gap-2">
              {t.proposal.actions.map((a, i) => (
                <button key={i} className="px-2.5 h-7 rounded-md text-[11.5px]"
                        style={i === 0
                          ? { background: TOK.ink, color: "#FFF", fontWeight: 500 }
                          : { color: TOK.sub, border: `1px solid ${TOK.line}`, background: "#FFF" }}>
                  {a}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="px-5 py-3 sticky bottom-0" style={{ background: "#FFF", borderTop: `1px solid ${TOK.hairline}` }}>
        <div className="flex items-center gap-2 px-3 h-9 rounded-md" style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
          <span className="text-[12px]" style={{ color: TOK.faint }}>Reply, propose a value, or @decouple…</span>
          <div className="flex-1"/>
          <I.arrowR s={12} c={TOK.mute}/>
        </div>
      </div>
    </aside>
  );
}

function Stat({ l, v, c }) {
  return (
    <div>
      <Trace>{l}</Trace>
      <div className="serif tabular" style={{ fontSize: 17, fontWeight: 600, color: c, letterSpacing: "-0.02em", lineHeight: 1 }}>{v}</div>
    </div>
  );
}

function Avatar({ name, color }) {
  return (
    <div className="rounded-full flex items-center justify-center text-white font-semibold"
         style={{ width: 22, height: 22, background: color, fontSize: 10.5 }}>
      {name}
    </div>
  );
}

window.Household_JointThreads = Household_JointThreads;
