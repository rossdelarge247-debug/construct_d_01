/* ============================================================
   04 · Our Household — PUSHED (Spatial reconciliation)
   ------------------------------------------------------------
   The two pictures fuse into a single shared constellation.
   - Each asset/category appears once, with two halves: Sarah's
     and Mark's. When they agree, the halves snap together into
     a calm green disc. When they don't, a coloured fissure
     opens — its width = the spread.
   - The AI sits between, narrating each fissure and offering a
     resolution. You can drag the slider in any fissure and feel
     the disagreement close in real time.
   ============================================================ */

function Household_Spatial() {
  const [pick, setPick] = React.useState("pension");

  return (
    <div style={{
      width: 1280, height: 860, background: "#F4F1EA", color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* dotted spatial grid */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `radial-gradient(${TOK.faint}33 1px, transparent 1px)`,
        backgroundSize: "22px 22px", pointerEvents: "none", opacity: 0.7
      }}/>

      {/* top bar */}
      <header className="flex items-center justify-between px-5 relative z-10"
              style={{ height: 50, background: "rgba(255,255,255,0.7)", backdropFilter: "blur(10px)",
                       borderBottom: `1px solid ${TOK.line}`, flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13} bg="#F4F1EA"/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Reconcile</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Our Household · Spatial</span>
          </div>
        </div>

        {/* top legend */}
        <div className="flex items-center gap-5 text-[11px]">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: "#2F6D5F" }}/>
            <span style={{ color: TOK.sub }}>Sarah</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: "#B45309" }}/>
            <span style={{ color: TOK.sub }}>Mark</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full" style={{ background: TOK.green }}/>
            <span style={{ color: TOK.sub }}>Agreed</span>
          </div>
        </div>

        <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                style={{ background: TOK.ink, color: "#FFF" }}>
          Move to proposal <I.arrowR s={11} c="#FFF"/>
        </button>
      </header>

      {/* canvas */}
      <div className="flex-1 relative" style={{ minHeight: 0 }}>

        {/* Big SVG constellation */}
        <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
          {/* central rule */}
          <line x1="50%" y1="80" x2="50%" y2="100%" stroke={TOK.line} strokeDasharray="2 4" strokeWidth={1}/>

          {/* fused tokens */}
          <FusedDisc x={300} y={200} r={64} agree label="Family home" big="£860k" small="agreed" gloss="Zoopla 12 Apr"/>
          <FusedDisc x={300} y={400} r={50} agree label="Halifax mortgage" big="£412k" small="agreed" gloss="live balance"/>
          <FusedDisc x={300} y={600} r={42} agree label="Joint savings" big="£28.4k" small="agreed" gloss="Halifax · live"/>

          <FissureDisc
            x={760} y={210} r={64}
            label="NHS pension (Sarah)" agreed
            big="£284k" gloss="CETV · 2 Mar"
            onClick={() => setPick("nhs")}
            picked={pick === "nhs"}
          />
          <FissureDisc
            x={760} y={400} r={70}
            label="Mark's SIPP" spreadPct={0.32}
            sarahN="£196k" markN="£218k" gloss="22.4k apart"
            onClick={() => setPick("pension")}
            picked={pick === "pension"}
            color={TOK.magenta}
          />
          <FissureDisc
            x={1010} y={300} r={56}
            label="Children's education" spreadPct={0.18}
            sarahN="£842/mo" markN="£980/mo"
            gloss="£138/mo apart"
            onClick={() => setPick("kids")}
            picked={pick === "kids"}
            color={TOK.magenta}
          />
          <FissureDisc
            x={1010} y={500} r={50}
            label="Holiday spending" spreadPct={0.42}
            sarahN="£3.4k/yr" markN="£5.8k/yr"
            gloss="£2.4k apart"
            onClick={() => setPick("holiday")}
            picked={pick === "holiday"}
            color={TOK.magenta}
          />
          <FissureDisc
            x={760} y={600} r={42}
            label="Mark's old DB" gap
            big="—" gloss="awaiting CETV"
            onClick={() => setPick("db")}
            picked={pick === "db"}
            color={TOK.flag}
          />

          {/* connecting tendrils */}
          <path d="M364 200 Q 540 180 696 210" stroke={TOK.line} strokeWidth={1} fill="none" strokeDasharray="3 5"/>
          <path d="M350 400 Q 540 420 690 400" stroke={TOK.line} strokeWidth={1} fill="none" strokeDasharray="3 5"/>
          <path d="M342 600 Q 540 600 718 600" stroke={TOK.line} strokeWidth={1} fill="none" strokeDasharray="3 5"/>
          <path d="M820 350 Q 920 320 954 300" stroke={TOK.line} strokeWidth={1} fill="none" strokeDasharray="3 5"/>
          <path d="M820 450 Q 920 480 960 500" stroke={TOK.line} strokeWidth={1} fill="none" strokeDasharray="3 5"/>

          {/* AI tendril toward picked */}
          {pick && <AITendril pick={pick}/>}
        </svg>

        {/* AI mediator card */}
        <MediatorCard pick={pick}/>

        {/* progress bar at top */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 z-20" style={{ width: 460 }}>
          <div className="rounded-full px-3 py-1.5 flex items-center gap-2"
               style={{ background: "#FFF", border: `1px solid ${TOK.line}`, boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}>
            <Trace color={TOK.green}>14 agreed</Trace>
            <div className="flex-1 h-[3px] rounded-full overflow-hidden" style={{ background: TOK.cream }}>
              <div className="h-full" style={{ width: "82%", background: `linear-gradient(90deg, ${TOK.green} 0%, ${TOK.green} 82%, ${TOK.magenta} 82%, ${TOK.magenta} 95%, ${TOK.flag} 95%)` }}/>
            </div>
            <Trace color={TOK.magenta}>3 differ</Trace>
          </div>
        </div>

        {/* command bar */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20" style={{ width: 540 }}>
          <div className="rounded-full px-4 py-2.5 flex items-center gap-3"
               style={{ background: "rgba(20,20,20,0.92)", backdropFilter: "blur(10px)" }}>
            <I.spark s={14} c={TOK.cyan}/>
            <span style={{ fontSize: 12.5, color: "#FFF", flex: 1 }}>
              <span style={{ color: "#9CA3AF" }}>Try · </span>
              "settle every dispute under £500"
            </span>
            <span className="mono" style={{ fontSize: 10, color: "#9CA3AF" }}>⌘K</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── A fully agreed disc ─── */
function FusedDisc({ x, y, r, label, big, small, gloss }) {
  return (
    <g>
      <circle cx={x} cy={y} r={r + 10} fill={TOK.greenSoft} opacity={0.5}/>
      <circle cx={x} cy={y} r={r} fill="#FFFFFF" stroke={TOK.green} strokeOpacity={0.5} strokeWidth={1}/>
      <foreignObject x={x - r} y={y - r} width={r * 2} height={r * 2}>
        <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 8 }}>
          <div style={{ fontSize: 9.5, color: TOK.mute, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600 }}>{label}</div>
          <div className="serif tabular" style={{ fontSize: r > 50 ? 22 : 16, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 2 }}>{big}</div>
          <div style={{ fontSize: 9.5, color: TOK.green, marginTop: 2, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase" }}>✓ {small}</div>
        </div>
      </foreignObject>
    </g>
  );
}

/* ─── A disc that's split (or has a gap) ─── */
function FissureDisc({ x, y, r, label, agreed, gap, sarahN, markN, big, spreadPct = 0, gloss, color = TOK.green, picked, onClick }) {
  const gapWidth = spreadPct * r * 1.6; // visual fissure
  return (
    <g style={{ cursor: "pointer" }} onClick={onClick}>
      {/* picked halo */}
      {picked && <circle cx={x} cy={y} r={r + 14} fill="none" stroke={color} strokeWidth={1} strokeDasharray="2 4" opacity={0.7}/>}
      {/* glow */}
      <circle cx={x} cy={y} r={r + 8} fill={agreed ? TOK.greenSoft : gap ? "#FEF3C7" : TOK.magentaSoft} opacity={0.4}/>

      {agreed ? (
        <>
          <circle cx={x} cy={y} r={r} fill="#FFFFFF" stroke={TOK.green} strokeOpacity={0.45} strokeWidth={1}/>
          <foreignObject x={x - r} y={y - r} width={r * 2} height={r * 2}>
            <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 8 }}>
              <div style={{ fontSize: 9.5, color: TOK.mute, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600 }}>{label}</div>
              <div className="serif tabular" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 2 }}>{big}</div>
              <div style={{ fontSize: 9.5, color: TOK.green, marginTop: 2, fontWeight: 600 }}>✓ agreed</div>
            </div>
          </foreignObject>
        </>
      ) : gap ? (
        <>
          <circle cx={x} cy={y} r={r} fill="#FFFEFA" stroke={TOK.flag} strokeDasharray="3 4" strokeWidth={1}/>
          <foreignObject x={x - r} y={y - r} width={r * 2} height={r * 2}>
            <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 8 }}>
              <div style={{ fontSize: 9.5, color: TOK.mute, letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 600 }}>{label}</div>
              <div className="serif" style={{ fontSize: 22, fontWeight: 600, color: TOK.flag }}>—</div>
              <div style={{ fontSize: 9.5, color: TOK.flag, marginTop: 2, fontWeight: 600 }}>{gloss}</div>
            </div>
          </foreignObject>
        </>
      ) : (
        <>
          {/* Sarah half (left) */}
          <path d={`M ${x - gapWidth/2} ${y - r} A ${r} ${r} 0 0 0 ${x - gapWidth/2} ${y + r} L ${x - gapWidth/2} ${y - r} Z`}
                fill="#F4FAF6" stroke="#2F6D5F" strokeOpacity={0.5} strokeWidth={1}/>
          {/* Mark half (right) */}
          <path d={`M ${x + gapWidth/2} ${y - r} A ${r} ${r} 0 0 1 ${x + gapWidth/2} ${y + r} L ${x + gapWidth/2} ${y - r} Z`}
                fill="#FDF6EC" stroke="#B45309" strokeOpacity={0.5} strokeWidth={1}/>
          {/* fissure colour-fill */}
          <rect x={x - gapWidth/2} y={y - r} width={gapWidth} height={r * 2} fill={color} opacity={0.18}/>
          {/* labels */}
          <text x={x - r * 0.45} y={y - 8} fontSize="14" fontFamily="'Source Serif Pro', serif" fontWeight="600" fill={TOK.ink} textAnchor="middle" style={{ fontVariantNumeric: "tabular-nums" }}>{sarahN}</text>
          <text x={x - r * 0.45} y={y + 8} fontSize="9" fill="#2F6D5F" textAnchor="middle" letterSpacing="0.1em" fontWeight="600">SARAH</text>
          <text x={x + r * 0.45} y={y - 8} fontSize="14" fontFamily="'Source Serif Pro', serif" fontWeight="600" fill={TOK.ink} textAnchor="middle" style={{ fontVariantNumeric: "tabular-nums" }}>{markN}</text>
          <text x={x + r * 0.45} y={y + 8} fontSize="9" fill="#B45309" textAnchor="middle" letterSpacing="0.1em" fontWeight="600">MARK</text>
          {/* category title (above) */}
          <text x={x} y={y - r - 12} fontSize="10" fill={TOK.mute} textAnchor="middle" letterSpacing="1.5" fontWeight="600">
            {label.toUpperCase()}
          </text>
          {/* spread (below) */}
          <text x={x} y={y + r + 16} fontSize="10" fill={color} textAnchor="middle" fontWeight="600">
            ↕ {gloss}
          </text>
        </>
      )}
    </g>
  );
}

/* ─── tendril from focused disc to mediator card ─── */
function AITendril({ pick }) {
  const positions = {
    nhs:     { x: 760, y: 210 },
    pension: { x: 760, y: 400 },
    kids:    { x: 1010, y: 300 },
    holiday: { x: 1010, y: 500 },
    db:      { x: 760, y: 600 },
  };
  const p = positions[pick] || positions.pension;
  return (
    <path d={`M ${p.x} ${p.y} Q ${(p.x + 100) / 2} ${p.y - 60} 100 ${p.y - 30}`}
          stroke={TOK.indigo} strokeWidth={1} fill="none" strokeDasharray="3 4" opacity={0.6}/>
  );
}

/* ─── AI mediator: bottom-left card explaining the picked fissure ─── */
function MediatorCard({ pick }) {
  const cards = {
    pension: {
      title: "Mark's SIPP — £22,400 apart",
      body: "Your figure (£196k) is from last year's annual statement. Mark's (£218k) includes Q1 2026 contributions and a 4% market gain. Both are accurate as of different dates — Mark's is current.",
      cite: ["HL · platform statement", "FCA guidance · most recent valuation"],
      actions: ["Use Mark's £218,400", "Request live CETV", "Discuss"],
    },
    kids: {
      title: "Children's education — £138/mo apart",
      body: "Sarah's £842 is what hits her account each month (term fees). Mark's £980 includes uniform, trips, and exam fees averaged annually. Both numbers are correct — they answer different questions.",
      cite: ["12 mo · 4 accounts", "St Mary's invoice trail"],
      actions: ["Use £980 (full)", "Show monthly + annual"],
    },
    holiday: {
      title: "Holiday spend — £2.4k apart",
      body: "The gap is mostly Cornwall (£2,200, paid by Mark) and a weekend in Edinburgh (£300). Both trips were taken together. I'd recommend treating the full £5,800 as joint household spend.",
      cite: ["Monzo · 12 mo trace", "Halifax · 12 mo trace"],
      actions: ["Treat as joint", "Keep individual"],
    },
    nhs: {
      title: "NHS pension — agreed",
      body: "Both of you used the same CETV statement (2 March 2026, £284,000). The number reconciles cleanly. I won't ask again unless a fresh statement arrives.",
      cite: ["CETV · 2 Mar 2026"],
      actions: ["Lock value"],
    },
    db: {
      title: "Mark's old DB pension — awaiting",
      body: "Royal Mail's CETV team usually responds in 8–12 weeks. Mark requested 18 April. I'm watching — when it arrives I'll slot it into the picture and notify you both.",
      cite: ["Royal Mail Pensions · request 18 Apr"],
      actions: ["Chase Royal Mail", "Note as estimate"],
    },
  };
  const c = cards[pick] || cards.pension;

  return (
    <div className="absolute z-20 rounded-2xl p-5"
         style={{
           top: 130, left: 18, width: 320,
           background: "rgba(255,255,255,0.96)", backdropFilter: "blur(10px)",
           border: `1px solid ${TOK.line}`, boxShadow: "0 8px 30px rgba(0,0,0,0.06)"
         }}>
      <div className="flex items-center gap-2">
        <Pulse color={TOK.indigo} size={6}/>
        <Trace color={TOK.indigo}>Mediating · live</Trace>
      </div>
      <div className="serif mt-2.5" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.02em" }}>
        {c.title}
      </div>
      <p className="serif mt-2.5" style={{ fontSize: 13, lineHeight: 1.5, color: TOK.sub, fontStyle: "italic" }}>
        {c.body}
      </p>
      <div className="mt-3 flex flex-wrap gap-1">
        {c.cite.map((x, i) => <Chip key={i}><span className="mono" style={{ fontSize: 9.5 }}>{x}</span></Chip>)}
      </div>
      <div className="mt-4 flex flex-wrap gap-1.5">
        {c.actions.map((a, i) => (
          <button key={i} className={`px-2.5 h-7 rounded-md text-[11.5px] ${i === 0 ? "font-medium" : ""}`}
                  style={i === 0
                    ? { background: TOK.ink, color: "#FFF" }
                    : { color: TOK.sub, border: `1px solid ${TOK.line}`, background: "#FFF" }}>
            {a}
          </button>
        ))}
      </div>
    </div>
  );
}

window.Household_Spatial = Household_Spatial;
