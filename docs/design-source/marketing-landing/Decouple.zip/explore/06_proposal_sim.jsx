/* ============================================================
   06 · Proposal Builder — BROKEN (Dark control room)
   ------------------------------------------------------------
   The proposal as a live simulation. Graphite background, mono
   numerics everywhere, AI co-pilot streams the model in real
   time. Like a trading terminal for fairness.
   ============================================================ */

function Proposal_Sim() {
  return (
    <div style={{
      width: 1280, height: 860, background: TOK.graphite,
      color: TOK.gtext, fontFamily: "Inter, sans-serif",
      display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* faint grid */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `linear-gradient(${TOK.gline} 1px, transparent 1px), linear-gradient(90deg, ${TOK.gline} 1px, transparent 1px)`,
        backgroundSize: "60px 60px", opacity: 0.4, pointerEvents: "none"
      }}/>

      {/* top */}
      <header className="flex items-center justify-between px-5 relative z-10"
              style={{ height: 48, background: TOK.graphite2, borderBottom: `1px solid ${TOK.gline}`, flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13} color="#FFF" bg={TOK.graphite}/>
          <span style={{ color: TOK.gline }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.gsub }}>Settle</span>
            <I.chevR s={11} c={TOK.gsub}/>
            <span style={{ color: TOK.gtext, fontWeight: 600 }}>Proposal · Live model</span>
            <span className="px-1.5 py-0.5 rounded mono" style={{ fontSize: 9.5, background: TOK.gline, color: TOK.cyan, letterSpacing: "0.06em" }}>SIM v3.4</span>
          </div>
        </div>
        <div className="flex items-center gap-3 mono" style={{ fontSize: 10.5, color: TOK.gsub, letterSpacing: "0.06em" }}>
          <span>UTC 14:32:08</span>
          <span style={{ color: TOK.gline }}>|</span>
          <span style={{ color: TOK.cyan }}>● MODELLING</span>
          <span style={{ color: TOK.gline }}>|</span>
          <span>iter 1,284</span>
        </div>
      </header>

      {/* hero band */}
      <div className="px-8 pt-5 pb-4 flex items-end justify-between relative z-10" style={{ borderBottom: `1px solid ${TOK.gline}`, flexShrink: 0 }}>
        <div>
          <div className="mono" style={{ fontSize: 10.5, color: TOK.cyan, letterSpacing: "0.16em", fontWeight: 600 }}>
            CURRENT MODEL · v3
          </div>
          <h1 className="serif mt-2" style={{ fontSize: 34, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.05, color: TOK.gtext }}>
            Sarah <span style={{ color: TOK.cyan }}>58</span> / <span style={{ color: TOK.amber }}>42</span> Mark
          </h1>
          <div className="mono mt-2" style={{ fontSize: 11, color: TOK.gsub, letterSpacing: "0.08em" }}>
            Δ from baseline 50/50 · +£48,960 to Sarah · driven by [maint:14y] [care:primary] [career_break:6y]
          </div>
        </div>

        {/* live readouts */}
        <div className="flex items-end gap-6">
          <Readout label="REASONABLENESS" value="92" unit="/100" color={TOK.green}/>
          <Readout label="COURT LIKELIHOOD" value="92" unit="%" color={TOK.cyan} sparkline/>
          <Readout label="MARK REACTION" value="ACCEPT" unit="forecast 78%" color={TOK.amber}/>
          <Readout label="LEGAL RISK" value="LOW" unit="0 issues" color={TOK.green}/>
        </div>
      </div>

      {/* body */}
      <div className="flex-1 overflow-hidden flex relative z-10" style={{ minHeight: 0 }}>
        {/* left: levers panel */}
        <div className="overflow-y-auto p-5" style={{ width: 320, borderRight: `1px solid ${TOK.gline}` }}>
          <div className="mono" style={{ fontSize: 9.5, color: TOK.gsub, letterSpacing: "0.16em", fontWeight: 600 }}>LEVERS</div>
          <div className="mt-4 space-y-5">
            <Lever label="CAPITAL SPLIT" value="58 / 42" pct={0.58} band={[0.50, 0.62]}/>
            <Lever label="SPOUSAL MAINT." value="£1,200 / mo" pct={0.40} sub="for 4 years, then step-down"/>
            <Lever label="MAINT. DURATION" value="48 mo" pct={0.66} sub="court ceiling: 60 mo"/>
            <Lever label="PENSION SHARE" value="41%" pct={0.41} sub="DB offset preferred" warn/>
            <Lever label="CHILD SUPPORT" value="£820 / mo" pct={0.30} sub="CMS calculator basis"/>
          </div>

          <div className="mt-6 pt-5" style={{ borderTop: `1px solid ${TOK.gline}` }}>
            <div className="mono" style={{ fontSize: 9.5, color: TOK.gsub, letterSpacing: "0.16em", fontWeight: 600 }}>QUICK SCENARIOS</div>
            <div className="mt-3 space-y-1.5">
              {[
                { l: "Clean break · sell home", n: "v3.A", color: TOK.cyan },
                { l: "Sarah keeps home + maint",   n: "v3", active: true, color: TOK.cyan },
                { l: "Mark buys her out", n: "v3.B", color: TOK.amber },
                { l: "Defer until kids 18", n: "v3.C", color: TOK.gsub },
              ].map((s, i) => (
                <button key={i} className="w-full flex items-center justify-between px-2.5 py-2 rounded text-left"
                        style={{
                          background: s.active ? TOK.graphite3 : "transparent",
                          border: `1px solid ${s.active ? s.color : TOK.gline}`,
                        }}>
                  <span style={{ fontSize: 11.5, color: TOK.gtext }}>{s.l}</span>
                  <span className="mono" style={{ fontSize: 10, color: s.color, letterSpacing: "0.06em" }}>{s.n}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* centre: live diagram */}
        <div className="flex-1 relative">
          <CenterModel/>
        </div>

        {/* right: AI co-pilot stream */}
        <aside className="overflow-y-auto p-5 flex flex-col" style={{ width: 360, borderLeft: `1px solid ${TOK.gline}`, background: TOK.graphite2 }}>
          <div className="flex items-center gap-2 mb-3">
            <Pulse color={TOK.cyan} size={6}/>
            <span className="mono" style={{ fontSize: 10, color: TOK.cyan, letterSpacing: "0.12em", fontWeight: 600 }}>
              CO-PILOT · STREAMING
            </span>
          </div>

          <div className="space-y-3 flex-1">
            <StreamLine ts="14:32:01" body="Iterating on capital split. Tested 50/50 → 60/40 in 0.5% steps."/>
            <StreamLine ts="14:32:02" body="58/42 maximises 'reasonableness' against last 3y of comparable cases."/>
            <StreamLine ts="14:32:03" hi body={<>Detected risk: pension share at 41% may be challenged. <span style={{ color: TOK.amber }}>Modelling DB offset alternative…</span></>}/>
            <StreamLine ts="14:32:04" body="DB offset reduces challenge probability by 14 points. Recommend."/>
            <StreamLine ts="14:32:05" body={<>Reading <span className="mono" style={{ color: TOK.cyan }}>Standish v Standish (2024)</span> for pension treatment.</>}/>
            <StreamLine ts="14:32:06" body="Confirmed: no non-matrimonial argument applies here. Proceed."/>
            <StreamLine ts="14:32:07" hi body={<>Final score <span style={{ color: TOK.green }}>92</span>. Mark's predicted reaction: <span style={{ color: TOK.amber }}>ACCEPT</span> (78%).</>}/>
            <StreamLine ts="14:32:08" pulse body="Continuing to monitor for new precedent and bank movements…"/>
          </div>

          <div className="pt-4 mt-4" style={{ borderTop: `1px solid ${TOK.gline}` }}>
            <div className="rounded-lg px-3 py-2.5 flex items-center gap-2"
                 style={{ background: TOK.graphite3, border: `1px solid ${TOK.gline}` }}>
              <I.spark s={13} c={TOK.cyan}/>
              <span style={{ fontSize: 12, color: TOK.gsub, flex: 1 }}>Ask the model anything…</span>
              <span className="mono" style={{ fontSize: 9.5, color: TOK.gsub }}>⌘K</span>
            </div>
          </div>
        </aside>
      </div>

      {/* footer ticker */}
      <footer className="flex items-center px-5 mono gap-6" style={{ height: 28, background: TOK.graphite2, borderTop: `1px solid ${TOK.gline}`, flexShrink: 0, fontSize: 10, color: TOK.gsub, letterSpacing: "0.06em" }}>
        <span>● LIVE</span>
        <span style={{ color: TOK.gline }}>|</span>
        <span>baseline 50/50</span>
        <span>·</span>
        <span style={{ color: TOK.cyan }}>current 58/42</span>
        <span>·</span>
        <span style={{ color: TOK.green }}>↑ +14 reasonableness vs v2</span>
        <span style={{ color: TOK.gline }}>|</span>
        <span>monitoring 4 case databases</span>
        <span style={{ color: TOK.gline }}>|</span>
        <span style={{ color: TOK.amber }}>1 advisory</span>
        <div className="flex-1"/>
        <span>auto-saved · v3 · 14:32:08</span>
      </footer>
    </div>
  );
}

function Readout({ label, value, unit, color, sparkline }) {
  return (
    <div>
      <div className="mono" style={{ fontSize: 9.5, color: TOK.gsub, letterSpacing: "0.12em", fontWeight: 600 }}>{label}</div>
      <div className="flex items-baseline gap-1.5 mt-1">
        <span className="serif tabular" style={{ fontSize: 26, fontWeight: 600, letterSpacing: "-0.02em", color }}>{value}</span>
        <span className="mono" style={{ fontSize: 10, color: TOK.gsub }}>{unit}</span>
      </div>
      {sparkline && (
        <svg width="80" height="14" className="mt-1">
          <polyline points="0,10 10,8 20,9 30,6 40,7 50,4 60,5 70,3 80,2"
                    fill="none" stroke={color} strokeWidth={1}/>
        </svg>
      )}
    </div>
  );
}

function Lever({ label, value, pct, band, sub, warn }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <span className="mono" style={{ fontSize: 9.5, color: TOK.gsub, letterSpacing: "0.1em", fontWeight: 600 }}>{label}</span>
        <span className="mono" style={{ fontSize: 11, color: warn ? TOK.amber : TOK.cyan, fontWeight: 600 }}>{value}</span>
      </div>
      <div className="relative h-1.5 rounded-full" style={{ background: TOK.graphite3 }}>
        {band && (
          <div className="absolute top-0 bottom-0 rounded-full"
               style={{ left: `${band[0] * 100}%`, width: `${(band[1] - band[0]) * 100}%`, background: `${TOK.green}33`, border: `1px solid ${TOK.green}66` }}/>
        )}
        <div className="absolute top-0 bottom-0 rounded-full" style={{ width: `${pct * 100}%`, background: warn ? TOK.amber : TOK.cyan }}/>
        <div className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full"
             style={{ left: `calc(${pct * 100}% - 6px)`, background: "#FFF", boxShadow: `0 0 0 2px ${warn ? TOK.amber : TOK.cyan}` }}/>
      </div>
      {sub && <div className="mono mt-1.5" style={{ fontSize: 10, color: TOK.gsub, letterSpacing: "0.04em" }}>{sub}</div>}
    </div>
  );
}

function StreamLine({ ts, body, hi, pulse }) {
  return (
    <div className="flex gap-2.5" style={{
      padding: "6px 8px", borderRadius: 4,
      background: hi ? TOK.graphite3 : "transparent",
      borderLeft: pulse ? `2px solid ${TOK.cyan}` : "2px solid transparent"
    }}>
      <span className="mono" style={{ fontSize: 10, color: TOK.gsub, letterSpacing: "0.04em", flexShrink: 0 }}>{ts}</span>
      <div style={{ fontSize: 11.5, color: TOK.gtext, lineHeight: 1.5 }}>
        {body}
      </div>
    </div>
  );
}

/* ─── centre live model: assets bar + future timeline ─── */
function CenterModel() {
  return (
    <div className="absolute inset-0 p-7 flex flex-col gap-5">
      {/* asset waterfall */}
      <div className="rounded-lg p-5" style={{ background: TOK.graphite2, border: `1px solid ${TOK.gline}` }}>
        <div className="flex items-center justify-between mb-4">
          <div className="mono" style={{ fontSize: 9.5, color: TOK.gsub, letterSpacing: "0.16em", fontWeight: 600 }}>ASSET ALLOCATION · LIVE</div>
          <Trace color={TOK.cyan}>£612k total · 58/42 split</Trace>
        </div>
        <div className="h-12 flex items-stretch rounded overflow-hidden" style={{ background: TOK.graphite3 }}>
          <Slice w={31} c={TOK.cyan} l="HOME" v="£260k" sub="Sarah keeps"/>
          <Slice w={20} c={`${TOK.cyan}AA`} l="PENSION (S)" v="£170k"/>
          <Slice w={7} c={`${TOK.cyan}77`} l="LIQ" v="£24k"/>
          <Slice w={2} c={TOK.gline} l="" v=""/>
          <Slice w={20} c={TOK.amber} l="HOME EQ" v="£187k" sub="Mark gets"/>
          <Slice w={14} c={`${TOK.amber}AA`} l="SIPP+DB" v="£134k"/>
          <Slice w={6} c={`${TOK.amber}77`} l="LIQ" v="£36k"/>
        </div>
      </div>

      {/* timeline */}
      <div className="rounded-lg p-5 flex-1" style={{ background: TOK.graphite2, border: `1px solid ${TOK.gline}` }}>
        <div className="flex items-center justify-between mb-4">
          <div className="mono" style={{ fontSize: 9.5, color: TOK.gsub, letterSpacing: "0.16em", fontWeight: 600 }}>TIMELINE · NEXT 5 YEARS</div>
          <Trace color={TOK.cyan}>monthly cashflow projection</Trace>
        </div>
        <svg viewBox="0 0 600 220" width="100%" height="220">
          {/* gridlines */}
          {[0, 1, 2, 3, 4, 5].map(y => (
            <line key={y} x1="40" y1={20 + y * 35} x2="600" y2={20 + y * 35} stroke={TOK.gline} strokeWidth={0.5}/>
          ))}
          {/* y labels */}
          {["£3k", "£2k", "£1k", "£0", "−£1k"].map((l, i) => (
            <text key={i} x={32} y={28 + i * 35 * 1.2} textAnchor="end" fontSize="9" fontFamily="JetBrains Mono, monospace" fill={TOK.gsub}>{l}</text>
          ))}
          {/* Sarah surplus area */}
          <path d="M 40 70 L 140 60 L 240 65 L 340 55 L 440 50 L 540 80 L 540 120 L 40 120 Z"
                fill={`${TOK.cyan}22`} stroke={TOK.cyan} strokeWidth={1.5}/>
          <text x={50} y={62} fontSize="10" fontFamily="JetBrains Mono, monospace" fill={TOK.cyan} fontWeight="600">SARAH</text>
          {/* Mark surplus area */}
          <path d="M 40 90 L 140 95 L 240 80 L 340 70 L 440 60 L 540 50 L 540 120 L 40 120 Z"
                fill={`${TOK.amber}22`} stroke={TOK.amber} strokeWidth={1.5} strokeDasharray="3 3"/>
          <text x={550} y={62} fontSize="10" fontFamily="JetBrains Mono, monospace" fill={TOK.amber} fontWeight="600" textAnchor="end">MARK</text>
          {/* maintenance step-down marker */}
          <line x1="380" y1="20" x2="380" y2="200" stroke={TOK.amber} strokeWidth={1} strokeDasharray="2 3" opacity={0.6}/>
          <text x={384} y={32} fontSize="9.5" fill={TOK.amber} fontFamily="JetBrains Mono, monospace">MAINT STEP-DOWN · YR 3</text>
          {/* x labels */}
          {["2026", "2027", "2028", "2029", "2030", "2031"].map((l, i) => (
            <text key={i} x={40 + i * 100} y={215} fontSize="9.5" fontFamily="JetBrains Mono, monospace" fill={TOK.gsub} textAnchor="middle">{l}</text>
          ))}
        </svg>
        <div className="flex items-center gap-4 mt-3 pt-3" style={{ borderTop: `1px solid ${TOK.gline}` }}>
          <Trace color={TOK.cyan}>● Sarah · surplus £620/mo by yr 3</Trace>
          <Trace color={TOK.amber}>● Mark · surplus £840/mo by yr 3</Trace>
          <div className="flex-1"/>
          <Trace color={TOK.green}>both above 'needs' floor · ✓</Trace>
        </div>
      </div>
    </div>
  );
}

function Slice({ w, c, l, v, sub }) {
  if (!l) return <div style={{ flex: w, background: c }}/>;
  return (
    <div className="relative flex items-center justify-center" style={{ flex: w, background: c }}>
      <div className="text-center">
        <div className="mono" style={{ fontSize: 9, color: "rgba(0,0,0,0.7)", letterSpacing: "0.06em", fontWeight: 700 }}>{l}</div>
        <div className="mono" style={{ fontSize: 10.5, color: "rgba(0,0,0,0.85)", fontWeight: 600 }}>{v}</div>
      </div>
      {sub && <div className="absolute -bottom-5 left-0 mono" style={{ fontSize: 9, color: TOK.gsub, letterSpacing: "0.04em" }}>{sub}</div>}
    </div>
  );
}

window.Proposal_Sim = Proposal_Sim;
