/* ============================================================
   12 · Household — Ambient with a centre Joint rail
   ------------------------------------------------------------
   Mash of #08 (ambient doc + comment threads) and #10 (joint
   middle column). Visual idea: a calm, document-feeling page
   with a quiet vertical "joint rail" running down the middle.
   - Items snap to one of three lanes: Sarah, Joint, Mark.
   - Joint items live on the centre rail with a soft node.
   - Sole items hang to one side with a hairline tether.
   - Conflicts live as twin nodes (Sarah's value | Mark's value)
     joined by a coloured bridge, with a thread bubble on the rail.
   - Aggregate totals (combined income/outgoings) live as larger
     nodes on the rail — the "combined points".
   ============================================================ */

function Household_AmbientRail() {
  const [openThread, setOpenThread] = React.useState("hsbc");

  return (
    <div style={{
      width: 1280, height: 920, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Reconcile</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>The combined picture</span>
            <Chip bg={TOK.magentaSoft} fg={TOK.magenta}>Joint rail · v2</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Avatar2 name="S" color={TOK.indigo}/>
          <Avatar2 name="M" color={TOK.magenta}/>
          <span className="mono" style={{ fontSize: 10, color: TOK.mute, letterSpacing: "0.04em" }}>both online</span>
          <button className="ml-2 h-7 px-2.5 rounded-md text-[11.5px] font-medium" style={{ background: TOK.ink, color: "#FFF" }}>
            Approve & lock
          </button>
        </div>
      </header>

      {/* status strip */}
      <div className="px-6 py-2.5 flex items-center gap-5" style={{ borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <Stat2 l="Joint" v="£455k" c={TOK.green}/>
        <Stat2 l="Sarah sole" v="£298k" c={TOK.indigo}/>
        <Stat2 l="Mark sole" v="£218k" c={TOK.magenta}/>
        <span style={{ color: TOK.line, fontSize: 18 }}>·</span>
        <Stat2 l="Threads open" v="3" c={TOK.flag}/>
        <Stat2 l="AI assumptions" v="14" c={TOK.mute}/>
        <div className="flex-1"/>
        <Pulse size={5}/>
        <span className="mono" style={{ fontSize: 10, color: TOK.sub, letterSpacing: "0.04em" }}>
          THE RAIL IS LIVE · 12s ago
        </span>
      </div>

      {/* body */}
      <div className="flex-1 overflow-hidden flex" style={{ minHeight: 0 }}>
        <div className="flex-1 overflow-y-auto" style={{ position: "relative" }}>
          {/* hero */}
          <div className="px-12 pt-7 pb-3">
            <Kicker color={TOK.magenta}>Sarah · Joint · Mark</Kicker>
            <h1 className="serif mt-1.5" style={{ fontSize: 32, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.08 }}>
              The shape of the <span style={{ fontStyle: "italic", color: TOK.sub }}>household</span>, on one rail.
            </h1>
            <Murmur color={TOK.magenta}>
              The line down the middle is what you hold <i>together</i>. Items hang to one side or the other when they're held alone.
              When the same fact has two values, you'll see a bridge across the rail — and a comment thread above it.
            </Murmur>
          </div>

          {/* THE RAIL */}
          <div className="relative px-8 pb-8" style={{ minHeight: 1200 }}>
            {/* the rail itself */}
            <div className="absolute" style={{
              left: "50%", top: 8, bottom: 0, width: 1.5,
              background: `linear-gradient(180deg, ${TOK.line} 0%, ${TOK.green}55 6%, ${TOK.green}55 94%, ${TOK.line} 100%)`,
              transform: "translateX(-50%)"
            }}/>
            {/* rail label at top */}
            <div className="absolute" style={{ left: "50%", top: -2, transform: "translateX(-50%)" }}>
              <div className="px-2.5 py-0.5 rounded-full" style={{ background: "#F0FDF4", border: `1px solid ${TOK.green}` }}>
                <span className="mono" style={{ fontSize: 9, letterSpacing: "0.1em", color: TOK.green, fontWeight: 600, textTransform: "uppercase" }}>JOINT RAIL</span>
              </div>
            </div>

            {/* HOME */}
            <SectionLabel>The home</SectionLabel>

            <RailRow lane="joint"
                     name="Family home · Hampstead" amt="£860,000"
                     note="Both names · Land Registry · Zoopla 12 Apr">
              <Murmur color={TOK.green}>Owned jointly. Equity defaults to 50/50 each side until you say otherwise.</Murmur>
            </RailRow>

            <RailConflict
              name="Independent valuation needed?"
              thread="house-val" threadCount={3} open={openThread} onOpen={setOpenThread}
              left={{ who: "Sarah", color: TOK.indigo, value: "trust Zoopla" }}
              right={{ who: "Mark", color: TOK.magenta, value: "wants RICS" }}
              ai="Zoopla confidence here is 0.78. Two recent comparables sold over 4 months ago — RICS ~£500 (split)."/>

            <RailRow lane="joint" debt
                     name="Halifax mortgage outstanding" amt="-£412,400"
                     note="Joint · live balance"/>

            {/* CASH */}
            <SectionLabel>Cash & savings</SectionLabel>

            <RailRow lane="joint" name="Monzo joint" amt="£8,640" note="Both named · live"/>
            <RailRow lane="sarah" name="Halifax current (Sarah)" amt="£14,820" note="Sole · live"/>
            <RailRow lane="mark"  name="Barclays current (Mark)" amt="£11,940" note="Sole · live"/>
            <RailRow lane="sarah" name="NS&I Premium Bonds (Sarah)" amt="£20,000" note="Self-declared"/>

            {/* PENSIONS */}
            <SectionLabel sub="held individually · divisible at proposal">Pensions</SectionLabel>

            <RailRow lane="sarah" name="NHS career pension" amt="£284,000" note="CETV · 2 Mar"/>

            <RailConflict
              name="DC pension (Mark) — current value"
              thread="mark-sipp" threadCount={2} open={openThread} onOpen={setOpenThread}
              left={{ who: "Sarah", color: TOK.indigo, value: "£196,000" }}
              right={{ who: "Mark", color: TOK.magenta, value: "£218,400" }}
              ai="Mark's figure is current and verifiable. Sarah's is from last year. Recommend updating."
              soleSide="mark"/>

            {/* DEBTS */}
            <SectionLabel>Debts</SectionLabel>

            <RailConflict
              name="HSBC Credit Card · balance"
              thread="hsbc" threadCount={5} open={openThread} onOpen={setOpenThread}
              left={{ who: "Sarah", color: TOK.indigo, value: "not declared" }}
              right={{ who: "Mark", color: TOK.magenta, value: "£6,200 · Jan" }}
              ai="Outflows from Sarah's Halifax to HSBC since November suggest the balance has moved. Mark's column, tagged as matrimonial debt."
              soleSide="mark" debt/>

            <RailRow lane="joint" debt name="John Lewis sofa finance" amt="-£1,820" note="Both signed"/>

            {/* INCOME · COMBINED POINT */}
            <SectionLabel>Income</SectionLabel>
            <RailRow lane="sarah" name="Sarah's NHS salary" amt="£3,847/mo" note="Halifax · stable"/>
            <RailRow lane="mark"  name="Mark's salary"      amt="£4,793/mo" note="Barclays · stable"/>
            <RailCombined
              label="Combined household income"
              amt="£8,640/mo"
              note="Sum used by court for reasonableness · auto-aggregated"/>

            {/* OUTGOINGS · COMBINED POINT */}
            <SectionLabel>Outgoings</SectionLabel>
            <RailRow lane="joint" name="Housing (mortgage, council, utilities)" amt="-£2,184/mo" note="From joint Monzo"/>
            <RailRow lane="joint" name="Children · school + activities" amt="-£1,210/mo" note="Default-joint"/>
            <RailConflict
              name="After-school club · £280/mo"
              thread="afterschool" threadCount={2} open={openThread} onOpen={setOpenThread}
              left={{ who: "Sarah", color: TOK.indigo, value: "Mark's contribution" }}
              right={{ who: "Mark", color: TOK.magenta, value: "my share of childcare" }}
              ai="Same money described two ways. I'll fold into joint child cost."
              note="discussion · not a number"/>
            <RailRow lane="sarah" name="Sarah's personal" amt="-£687/mo"/>
            <RailRow lane="mark"  name="Mark's personal"  amt="-£743/mo"/>
            <RailCombined
              label="Combined household outgoings"
              amt="-£4,824/mo"
              note="Tested against income · auto-aggregated"
              negative/>

            {/* CHILDREN */}
            <SectionLabel sub="context · revisited at proposal">The children</SectionLabel>
            <RailRow lane="joint" name="Lily (11) and Oscar (8)" amt="2 children" note="St Mary's · both at school"/>
            <RailConflict
              name="Schooling continuity"
              thread="schools" threadCount={8} open={openThread} onOpen={setOpenThread}
              left={{ who: "Sarah", color: TOK.indigo, value: "stay at St Mary's" }}
              right={{ who: "Mark", color: TOK.magenta, value: "open to a move" }}
              ai="Marking and parking. Resurfaces when we model Mark's housing — that's where school continuity actually gets decided."
              note="discussion · not a number"/>

            {/* THE TOTAL POT */}
            <div className="mt-10 flex justify-center">
              <div className="rounded-xl px-5 py-3" style={{ background: "#F0FDF4", border: `1px solid ${TOK.green}`, minWidth: 320 }}>
                <div className="text-center">
                  <Trace color={TOK.green}>matrimonial pot · ready for proposal</Trace>
                  <div className="serif tabular mt-1" style={{ fontSize: 28, fontWeight: 600, color: TOK.ink, letterSpacing: "-0.02em" }}>£971,380</div>
                  <Murmur color={TOK.green}>Joint £455k + Sarah's £298k + Mark's £218k. Pensions individually held but divisible at proposal stage.</Murmur>
                </div>
              </div>
            </div>

            <div className="h-12"/>
          </div>
        </div>

        {/* THREAD PANEL · reuses ThreadPanel from #11 (window.ThreadPanel) */}
        {window.ThreadPanel
          ? <window.ThreadPanel open={openThread} onClose={() => setOpenThread(null)}/>
          : <ThreadPanelLite open={openThread} onClose={() => setOpenThread(null)}/>
        }
      </div>

      <footer className="flex items-center justify-between px-6"
              style={{ height: 30, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>auto-saved</Trace><Trace>14 ai assumptions · 0 overrides</Trace>
        </div>
        <div className="text-[10.5px]" style={{ color: TOK.mute }}>
          The rail = held together · sides = held alone · bridges = still in conversation
        </div>
      </footer>
    </div>
  );
}

/* =============== rail pieces =============== */

function SectionLabel({ children, sub }) {
  return (
    <div className="relative my-5 flex items-center justify-center">
      <div className="px-3 py-1 rounded-full flex items-center gap-2" style={{
        background: TOK.bg, border: `1px solid ${TOK.line}`, position: "relative", zIndex: 1
      }}>
        <span className="serif" style={{ fontSize: 13, fontWeight: 600, color: TOK.ink }}>{children}</span>
        {sub && <Trace>· {sub}</Trace>}
      </div>
    </div>
  );
}

/* a single row that snaps to one of three lanes (sarah / joint / mark) */
function RailRow({ lane, name, amt, note, debt, children }) {
  const isJoint = lane === "joint";
  const isSarah = lane === "sarah";
  const isMark  = lane === "mark";
  const color = isJoint ? TOK.green : isSarah ? TOK.indigo : TOK.magenta;

  // Layout: 12-col grid centred on rail. Sarah lane fills cols 1-6, Mark 7-12, joint straddles centre.
  return (
    <div className="grid items-stretch py-1.5" style={{ gridTemplateColumns: "1fr 1fr", position: "relative" }}>
      {/* Sarah half */}
      <div className="pr-7 flex justify-end" style={{ position: "relative" }}>
        {isSarah && <SoloCard side="left" color={TOK.indigo} name={name} amt={amt} note={note} debt={debt}/>}
      </div>
      {/* Mark half */}
      <div className="pl-7 flex justify-start" style={{ position: "relative" }}>
        {isMark && <SoloCard side="right" color={TOK.magenta} name={name} amt={amt} note={note} debt={debt}/>}
      </div>

      {/* tether to rail */}
      {!isJoint && (
        <div className="absolute" style={{
          top: 22, height: 1, background: color + "55",
          left: isSarah ? "auto" : "50%",
          right: isSarah ? "50%" : "auto",
          width: 28
        }}/>
      )}

      {/* the joint node sits ON the rail */}
      {isJoint && (
        <div className="absolute pointer-events-none" style={{
          left: "50%", top: 0, transform: "translateX(-50%)",
          pointerEvents: "auto"
        }}>
          <JointCard name={name} amt={amt} note={note} debt={debt}/>
        </div>
      )}

      {/* dot on rail */}
      {!isJoint && (
        <div className="absolute" style={{
          left: "50%", top: 19, width: 7, height: 7, borderRadius: 99,
          background: "#FFF", border: `1.5px solid ${color}`, transform: "translate(-50%, 0)"
        }}/>
      )}
    </div>
  );
}

function SoloCard({ side, color, name, amt, note, debt }) {
  return (
    <div className="rounded-md px-3 py-2" style={{
      background: "#FFF", border: `1px solid ${TOK.line}`, maxWidth: 320,
      textAlign: side === "left" ? "right" : "left"
    }}>
      <div className="flex items-center gap-1.5" style={{ justifyContent: side === "left" ? "flex-end" : "flex-start" }}>
        <span style={{ width: 6, height: 6, borderRadius: 99, background: color, display: "inline-block" }}/>
        <span className="text-[12px] font-medium" style={{ color: TOK.ink }}>{name}</span>
      </div>
      <div className="mono tabular mt-0.5" style={{ fontSize: 13, fontWeight: 500, color: debt ? TOK.flag : TOK.ink }}>{amt}</div>
      {note && <Trace color={TOK.mute}>{note}</Trace>}
    </div>
  );
}

function JointCard({ name, amt, note, debt }) {
  return (
    <div className="rounded-md px-3 py-2 text-center" style={{
      background: "#F4FBF7", border: `1px solid ${TOK.green}`, minWidth: 280, maxWidth: 360
    }}>
      <div className="flex items-center justify-center gap-1.5">
        <I.users s={11} c={TOK.green}/>
        <span className="text-[12px] font-medium" style={{ color: TOK.ink }}>{name}</span>
      </div>
      <div className="mono tabular mt-0.5" style={{ fontSize: 13.5, fontWeight: 500, color: debt ? TOK.flag : TOK.green }}>{amt}</div>
      {note && <Trace color={TOK.mute}>{note}</Trace>}
    </div>
  );
}

/* a conflict — twin nodes joined by a coloured bridge across the rail */
function RailConflict({ name, thread, threadCount, open, onOpen, left, right, ai, soleSide, debt, note }) {
  const isOpen = open === thread;
  return (
    <div className="grid items-stretch py-3 my-1" style={{
      gridTemplateColumns: "1fr 1fr", position: "relative",
      background: isOpen ? "#FFFAF0" : "transparent",
      borderRadius: 12,
      border: isOpen ? `1px solid ${TOK.flag}` : `1px solid transparent`,
      paddingLeft: 6, paddingRight: 6
    }}>
      {/* row title above the bridge */}
      <div className="absolute" style={{
        left: "50%", top: -8, transform: "translateX(-50%)", zIndex: 3,
      }}>
        <div className="px-2.5 py-0.5 rounded-full flex items-center gap-1.5" style={{
          background: "#FFF", border: `1px solid ${TOK.flag}`,
        }}>
          <I.flag s={9} c={TOK.flag}/>
          <span className="text-[11px] font-medium" style={{ color: TOK.flag }}>{name}</span>
          {note && <Trace color={TOK.mute}>· {note}</Trace>}
        </div>
      </div>

      {/* Sarah node */}
      <div className="pr-7 flex justify-end items-center" style={{ paddingTop: 12 }}>
        <SideValue who={left.who} color={left.color} value={left.value}/>
      </div>
      <div className="pl-7 flex justify-start items-center" style={{ paddingTop: 12 }}>
        <SideValue who={right.who} color={right.color} value={right.value}/>
      </div>

      {/* the bridge across the rail */}
      <div className="absolute" style={{
        left: "calc(50% - 100px)", top: 36, width: 200, height: 16,
        pointerEvents: "none"
      }}>
        <svg viewBox="0 0 200 16" style={{ width: "100%", height: "100%" }}>
          <path d={`M 0 8 L 80 8 M 120 8 L 200 8`} stroke={TOK.flag} strokeWidth="1.5" strokeDasharray="3 3" fill="none"/>
          {/* twin tethers */}
          <line x1="0" y1="8" x2="-2" y2="8" stroke={left.color} strokeWidth="2"/>
          <line x1="200" y1="8" x2="202" y2="8" stroke={right.color} strokeWidth="2"/>
        </svg>
      </div>

      {/* thread bubble on rail */}
      <button onClick={() => onOpen(thread)}
              className="absolute flex items-center justify-center rounded-full"
              style={{
                left: "50%", top: 28, transform: "translate(-50%, 0)",
                width: 32, height: 32,
                background: isOpen ? TOK.flag : "#FFF",
                border: `1.5px solid ${TOK.flag}`,
                boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
                zIndex: 2
              }}>
        <span className="mono" style={{ fontSize: 11, fontWeight: 700, color: isOpen ? "#FFF" : TOK.flag }}>{threadCount}</span>
      </button>

      {/* AI take spans below */}
      <div className="col-span-2 flex items-start gap-2 px-8 mt-2">
        <I.spark s={11} c={TOK.flag} style={{ marginTop: 2, flexShrink: 0 }}/>
        <Murmur color={TOK.flag}>{ai}</Murmur>
      </div>
    </div>
  );
}

function SideValue({ who, color, value }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-md"
         style={{ background: "#FFF", border: `1px solid ${color}55`, maxWidth: 280 }}>
      <Avatar2 name={who?.[0] || "?"} color={color} size={20}/>
      <div className="min-w-0">
        <Trace color={color}>{who} says</Trace>
        <div className="text-[12.5px] truncate" style={{ color: TOK.ink }}>{value}</div>
      </div>
    </div>
  );
}

/* a "combined point" — large node on the rail for aggregates */
function RailCombined({ label, amt, note, negative }) {
  return (
    <div className="grid items-stretch my-3 py-2" style={{ gridTemplateColumns: "1fr 1fr", position: "relative" }}>
      <div/>
      <div/>
      <div className="absolute" style={{ left: "50%", top: 0, transform: "translateX(-50%)" }}>
        <div className="rounded-lg px-4 py-2.5 text-center" style={{
          background: "#FFF", border: `2px solid ${TOK.green}`, minWidth: 320,
          boxShadow: "0 2px 8px rgba(22,101,52,0.12)"
        }}>
          <div className="flex items-center justify-center gap-1.5">
            <I.layers s={11} c={TOK.green}/>
            <Trace color={TOK.green}>combined point</Trace>
          </div>
          <div className="text-[12px] font-medium mt-0.5" style={{ color: TOK.ink }}>{label}</div>
          <div className="serif tabular mt-1" style={{ fontSize: 22, fontWeight: 600, color: negative ? TOK.flag : TOK.green, letterSpacing: "-0.02em", lineHeight: 1 }}>{amt}</div>
          {note && <Trace color={TOK.mute}>{note}</Trace>}
        </div>
      </div>
    </div>
  );
}

/* tiny lite thread panel as fallback if window.ThreadPanel isn't loaded */
function ThreadPanelLite({ open, onClose }) {
  return (
    <aside style={{ width: 360, borderLeft: `1px solid ${TOK.line}`, background: "#FFF" }}
           className="overflow-y-auto p-7">
      <Kicker color={TOK.magenta}>Thread {open || "—"}</Kicker>
      <Murmur color={TOK.sub}>(thread panel from another artboard)</Murmur>
    </aside>
  );
}

function Avatar2({ name, color, size = 22 }) {
  return (
    <div className="rounded-full flex items-center justify-center text-white font-semibold"
         style={{ width: size, height: size, background: color, fontSize: size <= 20 ? 10 : 10.5 }}>
      {name}
    </div>
  );
}

function Stat2({ l, v, c }) {
  return (
    <div>
      <Trace>{l}</Trace>
      <div className="serif tabular" style={{ fontSize: 16, fontWeight: 600, color: c, letterSpacing: "-0.02em", lineHeight: 1 }}>{v}</div>
    </div>
  );
}

window.Household_AmbientRail = Household_AmbientRail;
