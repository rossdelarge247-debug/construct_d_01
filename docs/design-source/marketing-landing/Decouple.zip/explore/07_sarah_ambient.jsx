/* ============================================================
   07 · Sarah's Picture — Ambient (full landscape)
   ------------------------------------------------------------
   All five chapters of the picture on a single ambient canvas:
   Assets, Income, Debts, Outgoings, Children. Mix of auto-filled
   from banks (with confidence), partly done, and untouched. AI
   leaves todos in the margin against specific entries.
   This is about CAPTURING THE PICTURE — not the plan.
   ============================================================ */

function Sarah_Ambient() {
  const [navOpen, setNavOpen] = React.useState(false);
  return (
    <div style={{
      width: 1280, height: 920, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* faint vertical rule down the page */}
      <div style={{
        position: "absolute", left: 880, top: 0, bottom: 0, width: 1,
        background: TOK.hairline, pointerEvents: "none"
      }}/>

      {/* COLLAPSIBLE LEFT NAV */}
      {navOpen && (
        <div style={{ position: "absolute", inset: 0, zIndex: 30, display: "flex" }}>
          <div onClick={() => setNavOpen(false)}
               style={{ position: "absolute", inset: 0, background: "rgba(21,23,26,0.18)" }}/>
          <aside style={{
            position: "relative", zIndex: 1, width: 288, height: "100%",
            background: TOK.paper, borderRight: `1px solid ${TOK.line}`,
            display: "flex", flexDirection: "column",
            boxShadow: "0 12px 40px rgba(0,0,0,0.10)"
          }}>
            <div className="flex items-center justify-between px-4" style={{ height: 52, borderBottom: `1px solid ${TOK.hairline}` }}>
              <span className="serif" style={{ fontSize: 14, fontWeight: 600, letterSpacing: "-0.01em", color: TOK.ink }}>Decouple</span>
              <button onClick={() => setNavOpen(false)}
                      className="w-7 h-7 rounded-sm flex items-center justify-center"
                      style={{ background: "transparent" }}>
                <I.close s={14} c={TOK.sub}/>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto px-3 py-4">
              {/* you */}
              <div className="flex items-center gap-2 px-2 mb-3">
                <div className="rounded-full flex items-center justify-center text-white font-semibold"
                     style={{ width: 28, height: 28, background: TOK.indigo, fontSize: 11 }}>S</div>
                <div className="min-w-0">
                  <div className="text-[12.5px] font-medium" style={{ color: TOK.ink }}>Sarah Whitman</div>
                  <Trace>private workspace · saved</Trace>
                </div>
              </div>

              <NavSection label="The document">
                <NavItem icon="home"  active>Overview</NavItem>
                <NavItem icon="user">My picture</NavItem>
                <NavItem icon="users" right="invite">Our household</NavItem>
                <NavItem icon="scale" muted>Settlement</NavItem>
              </NavSection>

              <NavSection label="Chapters">
                <NavItem icon="bank"   right="64%">Assets</NavItem>
                <NavItem icon="pulse"  right="100%">Income</NavItem>
                <NavItem icon="flag"   right="!" alarm>Debts</NavItem>
                <NavItem icon="doc"    right="88%">Outgoings</NavItem>
                <NavItem icon="kid"    right="60%">Children</NavItem>
              </NavSection>

              <NavSection label="Shared">
                <NavItem icon="user" muted>Mark — invited</NavItem>
                <NavItem icon="lock" muted>Privacy & access</NavItem>
              </NavSection>

              <NavSection label="History">
                <NavItem icon="doc">Activity</NavItem>
                <NavItem icon="layers">Versions</NavItem>
              </NavSection>
            </div>
            <div className="px-3 py-3" style={{ borderTop: `1px solid ${TOK.hairline}` }}>
              <NavItem icon="brain">Help & guides</NavItem>
              <NavItem icon="cmd" muted>Settings</NavItem>
            </div>
          </aside>
        </div>
      )}

      {/* top bar */}
      <header className="flex items-center justify-between px-4"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-2">
          <button onClick={() => setNavOpen(true)}
                  className="w-9 h-9 rounded-md flex items-center justify-center"
                  style={{ background: "transparent" }}
                  onMouseEnter={e => e.currentTarget.style.background = TOK.cream}
                  onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                 stroke={TOK.ink} strokeWidth="1.8" strokeLinecap="round">
              <line x1="4" y1="7"  x2="20" y2="7"/>
              <line x1="4" y1="12" x2="20" y2="12"/>
              <line x1="4" y1="17" x2="20" y2="17"/>
            </svg>
          </button>
          <div className="flex items-center gap-1.5 text-[12px] ml-1">
            <span style={{ color: TOK.mute }}>Disclose</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Sarah's Picture</span>
            <Chip bg={TOK.indigoSoft} fg={TOK.indigo}>Private · only you</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 h-7 rounded-md" style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
            <Pulse size={5}/>
            <span className="mono" style={{ fontSize: 10, color: TOK.sub, letterSpacing: "0.04em" }}>4 banks · synced 3m ago</span>
          </div>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                  style={{ background: TOK.ink, color: "#FFF" }}>
            <I.share s={11} c="#FFF"/> Share with Mark
          </button>
        </div>
      </header>

      {/* command bar */}
      <div className="px-6 py-3 flex items-center gap-3" style={{ borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <I.spark s={14} c={TOK.indigo}/>
        <span style={{ flex: 1, fontSize: 13, color: TOK.faint }}>
          Ask anything · "what does my mortgage cost over the year?" · "find duplicate transactions"
        </span>
        <span className="mono" style={{ fontSize: 10, color: TOK.faint, letterSpacing: "0.06em" }}>⌘K</span>
      </div>

      {/* hero */}
      <div className="px-12 pt-7 pb-2 flex-shrink-0">
        <Kicker color={TOK.indigo}>Your picture · 64% complete</Kicker>
        <h1 className="serif mt-2" style={{ fontSize: 38, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.05 }}>
          The shape of your <span style={{ fontStyle: "italic", color: TOK.sub }}>financial life.</span>
        </h1>
        <div className="mt-4 grid grid-cols-5 gap-3">
          {[
            { l: "Assets",     v: "£612k",   sub: "11 entries · 2 to confirm",  pct: 82, c: TOK.indigo },
            { l: "Income",     v: "£5,140/mo", sub: "Salary + transfers",         pct: 100, c: TOK.green },
            { l: "Debts",      v: "—",        sub: "1 detected, balance unknown", pct: 12, c: TOK.flag, alarm: true },
            { l: "Outgoings",  v: "£4,287/mo", sub: "1,247 of 1,284 categorised", pct: 88, c: TOK.indigo },
            { l: "Children",   v: "2 kids",   sub: "Lily 11 · Oscar 8",           pct: 60, c: TOK.indigo },
          ].map((s, i) => (
            <div key={i} className="rounded-xl p-3.5" style={{
              background: s.alarm ? "#FFFAF0" : "#FFF",
              border: `1px solid ${s.alarm ? "#F3D88A" : TOK.line}`,
            }}>
              <div className="flex items-center justify-between">
                <Trace color={s.alarm ? TOK.flag : TOK.mute}>{s.l}</Trace>
                {s.alarm && <I.flag s={10} c={TOK.flag}/>}
              </div>
              <div className="mt-1.5 serif tabular" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em", color: s.alarm ? TOK.flag : TOK.ink }}>
                {s.v}
              </div>
              <div className="mt-0.5 text-[10.5px]" style={{ color: TOK.mute, lineHeight: 1.3 }}>{s.sub}</div>
              <div className="mt-2 h-[2px] rounded-full overflow-hidden" style={{ background: TOK.cream }}>
                <div className="h-full" style={{ width: `${s.pct}%`, background: s.c }}/>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* body */}
      <div className="flex-1 overflow-hidden flex" style={{ minHeight: 0 }}>
        {/* document column */}
        <div className="flex-1 overflow-y-auto px-12 py-6" style={{ maxWidth: 880 }}>

          {/* CHAPTER · Assets */}
          <ChapterBlock
            n="01" title="Assets" total="£612k" status="2 to confirm" accent={TOK.indigo}>
            <PicRow icon="home" name="Family home · Hampstead" amt="£860,000"
                    src="Zoopla estimate · 12 Apr 2026" conf={0.9}
                    badge={{ k: "auto", t: "auto-valued" }}/>
            <PicRow icon="bank" name="Halifax current account" amt="£14,820"
                    src="Halifax · live balance" conf={1}
                    badge={{ k: "live", t: "live" }}/>
            <PicRow icon="bank" name="Monzo joint" amt="£8,640"
                    src="Monzo · live balance" conf={1}
                    badge={{ k: "live", t: "live" }}/>
            <PicRow icon="pension" name="NHS career pension" amt="£284,000"
                    src="CETV · 2 Mar 2026" conf={1}/>
            <PicRow icon="bank" name="Premium Bonds" amt="—"
                    src="No statement uploaded" todo
                    todoText="Upload last NS&I statement"/>
            <PicRow icon="car" name="Vehicles · 2018 Volvo" amt="£14,200"
                    src="Auto Trader · estimate" conf={0.85} badge={{ k: "auto", t: "auto-valued" }}/>
          </ChapterBlock>

          <HR my={24}/>

          {/* CHAPTER · Income */}
          <ChapterBlock
            n="02" title="Income" total="£5,140/mo" status="all sources read" accent={TOK.green} done>
            <PicRow icon="bank" name="NHS salary (post-tax)" amt="£3,847/mo"
                    src="Halifax · monthly · stable" conf={1} badge={{ k: "live", t: "live" }}/>
            <PicRow icon="bank" name="Mark's transfers (children)" amt="£1,140/mo"
                    src="Detected as 'after-school'" conf={0.96}
                    badge={{ k: "auto", t: "AI matched" }}/>
            <PicRow icon="bank" name="Locum shifts" amt="£153/mo avg"
                    src="Variable · last 12 mo" conf={0.92}/>
          </ChapterBlock>

          <HR my={24}/>

          {/* CHAPTER · Debts (the alarm chapter) */}
          <ChapterBlock
            n="03" title="Debts" total="?" status="1 to query" accent={TOK.flag} alarm>
            <PicRow icon="bank" name="Halifax mortgage outstanding" amt="£412,400"
                    src="Halifax · live balance" conf={1} badge={{ k: "live", t: "live" }}/>
            <PicRow icon="bank" name="HSBC Credit Card" amt="?"
                    src="Detected via Halifax payment trail · payee 'HSBCCC'"
                    todo todoText="What's the current balance?"
                    sub="Decouple has spotted regular payments of £180–£420/mo to HSBC. We can't read the balance from open banking — please add it manually or connect HSBC."
                    actions={["Connect HSBC", "Enter balance manually"]}
                    flag/>
            <PicRow icon="doc" name="Personal loan" amt="—"
                    src="No record · please confirm if any" todo
                    todoText="Confirm: any other personal debt?"
                    actions={["Yes, I have a loan", "No, none"]}/>
          </ChapterBlock>

          <HR my={24}/>

          {/* CHAPTER · Outgoings */}
          <ChapterBlock
            n="04" title="Outgoings" total="£4,287/mo" status="3 categories need attention" accent={TOK.indigo}>
            <PicRow icon="home" name="Housing"     amt="£2,184/mo" src="Mortgage, council tax, utilities" conf={1} sublist={[
              "Halifax mortgage · £1,842",
              "Council tax · £218",
              "British Gas · £184 (↑22% YoY · could save £340/yr)",
            ]}/>
            <PicRow icon="kid"  name="The children" amt="£1,210/mo" src="Education + activities + clothes" conf={0.94} flag
                    todoText="Mark's £280/mo for after-school — treat as his contribution?"
                    actions={["Yes, count as Mark's", "No, mine"]}/>
            <PicRow icon="bank" name="Personal"    amt="£893/mo"   src="Food, transport, health, leisure" conf={1}/>
          </ChapterBlock>

          <HR my={24}/>

          {/* CHAPTER · Children */}
          <ChapterBlock
            n="05" title="The children" total="2" status="basic info captured" accent={TOK.indigo}>
            <PicChild name="Lily"   age="11" school="Y6 · St Mary's" notes="Asthma · inhaler"/>
            <PicChild name="Oscar"  age="8"  school="Y4 · St Mary's" notes="No medical notes"/>
            <div className="mt-3 rounded-lg p-3" style={{ background: TOK.cream, border: `1px dashed ${TOK.line}` }}>
              <div className="flex items-start gap-2">
                <I.spark s={12} c={TOK.indigo} style={{ marginTop: 2, flexShrink: 0 }}/>
                <Murmur>
                  This is just basic information about the children for context. The plan for them — schooling,
                  living arrangements, contact — is built later in the proposal. We'll come back here.
                </Murmur>
              </div>
            </div>
          </ChapterBlock>

          <div className="h-12"/>
        </div>

        {/* AI margin column */}
        <aside className="overflow-y-auto px-7 py-6" style={{ width: 380, background: "#FFF", borderLeft: `1px solid ${TOK.line}` }}>
          <Kicker color={TOK.indigo}>Decouple is reading along</Kicker>
          <div className="mt-4 flex items-center gap-2">
            <Pulse color={TOK.indigo} size={6}/>
            <span className="mono" style={{ fontSize: 10.5, color: TOK.indigo, letterSpacing: "0.04em" }}>
              READING · 3 chapters live
            </span>
          </div>

          {/* margin todos anchored to chapters */}
          <div className="mt-7 space-y-7">
            <MNote tag="against debts" color={TOK.flag}
                   q="HSBC Credit Card · balance?"
                   body={<>I see <b style={{ color: TOK.ink }}>regular payments to HSBC</b> from your Halifax account — likely a credit card. I can't read the balance unless you connect HSBC. Without it, your debts chapter stays incomplete and the proposal will under-count what you owe.</>}
                   actions={["Connect HSBC", "Enter manually"]}/>

            <MNote tag="against assets" color={TOK.indigo}
                   q="NS&I Premium Bonds"
                   body="You mentioned Premium Bonds in your initial chat. I haven't found a record. Drop the latest statement and I'll add it."
                   actions={["Upload statement", "Skip · I don't have any"]}/>

            <MNote tag="against outgoings" color={TOK.indigo}
                   q="11 subscriptions detected"
                   body={<>Spotify, Netflix, Disney+ x2 (one looks like Mark's), iCloud, ChatGPT, Calm, Audible, Times, NYT, Strava. <b style={{ color: TOK.ink }}>Two duplicates</b> · about £18/mo cleanup.</>}
                   actions={["Show all 11", "Mark Disney+ as Mark's"]}/>

            <MNote tag="watching for" color={TOK.mute}
                   q="annual irregulars"
                   body="MOT, insurance renewals, school trips. I'll spot them as they hit and fold them into your outgoings."/>

            <MNote tag="ready when you are" color={TOK.green}
                   q="ready to share?"
                   body={<>Once debts is settled (and Premium Bonds confirmed) your picture is at <b style={{ color: TOK.ink }}>~94%</b> — strong enough to share with Mark. He'll start the same flow on his side.</>}
                   primary/>
          </div>

          <HR my={24}/>

          <Kicker>I'm working on</Kicker>
          <div className="mt-3 space-y-2">
            {[
              { t: "Categorising 37 transactions", p: 94 },
              { t: "Reading Mark's transfer pattern", p: 71 },
              { t: "Estimating annual irregulars", p: 41 },
            ].map((t, i) => (
              <div key={i}>
                <div className="flex items-center justify-between text-[11.5px]">
                  <span style={{ color: TOK.sub }}>{t.t}</span>
                  <span className="mono tabular" style={{ color: TOK.faint, fontSize: 10 }}>{t.p}%</span>
                </div>
                <div className="mt-1 h-[2px] rounded-full overflow-hidden" style={{ background: TOK.cream }}>
                  <div className="h-full" style={{ width: `${t.p}%`, background: TOK.indigo }}/>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>

      <footer className="flex items-center justify-between px-6"
              style={{ height: 30, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>auto-saved</Trace><Trace>v1 · sarah only</Trace><Trace>read-only · banks</Trace>
        </div>
        <div className="text-[10.5px]" style={{ color: TOK.mute }}>
          64% complete · <span style={{ color: TOK.flag, fontWeight: 600 }}>Debts is the next gap</span>
        </div>
      </footer>
    </div>
  );
}

/* ----- pieces ----- */

function ChapterBlock({ n, title, total, status, accent, done, alarm, children }) {
  return (
    <section className="mt-4 first:mt-0">
      <div className="flex items-baseline justify-between">
        <div className="flex items-baseline gap-3">
          <span className="mono" style={{ fontSize: 11, color: accent, letterSpacing: "0.16em", fontWeight: 600 }}>{n}</span>
          <h2 className="serif" style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em" }}>{title}</h2>
          {done && <Chip bg="#F0FDF4" fg={TOK.green} border="#BBF7D0">complete</Chip>}
          {alarm && <Chip bg="#FFFAF0" fg={TOK.flag} border="#F3D88A">needs attention</Chip>}
        </div>
        <div className="text-right">
          <div className="serif tabular" style={{ fontSize: 20, fontWeight: 600, color: alarm ? TOK.flag : TOK.ink }}>{total}</div>
          <Trace>{status}</Trace>
        </div>
      </div>
      <div className="mt-3 rounded-xl overflow-hidden" style={{ border: `1px solid ${TOK.line}`, background: "#FFF" }}>
        {children}
      </div>
    </section>
  );
}

function PicRow({ icon, name, amt, src, conf, badge, todo, todoText, sub, sublist, actions, flag }) {
  const Icon = I[icon] || I.bank;
  return (
    <div className="flex items-start gap-3 px-4 py-3" style={{ borderTop: "1px solid " + TOK.hairline }}>
      <div className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
           style={{ background: todo ? "#FFFAF0" : TOK.cream, color: todo ? TOK.flag : TOK.sub }}>
        <Icon s={13} c={todo ? TOK.flag : TOK.sub}/>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[13.5px] font-medium" style={{ color: todo ? TOK.flag : TOK.ink }}>{name}</span>
          {badge && (
            <Chip bg={badge.k === "live" ? "#F0FDF4" : TOK.cream}
                  fg={badge.k === "live" ? TOK.green : TOK.sub}
                  border={badge.k === "live" ? "#BBF7D0" : TOK.line}>
              {badge.k === "live" && <Pulse color={TOK.green} size={4}/>} {badge.t}
            </Chip>
          )}
          {flag && <I.flag s={10} c={TOK.flag}/>}
        </div>
        <div className="mt-0.5 flex items-center gap-2">
          <Trace>{src}</Trace>
          {conf != null && <Trace color={conf < 0.95 ? TOK.flag : TOK.faint}>· conf {Math.round(conf * 100)}%</Trace>}
        </div>
        {sub && <div className="mt-1.5 text-[11.5px]" style={{ color: TOK.sub, lineHeight: 1.5 }}>{sub}</div>}
        {sublist && (
          <ul className="mt-2 space-y-0.5">
            {sublist.map((s, i) => <li key={i} className="text-[11px] mono" style={{ color: TOK.sub }}>↳ {s}</li>)}
          </ul>
        )}
        {todoText && (
          <div className="mt-2 flex items-start gap-2 pl-2" style={{ borderLeft: `2px solid ${todo || flag ? TOK.flag : TOK.indigo}` }}>
            <I.spark s={11} c={todo || flag ? TOK.flag : TOK.indigo} style={{ marginTop: 2, flexShrink: 0 }}/>
            <Murmur color={todo || flag ? TOK.flag : TOK.indigo}>{todoText}</Murmur>
          </div>
        )}
        {actions && (
          <div className="mt-2 flex flex-wrap gap-1.5">
            {actions.map((a, i) => (
              <button key={i} className="px-2.5 h-6 rounded-md text-[11px]"
                      style={i === 0
                        ? { background: TOK.ink, color: "#FFF", fontWeight: 500 }
                        : { color: TOK.sub, border: `1px solid ${TOK.line}` }}>
                {a}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="text-right flex-shrink-0" style={{ minWidth: 80 }}>
        <div className="mono tabular" style={{ fontSize: 13, color: todo ? TOK.flag : TOK.ink, fontWeight: 500 }}>
          {amt}
        </div>
      </div>
    </div>
  );
}

function PicChild({ name, age, school, notes }) {
  return (
    <div className="flex items-start gap-3 px-4 py-3" style={{ borderTop: "1px solid " + TOK.hairline }}>
      <div className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: TOK.cream, color: TOK.sub }}>
        <I.kid s={13} c={TOK.sub}/>
      </div>
      <div className="flex-1">
        <div className="flex items-baseline gap-2">
          <span className="serif" style={{ fontSize: 16, fontWeight: 600 }}>{name}</span>
          <span style={{ color: TOK.mute, fontSize: 12 }}>· age {age}</span>
        </div>
        <div className="mt-0.5 text-[11.5px]" style={{ color: TOK.sub }}>{school} · {notes}</div>
      </div>
    </div>
  );
}

function MNote({ tag, color, q, body, actions, primary }) {
  return (
    <div className="relative pl-4">
      <span className="absolute left-0 top-1.5 w-2 h-2 rounded-full" style={{ background: color }}/>
      <Trace>{tag}</Trace>
      <div className="serif mt-1" style={{ fontSize: 14.5, fontWeight: 600, color: TOK.ink, letterSpacing: "-0.01em" }}>
        {q}
      </div>
      <Murmur color={color}>{body}</Murmur>
      {actions && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {actions.map((a, i) => (
            <button key={i} className="px-2.5 h-6 rounded-md text-[11px]"
                    style={i === 0
                      ? { background: TOK.ink, color: "#FFF", fontWeight: 500 }
                      : { color: TOK.sub, border: `1px solid ${TOK.line}` }}>
              {a}
            </button>
          ))}
        </div>
      )}
      {primary && (
        <button className="mt-2 px-2.5 h-7 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                style={{ background: color, color: "#FFF" }}>
          Share with Mark <I.arrowR s={11} c="#FFF"/>
        </button>
      )}
    </div>
  );
}

window.Sarah_Ambient = Sarah_Ambient;

/* ----- Nav primitives for the collapsible drawer ----- */
function NavSection({ label, children }) {
  return (
    <div className="mb-4">
      <div className="px-2 mb-1.5 mono" style={{
        fontSize: 9.5, letterSpacing: "0.12em", color: TOK.mute,
        textTransform: "uppercase", fontWeight: 600
      }}>{label}</div>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

function NavItem({ icon, children, active, muted, alarm, right }) {
  const Ic = I[icon] || I.doc;
  const fg = alarm ? TOK.flag : (muted ? TOK.mute : TOK.ink);
  return (
    <button className="w-full flex items-center gap-2.5 px-2 py-1.5 rounded-md text-left"
            style={{
              background: active ? "#FFF" : "transparent",
              border: active ? `1px solid ${TOK.line}` : "1px solid transparent",
              color: fg
            }}
            onMouseEnter={e => { if (!active) e.currentTarget.style.background = "#FFFFFF99"; }}
            onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      <Ic s={13} c={alarm ? TOK.flag : (muted ? TOK.mute : TOK.sub)}/>
      <span className="flex-1 serif" style={{ fontSize: 13.5, fontWeight: active ? 600 : 400, letterSpacing: "-0.005em" }}>
        {children}
      </span>
      {right && (
        <span className="mono tabular" style={{
          fontSize: 10, color: alarm ? TOK.flag : TOK.mute,
          fontWeight: alarm ? 700 : 500, letterSpacing: "0.04em"
        }}>{right}</span>
      )}
    </button>
  );
}
