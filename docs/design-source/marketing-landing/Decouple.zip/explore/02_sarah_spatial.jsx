/* ============================================================
   02 · Sarah's Picture — PUSHED (Spatial canvas)
   ------------------------------------------------------------
   The disclosure as a living map of money. Accounts are nodes,
   categories are clusters, the AI is the camera — it zooms you
   to where attention is required, narrates what it sees, and
   leaves quiet annotations in space.
   ============================================================ */

function Sarah_Spatial() {
  const [focus, setFocus] = React.useState("children");

  return (
    <div style={{
      width: 1280, height: 860, background: "#F4F1EA", color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* dotted spatial grid */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `radial-gradient(${TOK.faint}33 1px, transparent 1px)`,
        backgroundSize: "22px 22px", pointerEvents: "none", opacity: 0.7
      }}/>

      {/* ─── top bar ─── */}
      <header className="flex items-center justify-between px-5 relative z-10"
              style={{ height: 50, background: "rgba(255,255,255,0.7)", backdropFilter: "blur(10px)",
                       borderBottom: `1px solid ${TOK.line}`, flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13} bg="#F4F1EA"/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Disclose</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Sarah's Picture</span>
            <Chip bg={TOK.indigoSoft} fg={TOK.indigo}>Spatial</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-1 py-0.5 rounded-md"
               style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
            {["Map", "Document", "Timeline"].map((t, i) => (
              <button key={t} className="px-2.5 h-6 rounded-[5px] text-[11px] font-medium"
                      style={{ background: i === 0 ? TOK.ink : "transparent", color: i === 0 ? "#FFF" : TOK.sub }}>
                {t}
              </button>
            ))}
          </div>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                  style={{ background: TOK.ink, color: "#FFF" }}>
            <I.share s={11} c="#FFF"/> Share with Mark
          </button>
        </div>
      </header>

      {/* ─── canvas ─── */}
      <div className="flex-1 relative" style={{ minHeight: 0 }}>
        {/* AI focus ring (the camera halo) */}
        <FocusRing focus={focus}/>

        {/* the constellation */}
        <Constellation focus={focus} setFocus={setFocus}/>

        {/* AI camera card — top-left */}
        <div className="absolute top-5 left-5 z-20" style={{ width: 296 }}>
          <div className="rounded-xl p-4"
               style={{ background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
                        border: `1px solid ${TOK.line}`, boxShadow: "0 4px 24px rgba(0,0,0,0.04)" }}>
            <div className="flex items-center gap-2">
              <Pulse color={TOK.indigo} size={6}/>
              <span className="mono" style={{ fontSize: 10.5, color: TOK.indigo, letterSpacing: "0.06em" }}>
                CAMERA · LOOKING AT
              </span>
            </div>
            <div className="serif mt-2.5" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>
              The children
            </div>
            <Murmur>
              The most uncertain part of your picture. Five entries depend on Mark; two need a school
              statement to confirm. I'd resolve these next.
            </Murmur>
            <div className="mt-3 flex items-center gap-1.5">
              <button className="px-2.5 h-7 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                      style={{ background: TOK.ink, color: "#FFF" }}>
                <I.zoom s={11} c="#FFF"/> Open
              </button>
              <button className="px-2.5 h-7 rounded-md text-[11.5px]"
                      style={{ color: TOK.sub, border: `1px solid ${TOK.line}`, background: "#FFF" }}>
                Suggest next
              </button>
            </div>
          </div>

          {/* secondary: AI todo list */}
          <div className="mt-2.5 rounded-xl p-3.5"
               style={{ background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
                        border: `1px solid ${TOK.line}` }}>
            <Kicker>I'm working on</Kicker>
            <div className="mt-2 space-y-1.5">
              {[
                { t: "Categorise 37 transactions", d: TOK.indigo, p: "94%" },
                { t: "Reconcile cash gifts vs. salary", d: TOK.flag, p: "1 stuck" },
                { t: "Estimate annual irregulars",   d: TOK.mute, p: "ready" }
              ].map((r, i) => (
                <div key={i} className="flex items-center gap-2 text-[11.5px]">
                  <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: r.d }}/>
                  <span className="flex-1 truncate" style={{ color: TOK.sub }}>{r.t}</span>
                  <Trace color={TOK.faint}>{r.p}</Trace>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* totals card — top-right */}
        <div className="absolute top-5 right-5 z-20" style={{ width: 232 }}>
          <div className="rounded-xl p-4"
               style={{ background: "rgba(255,255,255,0.92)", backdropFilter: "blur(8px)",
                        border: `1px solid ${TOK.line}` }}>
            <Kicker>Picture so far</Kicker>
            <div className="mt-2 grid grid-cols-2 gap-3">
              <div>
                <Trace>Net assets</Trace>
                <Big size={22}>£612k</Big>
              </div>
              <div>
                <Trace>Monthly out</Trace>
                <Big size={22}>£4.3k</Big>
              </div>
              <div>
                <Trace>Monthly in</Trace>
                <Big size={22}>£5.1k</Big>
              </div>
              <div>
                <Trace color={TOK.flag}>Open gaps</Trace>
                <Big size={22} color={TOK.flag}>3</Big>
              </div>
            </div>
            <div className="mt-3 h-[3px] rounded-full overflow-hidden" style={{ background: TOK.cream }}>
              <div className="h-full rounded-full" style={{ width: "62%", background: TOK.indigo }}/>
            </div>
            <Trace>62% disclosed · 8 of 9 sections</Trace>
          </div>
        </div>

        {/* command bar — bottom centre */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20" style={{ width: 540 }}>
          <div className="rounded-full px-4 py-2.5 flex items-center gap-3"
               style={{ background: "rgba(20,20,20,0.92)", backdropFilter: "blur(10px)",
                        boxShadow: "0 12px 40px rgba(0,0,0,0.18)" }}>
            <I.spark s={14} c={TOK.cyan}/>
            <span style={{ fontSize: 12.5, color: "#FFF", flex: 1 }}>
              <span style={{ color: "#9CA3AF" }}>Try · </span>
              "show me everything that depends on Mark"
            </span>
            <span className="mono" style={{ fontSize: 10, color: "#9CA3AF", letterSpacing: "0.06em" }}>⌘K</span>
            <span style={{ color: "#9CA3AF" }}>·</span>
            <button style={{ color: "#FFF", fontSize: 11 }} className="flex items-center gap-1">
              <I.mic s={11} c="#FFF"/> dictate
            </button>
          </div>
          <div className="mt-2 flex items-center gap-1.5 justify-center">
            {["values not in any account", "what changes if I move out", "duplicate subscriptions"].map((s, i) => (
              <span key={i} className="px-2.5 py-1 rounded-full text-[10.5px]"
                    style={{ background: "rgba(255,255,255,0.7)", color: TOK.sub, border: `1px solid ${TOK.line}` }}>
                {s}
              </span>
            ))}
          </div>
        </div>

        {/* zoom level */}
        <div className="absolute bottom-6 left-5 z-20 flex items-center gap-1 px-1 py-0.5 rounded-md"
             style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
          <button className="w-6 h-6 flex items-center justify-center rounded-[5px]" style={{ color: TOK.sub }}>
            <I.plus s={12}/>
          </button>
          <span className="mono px-1" style={{ fontSize: 10.5, color: TOK.sub, letterSpacing: "0.04em" }}>72%</span>
          <button className="w-6 h-6 flex items-center justify-center rounded-[5px]" style={{ color: TOK.sub }}>
            <I.layers s={12}/>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   The constellation — accounts orbiting clusters of categories
   ============================================================ */
function Constellation({ focus, setFocus }) {
  // categories
  const cats = [
    { id: "home",     label: "The home",          x: 410, y: 240, size: 160, total: "£612k", n: 4,  accent: TOK.indigo, ic: "home" },
    { id: "children", label: "The children",      x: 700, y: 380, size: 200, total: "£1,210/mo", n: 7, flag: 2, accent: TOK.flag, ic: "kid" },
    { id: "pensions", label: "Pensions",          x: 240, y: 460, size: 130, total: "£284k", n: 3, flag: 1, accent: TOK.indigo, ic: "pension" },
    { id: "savings",  label: "Savings",           x: 950, y: 230, size: 110, total: "£42.6k", n: 4,  accent: TOK.indigo, ic: "bank" },
    { id: "vehicles", label: "Vehicles",          x: 990, y: 480, size: 90,  total: "£18k",   n: 2,  accent: TOK.mute, ic: "car" },
    { id: "subs",     label: "Subscriptions",     x: 540, y: 560, size: 70,  total: "£98/mo", n: 11, accent: TOK.mute, ic: "doc" },
  ];

  // edges
  const edges = [
    { a: "home", b: "pensions" },
    { a: "home", b: "children" },
    { a: "children", b: "subs" },
    { a: "savings", b: "home" },
    { a: "vehicles", b: "children" },
  ];

  const find = (id) => cats.find(c => c.id === id);

  return (
    <svg width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
      {/* edges */}
      {edges.map((e, i) => {
        const A = find(e.a), B = find(e.b);
        return (
          <line key={i} x1={A.x} y1={A.y} x2={B.x} y2={B.y}
                stroke={TOK.faint} strokeWidth={1} strokeDasharray="3 4" opacity={0.7}/>
        );
      })}

      {/* annotation flag near children */}
      <g>
        <line x1={780} y1={310} x2={830} y2={260} stroke={TOK.flag} strokeWidth={1}/>
        <foreignObject x={830} y={228} width={210} height={80}>
          <div style={{ fontSize: 11.5, color: TOK.flag, lineHeight: 1.4, fontStyle: "italic", fontFamily: "'Source Serif Pro', serif" }}>
            Two entries here can't be answered without Mark. They will reconcile naturally when he shares.
          </div>
        </foreignObject>
      </g>

      {/* annotation near subs */}
      <g>
        <line x1={520} y1={580} x2={400} y2={640} stroke={TOK.indigo} strokeWidth={1}/>
        <foreignObject x={210} y={620} width={200} height={50}>
          <div style={{ fontSize: 11.5, color: TOK.indigo, lineHeight: 1.4, fontStyle: "italic", fontFamily: "'Source Serif Pro', serif" }}>
            11 subscriptions, 2 duplicates. Worth £18/mo to clean up.
          </div>
        </foreignObject>
      </g>

      {/* nodes */}
      {cats.map(c => (
        <g key={c.id} style={{ cursor: "pointer" }} onClick={() => setFocus(c.id)}>
          {/* halo if focused */}
          {focus === c.id && (
            <circle cx={c.x} cy={c.y} r={c.size / 2 + 18} fill="none" stroke={c.accent} strokeWidth={1} strokeDasharray="2 5" opacity={0.6}/>
          )}
          {/* outer soft ring */}
          <circle cx={c.x} cy={c.y} r={c.size / 2} fill={c.accent === TOK.flag ? "#FCE7F3" : c.accent === TOK.indigo ? TOK.indigoSoft : TOK.cream} opacity={0.5}/>
          {/* core */}
          <circle cx={c.x} cy={c.y} r={c.size / 2 - 14} fill="#FFFFFF" stroke={TOK.line} strokeWidth={1}/>
          {/* label */}
          <foreignObject x={c.x - c.size / 2} y={c.y - 30} width={c.size} height={c.size}>
            <div style={{ width: "100%", height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 8 }}>
              <div style={{ fontSize: 11, color: TOK.mute, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 600 }}>
                {c.label}
              </div>
              <div className="serif tabular" style={{ fontSize: c.size > 130 ? 22 : 16, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 4, color: TOK.ink }}>
                {c.total}
              </div>
              <div style={{ fontSize: 10, color: TOK.mute, marginTop: 2 }}>
                {c.n} entries
                {c.flag ? <span style={{ color: TOK.flag, fontWeight: 600 }}> · {c.flag} flagged</span> : null}
              </div>
            </div>
          </foreignObject>
        </g>
      ))}

      {/* signal trail — pulse moving from children to savings */}
      <circle r="3" fill={TOK.indigo}>
        <animateMotion dur="3.4s" repeatCount="indefinite" path="M700,380 C800,320 900,280 950,230"/>
      </circle>
    </svg>
  );
}

function FocusRing({ focus }) {
  // soft radial wash behind the focused cluster
  const positions = {
    children: { x: 700, y: 380, c: TOK.flag },
    home:     { x: 410, y: 240, c: TOK.indigo },
    pensions: { x: 240, y: 460, c: TOK.indigo },
    savings:  { x: 950, y: 230, c: TOK.indigo },
    vehicles: { x: 990, y: 480, c: TOK.mute },
    subs:     { x: 540, y: 560, c: TOK.mute },
  };
  const p = positions[focus] || positions.children;
  return (
    <div className="absolute pointer-events-none" style={{
      left: p.x - 280, top: p.y - 280, width: 560, height: 560,
      background: `radial-gradient(circle at center, ${p.c}1A 0%, transparent 60%)`,
      filter: "blur(2px)"
    }}/>
  );
}

window.Sarah_Spatial = Sarah_Spatial;
