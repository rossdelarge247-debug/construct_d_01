/* ============================================================
   03 · Our Household Picture — EVOLVED (Ambient diff)
   ------------------------------------------------------------
   The reconciled household — Sarah's column on the left, Mark's
   on the right, AI narrating each disagreement in the centre
   gutter. Inline diff style. Numbers carry provenance. Hover any
   delta and AI explains why it differs.
   ============================================================ */

function Household_Evolved() {
  return (
    <div style={{
      width: 1280, height: 860, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Reconcile</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Our Household</span>
            <Chip bg={TOK.magentaSoft} fg={TOK.magenta}>Both pictures live</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Chip bg="#F0FDF4" fg={TOK.green} border="#BBF7D0">
            <Pulse color={TOK.green} size={5}/> 14 of 17 agreed
          </Chip>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                  style={{ background: TOK.ink, color: "#FFF" }}>
            Move to proposal <I.arrowR s={11} c="#FFF"/>
          </button>
        </div>
      </header>

      {/* hero band */}
      <div className="px-12 pt-7 pb-5 flex items-end gap-12 flex-shrink-0" style={{ background: "#FFF" }}>
        <div>
          <Kicker color={TOK.magenta}>Phase 2 · Reconcile</Kicker>
          <h1 className="serif mt-2" style={{
            fontSize: 44, fontWeight: 600, letterSpacing: "-0.03em", lineHeight: 1.05
          }}>
            Where you <span style={{ fontStyle: "italic", color: TOK.green }}>agree</span>,
            and where you <span style={{ fontStyle: "italic", color: TOK.magenta }}>differ</span>.
          </h1>
        </div>
        <div className="flex-1 flex items-end justify-end gap-7">
          <Stat label="Agreed values" value="£612k" sub="14 entries"/>
          <Stat label="In dispute" value="£94.3k" sub="3 entries · 13% spread" color={TOK.magenta}/>
          <Stat label="Awaiting Mark" value="2" sub="pension CETV, holiday spend" color={TOK.flag}/>
        </div>
      </div>

      {/* legend strip */}
      <div className="px-12 py-3 flex items-center gap-6 text-[11px]" style={{ background: TOK.cream, borderTop: `1px solid ${TOK.line}`, borderBottom: `1px solid ${TOK.line}`, flexShrink: 0 }}>
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ background: "#2F6D5F" }}/> <span style={{ color: TOK.sub }}>Sarah's value</span></div>
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ background: "#B45309" }}/> <span style={{ color: TOK.sub }}>Mark's value</span></div>
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ background: TOK.green }}/> <span style={{ color: TOK.sub }}>Agreed</span></div>
        <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full" style={{ background: TOK.magenta }}/> <span style={{ color: TOK.sub }}>Disagreement</span></div>
        <div className="flex-1"/>
        <Trace>view: side by side · sort: contention · 17 items</Trace>
      </div>

      {/* body: 3-column ledger */}
      <div className="flex-1 overflow-y-auto px-12 py-8" style={{ minHeight: 0 }}>
        <ReconBlock
          chapter="The home"
          rows={[
            { name: "Family home · Hampstead", a: "£860,000", b: "£860,000", agree: true, prov: "Zoopla · 12 Apr 2026" },
            { name: "Halifax mortgage", a: "£412,400", b: "£412,400", agree: true, prov: "Halifax · live balance" },
            {
              name: "Net equity", a: "£447,600", b: "£447,600", agree: true, prov: "Calculated", emph: true,
            },
          ]}
        />

        <ReconBlock
          chapter="Pensions · most contested"
          contested
          rows={[
            {
              name: "NHS career pension (Sarah)",
              a: "£284,000", b: "£284,000", agree: true,
              prov: "CETV statement · 2 Mar 2026",
            },
            {
              name: "Mark's SIPP",
              a: "£196,000", b: "£218,400", agree: false,
              spread: "£22,400",
              prov: "Sarah used last year's statement · Mark added Q1 contributions",
              ai: "Mark's figure is current and verifiable. Recommend updating to £218,400.",
              actions: ["Accept Mark's", "Discuss"],
            },
            {
              name: "Mark's old DB pension",
              a: "—", b: "Awaiting CETV",
              gap: true,
              prov: "Royal Mail · requested 18 Apr",
              ai: "Statement usually arrives within 3 months. I'll watch for it and slot it in automatically.",
            },
          ]}
        />

        <ReconBlock
          chapter="Family expenses"
          contested
          rows={[
            {
              name: "Children's education",
              a: "£842/mo", b: "£980/mo", agree: false, spread: "£138/mo",
              prov: "Sarah counts term-time; Mark includes uniform/trip averages",
              ai: "Both right. The full picture is £980. Sarah's number is what hits her account directly.",
              actions: ["Use £980", "Show split"],
            },
            {
              name: "Holiday spending (joint)",
              a: "£3,400/yr", b: "£5,800/yr", agree: false, spread: "£2,400/yr",
              prov: "12-month bank average from each",
              ai: "Difference is mostly the Cornwall trip — paid from Mark's account but you both went. I'd treat as joint.",
              actions: ["Treat as joint", "Keep individual"],
            },
            {
              name: "Weekly groceries",
              a: "£412/mo", b: "£420/mo", agree: true, soft: true,
              prov: "Within rounding tolerance",
            },
          ]}
        />

        <div className="h-12"/>
      </div>

      {/* footer */}
      <footer className="flex items-center justify-between px-6"
              style={{ height: 32, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>both pictures · live</Trace>
          <Trace>last sync · just now</Trace>
        </div>
        <div className="text-[10.5px]" style={{ color: TOK.mute }}>
          <span className="mono">⌘ + click</span> any value to question its provenance
        </div>
      </footer>
    </div>
  );
}

function Stat({ label, value, sub, color = TOK.ink }) {
  return (
    <div>
      <Trace>{label}</Trace>
      <div className="flex items-baseline gap-2 mt-0.5">
        <Big size={28} color={color}>{value}</Big>
      </div>
      <div className="text-[11px] mt-0.5" style={{ color: TOK.mute }}>{sub}</div>
    </div>
  );
}

function ReconBlock({ chapter, contested, rows }) {
  return (
    <section className="mt-8 first:mt-0">
      <div className="flex items-baseline justify-between mb-3">
        <h2 className="serif" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>
          {chapter}
        </h2>
        {contested && <Trace color={TOK.magenta}>contention here</Trace>}
      </div>
      <div className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${TOK.line}`, background: "#FFF" }}>
        {rows.map((r, i) => <ReconRow key={i} r={r} idx={i}/>)}
      </div>
    </section>
  );
}

function ReconRow({ r }) {
  const agree = r.agree;
  const gap = r.gap;
  return (
    <div className="grid items-stretch" style={{
      gridTemplateColumns: "1.2fr 1fr 36px 1fr",
      borderTop: `1px solid ${TOK.hairline}`
    }}>
      {/* name + provenance + AI murmur */}
      <div className="px-5 py-4" style={{ background: r.emph ? TOK.cream : "transparent" }}>
        <div className="flex items-center gap-2">
          <span className="text-[13.5px] font-medium" style={{ color: TOK.ink }}>{r.name}</span>
          {r.emph && <Chip bg="#FFF" fg={TOK.green} border="#BBF7D0">Reconciled</Chip>}
        </div>
        <Trace>{r.prov}</Trace>
        {r.ai && (
          <div className="mt-2 flex items-start gap-2 pl-2"
               style={{ borderLeft: `2px solid ${gap ? TOK.flag : agree ? TOK.green : TOK.magenta}` }}>
            <I.spark s={11} c={gap ? TOK.flag : agree ? TOK.green : TOK.magenta} style={{ marginTop: 2, flexShrink: 0 }}/>
            <Murmur color={gap ? TOK.flag : agree ? TOK.green : TOK.magenta}>{r.ai}</Murmur>
          </div>
        )}
        {r.actions && (
          <div className="mt-2 flex gap-1.5">
            <button className="px-2.5 h-6 rounded-md text-[11px] font-medium" style={{ background: TOK.ink, color: "#FFF" }}>
              {r.actions[0]}
            </button>
            <button className="px-2.5 h-6 rounded-md text-[11px]" style={{ color: TOK.sub, border: `1px solid ${TOK.line}` }}>
              {r.actions[1]}
            </button>
          </div>
        )}
      </div>

      {/* Sarah column */}
      <div className="px-4 py-4 text-right" style={{
        background: agree && !r.soft ? "#F4FAF6" : r.emph ? TOK.cream : "transparent",
        borderLeft: `1px solid ${TOK.hairline}`
      }}>
        <Trace color="#2F6D5F">SARAH</Trace>
        <div className="mono tabular mt-1" style={{ fontSize: 15, fontWeight: 500, color: TOK.ink }}>
          {r.a}
        </div>
      </div>

      {/* the gutter — agreement glyph */}
      <div className="flex items-center justify-center" style={{
        background: agree ? "#F0FDF4" : gap ? "#FFFAF0" : "#FCE7F3"
      }}>
        {agree
          ? <I.check s={14} c={TOK.green} w={2.5}/>
          : gap
            ? <span style={{ color: TOK.flag, fontSize: 16, fontWeight: 600 }}>·</span>
            : <span style={{ color: TOK.magenta, fontSize: 13, fontWeight: 600 }}>↔</span>
        }
      </div>

      {/* Mark column */}
      <div className="px-4 py-4 text-left" style={{
        background: agree && !r.soft ? "#F4FAF6" : r.emph ? TOK.cream : "transparent",
        borderLeft: `1px solid ${TOK.hairline}`
      }}>
        <Trace color="#B45309">MARK</Trace>
        <div className="mono tabular mt-1" style={{ fontSize: 15, fontWeight: 500, color: gap ? TOK.flag : TOK.ink }}>
          {r.b}
        </div>
        {r.spread && <Trace color={TOK.magenta}>↕ {r.spread}</Trace>}
      </div>
    </div>
  );
}

window.Household_Evolved = Household_Evolved;
