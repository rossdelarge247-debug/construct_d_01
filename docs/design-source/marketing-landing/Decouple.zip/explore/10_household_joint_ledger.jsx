/* ============================================================
   10 · Household Picture — Sarah · JOINT · Mark (ES2-style)
   ------------------------------------------------------------
   Three-column ledger with a JOINT middle column. AI applies
   sensible default assumptions about where each item lands:
   - sole accounts → owner column
   - joint accounts → middle column
   - shared home → middle, with default 50/50 equity in solo
   - aggregate totals → middle
   - debts in sole names → owner column
   Each row shows a small "AI assumption" murmur the user can
   override (Move to joint / Split / Owner only).
   ============================================================ */

function Household_JointLedger() {
  return (
    <div style={{
      width: 1280, height: 920, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Reconcile</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Sarah · Joint · Mark</span>
            <Chip bg={TOK.magentaSoft} fg={TOK.magenta}>Form D81 mode</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Chip bg={TOK.cream} fg={TOK.sub}>
            <I.spark s={10} c={TOK.indigo}/> AI applied 14 default assumptions
          </Chip>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium" style={{ background: TOK.ink, color: "#FFF" }}>
            Approve & lock
          </button>
        </div>
      </header>

      {/* hero */}
      <div className="px-12 pt-7 pb-5 flex items-end gap-12 flex-shrink-0" style={{ background: "#FFF" }}>
        <div>
          <Kicker color={TOK.magenta}>Phase 2 · Reconcile · enhanced D81</Kicker>
          <h1 className="serif mt-2" style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.05 }}>
            Yours, <span style={{ fontStyle: "italic", color: TOK.green }}>jointly held</span>, and theirs.
          </h1>
          <Murmur color={TOK.sub}>
            Decouple has read both pictures and slotted each item where it most likely belongs.
            Joint accounts and the shared home sit in the middle. Sole accounts and personal debts sit under the named person.
            Anything you disagree with — drag it, or tap "reassign".
          </Murmur>
        </div>
        <div className="flex-1 flex items-end justify-end gap-7">
          <ColTotal label="Sarah · sole" value="£298k" color={TOK.indigo}/>
          <ColTotal label="Joint" value="£455k" color={TOK.green} primary/>
          <ColTotal label="Mark · sole" value="£218k" color={TOK.magenta}/>
        </div>
      </div>

      {/* column header strip */}
      <div className="px-12 pt-3 grid items-center" style={{
        gridTemplateColumns: "180px 1fr 1fr 1fr",
        background: "#FFF", flexShrink: 0
      }}>
        <div/>
        <ColHeader who="Sarah" color={TOK.indigo} sub="sole · in her name"/>
        <ColHeader who="Joint" color={TOK.green} sub="held / used by both" emph/>
        <ColHeader who="Mark" color={TOK.magenta} sub="sole · in his name"/>
      </div>

      {/* ledger body */}
      <div className="flex-1 overflow-y-auto px-12 py-4" style={{ minHeight: 0 }}>

        {/* ASSETS · Property */}
        <LedgerSection title="The home" total="£447.6k joint equity">
          <LedgerRow
            chapter="Property"
            name="Family home · Hampstead"
            kind="asset"
            joint={{ amt: "£860,000", note: "Owned jointly · Land Registry both names" }}
            assumption="Held jointly. Equity defaulted to 50/50 each side until you say otherwise."
            actions={["Keep 50/50", "Adjust split"]}
            split={{ s: "£223.8k", m: "£223.8k", note: "default 50/50 of net equity" }}
          />
          <LedgerRow
            chapter="Mortgage"
            name="Halifax mortgage outstanding"
            kind="debt"
            joint={{ amt: "-£412,400", note: "Joint mortgage · live balance" }}
            assumption="Joint debt — sits against the home, not against either person."
          />
        </LedgerSection>

        {/* ASSETS · Cash */}
        <LedgerSection title="Cash & savings">
          <LedgerRow
            chapter="Account"
            name="Monzo joint account"
            kind="asset"
            joint={{ amt: "£8,640", note: "Both named · live balance" }}
            assumption="Sits in the middle by default — both your names are on it."
          />
          <LedgerRow
            chapter="Account"
            name="Halifax current (Sarah)"
            kind="asset"
            sarah={{ amt: "£14,820", note: "Sole · live balance" }}
            assumption="In Sarah's name only — kept on her side."
          />
          <LedgerRow
            chapter="Account"
            name="Barclays current (Mark)"
            kind="asset"
            mark={{ amt: "£11,940", note: "Sole · live balance" }}
            assumption="In Mark's name only — kept on his side."
          />
          <LedgerRow
            chapter="Savings"
            name="NS&I Premium Bonds (Sarah)"
            kind="asset"
            sarah={{ amt: "£20,000", note: "Self-declared" }}
            assumption="Bonds register in one name only — sits with Sarah."
          />
        </LedgerSection>

        {/* PENSIONS */}
        <LedgerSection title="Pensions" total="held individually by law" subtle>
          <LedgerRow
            chapter="Pension"
            name="NHS career pension (Sarah)"
            kind="asset"
            sarah={{ amt: "£284,000", note: "CETV · 2 Mar 2026" }}
            assumption="Pensions are personal by definition — kept under each name. They become divisible at the proposal stage via a sharing order."
          />
          <LedgerRow
            chapter="Pension"
            name="DC pension (Mark)"
            kind="asset"
            mark={{ amt: "£218,400", note: "Aviva · 31 Mar 2026" }}
            assumption="Same rule — kept under Mark's name."
          />
          <LedgerRow
            chapter="Pension"
            name="Mark's old DB pension"
            kind="asset"
            mark={{ amt: "—", note: "CETV requested · awaiting" }}
            assumption="Will land under Mark when statement arrives."
            flag
          />
        </LedgerSection>

        {/* DEBTS */}
        <LedgerSection title="Debts">
          <LedgerRow
            chapter="Credit card"
            name="HSBC Credit Card"
            kind="debt"
            mark={{ amt: "-£6,200", note: "Sole · in Mark's name" }}
            assumption="In Mark's name only. Kept against him — but flagged for the proposal because it was incurred during the marriage."
            flag
            actions={["Treat as sole (Mark)", "Treat as joint matrimonial debt"]}
          />
          <LedgerRow
            chapter="Loan"
            name="John Lewis sofa finance"
            kind="debt"
            joint={{ amt: "-£1,820", note: "Both named on agreement" }}
            assumption="Both signed — sits in the middle."
          />
        </LedgerSection>

        {/* INCOME · aggregated */}
        <LedgerSection title="Income · monthly post-tax">
          <LedgerRow
            chapter="Salary"
            name="Sarah's NHS salary"
            kind="flow"
            sarah={{ amt: "£3,847/mo", note: "Halifax · stable" }}
            assumption="Earned by Sarah — sits with her."
          />
          <LedgerRow
            chapter="Salary"
            name="Mark's salary"
            kind="flow"
            mark={{ amt: "£4,793/mo", note: "Barclays · stable" }}
            assumption="Earned by Mark — sits with him."
          />
          <LedgerRow
            chapter="Aggregate"
            name="Combined household income"
            kind="flow"
            joint={{ amt: "£8,640/mo", note: "Sum · used to test reasonableness", emph: true }}
            assumption="Aggregate totals always sit in the middle — this is the figure court uses to test the proposal."
          />
        </LedgerSection>

        {/* OUTGOINGS */}
        <LedgerSection title="Outgoings · monthly">
          <LedgerRow
            chapter="Housing"
            name="Mortgage, council tax, utilities"
            kind="flow"
            joint={{ amt: "-£2,184/mo", note: "Paid from joint Monzo" }}
            assumption="Pays from joint account — sits in the middle."
          />
          <LedgerRow
            chapter="Children"
            name="School fees, childcare, activities"
            kind="flow"
            joint={{ amt: "-£1,210/mo", note: "Both contribute" }}
            assumption="Child costs default to joint — they support both of you in raising the children."
          />
          <LedgerRow
            chapter="Personal"
            name="Sarah's personal spend"
            kind="flow"
            sarah={{ amt: "-£687/mo", note: "Halifax personal" }}
            assumption="Personal spend stays personal."
          />
          <LedgerRow
            chapter="Personal"
            name="Mark's personal spend"
            kind="flow"
            mark={{ amt: "-£743/mo", note: "Barclays personal" }}
            assumption="Same — Mark's side."
          />
          <LedgerRow
            chapter="Aggregate"
            name="Combined household outgoings"
            kind="flow"
            joint={{ amt: "-£4,824/mo", note: "Sum · for reasonableness test", emph: true }}
            assumption="Total is what the court uses against income."
          />
        </LedgerSection>

        {/* THE BOTTOM LINE */}
        <section className="mt-8 mb-6 rounded-2xl overflow-hidden" style={{ border: `1px solid ${TOK.green}`, background: "#FFF" }}>
          <div className="px-5 py-2.5 flex items-center justify-between" style={{ background: "#F0FDF4", borderBottom: `1px solid ${TOK.green}` }}>
            <Kicker color={TOK.green}>Total picture · the matrimonial pot</Kicker>
            <Trace color={TOK.green}>aggregated · ready for proposal</Trace>
          </div>
          <div className="grid items-stretch" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr" }}>
            <div className="px-5 py-4" style={{ borderRight: `1px solid ${TOK.hairline}` }}>
              <Trace>net worth</Trace>
              <div className="serif" style={{ fontSize: 15, fontWeight: 600 }}>Total</div>
            </div>
            <BottomCol label="SARAH SOLE" color={TOK.indigo} amt="£298,820" sub="3 items"/>
            <BottomCol label="JOINT" color={TOK.green} amt="£454,620" sub="6 items" emph/>
            <BottomCol label="MARK SOLE" color={TOK.magenta} amt="£217,940" sub="4 items"/>
          </div>
          <div className="px-5 py-3 flex items-center gap-3" style={{ background: TOK.cream, borderTop: `1px solid ${TOK.hairline}` }}>
            <I.spark s={13} c={TOK.green}/>
            <Murmur color={TOK.green}>
              The combined matrimonial pot is <b style={{ color: TOK.ink }}>£971,380</b>.
              Pensions inside that pot are individually held but legally divisible — the proposal will treat them with sharing orders.
              Approving this picture moves you to scenario modelling.
            </Murmur>
          </div>
        </section>

        <div className="h-12"/>
      </div>

      {/* footer */}
      <footer className="flex items-center justify-between px-6"
              style={{ height: 32, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>both pictures · live</Trace>
          <Trace>14 ai assumptions · 0 overrides</Trace>
        </div>
        <div className="text-[10.5px]" style={{ color: TOK.mute }}>
          Drag any row between columns · or tap "reassign" inline
        </div>
      </footer>
    </div>
  );
}

/* ----- pieces ----- */

function ColTotal({ label, value, color, primary }) {
  return (
    <div className={primary ? "rounded-lg px-3 py-1.5" : ""}
         style={primary ? { background: "#F0FDF4", border: `1px solid ${TOK.green}` } : {}}>
      <Trace color={color}>{label}</Trace>
      <div className="serif tabular" style={{ fontSize: 26, fontWeight: 600, color, letterSpacing: "-0.02em", lineHeight: 1 }}>
        {value}
      </div>
    </div>
  );
}

function ColHeader({ who, color, sub, emph }) {
  return (
    <div className="px-4 py-2.5 text-center" style={{
      background: emph ? "#F0FDF4" : "transparent",
      borderTop: emph ? `2px solid ${color}` : `1px solid ${TOK.line}`,
      borderLeft: `1px solid ${TOK.line}`,
      borderRight: `1px solid ${TOK.line}`,
      borderBottom: `1px solid ${TOK.line}`,
    }}>
      <div className="flex items-center justify-center gap-2">
        <span className="rounded-full" style={{ width: 8, height: 8, background: color }}/>
        <span style={{ fontSize: 13, fontWeight: 600, color }}>{who}</span>
      </div>
      <Trace color={TOK.mute}>{sub}</Trace>
    </div>
  );
}

function LedgerSection({ title, total, subtle, children }) {
  return (
    <section className="mt-6 first:mt-2">
      <div className="flex items-baseline justify-between mb-2 px-1">
        <h2 className="serif" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.015em", color: subtle ? TOK.sub : TOK.ink }}>
          {title}
        </h2>
        {total && <Trace color={TOK.mute}>{total}</Trace>}
      </div>
      <div className="rounded-xl overflow-hidden" style={{ border: `1px solid ${TOK.line}`, background: "#FFF" }}>
        {children}
      </div>
    </section>
  );
}

function LedgerRow({ chapter, name, kind, sarah, joint, mark, assumption, actions, flag, split }) {
  const isDebt = kind === "debt";
  const isFlow = kind === "flow";
  return (
    <div style={{ borderTop: "1px solid " + TOK.hairline }}>
      <div className="grid items-stretch" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr" }}>
        {/* row label */}
        <div className="px-4 py-3.5">
          <Trace color={TOK.mute}>{chapter}</Trace>
          <div className="text-[12.5px] font-medium mt-0.5" style={{ color: TOK.ink, lineHeight: 1.3 }}>{name}</div>
          {flag && <Trace color={TOK.flag}>· flag for proposal</Trace>}
        </div>
        {/* Sarah cell */}
        <Cell data={sarah} color={TOK.indigo} isDebt={isDebt} isFlow={isFlow}/>
        {/* Joint cell — soft fill */}
        <Cell data={joint} color={TOK.green} isDebt={isDebt} isFlow={isFlow} joint/>
        {/* Mark cell */}
        <Cell data={mark} color={TOK.magenta} isDebt={isDebt} isFlow={isFlow}/>
      </div>

      {/* split line — when joint asset spreads to solos by default (e.g. house) */}
      {split && (
        <div className="grid items-center" style={{ gridTemplateColumns: "180px 1fr 1fr 1fr", background: TOK.cream }}>
          <div className="px-4 py-1.5">
            <Trace color={TOK.mute}>↳ default split</Trace>
          </div>
          <div className="px-4 py-1.5 text-right">
            <span className="mono tabular" style={{ fontSize: 12, color: TOK.indigo }}>{split.s}</span>
          </div>
          <div className="px-4 py-1.5 text-center" style={{ borderLeft: `1px solid ${TOK.hairline}`, borderRight: `1px solid ${TOK.hairline}` }}>
            <Trace color={TOK.faint}>{split.note}</Trace>
          </div>
          <div className="px-4 py-1.5 text-left">
            <span className="mono tabular" style={{ fontSize: 12, color: TOK.magenta }}>{split.m}</span>
          </div>
        </div>
      )}

      {/* assumption strip */}
      {assumption && (
        <div className="grid items-center" style={{ gridTemplateColumns: "180px 1fr", background: TOK.bg, borderTop: `1px dashed ${TOK.line}` }}>
          <div/>
          <div className="px-4 py-2 flex items-start gap-2" style={{ gridColumn: "2 / span 3" }}>
            <I.spark s={11} c={flag ? TOK.flag : TOK.indigo} style={{ marginTop: 2, flexShrink: 0 }}/>
            <Murmur color={flag ? TOK.flag : TOK.indigo}>
              <span className="mono not-italic" style={{ fontSize: 9.5, letterSpacing: "0.06em", color: TOK.mute, textTransform: "uppercase", marginRight: 6 }}>AI ASSUMPTION</span>
              {assumption}
            </Murmur>
            {actions && (
              <div className="flex gap-1.5 ml-auto flex-shrink-0">
                {actions.map((a, i) => (
                  <button key={i} className="px-2 h-6 rounded-md text-[10.5px]"
                          style={i === 0
                            ? { background: TOK.ink, color: "#FFF", fontWeight: 500 }
                            : { color: TOK.sub, border: `1px solid ${TOK.line}`, background: "#FFF" }}>
                    {a}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Cell({ data, color, isDebt, joint }) {
  const filled = !!data;
  return (
    <div className="px-4 py-3.5"
         style={{
           background: joint && filled ? "#F4FBF7" : (joint ? TOK.cream + "66" : "transparent"),
           borderLeft: `1px solid ${TOK.hairline}`,
           textAlign: joint ? "center" : (color === TOK.indigo ? "right" : "left"),
           minHeight: 56
         }}>
      {filled ? (
        <>
          <div className="mono tabular" style={{
            fontSize: data.emph ? 16 : 14,
            fontWeight: data.emph ? 600 : 500,
            color: isDebt ? TOK.flag : (joint ? TOK.green : TOK.ink),
            letterSpacing: "-0.005em"
          }}>
            {data.amt}
          </div>
          <Trace color={TOK.mute}>{data.note}</Trace>
        </>
      ) : (
        <div className="mono" style={{ fontSize: 11, color: TOK.faint, letterSpacing: "0.06em" }}>—</div>
      )}
    </div>
  );
}

function BottomCol({ label, color, amt, sub, emph }) {
  return (
    <div className="px-4 py-4 text-center" style={{
      background: emph ? "#F0FDF4" : "transparent",
      borderRight: `1px solid ${TOK.hairline}`
    }}>
      <Trace color={color}>{label}</Trace>
      <div className="serif tabular mt-1" style={{ fontSize: 22, fontWeight: 600, color, letterSpacing: "-0.02em", lineHeight: 1 }}>
        {amt}
      </div>
      <Trace color={TOK.mute}>{sub}</Trace>
    </div>
  );
}

window.Household_JointLedger = Household_JointLedger;
