/* ============================================================
   01 · Sarah's Picture — EVOLVED (Ambient AI)
   ------------------------------------------------------------
   The disclosure document, but it now thinks alongside you.
   - Editorial document layout, generous margins, serif headings
   - Every number carries a mono provenance trace (where it came from)
   - AI murmurs in the margin: small italic serif notes that flag,
     question, congratulate. Quiet, never modal.
   - Pulse dots = live syncing; subtle "AI working" stripes.
   - The right margin is the AI's column — not a chat, more like
     an editor's pencil.
   ============================================================ */

function Sarah_Evolved() {
  const [cmd, setCmd] = React.useState("");
  const [navOpen, setNavOpen] = React.useState(false);
  return (
    <div style={{
      width: 1280, height: 860, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* faint vertical rule down the page — the editor's margin */}
      <div style={{
        position: "absolute", left: 880, top: 0, bottom: 0, width: 1,
        background: TOK.hairline, pointerEvents: "none"
      }}/>

      {/* ─── COLLAPSIBLE LEFT NAV ─── */}
      {navOpen && <EvolvedDrawer onClose={() => setNavOpen(false)}/>}

      {/* ─── top bar ─── */}
      <header className="flex items-center justify-between px-4"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-2">
          <button onClick={() => setNavOpen(true)}
                  className="w-9 h-9 rounded-md flex items-center justify-center"
                  style={{ background: "transparent" }}
                  onMouseEnter={e => e.currentTarget.style.background = TOK.cream}
                  onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
                 stroke={TOK.ink} strokeWidth="1.8" strokeLinecap="round">
              <line x1="4" y1="7"  x2="20" y2="7"/>
              <line x1="4" y1="12" x2="20" y2="12"/>
              <line x1="4" y1="17" x2="20" y2="17"/>
            </svg>
          </button>
          <span className="ml-1" style={{ fontSize: 13, letterSpacing: "-0.01em", fontWeight: 600, color: TOK.ink }}>decouple</span>
          <span style={{ color: "#E5E7EB", marginLeft: 8 }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px] ml-2">
            <span style={{ color: TOK.mute }}>Disclose</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Sarah's Picture</span>
            <Chip bg={TOK.indigoSoft} fg={TOK.indigo}>Private · only you</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 h-7 rounded-md"
               style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
            <Pulse size={5}/>
            <span className="mono" style={{ fontSize: 10, color: TOK.sub, letterSpacing: "0.04em" }}>
              4 banks · synced 3m ago
            </span>
          </div>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                  style={{ background: TOK.ink, color: "#FFF" }}>
            <I.share s={11} c="#FFF"/> Share with Mark
          </button>
        </div>
      </header>

      {/* ─── command bar (ambient natural language) ─── */}
      <div className="px-6 py-3 flex items-center gap-3" style={{ borderBottom: `1px solid ${TOK.line}`, background: "#FFF" }}>
        <I.spark s={14} c={TOK.indigo}/>
        <input
          value={cmd}
          onChange={e => setCmd(e.target.value)}
          placeholder='Ask anything — "what does my mortgage cost over the year?" · "find duplicate transactions"'
          className="flex-1 outline-none"
          style={{ background: "transparent", fontSize: 13, color: TOK.ink }}/>
        <span className="mono" style={{ fontSize: 10, color: TOK.faint, letterSpacing: "0.06em" }}>
          ⌘K
        </span>
      </div>

      {/* ─── body: document column + AI margin ─── */}
      <div className="flex-1 overflow-hidden flex" style={{ minHeight: 0 }}>
        {/* document column */}
        <div className="flex-1 overflow-y-auto px-12 py-10" style={{ maxWidth: 880 }}>
          {/* hero header */}
          <div>
            <Kicker color={TOK.indigo}>Section 8 of 9 · Outgoings</Kicker>
            <h1 className="serif mt-3" style={{
              fontSize: 56, fontWeight: 600, letterSpacing: "-0.03em", lineHeight: 1.02
            }}>
              The shape of your<br/>
              <span style={{ fontStyle: "italic", color: TOK.sub }}>monthly life.</span>
            </h1>
            <p className="serif mt-5" style={{
              fontSize: 16.5, lineHeight: 1.55, color: TOK.sub, fontStyle: "italic", maxWidth: 520
            }}>
              Decouple has read 1,284 transactions across four accounts and grouped them
              into the categories below. Three of them need your attention.
            </p>
          </div>

          {/* meta strip */}
          <div className="mt-7 grid grid-cols-3 gap-6">
            <div>
              <Trace>Total monthly · 12 mo avg</Trace>
              <div className="mt-1 flex items-baseline gap-2">
                <Big size={36}>£4,287</Big>
                <span style={{ color: TOK.sub, fontSize: 13 }}>/month</span>
              </div>
            </div>
            <div>
              <Trace>Categorised</Trace>
              <div className="mt-1 flex items-baseline gap-2">
                <Big size={36} color={TOK.sub}>1,247<span style={{ color: TOK.faint }}>/1,284</span></Big>
              </div>
              <div className="mt-1.5 h-[3px] rounded-full overflow-hidden" style={{ background: TOK.cream }}>
                <div className="h-full rounded-full" style={{ width: "97%", background: TOK.indigo }}/>
              </div>
            </div>
            <div>
              <Trace color={TOK.flag}>Need your attention</Trace>
              <div className="mt-1 flex items-baseline gap-2">
                <Big size={36} color={TOK.flag}>3</Big>
                <span style={{ color: TOK.flag, fontSize: 12 }}>↘ 12 yesterday</span>
              </div>
            </div>
          </div>

          <HR my={28}/>

          {/* CATEGORY: Housing */}
          <CategoryBlock
            title="Housing"
            sub="Mortgage, council tax, utilities, maintenance"
            total="£2,184"
            share="51%"
            rows={[
              { name: "Halifax mortgage",   amt: "£1,842.00", source: "Halifax · monthly DD", note: null, conf: 1.0 },
              { name: "Council tax · Band D", amt: "£218.40",   source: "Westminster · monthly DD", note: null, conf: 1.0 },
              { name: "British Gas · dual",  amt: "£184.50",   source: "Monzo · variable", note: { kind: "ai", text: "↑ 22% YoY. Switching to Octopus would save ~£340/year." }, conf: 0.96 },
              { name: "Thames Water",        amt: "£62.10",    source: "Halifax · quarterly", note: null, conf: 1.0 },
            ]}
          />

          {/* CATEGORY: The children */}
          <CategoryBlock
            title="The children"
            sub="School, activities, childcare, clothes"
            total="£1,210"
            share="28%"
            flag={2}
            rows={[
              { name: "St. Mary's school fees", amt: "£842.00", source: "Halifax · termly", note: null, conf: 1.0 },
              { name: "Footlights drama club",  amt: "£140.00", source: "Monzo · monthly", note: null, conf: 1.0 },
              { name: "Gymnastics + tennis",    amt: "£185.00", source: "Monzo · monthly", note: null, conf: 0.94 },
              { name: "After-school club",      amt: "—",       source: "Possibly paid in cash", note: { kind: "flag", text: "Mark may pay this directly. Worth confirming with him." }, conf: null, gap: true },
            ]}
          />

          {/* CATEGORY: Personal */}
          <CategoryBlock
            title="Personal"
            sub="Food, transport, health, leisure"
            total="£893"
            share="21%"
            flag={1}
            rows={[
              { name: "Tesco · groceries",     amt: "£412.00", source: "Monzo · weekly avg", note: null, conf: 1.0 },
              { name: "TfL travel",            amt: "£156.00", source: "Monzo · monthly avg", note: null, conf: 1.0 },
              { name: "Bupa health",           amt: "£68.40",  source: "Halifax · monthly DD", note: { kind: "ai", text: "Could move to joint policy after settlement — keep noted." }, conf: 1.0 },
              { name: "Misc subscriptions",    amt: "£98.20",  source: "Across 11 services", note: null, conf: 0.88, expand: true },
            ]}
          />

          {/* end-of-doc reasoning */}
          <div className="mt-10 rounded-2xl p-6"
               style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
            <div className="flex items-start gap-4">
              <I.brain s={20} c={TOK.indigo}/>
              <div className="flex-1">
                <div className="serif" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.02em" }}>
                  How I see your outgoings.
                </div>
                <p className="serif mt-2" style={{ fontSize: 14, lineHeight: 1.55, color: TOK.sub, fontStyle: "italic" }}>
                  Most of your spending is unavoidable — housing and the children together
                  account for 79% of every month. That's a useful number for the proposal:
                  it sets a floor under what you need to live. Three items above are still
                  uncertain. Two depend on Mark, one on a category I can't read from your
                  bank alone. Resolving them will let me close this section.
                </p>
                <div className="mt-3 flex items-center gap-4 text-[11px]" style={{ color: TOK.mute }}>
                  <Trace>Reasoning · 12 mo · 4 accounts</Trace>
                  <button className="underline" style={{ color: TOK.indigo }}>see how I worked this out</button>
                </div>
              </div>
            </div>
          </div>

          <div className="h-12"/>
        </div>

        {/* ─── AI margin column ─── */}
        <aside className="overflow-y-auto px-7 py-10"
               style={{ width: 380, background: "#FFF", borderLeft: `1px solid ${TOK.line}` }}>
          <Kicker color={TOK.indigo}>Decouple is reading along</Kicker>

          {/* Live trace */}
          <div className="mt-4 flex items-center gap-2">
            <Pulse color={TOK.indigo} size={6}/>
            <span className="mono" style={{ fontSize: 10.5, color: TOK.indigo, letterSpacing: "0.04em" }}>
              MATCHING · 8 of 11 subscriptions
            </span>
          </div>

          {/* margin notes — anchored to document points */}
          <div className="mt-7 space-y-7">
            <MarginNote
              tag="against the home block"
              dot={TOK.indigo}>
              <Murmur>
                Your mortgage rate fixes in <b style={{ fontStyle: "normal", color: TOK.ink }}>March 2027</b>.
                A court will want to know what monthly cost you're planning around. Want me to draft
                two scenarios — current rate vs. SVR?
              </Murmur>
              <ActionRow primary="Draft scenarios" secondary="Not now"/>
            </MarginNote>

            <MarginNote
              tag="against the children"
              dot={TOK.flag}>
              <Murmur color={TOK.flag}>
                I can see Mark's transfers <b style={{ fontStyle: "normal", color: TOK.ink }}>£280/mo</b> coming in,
                labelled "after school". Should I treat this as his contribution and remove it from
                your figures?
              </Murmur>
              <ActionRow primary="Yes, treat as Mark's" secondary="Keep separate"/>
            </MarginNote>

            <MarginNote
              tag="quiet observation"
              dot={TOK.mute}>
              <Murmur color={TOK.sub}>
                A standing order to "<span style={{ fontStyle: "normal", fontFamily: "inherit" }}>Mum</span>"
                of £150/mo is paused in March. I won't include it in your needs unless you tell me to.
              </Murmur>
              <ActionRow primary="Include" secondary="Skip"/>
            </MarginNote>

            <MarginNote
              tag="reconciliation preview"
              dot={TOK.warn}>
              <Murmur color={TOK.warn}>
                When Mark shares his picture, two things will likely disagree: who pays for
                <b style={{ fontStyle: "normal", color: TOK.ink }}> private medical </b> and
                whether <b style={{ fontStyle: "normal", color: TOK.ink }}>holiday spend </b>
                is a joint expense. I'll surface both as soon as he's ready.
              </Murmur>
            </MarginNote>
          </div>

          <HR my={28}/>

          {/* AI todo, very quiet */}
          <Kicker>I am still working on</Kicker>
          <div className="mt-3 space-y-2">
            {[
              { t: "Identifying recurring subscriptions", p: 72 },
              { t: "Estimating annual irregulars (insurance, MOT)", p: 41 },
              { t: "Cross-checking against Mark's salary credits", p: 18 },
            ].map((t, i) => (
              <div key={i}>
                <div className="flex items-center justify-between text-[11.5px]">
                  <span style={{ color: TOK.sub }}>{t.t}</span>
                  <span className="mono tabular" style={{ color: TOK.faint, fontSize: 10 }}>{t.p}%</span>
                </div>
                <div className="mt-1 h-[2px] rounded-full overflow-hidden" style={{ background: TOK.cream }}>
                  <div className="h-full" style={{ width: `${t.p}%`, background: TOK.indigo }}/>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>

      {/* footer status */}
      <footer className="flex items-center justify-between px-6"
              style={{ height: 30, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>auto-saved</Trace>
          <Trace>v1 · sarah only</Trace>
          <Trace>read-only · banks</Trace>
        </div>
        <div className="flex items-center gap-3 text-[10.5px]" style={{ color: TOK.mute }}>
          <span>62% complete</span>
          <span>·</span>
          <span style={{ color: TOK.indigo, fontWeight: 600 }}>Outgoings is the last gap</span>
        </div>
      </footer>
    </div>
  );
}

/* ----- supporting ----- */

function CategoryBlock({ title, sub, total, share, flag, rows }) {
  return (
    <section className="mt-9">
      <div className="flex items-baseline justify-between">
        <div>
          <h2 className="serif" style={{ fontSize: 26, fontWeight: 600, letterSpacing: "-0.02em" }}>
            {title}
          </h2>
          <div className="mt-1 text-[12.5px]" style={{ color: TOK.mute }}>{sub}</div>
        </div>
        <div className="text-right flex items-center gap-3">
          {flag ? (
            <span className="inline-flex items-center gap-1 mono"
                  style={{ fontSize: 10, color: TOK.flag, letterSpacing: "0.06em" }}>
              <I.flag s={10} c={TOK.flag}/> {flag} need attention
            </span>
          ) : null}
          <div>
            <Big size={26}>{total}</Big>
            <Trace>{share} of monthly</Trace>
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-xl overflow-hidden" style={{ border: `1px solid ${TOK.line}`, background: "#FFF" }}>
        {rows.map((r, i) => (
          <div key={i} className="flex items-start gap-4 px-4 py-3"
               style={{ borderTop: i ? `1px solid ${TOK.hairline}` : "none" }}>
            <div className="flex-1 min-w-0">
              <div className="text-[13.5px] font-medium" style={{ color: r.gap ? TOK.flag : TOK.ink }}>
                {r.name}
              </div>
              <div className="mt-0.5 flex items-center gap-2">
                <Trace>{r.source}</Trace>
                {r.conf != null && (
                  <Trace color={r.conf < 0.95 ? TOK.flag : TOK.faint}>
                    · conf {Math.round(r.conf * 100)}%
                  </Trace>
                )}
                {r.expand && <span className="mono" style={{ fontSize: 9.5, color: TOK.indigo, letterSpacing: "0.06em", cursor: "pointer" }}>↳ expand</span>}
              </div>
              {r.note && (
                <div className="mt-2 flex items-start gap-2 pl-2"
                     style={{ borderLeft: `2px solid ${r.note.kind === "flag" ? TOK.flag : TOK.indigo}` }}>
                  <I.spark s={11} c={r.note.kind === "flag" ? TOK.flag : TOK.indigo} style={{ marginTop: 2 }}/>
                  <Murmur color={r.note.kind === "flag" ? TOK.flag : TOK.indigo}>{r.note.text}</Murmur>
                </div>
              )}
            </div>
            <div className="text-right">
              <div className="mono tabular" style={{ fontSize: 13, color: r.gap ? TOK.flag : TOK.ink, fontWeight: 500 }}>
                {r.amt}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

function MarginNote({ tag, dot, children }) {
  return (
    <div className="relative pl-4">
      <span className="absolute left-0 top-1.5 w-2 h-2 rounded-full" style={{ background: dot }}/>
      <Trace>{tag}</Trace>
      <div className="mt-1.5">{children}</div>
    </div>
  );
}

function ActionRow({ primary, secondary }) {
  return (
    <div className="mt-2.5 flex items-center gap-1.5">
      <button className="px-2.5 h-6 rounded-md text-[11px] font-medium"
              style={{ background: TOK.ink, color: "#FFF" }}>{primary}</button>
      <button className="px-2.5 h-6 rounded-md text-[11px]"
              style={{ color: TOK.sub }}>{secondary}</button>
    </div>
  );
}

/* ============================================================
   Collapsible left nav — drawer over scrim
   Mirrors the wireframe IA: Prepare → Shared → Settle → Finalise
   ============================================================ */
function EvolvedDrawer({ onClose }) {
  return (
    <div style={{ position: "absolute", inset: 0, zIndex: 30, display: "flex" }}>
      <div onClick={onClose}
           style={{ position: "absolute", inset: 0, background: "rgba(21,23,26,0.18)" }}/>
      <aside style={{
        position: "relative", zIndex: 1, width: 296, height: "100%",
        background: TOK.paper, borderRight: `1px solid ${TOK.line}`,
        display: "flex", flexDirection: "column",
        boxShadow: "0 12px 40px rgba(0,0,0,0.10)"
      }}>
        {/* header — wordmark + close */}
        <div className="flex items-center justify-between px-4"
             style={{ height: 52, borderBottom: `1px solid ${TOK.hairline}` }}>
          <span style={{ fontSize: 14, letterSpacing: "-0.01em", fontWeight: 600, color: TOK.ink }}>decouple</span>
          <button onClick={onClose}
                  className="w-7 h-7 rounded-sm flex items-center justify-center"
                  style={{ background: "transparent" }}>
            <I.close s={14} c={TOK.sub}/>
          </button>
        </div>

        {/* back to dashboard */}
        <div className="px-4 pt-3 pb-2" style={{ borderBottom: `1px solid ${TOK.hairline}` }}>
          <button className="flex items-center gap-1.5 text-[12px]" style={{ color: TOK.sub }}>
            <I.chevR s={11} c={TOK.sub} style={{ transform: "rotate(180deg)" }}/>
            <span>Back to Dashboard</span>
          </button>
        </div>

        {/* sections */}
        <div className="flex-1 overflow-y-auto px-3 py-4">
          {/* you */}
          <div className="flex items-center gap-2 px-2 mb-3">
            <div className="rounded-full flex items-center justify-center text-white font-semibold"
                 style={{ width: 28, height: 28, background: TOK.indigo, fontSize: 11 }}>S</div>
            <div className="min-w-0">
              <div className="text-[12.5px] font-medium" style={{ color: TOK.ink }}>Sarah Whitman</div>
              <Trace>private workspace · saved</Trace>
            </div>
          </div>

          <DrawerSection label="Prepare your disclosure">
            <DrawerItem active>Your position</DrawerItem>
            <DrawerItem progress={60} indent>Children <span style={{ color: TOK.faint }}>(2)</span></DrawerItem>
            <DrawerSubhead>Finances</DrawerSubhead>
            <DrawerItem progress={100} indent>Income <span style={{ color: TOK.faint }}>(1)</span></DrawerItem>
            <DrawerItem progress={82} indent>Assets <span style={{ color: TOK.faint }}>(3)</span></DrawerItem>
            <DrawerItem progress={12} indent alarm>Debt <span style={{ color: TOK.faint }}>(0)</span></DrawerItem>
            <DrawerItem progress={88} indent>Outgoings</DrawerItem>
          </DrawerSection>

          <DrawerSection label="Shared position" muted lock>
            <div className="px-2 py-1.5">
              <Trace>unlocks once both parties have prepared</Trace>
            </div>
          </DrawerSection>

          <DrawerSection label="Settle and agree" muted lock>
            <DrawerItem indent muted>The proposal</DrawerItem>
            <DrawerItem indent muted>Children</DrawerItem>
            <DrawerItem indent muted>Assets</DrawerItem>
            <DrawerItem indent muted>Needs</DrawerItem>
          </DrawerSection>

          <DrawerSection label="Finalisation" muted lock/>
        </div>

        {/* footer */}
        <div className="px-4 py-3" style={{ borderTop: `1px solid ${TOK.hairline}`, background: "#FFFFFF80" }}>
          <Trace>Help & guides</Trace>
          <div className="mt-1.5 flex items-center gap-3 text-[11.5px]" style={{ color: TOK.sub }}>
            <span>Help centre</span>
            <span style={{ color: TOK.faint }}>·</span>
            <span>Speak to an advisor</span>
          </div>
        </div>
      </aside>
    </div>
  );
}

function DrawerSection({ label, muted, lock, children }) {
  return (
    <div className="mb-4">
      <div className="px-2 mb-1.5 flex items-center justify-between">
        <span className="mono" style={{
          fontSize: 9.5, letterSpacing: "0.12em",
          color: muted ? TOK.faint : TOK.mute,
          textTransform: "uppercase", fontWeight: 600
        }}>{label}</span>
        {lock && (
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke={TOK.faint} strokeWidth="2">
            <rect x="5" y="11" width="14" height="10" rx="2"/>
            <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
          </svg>
        )}
      </div>
      {children && <div className="space-y-0.5">{children}</div>}
    </div>
  );
}

function DrawerSubhead({ children }) {
  return (
    <div className="px-2 pt-2.5 pb-1 mono" style={{
      fontSize: 9.5, letterSpacing: "0.10em", color: TOK.mute,
      textTransform: "uppercase", fontWeight: 500
    }}>{children}</div>
  );
}

function DrawerItem({ children, active, indent, muted, alarm, progress }) {
  const fg = alarm ? TOK.flag : (muted ? TOK.faint : TOK.ink);
  return (
    <button className="w-full flex items-center gap-2 py-1.5 rounded-md text-left"
            style={{
              paddingLeft: indent ? 18 : 8,
              paddingRight: 8,
              background: active ? "#FFF" : "transparent",
              border: active ? `1px solid ${TOK.line}` : "1px solid transparent",
              color: fg
            }}
            onMouseEnter={e => { if (!active && !muted) e.currentTarget.style.background = "#FFFFFF99"; }}
            onMouseLeave={e => { if (!active) e.currentTarget.style.background = "transparent"; }}>
      <span className="flex-1 serif" style={{
        fontSize: 13.5, fontWeight: active ? 600 : 400, letterSpacing: "-0.005em"
      }}>{children}</span>
      {progress != null && (
        <span className="rounded-full overflow-hidden" style={{
          width: 36, height: 4, background: TOK.cream, flexShrink: 0
        }}>
          <span className="block h-full rounded-full" style={{
            width: progress + "%",
            background: alarm ? TOK.flag : (progress === 100 ? TOK.pulse : TOK.indigo)
          }}/>
        </span>
      )}
    </button>
  );
}

window.Sarah_Evolved = Sarah_Evolved;
