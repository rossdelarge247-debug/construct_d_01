/* ============================================================
   09 · Proposal Builder — The Pot
   ------------------------------------------------------------
   The proposal as one whole pot being divided. Visualises every
   component (assets, debts, pensions, maintenance, support) and
   surfaces the swings/roundabouts as live levers. Move one, the
   pot rebalances; AI calls out what just changed.
   ============================================================ */

function Proposal_Pot() {
  // levers
  const [houseTo, setHouseTo]       = React.useState(60); // % to Sarah of house equity
  const [pensionShare, setPension]  = React.useState(50); // % to Sarah of pensions
  const [maintenance, setMaint]     = React.useState(950); // £ from Mark to Sarah / mo
  const [years, setYears]           = React.useState(7);   // term (years)

  // figures (drawn from earlier disclosure)
  const houseEq = 860 - 412.4; // £447.6k
  const pensions = 284 + 198.5; // £482.5k
  const liquid = 14.82 + 8.64; // £23.46k
  const debt = -6.2; // hsbc cc

  const sFromHouse = houseEq * houseTo / 100;
  const mFromHouse = houseEq - sFromHouse;
  const sFromPen   = pensions * pensionShare / 100;
  const mFromPen   = pensions - sFromPen;
  const sLiquid    = liquid / 2;
  const mLiquid    = liquid / 2 + debt;

  const sTotal = sFromHouse + sFromPen + sLiquid;
  const mTotal = mFromHouse + mFromPen + mLiquid;
  const total  = sTotal + mTotal;
  const sPct   = (sTotal / total) * 100;

  return (
    <div style={{
      width: 1280, height: 920, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Propose</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>The pot</span>
            <Chip bg={TOK.skySoft} fg={TOK.sky}>Live model · v4</Chip>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Avatar name="S" color={TOK.indigo}/>
          <Avatar name="M" color={TOK.magenta}/>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium" style={{ background: TOK.ink, color: "#FFF" }}>
            Save scenario
          </button>
        </div>
      </header>

      <div className="flex-1 grid" style={{ gridTemplateColumns: "1fr 380px", minHeight: 0 }}>

        {/* ============= MAIN STAGE ============= */}
        <div className="overflow-y-auto px-10 py-7">
          <Kicker color={TOK.sky}>The pot · everything to be divided</Kicker>
          <div className="flex items-baseline gap-4 mt-1">
            <Big size={48}>£{(total).toFixed(0)}k</Big>
            <span className="serif" style={{ fontSize: 16, color: TOK.sub, fontStyle: "italic" }}>
              total household value · before division
            </span>
          </div>

          {/* THE POT — split bar */}
          <div className="mt-6">
            <div className="flex items-baseline justify-between mb-2">
              <div className="flex items-center gap-2">
                <Avatar name="S" color={TOK.indigo}/>
                <span className="text-[12.5px] font-medium" style={{ color: TOK.indigo }}>Sarah</span>
                <span className="serif tabular" style={{ fontSize: 18, fontWeight: 600 }}>£{sTotal.toFixed(0)}k</span>
                <Trace color={TOK.indigo}>{sPct.toFixed(0)}%</Trace>
              </div>
              <div className="flex items-center gap-2">
                <Trace color={TOK.magenta}>{(100 - sPct).toFixed(0)}%</Trace>
                <span className="serif tabular" style={{ fontSize: 18, fontWeight: 600 }}>£{mTotal.toFixed(0)}k</span>
                <span className="text-[12.5px] font-medium" style={{ color: TOK.magenta }}>Mark</span>
                <Avatar name="M" color={TOK.magenta}/>
              </div>
            </div>

            <div className="rounded-lg overflow-hidden flex" style={{ height: 76, border: `1px solid ${TOK.line}` }}>
              <div style={{ width: `${sPct}%`, background: "linear-gradient(180deg, #4338CA 0%, #312E9C 100%)", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "8px 12px" }}>
                <PotPart label="House" amt={sFromHouse} fg="#FFF" mute="rgba(255,255,255,0.7)"/>
                <div className="flex gap-3">
                  <PotPart label="Pension" amt={sFromPen} fg="#FFF" mute="rgba(255,255,255,0.7)" small/>
                  <PotPart label="Liquid"  amt={sLiquid}  fg="#FFF" mute="rgba(255,255,255,0.7)" small/>
                </div>
              </div>
              <div style={{ width: `${100 - sPct}%`, background: "linear-gradient(180deg, #9D174D 0%, #6B0F35 100%)", display: "flex", flexDirection: "column", justifyContent: "space-between", padding: "8px 12px" }}>
                <PotPart label="House" amt={mFromHouse} fg="#FFF" mute="rgba(255,255,255,0.75)"/>
                <div className="flex gap-3">
                  <PotPart label="Pension" amt={mFromPen} fg="#FFF" mute="rgba(255,255,255,0.75)" small/>
                  <PotPart label="Liquid"  amt={mLiquid}  fg="#FFF" mute="rgba(255,255,255,0.75)" small/>
                </div>
              </div>
            </div>

            {/* legend */}
            <div className="mt-2 flex items-center justify-between text-[10.5px]" style={{ color: TOK.mute }}>
              <span className="mono" style={{ letterSpacing: "0.04em" }}>HOUSE EQUITY £{houseEq.toFixed(0)}K  ·  PENSIONS £{pensions.toFixed(0)}K  ·  LIQUID £{liquid.toFixed(0)}K  ·  DEBT -£{Math.abs(debt).toFixed(1)}K</span>
              <Trace color={TOK.sky}>Drag levers below to rebalance</Trace>
            </div>
          </div>

          {/* SWINGS & ROUNDABOUTS */}
          <div className="mt-8">
            <Kicker color={TOK.sky}>Swings & roundabouts · live trade-offs</Kicker>
            <p className="serif mt-1" style={{ fontSize: 16, color: TOK.sub, fontStyle: "italic", maxWidth: 640, lineHeight: 1.4 }}>
              Move any lever — the others stay still, the pot rebalances, and Decouple tells you what just shifted.
            </p>

            <div className="mt-4 grid grid-cols-2 gap-3">
              <Lever label="House equity to Sarah"
                     value={houseTo} unit="%"
                     onChange={setHouseTo} min={0} max={100}
                     left="Mark keeps house" right="Sarah keeps house"
                     swing={`Sarah +£${(houseEq * (houseTo - 50) / 100).toFixed(0)}k`}
                     round={`Mark would need ${houseTo > 50 ? "lump-sum buy-out" : "to buy out Sarah"}`}/>

              <Lever label="Pension share to Sarah"
                     value={pensionShare} unit="%"
                     onChange={setPension} min={20} max={80}
                     left="Mark keeps more" right="Sarah keeps more"
                     swing={`Long-term retirement value swings £${Math.abs(pensions * (pensionShare - 50) / 100).toFixed(0)}k`}
                     round="Pension sharing order required (CSO £500–£1,200)"/>

              <Lever label="Spousal maintenance"
                     value={maintenance} unit="£/mo"
                     onChange={setMaint} min={0} max={2400} step={50}
                     left="Clean break" right="Higher monthly"
                     swing={`Mark pays £${(maintenance * 12 / 1000).toFixed(1)}k/yr · for ${years} years`}
                     round="Reviews when Sarah's income changes; ends at remarriage"/>

              <Lever label="Term"
                     value={years} unit="yr"
                     onChange={setYears} min={1} max={15} step={1}
                     left="Short" right="Long"
                     swing={`Total maintenance £${((maintenance * 12 * years) / 1000).toFixed(0)}k`}
                     round={years >= 10 ? "Court may view as joint-lives — risky" : "Within typical clean-break window"}/>
            </div>
          </div>

          {/* FUTURES — projection */}
          <div className="mt-8">
            <Kicker color={TOK.sky}>Where this lands you</Kicker>
            <div className="mt-3 grid grid-cols-3 gap-3">
              <FutureCard
                who="Sarah" color={TOK.indigo}
                today={`£${sTotal.toFixed(0)}k`}
                fiveYr={`£${(sTotal + (maintenance * 12 * Math.min(5, years) / 1000) - 60).toFixed(0)}k`}
                note={`Plus £${maintenance}/mo for ${Math.min(5, years)} of next 5 yrs. House equity locked until kids 18.`}/>
              <FutureCard
                who="Mark" color={TOK.magenta}
                today={`£${mTotal.toFixed(0)}k`}
                fiveYr={`£${(mTotal - (maintenance * 12 * Math.min(5, years) / 1000) - 30).toFixed(0)}k`}
                note={`Minus £${maintenance}/mo. Re-deposit needed (~£${Math.max(0, 80 - mLiquid).toFixed(0)}k) to buy.`}/>
              <FutureCard
                who="The pot" color={TOK.sky}
                today={`£${total.toFixed(0)}k`}
                fiveYr={`£${(total + 30).toFixed(0)}k`}
                note="Assuming UK inflation tracks 2.4% and pensions grow 4%. Updates as you move levers."/>
            </div>
          </div>

          {/* fairness gauges */}
          <div className="mt-7 rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
            <div className="grid grid-cols-3 gap-6">
              <Gauge label="Reasonableness" value={88} note="Within typical s.25 outcomes" color={TOK.green}/>
              <Gauge label="Court likelihood" value={91} note="Likely approved as drafted" color={TOK.green}/>
              <Gauge label="Sarah needs met"  value={72} note="Tight in years 6–7 — review trigger added" color={TOK.flag}/>
            </div>
          </div>

          <div className="h-12"/>
        </div>

        {/* ============= AI RAIL ============= */}
        <aside className="overflow-y-auto px-7 py-6" style={{ background: "#FFF", borderLeft: `1px solid ${TOK.line}` }}>
          <div className="flex items-center gap-2">
            <Pulse color={TOK.sky} size={6}/>
            <Trace color={TOK.sky}>Decouple is modelling along</Trace>
          </div>

          <h3 className="serif mt-3" style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-0.01em" }}>
            What just changed
          </h3>
          <Murmur color={TOK.sky}>
            You moved the house lever to <b style={{ color: TOK.ink }}>{houseTo}%</b> for Sarah.
            That's £{Math.abs(sFromHouse - houseEq / 2).toFixed(0)}k swung from {houseTo > 50 ? "Mark to Sarah" : "Sarah to Mark"}.
            Mark's deposit fund just {houseTo > 50 ? "shrank" : "grew"} by the same amount.
          </Murmur>

          <HR my={20}/>

          <Kicker color={TOK.sky}>Trade-offs you've made so far</Kicker>
          <div className="mt-3 space-y-3">
            <Tradeoff
              left={{ who: "Sarah", color: TOK.indigo, body: "keeps the house" }}
              right={{ who: "Mark", color: TOK.magenta, body: "keeps £4k/yr more pension" }}
              note="House liquidity is locked. Pension grows quietly."/>
            <Tradeoff
              left={{ who: "Mark", color: TOK.magenta, body: `pays £${maintenance}/mo` }}
              right={{ who: "Sarah", color: TOK.indigo, body: "no claim on Mark's future bonuses" }}
              note={`Clean-break-ish · ends at year ${years}`}/>
            <Tradeoff
              left={{ who: "Both", color: TOK.sky, body: "split liquid 50/50" }}
              right={{ who: "Both", color: TOK.sky, body: "Mark covers HSBC card from his half" }}
              note="Card debt was incurred during the marriage."/>
          </div>

          <HR my={20}/>

          <Kicker color={TOK.flag}>Watch-outs</Kicker>
          <div className="mt-3 space-y-3">
            <WatchOut
              title={`Sarah's year-${years} cliff`}
              body={<>When maintenance ends in year {years}, Sarah's monthly income drops by £{maintenance}. Her NHS salary covers needs but leaves no surplus for Lily's university.</>}
              action={`Add a step-down to year ${years + 2}`}/>
            <WatchOut
              title="Pension sharing order — courts only"
              body="A pension sharing order can't be done by agreement alone. You'll need to file a consent order — Decouple drafts this for you."
              action="Draft consent order"/>
          </div>

          <HR my={20}/>

          <Kicker color={TOK.sky}>If you wanted to push further</Kicker>
          <div className="mt-3 space-y-2">
            {["Try 'Sarah keeps house, Mark keeps pension' (clean swap)",
              "Try '50/50 of everything, sell house in 3 yrs'",
              "Try 'Mark buys Sarah out today'"].map((s, i) => (
              <button key={i} className="w-full text-left px-3 py-2 rounded-md text-[12px]"
                      style={{ border: `1px solid ${TOK.line}`, color: TOK.ink, background: TOK.bg }}>
                <span className="serif italic" style={{ color: TOK.sky }}>↗</span>  {s}
              </button>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ----- pieces ----- */

function PotPart({ label, amt, fg, mute, small }) {
  return (
    <div>
      <div className="mono" style={{ fontSize: small ? 9 : 9.5, color: mute, letterSpacing: "0.06em", textTransform: "uppercase" }}>
        {label}
      </div>
      <div className="serif tabular" style={{ fontSize: small ? 13 : 16, color: fg, fontWeight: 600, lineHeight: 1.1 }}>
        £{amt.toFixed(0)}k
      </div>
    </div>
  );
}

function Lever({ label, value, unit, onChange, min, max, step = 1, left, right, swing, round }) {
  return (
    <div className="rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
      <div className="flex items-baseline justify-between">
        <div className="text-[12.5px] font-medium" style={{ color: TOK.ink }}>{label}</div>
        <div className="serif tabular" style={{ fontSize: 18, fontWeight: 600, color: TOK.sky }}>
          {unit === "%" ? `${value}${unit}` : `${unit === "£/mo" ? `£${value}/mo` : `${value} ${unit}`}`}
        </div>
      </div>
      <input type="range" min={min} max={max} step={step}
             value={value} onChange={e => onChange(Number(e.target.value))}
             className="w-full mt-2.5"
             style={{ accentColor: TOK.sky }}/>
      <div className="flex justify-between text-[10px] mt-0.5" style={{ color: TOK.faint }}>
        <span>{left}</span><span>{right}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 pt-3" style={{ borderTop: "1px solid " + TOK.hairline }}>
        <div>
          <Trace color={TOK.indigo}>swing</Trace>
          <div className="text-[11.5px] mt-0.5" style={{ color: TOK.ink, lineHeight: 1.4 }}>{swing}</div>
        </div>
        <div>
          <Trace color={TOK.flag}>roundabout</Trace>
          <div className="text-[11.5px] mt-0.5" style={{ color: TOK.ink, lineHeight: 1.4 }}>{round}</div>
        </div>
      </div>
    </div>
  );
}

function FutureCard({ who, color, today, fiveYr, note }) {
  return (
    <div className="rounded-xl p-4" style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
      <div className="flex items-center gap-2">
        <Avatar name={who[0]} color={color}/>
        <span className="text-[12.5px] font-medium" style={{ color: color }}>{who}</span>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <div>
          <Trace>today</Trace>
          <div className="serif tabular" style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.02em" }}>{today}</div>
        </div>
        <div>
          <Trace>5 yrs</Trace>
          <div className="serif tabular" style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.02em", color: TOK.sub }}>{fiveYr}</div>
        </div>
      </div>
      <div className="mt-2 text-[11px]" style={{ color: TOK.sub, lineHeight: 1.45 }}>{note}</div>
    </div>
  );
}

function Gauge({ label, value, note, color }) {
  const dash = 2 * Math.PI * 22;
  const off = dash * (1 - value / 100);
  return (
    <div className="flex items-center gap-3">
      <svg width={64} height={64} viewBox="0 0 64 64">
        <circle cx="32" cy="32" r="22" stroke={TOK.line} strokeWidth="4" fill="none"/>
        <circle cx="32" cy="32" r="22" stroke={color} strokeWidth="4" fill="none"
                strokeLinecap="round" strokeDasharray={dash} strokeDashoffset={off}
                transform="rotate(-90 32 32)"/>
        <text x="32" y="36" fill={TOK.ink} fontSize="14" fontWeight="600" textAnchor="middle"
              fontFamily="Source Serif Pro">{value}</text>
      </svg>
      <div className="min-w-0 flex-1">
        <div className="text-[12px] font-medium" style={{ color: TOK.ink }}>{label}</div>
        <div className="text-[10.5px]" style={{ color: TOK.sub, lineHeight: 1.35 }}>{note}</div>
      </div>
    </div>
  );
}

function Tradeoff({ left, right, note }) {
  return (
    <div>
      <div className="flex items-center gap-2 text-[12px]">
        <Avatar name={left.who[0]} color={left.color}/>
        <span style={{ color: TOK.ink }}>{left.body}</span>
        <span style={{ color: TOK.faint }}>↔</span>
        <Avatar name={right.who[0]} color={right.color}/>
        <span style={{ color: TOK.ink }}>{right.body}</span>
      </div>
      <Murmur color={TOK.sub}>{note}</Murmur>
    </div>
  );
}

function WatchOut({ title, body, action }) {
  return (
    <div className="rounded-md p-3" style={{ background: "#FFFAF0", border: `1px solid #F3D88A` }}>
      <div className="flex items-start gap-2">
        <I.flag s={11} c={TOK.flag} style={{ marginTop: 2, flexShrink: 0 }}/>
        <div className="min-w-0">
          <div className="text-[12px] font-medium" style={{ color: TOK.flag }}>{title}</div>
          <Murmur color={TOK.sub}>{body}</Murmur>
          <button className="mt-2 px-2 h-6 rounded-md text-[11px]" style={{ background: TOK.flag, color: "#FFF", fontWeight: 500 }}>
            {action}
          </button>
        </div>
      </div>
    </div>
  );
}

window.Proposal_Pot = Proposal_Pot;
