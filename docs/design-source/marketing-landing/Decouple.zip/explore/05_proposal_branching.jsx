/* ============================================================
   05 · Proposal Builder — PUSHED (Branching scenarios)
   ------------------------------------------------------------
   The proposal as a tree of futures. Each branch is a scenario —
   "Sarah keeps the house", "We sell and split", "Mark buys her
   out". The active branch flows down the centre with live
   fairness gauges. AI streams its reasoning as you drag a node.
   ============================================================ */

function Proposal_Branching() {
  const [branch, setBranch] = React.useState("keep");

  return (
    <div style={{
      width: 1280, height: 860, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Settle</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Proposal Builder</span>
            <Chip bg={TOK.skySoft} fg={TOK.sky}>v3 · drafting</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Chip bg="#F0FDF4" fg={TOK.green} border="#BBF7D0">
            <Pulse color={TOK.green} size={5}/> within reasonable band
          </Chip>
          <button className="h-7 px-2.5 rounded-md text-[11.5px] font-medium flex items-center gap-1.5"
                  style={{ background: TOK.ink, color: "#FFF" }}>
            Send to Mark <I.arrowR s={11} c="#FFF"/>
          </button>
        </div>
      </header>

      {/* hero strip */}
      <div className="px-12 pt-6 pb-5 flex items-end justify-between" style={{ background: "#FFF", flexShrink: 0 }}>
        <div>
          <Kicker color={TOK.sky}>Phase 3 · Settle</Kicker>
          <h1 className="serif mt-2" style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.05 }}>
            Three futures. <span style={{ fontStyle: "italic", color: TOK.sub }}>Pick one to refine.</span>
          </h1>
        </div>

        {/* fairness gauge */}
        <div className="flex items-center gap-6">
          <div>
            <Trace>Capital split (Sarah)</Trace>
            <Big size={32} color={TOK.sky}>58%</Big>
          </div>
          <div>
            <Trace>Reasonableness</Trace>
            <div className="flex items-center gap-1.5 mt-1">
              <Pulse color={TOK.green} size={6}/>
              <span style={{ fontSize: 14, color: TOK.green, fontWeight: 600 }}>Within band</span>
            </div>
          </div>
          <div>
            <Trace>Court likelihood</Trace>
            <Big size={32}>92<span style={{ fontSize: 14, color: TOK.mute, fontWeight: 400 }}>%</span></Big>
          </div>
        </div>
      </div>

      {/* the branch tree */}
      <div className="flex-1 overflow-hidden flex" style={{ minHeight: 0 }}>
        {/* tree column */}
        <div className="flex-1 relative" style={{ minWidth: 0 }}>
          <BranchTree branch={branch} setBranch={setBranch}/>
        </div>

        {/* AI reasoning rail */}
        <aside style={{ width: 360, background: "#FFF", borderLeft: `1px solid ${TOK.line}` }}
               className="overflow-y-auto p-6">
          <div className="flex items-center gap-2">
            <Pulse color={TOK.sky} size={6}/>
            <Trace color={TOK.sky}>Reasoning · live</Trace>
          </div>
          <div className="serif mt-2.5" style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.02em" }}>
            Why I'm scoring this 92.
          </div>

          <div className="mt-4 space-y-4">
            <ReasoningStep n="1" title="Marriage length" body="14 years. The court applies the 'sharing principle' to all matrimonial assets — full equality is the starting point."/>
            <ReasoningStep n="2" title="Departure from 50/50" body="Sarah +8% reflects her primary care of two children under 16, and a 6-year career break for caregiving. This is consistent with White v White and section 25 factors."/>
            <ReasoningStep n="3" title="Pension offset" body="Sarah keeps her smaller NHS pension; Mark keeps his SIPP plus the older DB. Net pension share to Sarah: 41%. Combined with capital, Sarah's total share is 54%."/>
            <ReasoningStep n="4" title="Maintenance" body="Spousal periodical payments of £1,200/mo for 4 years gives Sarah a clean break runway while she returns to NHS Band 7 work."/>
            <ReasoningStep n="5" title="Where I'd push back" pulse body="Mark may reasonably argue for a faster step-down on maintenance. I've modelled 4-year tapered as a fallback — see Branch B."/>
          </div>

          <HR my={20}/>

          <Kicker>Cited authorities</Kicker>
          <div className="mt-2 space-y-2">
            {[
              { t: "White v White (2000)", s: "yardstick of equality" },
              { t: "Matrimonial Causes Act 1973, s.25", s: "factors to consider" },
              { t: "Charman v Charman (2007)", s: "long marriage sharing" },
              { t: "Standish v Standish (2024)", s: "matrimonial vs non-matrimonial" }
            ].map((c, i) => (
              <div key={i} className="flex items-start gap-2 text-[11.5px]" style={{ color: TOK.sub }}>
                <I.doc s={11} c={TOK.sky} style={{ marginTop: 2, flexShrink: 0 }}/>
                <div>
                  <span style={{ color: TOK.ink, fontWeight: 500 }}>{c.t}</span>
                  <span style={{ color: TOK.mute }}> · {c.s}</span>
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>

      {/* footer / chip strip of micro-toggles */}
      <footer className="flex items-center justify-between px-6"
              style={{ height: 36, borderTop: `1px solid ${TOK.line}`, background: TOK.cream, flexShrink: 0 }}>
        <div className="flex items-center gap-3 text-[11px]" style={{ color: TOK.sub }}>
          <Trace color={TOK.sky}>levers</Trace>
          {["50/50", "55/45", "58/42 (current)", "60/40", "Spousal: 4y", "Spousal: 2y", "Pension share", "Pension offset"].map((c, i) => (
            <button key={i} className="px-2 h-6 rounded-md text-[10.5px]"
                    style={{ background: c.includes("current") ? TOK.sky : "#FFF", color: c.includes("current") ? "#FFF" : TOK.sub, border: `1px solid ${c.includes("current") ? TOK.sky : TOK.line}` }}>
              {c}
            </button>
          ))}
        </div>
        <Trace>auto-saved · v3</Trace>
      </footer>
    </div>
  );
}

function ReasoningStep({ n, title, body, pulse }) {
  return (
    <div className="flex gap-3">
      <div className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center mono"
           style={{ background: pulse ? TOK.skySoft : TOK.cream, color: TOK.sky, fontSize: 10, fontWeight: 600 }}>
        {pulse ? <Pulse color={TOK.sky} size={5}/> : n}
      </div>
      <div className="flex-1">
        <div className="text-[12.5px] font-semibold" style={{ color: TOK.ink }}>{title}</div>
        <div className="serif mt-0.5" style={{ fontSize: 12.5, lineHeight: 1.5, color: TOK.sub, fontStyle: "italic" }}>
          {body}
        </div>
      </div>
    </div>
  );
}

/* ─── the actual tree ─── */
function BranchTree({ branch, setBranch }) {
  return (
    <svg width="100%" height="100%" viewBox="0 0 880 660" preserveAspectRatio="xMidYMid meet">
      {/* root */}
      <g>
        <circle cx={440} cy={70} r={32} fill="#FFF" stroke={TOK.ink} strokeWidth={1.5}/>
        <text x={440} y={74} textAnchor="middle" fontSize="10" letterSpacing="1.5" fontWeight="600" fill={TOK.ink}>START</text>
        <text x={440} y={120} textAnchor="middle" fontSize="11" fill={TOK.mute}>Net £612k · 2 children · 14y marriage</text>
      </g>

      {/* branch lines */}
      <path d="M 440 102 Q 440 160 200 220" stroke={branch === "keep" ? TOK.sky : TOK.faint} strokeWidth={branch === "keep" ? 2 : 1} fill="none"/>
      <path d="M 440 102 Q 440 160 440 220" stroke={branch === "sell" ? TOK.sky : TOK.faint} strokeWidth={branch === "sell" ? 2 : 1} fill="none"/>
      <path d="M 440 102 Q 440 160 680 220" stroke={branch === "buy"  ? TOK.sky : TOK.faint} strokeWidth={branch === "buy"  ? 2 : 1} fill="none"/>

      {/* three branches */}
      <BranchNode
        x={200} y={230} active={branch === "keep"} onClick={() => setBranch("keep")}
        title="A · Sarah keeps the home" pct="58/42" cap="£612k" gauge="92"
        leaf="Mark releases mortgage, takes more pension"
      />
      <BranchNode
        x={440} y={230} active={branch === "sell"} onClick={() => setBranch("sell")}
        title="B · Sell, split clean" pct="55/45" cap="£612k" gauge="86"
        leaf="Both rehome — Sarah needs ~£480k for similar area"
      />
      <BranchNode
        x={680} y={230} active={branch === "buy"} onClick={() => setBranch("buy")}
        title="C · Mark buys her out" pct="50/50" cap="£612k" gauge="78"
        leaf="Mark refinances · Sarah liquid for next phase"
      />

      {/* sub-branches under active */}
      {branch === "keep" && <SubTree x={200}/>}
      {branch === "sell" && <SubTree x={440}/>}
      {branch === "buy"  && <SubTree x={680}/>}

      {/* outcome leaves at bottom */}
      <text x={20} y={640} fontSize="10" fill={TOK.mute} letterSpacing="1.5" fontWeight="600">FUTURES →</text>
    </svg>
  );
}

function BranchNode({ x, y, title, pct, cap, gauge, leaf, active, onClick }) {
  return (
    <g style={{ cursor: "pointer" }} onClick={onClick}>
      {active && <rect x={x - 110} y={y - 12} width={220} height={104} rx={12} fill={TOK.skySoft} opacity={0.6}/>}
      <rect x={x - 100} y={y - 4} width={200} height={92} rx={10}
            fill="#FFF" stroke={active ? TOK.sky : TOK.line} strokeWidth={active ? 1.5 : 1}/>
      <text x={x - 86} y={y + 16} fontSize="11.5" fontWeight="600" fill={TOK.ink}>{title}</text>
      <text x={x - 86} y={y + 36} fontSize="10" fill={TOK.mute} letterSpacing="0.06em">SARAH/MARK · CAPITAL</text>
      <text x={x - 86} y={y + 56} fontSize="20" fontFamily="'Source Serif Pro', serif" fontWeight="600" fill={active ? TOK.sky : TOK.ink} style={{ fontVariantNumeric: "tabular-nums" }}>{pct}</text>
      <text x={x + 86} y={y + 56} fontSize="13" fontFamily="'JetBrains Mono', monospace" fill={TOK.sub} textAnchor="end">{cap}</text>
      <foreignObject x={x - 86} y={y + 64} width={172} height={20}>
        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: active ? TOK.sky : TOK.mute }}>
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: gauge >= 90 ? TOK.green : gauge >= 80 ? TOK.sky : TOK.flag }}/>
          <span style={{ fontFamily: "JetBrains Mono, monospace" }}>court likelihood {gauge}%</span>
        </div>
      </foreignObject>
      <text x={x} y={y + 110} textAnchor="middle" fontSize="10.5" fontStyle="italic" fontFamily="'Source Serif Pro', serif" fill={TOK.sub}>{leaf}</text>
    </g>
  );
}

function SubTree({ x }) {
  const subs = [
    { dx: -90, label: "4y maint.", v: "£1,200/mo" },
    { dx: 0,   label: "Pension share 41%", v: "DB offset" },
    { dx: 90,  label: "Step-down", v: "Yr 3 →£600" }
  ];
  return (
    <g>
      <line x1={x} y1={350} x2={x} y2={400} stroke={TOK.faint} strokeDasharray="2 3"/>
      {subs.map((s, i) => (
        <g key={i}>
          <line x1={x} y1={400} x2={x + s.dx} y2={440} stroke={TOK.faint} strokeDasharray="2 3"/>
          <rect x={x + s.dx - 60} y={440} width={120} height={48} rx={8} fill={TOK.cream} stroke={TOK.line} strokeWidth={1}/>
          <text x={x + s.dx} y={460} textAnchor="middle" fontSize="10.5" fontWeight="600" fill={TOK.ink}>{s.label}</text>
          <text x={x + s.dx} y={478} textAnchor="middle" fontSize="11" fontFamily="'JetBrains Mono', monospace" fill={TOK.sub}>{s.v}</text>
        </g>
      ))}
      {/* outcome circle */}
      <circle cx={x} cy={560} r={34} fill={TOK.greenSoft} stroke={TOK.green} strokeWidth={1.5}/>
      <text x={x} y={557} textAnchor="middle" fontSize="9.5" letterSpacing="1.5" fontWeight="600" fill={TOK.green}>OUTCOME</text>
      <text x={x} y={573} textAnchor="middle" fontSize="14" fontFamily="'Source Serif Pro', serif" fontWeight="600" fill={TOK.green}>fair · 92</text>
      <line x1={x - 130} y1={500} x2={x + 130} y2={500} stroke={TOK.faint} strokeDasharray="2 3"/>
    </g>
  );
}

window.Proposal_Branching = Proposal_Branching;
