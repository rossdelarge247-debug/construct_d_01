/* ============================================================
   08 · Household Picture — Ambient with comment threads
   ------------------------------------------------------------
   Single doc-style merged picture. Each row is one fact.
   Most rows AGREE silently. Conflicts and queries surface as
   inline thread bubbles with fly-out comment threads (ES2-style).
   ============================================================ */

function Household_Ambient() {
  const [openThread, setOpenThread] = React.useState("hsbc");

  return (
    <div style={{
      width: 1280, height: 920, background: TOK.bg, color: TOK.ink,
      fontFamily: "Inter, sans-serif", display: "flex", flexDirection: "column",
      position: "relative", overflow: "hidden"
    }}>
      {/* top bar */}
      <header className="flex items-center justify-between px-6"
              style={{ height: 52, borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-3">
          <Wordmark size={13}/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12px]">
            <span style={{ color: TOK.mute }}>Disclose</span>
            <I.chevR s={11} c={TOK.faint}/>
            <span style={{ color: TOK.ink, fontWeight: 600 }}>Our household picture</span>
            <Chip bg={TOK.magentaSoft} fg={TOK.magenta}>Shared · Sarah & Mark</Chip>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Avatar name="S" color={TOK.indigo}/>
          <Avatar name="M" color={TOK.magenta}/>
          <span className="mono" style={{ fontSize: 10, color: TOK.mute, letterSpacing: "0.04em" }}>both online · 2m ago</span>
          <button className="ml-2 h-7 px-2.5 rounded-md text-[11.5px] font-medium" style={{ background: TOK.ink, color: "#FFF" }}>
            Approve & lock
          </button>
        </div>
      </header>

      {/* status strip */}
      <div className="px-6 py-3 flex items-center gap-5" style={{ borderBottom: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <Stat l="Agreed" v="34" c={TOK.green}/>
        <Stat l="Conflicts" v="3" c={TOK.flag}/>
        <Stat l="Open queries" v="2" c={TOK.indigo}/>
        <Stat l="Auto-resolved by AI" v="11" c={TOK.mute}/>
        <div className="flex-1"/>
        <div className="flex items-center gap-2">
          <Pulse size={5}/>
          <span className="mono" style={{ fontSize: 10, color: TOK.sub, letterSpacing: "0.04em" }}>
            DECOUPLE IS LISTENING · last activity 12s ago
          </span>
        </div>
      </div>

      {/* body */}
      <div className="flex-1 overflow-hidden flex" style={{ minHeight: 0 }}>
        {/* doc */}
        <div className="flex-1 overflow-y-auto px-12 py-7" style={{ position: "relative" }}>

          <Kicker color={TOK.magenta}>The combined picture · v3 draft</Kicker>
          <h1 className="serif mt-2" style={{ fontSize: 36, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1.05 }}>
            The shape of the <span style={{ fontStyle: "italic", color: TOK.sub }}>household</span> we are unwinding.
          </h1>
          <Murmur color={TOK.magenta}>
            Decouple has merged your two pictures. Where you both saw the same number, it stays quiet.
            Where you didn't, the disagreement is in the margin — leave a comment, propose a value, or accept the AI's reading.
          </Murmur>

          <HR my={28}/>

          {/* ASSETS */}
          <SectionHeader n="01" title="Assets" agreed="9 of 11" accent={TOK.magenta}/>
          <Row v="agreed"
               name="Family home · Hampstead" amt="£860,000" src="Joint · Zoopla · 12 Apr"/>

          <Row v="conflict" id="house-val" open={openThread === "house-val"} onOpen={() => setOpenThread("house-val")}
               name="Independent valuation needed?" amt="?"
               sLabel="Sarah" sValue="trust Zoopla" mLabel="Mark" mValue="get RICS valuation"
               threadCount={3}
               aiTake="Zoopla's confidence is 0.78 here. Two of the comparables sold over 4 months ago. A RICS valuation is ~£500 — small price for a single shared number."
               actions={["Book RICS valuation", "Stay with Zoopla"]}/>

          <Row v="agreed" name="Halifax mortgage outstanding" amt="-£412,400" src="Halifax · live"/>

          <Row v="conflict" id="hsbc" open={openThread === "hsbc"} onOpen={() => setOpenThread("hsbc")}
               name="HSBC Credit Card balance" amt="?"
               sLabel="Sarah" sValue="not declared yet" mLabel="Mark" mValue="says it's £6,200"
               threadCount={5}
               aiTake="Mark filled in £6,200 from his most recent statement. Sarah hasn't connected HSBC. The transfer pattern from Sarah's Halifax to HSBC suggests the balance is closer to £8,400 today — please check."
               actions={["Sarah: connect HSBC", "Accept Mark's £6,200"]}/>

          <Row v="agreed" name="NHS career pension (Sarah)" amt="£284,000" src="CETV · 2 Mar"/>
          <Row v="agreed" name="DC pension (Mark)" amt="£198,500" src="Aviva · 31 Mar"/>

          <HR my={24}/>

          {/* CHILDREN */}
          <SectionHeader n="02" title="The children" agreed="silent · context only" accent={TOK.magenta}/>
          <Row v="query" id="schools" open={openThread === "schools"} onOpen={() => setOpenThread("schools")}
               name="Schooling continuity"
               sLabel="Sarah" sValue="stay at St Mary's" mLabel="Mark" mValue="open to a move"
               threadCount={8} note="not a number — a discussion"
               aiTake="This is one of the hardest things to keep separate from money. I'll surface it again later when the proposal touches Mark's housing — moves and schools tend to land in the same conversation."/>

          <HR my={24}/>

          {/* OUTGOINGS */}
          <SectionHeader n="03" title="Outgoings — the contested ones" agreed="14 of 17" accent={TOK.magenta}/>

          <Row v="conflict" id="afterschool" open={openThread === "afterschool"} onOpen={() => setOpenThread("afterschool")}
               name="After-school club · £280/mo"
               sLabel="Sarah" sValue="Mark's contribution" mLabel="Mark" mValue="my share of childcare"
               threadCount={2}
               aiTake="You're saying the same thing in different words — Sarah counts it as income, Mark counts it as outgoing. I'll fold them so it doesn't double-count in the proposal."
               actions={["Apply AI's reading", "Discuss"]}/>

          <Row v="agreed" name="Council tax · £218/mo" src="Both ledgers match"/>

          <Row v="conflict"
               name="British Gas · annual review"
               sLabel="Sarah" sValue="£184/mo" mLabel="Mark" mValue="£167/mo"
               threadCount={1}
               aiTake="Mark's number is from Jan, Sarah's from this week's bill. The current direct debit is £184 — using that."/>

          <HR my={24}/>

          {/* INCOME */}
          <SectionHeader n="04" title="Income" agreed="all sources match" accent={TOK.green}/>
          <Row v="agreed" name="Salaries · combined post-tax" amt="£8,640/mo" src="Both ledgers · live"/>

          <div className="h-12"/>
        </div>

        {/* THREAD PANEL · fly-out */}
        <ThreadPanel open={openThread} onClose={() => setOpenThread(null)}/>
      </div>

      <footer className="flex items-center justify-between px-6"
              style={{ height: 30, borderTop: `1px solid ${TOK.line}`, background: "#FFF", flexShrink: 0 }}>
        <div className="flex items-center gap-4 text-[10.5px]" style={{ color: TOK.mute }}>
          <Trace>auto-saved</Trace><Trace>v3 · both editing</Trace><Trace>11 ai resolutions logged</Trace>
        </div>
        <div className="text-[10.5px]" style={{ color: TOK.mute }}>
          3 conflicts to settle · then this picture locks and the proposal can begin
        </div>
      </footer>
    </div>
  );
}

/* ----- pieces ----- */

function Avatar({ name, color }) {
  return (
    <div className="rounded-full flex items-center justify-center text-white font-semibold"
         style={{ width: 22, height: 22, background: color, fontSize: 10.5 }}>
      {name}
    </div>
  );
}

function Stat({ l, v, c }) {
  return (
    <div>
      <Trace>{l}</Trace>
      <div className="serif tabular" style={{ fontSize: 18, fontWeight: 600, color: c, letterSpacing: "-0.02em", lineHeight: 1 }}>{v}</div>
    </div>
  );
}

function SectionHeader({ n, title, agreed, accent }) {
  return (
    <div className="flex items-baseline justify-between mt-6">
      <div className="flex items-baseline gap-3">
        <span className="mono" style={{ fontSize: 11, color: accent, letterSpacing: "0.16em", fontWeight: 600 }}>{n}</span>
        <h2 className="serif" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>{title}</h2>
      </div>
      <Trace>{agreed}</Trace>
    </div>
  );
}

/* a row: agreed (silent), conflict (split + thread), or query */
function Row({ v, id, open, onOpen, name, amt, src,
               sLabel, sValue, mLabel, mValue, threadCount, aiTake, actions, note }) {
  if (v === "agreed") {
    return (
      <div className="flex items-center gap-3 py-2.5" style={{ borderTop: "1px solid " + TOK.hairline }}>
        <I.check s={12} c={TOK.green} w={2.2}/>
        <span className="text-[13.5px]" style={{ color: TOK.ink }}>{name}</span>
        <Trace>{src}</Trace>
        <div className="flex-1"/>
        {amt && <span className="mono tabular" style={{ fontSize: 13, color: TOK.ink, fontWeight: 500 }}>{amt}</span>}
      </div>
    );
  }

  // conflict / query
  const isQuery = v === "query";
  const accent = isQuery ? TOK.indigo : TOK.flag;
  const accentBg = isQuery ? TOK.indigoSoft : "#FFFAF0";

  return (
    <div className={`relative my-1.5 rounded-lg overflow-hidden ${open ? "ring-1" : ""}`}
         style={{
           background: open ? accentBg : "transparent",
           border: open ? `1px solid ${accent}` : `1px solid transparent`,
           paddingLeft: 14, paddingRight: 14
         }}>
      <div className="flex items-center gap-3 py-2.5">
        <span className="w-3 h-3 rounded-sm rotate-45 flex-shrink-0" style={{ background: accent }}/>
        <span className="text-[13.5px] font-medium" style={{ color: TOK.ink }}>{name}</span>
        {note && <Trace color={TOK.mute}>· {note}</Trace>}
        <div className="flex-1"/>
        <button onClick={onOpen}
                className="flex items-center gap-1.5 h-6 px-2 rounded-md text-[10.5px]"
                style={{ background: accent, color: "#FFF", fontWeight: 500 }}>
          <I.spark s={10} c="#FFF"/>
          {threadCount} {threadCount === 1 ? "comment" : "comments"}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 pb-3">
        <SideValue who={sLabel} color={TOK.indigo} value={sValue}/>
        <SideValue who={mLabel} color={TOK.magenta} value={mValue}/>
      </div>
    </div>
  );
}

function SideValue({ who, color, value }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-md"
         style={{ background: "#FFF", border: `1px solid ${TOK.line}` }}>
      <Avatar name={who?.[0] || "?"} color={color}/>
      <div className="min-w-0 flex-1">
        <Trace color={color}>{who} says</Trace>
        <div className="text-[12.5px] truncate" style={{ color: TOK.ink }}>{value}</div>
      </div>
    </div>
  );
}

function ThreadPanel({ open, onClose }) {
  const threads = {
    "hsbc": {
      title: "HSBC Credit Card balance",
      kind: "conflict",
      messages: [
        { who: "M", color: TOK.magenta, name: "Mark", t: "2d ago", body: "Filled in £6,200 from my Jan statement." },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "2d ago",
          body: <>I see regular outflows from <b>Sarah's</b> Halifax to HSBC of £180–£420/mo since November. The balance has likely changed.</>, ai: true },
        { who: "S", color: TOK.indigo, name: "Sarah", t: "1d ago", body: "I haven't connected HSBC because I'm not sure I want it pulling that history. Can I just enter today's balance?" },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "1d ago",
          body: <>Yes — manual is fine. I'll mark it <b>self-declared</b> rather than <b>verified</b>, which is normal for credit cards.</>, ai: true },
        { who: "M", color: TOK.magenta, name: "Mark", t: "now", body: "Happy with whichever — let's just settle on a number this week." }
      ],
      proposal: {
        body: <>Sarah enters today's balance manually. Mark's £6,200 is replaced. The figure is tagged <b>self-declared</b> in the proposal.</>,
        actions: ["Apply", "Suggest another"]
      }
    },
    "house-val": {
      title: "Independent valuation needed?",
      kind: "conflict",
      messages: [
        { who: "M", color: TOK.magenta, name: "Mark", t: "3d ago", body: "I'd like a RICS valuation before we plan anything. Single biggest number." },
        { who: "S", color: TOK.indigo, name: "Sarah", t: "3d ago", body: "Feels like overkill. Zoopla's been within 3% on this street." },
        { who: "AI", color: TOK.flag, name: "Decouple", t: "2d ago",
          body: <>Zoopla's confidence here is <b>0.78</b> — lower than usual. Two recent comparables (no. 14, no. 32) sold over 4 months ago. A RICS valuation is ~£500.</>, ai: true }
      ],
      proposal: {
        body: <>Get RICS now (cost: ~£500, split). Use Zoopla as a working figure until it lands. Lock proposal scenarios on the verified number.</>,
        actions: ["Apply", "Discuss more"]
      }
    },
    "schools": {
      title: "Schooling continuity",
      kind: "query",
      messages: [
        { who: "S", color: TOK.indigo, name: "Sarah", t: "5d ago", body: "Lily's settled at St Mary's. Oscar starts juniors there next year. I want this to stay still." },
        { who: "M", color: TOK.magenta, name: "Mark", t: "5d ago", body: "Open to it. But if I move further out for housing, the daily round-trip matters." },
        { who: "AI", color: TOK.indigo, name: "Decouple", t: "4d ago",
          body: <>Marking this and parking it. I'll resurface it when we model Mark's housing — that's where school continuity actually gets decided.</>, ai: true }
      ]
    },
    "afterschool": {
      title: "After-school club · £280/mo",
      kind: "conflict",
      messages: [
        { who: "AI", color: TOK.flag, name: "Decouple", t: "now",
          body: <>You're describing the same money two ways. Sarah's "Mark's contribution" income is Mark's "my share of childcare" outgoing. I'll fold them.</>, ai: true }
      ],
      proposal: {
        body: <>Treat as a single shared expense, paid by Mark monthly. It sits as a child cost in the proposal — not as Sarah's income or Mark's outgoing.</>,
        actions: ["Apply", "Keep separate"]
      }
    }
  };

  const t = threads[open];
  if (!t) {
    return (
      <aside style={{ width: 360, borderLeft: `1px solid ${TOK.line}`, background: "#FFF" }}
             className="overflow-y-auto p-7">
        <Kicker color={TOK.magenta}>No thread open</Kicker>
        <Murmur color={TOK.sub}>Click any conflict marker in the document to open its thread.</Murmur>
      </aside>
    );
  }

  return (
    <aside style={{ width: 380, borderLeft: `1px solid ${TOK.line}`, background: "#FFF" }}
           className="overflow-y-auto flex flex-col">
      <div className="flex items-start justify-between px-5 py-4 sticky top-0" style={{ background: "#FFF", borderBottom: `1px solid ${TOK.hairline}` }}>
        <div className="min-w-0 pr-2">
          <Trace color={t.kind === "conflict" ? TOK.flag : TOK.indigo}>
            {t.kind === "conflict" ? "Conflict thread" : "Query thread"} · {t.messages.length} messages
          </Trace>
          <div className="serif mt-1" style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-0.01em" }}>{t.title}</div>
        </div>
        <button onClick={onClose} style={{ color: TOK.mute, padding: 2 }}><I.close s={14} c={TOK.mute}/></button>
      </div>

      <div className="flex-1 px-5 py-4 space-y-4">
        {t.messages.map((m, i) => (
          <div key={i} className="flex gap-2.5">
            {m.ai
              ? <div className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
                     style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
                  <I.spark s={13} c={TOK.flag}/>
                </div>
              : <Avatar name={m.who} color={m.color}/>
            }
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-1.5">
                <span className="text-[12px] font-semibold" style={{ color: m.color }}>{m.name}</span>
                {m.ai && <Chip bg={TOK.cream} fg={TOK.sub}>AI</Chip>}
                <Trace>{m.t}</Trace>
              </div>
              {m.ai
                ? <Murmur color={TOK.flag}>{m.body}</Murmur>
                : <div className="mt-0.5 text-[12.5px]" style={{ color: TOK.ink, lineHeight: 1.5 }}>{m.body}</div>}
            </div>
          </div>
        ))}

        {t.proposal && (
          <div className="rounded-lg p-3 mt-2" style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
            <Kicker color={TOK.flag}>Decouple proposes a resolution</Kicker>
            <div className="mt-1.5 text-[12.5px]" style={{ color: TOK.ink, lineHeight: 1.5 }}>{t.proposal.body}</div>
            <div className="mt-3 flex gap-2">
              {t.proposal.actions.map((a, i) => (
                <button key={i} className="px-2.5 h-7 rounded-md text-[11.5px]"
                        style={i === 0
                          ? { background: TOK.ink, color: "#FFF", fontWeight: 500 }
                          : { color: TOK.sub, border: `1px solid ${TOK.line}`, background: "#FFF" }}>
                  {a}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="px-5 py-3 sticky bottom-0" style={{ background: "#FFF", borderTop: `1px solid ${TOK.hairline}` }}>
        <div className="flex items-center gap-2 px-3 h-9 rounded-md" style={{ background: TOK.cream, border: `1px solid ${TOK.line}` }}>
          <span className="text-[12px]" style={{ color: TOK.faint }}>Reply, propose a value, or @decouple…</span>
          <div className="flex-1"/>
          <I.arrowR s={12} c={TOK.mute}/>
        </div>
      </div>
    </aside>
  );
}

window.Household_Ambient = Household_Ambient;
