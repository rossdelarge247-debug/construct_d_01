/* ============================================================
   Shared tokens, primitives, and icons for the exploration set
   ============================================================ */

const TOK = {
  ink:   "#1A1A1A",
  sub:   "#57534E",
  mute:  "#8A8580",
  faint: "#B8B2AA",
  line:  "#E5E3DC",
  hairline: "#EFECE5",
  bg:    "#FAFAF7",
  panel: "#FFFFFF",
  cream: "#F5F2EA",
  paper: "#F8F5EE",

  // ambient
  pulse: "#059669",
  flag:  "#B45309",
  warn:  "#9D174D",

  // accents per screen
  indigo: "#4338CA",
  indigoSoft: "#EEF2FF",
  magenta: "#9D174D",
  magentaSoft: "#FCE7F3",
  sky:   "#0369A1",
  skySoft: "#E0F2FE",
  green: "#166534",
  greenSoft: "#DCFCE7",

  // dark
  graphite: "#0E0E10",
  graphite2:"#16161A",
  graphite3:"#1E1E24",
  gline:    "#2A2A32",
  gtext:    "#E7E5E0",
  gsub:     "#9A968F",
  cyan:     "#67E8F9",
  amber:    "#FBBF24",
};

/* tiny SVG icon kit — sized via `s`, stroke via `c`, weight via `w` */
const Ic = (children, p = {}) => (
  <svg width={p.s || 14} height={p.s || 14} viewBox="0 0 24 24" fill="none"
       stroke={p.c || "currentColor"} strokeWidth={p.w || 1.6}
       strokeLinecap="round" strokeLinejoin="round" style={p.style}>{children}</svg>
);

const I = {
  arrowR: (p) => Ic(<><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></>, p),
  arrowL: (p) => Ic(<><line x1="19" y1="12" x2="5" y2="12"/><polyline points="11 18 5 12 11 6"/></>, p),
  chevR:  (p) => Ic(<polyline points="9 6 15 12 9 18"/>, p),
  chevD:  (p) => Ic(<polyline points="6 9 12 15 18 9"/>, p),
  chevU:  (p) => Ic(<polyline points="6 15 12 9 18 15"/>, p),
  check:  (p) => Ic(<polyline points="5 12 10 17 19 7"/>, p),
  close:  (p) => Ic(<><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></>, p),
  plus:   (p) => Ic(<><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>, p),
  spark:  (p) => Ic(<><path d="M12 3l1.5 5L18 9.5 13.5 11 12 16l-1.5-5L6 9.5 10.5 8z"/><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z"/></>, p),
  search: (p) => Ic(<><circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.5" y2="16.5"/></>, p),
  cmd:    (p) => Ic(<path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/>, p),
  flag:   (p) => Ic(<><path d="M4 21V4"/><path d="M4 4h12l-2 4 2 4H4"/></>, p),
  filter: (p) => Ic(<polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5"/>, p),
  share:  (p) => Ic(<><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.6" y1="13.5" x2="15.4" y2="17.5"/><line x1="15.4" y1="6.5" x2="8.6" y2="10.5"/></>, p),
  diff:   (p) => Ic(<><path d="M7 7v10"/><path d="M17 7v10"/><path d="M7 12h4"/><path d="M13 12h4"/></>, p),
  zoom:   (p) => Ic(<><circle cx="11" cy="11" r="6"/><line x1="20" y1="20" x2="15.5" y2="15.5"/><line x1="8" y1="11" x2="14" y2="11"/><line x1="11" y1="8" x2="11" y2="14"/></>, p),
  pin:    (p) => Ic(<><path d="M12 17v5"/><path d="M9 11h6l1.5-7h-9z"/><path d="M9 11l-2 6h10l-2-6"/></>, p),
  branch: (p) => Ic(<><circle cx="6" cy="6" r="2.5"/><circle cx="6" cy="18" r="2.5"/><circle cx="18" cy="12" r="2.5"/><path d="M6 8.5v7"/><path d="M6 12c8 0 6 0 9.5 0"/></>, p),
  brain:  (p) => Ic(<><path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-1 5 3 3 0 0 0 1 5v1a3 3 0 0 0 3 3"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 1 5 3 3 0 0 1-1 5v1a3 3 0 0 1-3 3"/></>, p),
  scale:  (p) => Ic(<><path d="M12 3v18"/><path d="M5 9l-2 6h6z"/><path d="M19 9l-2 6h6z"/><path d="M5 9h14"/></>, p),
  user:   (p) => Ic(<><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></>, p),
  users:  (p) => Ic(<><circle cx="9" cy="8" r="3.5"/><path d="M2 21a7 7 0 0 1 14 0"/><circle cx="17" cy="9" r="3"/><path d="M14 21a6 6 0 0 1 8-5.5"/></>, p),
  lock:   (p) => Ic(<><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></>, p),
  bank:   (p) => Ic(<><path d="M3 10l9-6 9 6"/><line x1="3" y1="10" x2="21" y2="10"/><line x1="6" y1="10" x2="6" y2="18"/><line x1="10" y1="10" x2="10" y2="18"/><line x1="14" y1="10" x2="14" y2="18"/><line x1="18" y1="10" x2="18" y2="18"/><line x1="3" y1="21" x2="21" y2="21"/></>, p),
  home:   (p) => Ic(<><path d="M3 11l9-8 9 8"/><path d="M5 10v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V10"/></>, p),
  car:    (p) => Ic(<><path d="M5 17h14"/><rect x="3" y="11" width="18" height="6" rx="2"/><path d="M5 11l2-5h10l2 5"/><circle cx="7" cy="17" r="1.5"/><circle cx="17" cy="17" r="1.5"/></>, p),
  pension:(p) => Ic(<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>, p),
  kid:    (p) => Ic(<><circle cx="12" cy="6" r="3"/><path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/></>, p),
  doc:    (p) => Ic(<><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></>, p),
  pulse:  (p) => Ic(<polyline points="3 12 7 12 10 4 14 20 17 12 21 12"/>, p),
  mic:    (p) => Ic(<><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><line x1="12" y1="18" x2="12" y2="22"/></>, p),
  layers: (p) => Ic(<><polygon points="12 2 22 8 12 14 2 8"/><polyline points="2 14 12 20 22 14"/></>, p),
};

/* ============================================================
   Decouple wordmark (compact)
   ============================================================ */
function Wordmark({ size = 14, color = "#111", bg = "#FAFAF7" }) {
  const r = size * 1.05;
  return (
    <div className="flex items-center gap-2 select-none">
      <div className="relative" style={{ width: r, height: r }} aria-hidden>
        <div className="absolute inset-0 rounded-full" style={{ background: color }}/>
        <div className="absolute rounded-full" style={{ left: "42%", top: 0, width: "58%", height: "100%", background: bg }}/>
        <div className="absolute rounded-full" style={{ left: "45%", top: "12%", width: "10%", height: "76%", background: color }}/>
      </div>
      <span style={{ fontSize: size, letterSpacing: "-0.01em", fontWeight: 600, color }}>decouple</span>
    </div>
  );
}

/* ============================================================
   Reusable bits
   ============================================================ */

/* Soft ambient pulse dot */
function Pulse({ color = TOK.pulse, size = 6 }) {
  return (
    <span className="relative inline-flex" style={{ width: size, height: size }}>
      <span className="absolute inset-0 rounded-full opacity-50 animate-ping" style={{ background: color }}/>
      <span className="relative rounded-full" style={{ width: size, height: size, background: color }}/>
    </span>
  );
}

/* Mono provenance chip — under any data point */
function Trace({ children, color = TOK.mute }) {
  return (
    <span className="mono" style={{
      fontSize: 9.5, letterSpacing: "0.04em", color, textTransform: "uppercase", fontWeight: 500
    }}>{children}</span>
  );
}

/* AI margin note — italic serif murmur */
function Murmur({ children, color = TOK.indigo, align = "left" }) {
  return (
    <div className="serif" style={{
      fontSize: 12.5, lineHeight: 1.4, color, fontStyle: "italic",
      fontWeight: 400, textAlign: align, letterSpacing: "-0.005em"
    }}>{children}</div>
  );
}

/* Section kicker — uppercase tracked label */
function Kicker({ children, color = TOK.mute }) {
  return (
    <div style={{
      fontSize: 10, letterSpacing: "0.16em", textTransform: "uppercase",
      fontWeight: 600, color
    }}>{children}</div>
  );
}

/* Big serif hero number */
function Big({ children, color = TOK.ink, size = 44 }) {
  return (
    <div className="serif tabular" style={{
      fontSize: size, fontWeight: 600, letterSpacing: "-0.025em", lineHeight: 1, color
    }}>{children}</div>
  );
}

/* Soft cream chip */
function Chip({ children, bg = TOK.cream, fg = TOK.sub, border }) {
  return (
    <span className="inline-flex items-center gap-1" style={{
      padding: "2px 7px", borderRadius: 999,
      fontSize: 10.5, fontWeight: 500, color: fg, background: bg,
      border: border ? `1px solid ${border}` : "none"
    }}>{children}</span>
  );
}

/* Mini subtle hairline */
const HR = ({ c = TOK.line, my = 12 }) => (
  <div style={{ height: 1, background: c, margin: `${my}px 0` }}/>
);

window.TOK = TOK;
window.I = I;
window.Wordmark = Wordmark;
window.Pulse = Pulse;
window.Trace = Trace;
window.Murmur = Murmur;
window.Kicker = Kicker;
window.Big = Big;
window.Chip = Chip;
window.HR = HR;
