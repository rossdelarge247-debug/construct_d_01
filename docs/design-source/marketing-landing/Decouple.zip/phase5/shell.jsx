/* Phase 5 — Finalise: shared primitives (doc icon, status dot, paper styles) */
(function(){
const { P4_IcBase: Ic, P4_TOK: T } = window;

const IDoc      = (p) => <Ic {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></Ic>;
const IPrint    = (p) => <Ic {...p}><polyline points="6 9 6 2 18 2 18 9"/><rect x="4" y="9" width="16" height="8" rx="2"/><rect x="6" y="14" width="12" height="8"/></Ic>;
const IDownload = (p) => <Ic {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></Ic>;
const IEdit     = (p) => <Ic {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 1 1 3 3L7 19l-4 1 1-4z"/></Ic>;
const IShield   = (p) => <Ic {...p}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></Ic>;
const IStar     = (p) => (
  <Ic {...p}><polygon points="12 2 15 9 22 10 17 15 18 22 12 18 6 22 7 15 2 10 9 9 12 2" fill="currentColor"/></Ic>
);
const IClock    = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></Ic>;
const ISpark    = (p) => <Ic {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8"/></Ic>;
const IInfo     = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="8"/><line x1="12" y1="11" x2="12" y2="17"/></Ic>;
const IWarn     = (p) => <Ic {...p}><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12" y2="17"/></Ic>;
const ICheck    = (p) => <Ic {...p}><polyline points="5 12 10 17 19 7"/></Ic>;
const IExternal = (p) => <Ic {...p}><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></Ic>;
const ISend     = (p) => <Ic {...p}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></Ic>;

function StatusDot({ state }) {
  /* state: 'done' | 'current' | 'upcoming' */
  const ring = state === "current" ? { boxShadow: "0 0 0 4px rgba(37,99,235,0.18)" } : {};
  const bg = state === "done" ? "#059669" : state === "current" ? "#2563EB" : "#D1D5DB";
  return (
    <span className="inline-block rounded-full flex-shrink-0"
          style={{ width: 12, height: 12, background: bg, ...ring }}/>
  );
}

/* Soft card (white, hair border, 16px radius) */
function SoftCard({ children, style = {}, className = "" }) {
  return (
    <div className={`rounded-2xl ${className}`}
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}`, ...style }}>
      {children}
    </div>
  );
}

Object.assign(window, {
  P5_Ic: { Doc: IDoc, Print: IPrint, Download: IDownload, Edit: IEdit,
           Shield: IShield, Star: IStar, Clock: IClock, Spark: ISpark,
           Info: IInfo, Warn: IWarn, Check: ICheck, External: IExternal, Send: ISend },
  P5_StatusDot: StatusDot,
  P5_SoftCard: SoftCard,
  P5_PAPER_BG: "#FDFCF8",
  P5_RED: "#E5484D",
  P5_GREEN: "#059669",
  P5_BLUE: "#2563EB"
});
})();
