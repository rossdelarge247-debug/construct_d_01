/* Phase 5 · View A — Generation hub */
(function(){
const { useState, useEffect } = React;
const { P4_TOK: T, P4_Avatar, P4_TopBar, P4_ChapterRail, P4_FloatingRouter, P4_TweakPanel,
        P5_Ic: I5, P5_DOCS, P5_SECTION_STATUS, P5_RED } = window;

const STEPS = [
  "Generating consent order…",
  "Compiling D81 and Section 10 narrative…",
  "Generating pension sharing annex…",
  "Running quality checks…"
];

function DocCard({ doc, includeOpt, setIncludeOpt }) {
  const optional = doc.status === "optional";
  const on = optional ? includeOpt : true;
  return (
    <div className="rounded-xl p-4 flex items-start gap-3 transition"
         style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
      <div className="flex items-center justify-center flex-shrink-0 rounded-lg"
           style={{ width: 36, height: 36, background: "#F5F3EE", color: T.INK }}>
        <I5.Doc size={18}/>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <div style={{ fontSize: 13.5, fontWeight: 600 }}>{doc.title}</div>
          {doc.required && (
            <span className="label-xs whitespace-nowrap" style={{ color: T.MUTE }}>Required</span>
          )}
        </div>
        <div style={{ fontSize: 12.5, color: T.SUB, marginTop: 3, lineHeight: 1.5 }}>
          {doc.body}
        </div>
        <div className="mt-2.5 flex items-center gap-1.5" style={{ fontSize: 11.5 }}>
          {optional ? (
            <label className="inline-flex items-center gap-1.5 cursor-pointer" style={{ color: T.SUB }}>
              <input type="checkbox" checked={on} onChange={e => setIncludeOpt(e.target.checked)}/>
              Include this too
            </label>
          ) : (
            <span className="inline-flex items-center gap-1" style={{ color: "#059669", fontWeight: 600 }}>
              <I5.Check size={12} stroke="#059669" strokeWidth={2.5}/> Ready to generate
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

function ProgressRunner({ onDone }) {
  const [step, setStep] = useState(0);
  useEffect(() => {
    if (step >= STEPS.length) { setTimeout(onDone, 500); return; }
    const t = setTimeout(() => setStep(s => s + 1), 800);
    return () => clearTimeout(t);
  }, [step]);
  return (
    <div className="rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
      <div className="label-xs mb-3" style={{ color: T.MUTE }}>Generating</div>
      {STEPS.map((s, i) => {
        const done = i < step;
        const active = i === step;
        return (
          <div key={i} className="flex items-center gap-2.5 py-1.5" style={{ opacity: done || active ? 1 : 0.4 }}>
            <span className="w-4 h-4 rounded-full inline-flex items-center justify-center" style={{ background: done ? "#059669" : active ? T.INK : "#E5E7EB" }}>
              {done && <I5.Check size={10} stroke="#FFF" strokeWidth={3}/>}
              {active && <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"/>}
            </span>
            <span style={{ fontSize: 13, color: T.INK, fontWeight: done || active ? 500 : 400 }}>
              {s} {done && "✓"}
            </span>
          </div>
        );
      })}
    </div>
  );
}

function App() {
  const [includeOpt, setIncludeOpt] = useState(false);
  const [running, setRunning] = useState(false);
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => ({ ...t, [id]: value }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
  };

  const topRight = (
    <div className="flex items-center gap-2">
      <button className="h-8 px-3 rounded-md inline-flex items-center gap-1.5 whitespace-nowrap" style={{ border: `1px solid ${T.HAIR}`, background: "#FFF", fontSize: 12.5 }}>Help</button>
      <P4_Avatar who="S" size={28}/>
    </div>
  );

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar viewMeta={{ phase: "Phase 5", title: "Settlement · v5.0 AGREED · Generating documents", version: "v5.0", statusLabel: "AGREED", statusKind: "agreed" }} right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={P5_SECTION_STATUS}
                        title="Agreed settlement"
                        subtitle="Ready to generate legal documents"
                        pct={100}
                        currentRoute="fin-generate"
                        showInlineRouter={tweaks.router === "inline"}/>

        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[760px] mx-auto px-8 py-10 pb-40">
            <div className="label-xs mb-1.5" style={{ color: T.AGREED }}>Phase 5 · Finalise</div>
            <h1 style={{ fontSize: 32, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
              Generate your legal documents
            </h1>
            <p className="mt-3" style={{ fontSize: 14.5, color: T.SUB, lineHeight: 1.55 }}>
              Everything you've agreed can now be turned into the documents the court needs. It takes about 30 seconds.
            </p>

            <div className="mt-7 space-y-3">
              {P5_DOCS.map(d => (
                <DocCard key={d.id} doc={d} includeOpt={includeOpt} setIncludeOpt={setIncludeOpt}/>
              ))}
            </div>

            <div className="mt-7">
              {!running ? (
                <button onClick={() => setRunning(true)}
                        className="inline-flex items-center gap-2 h-11 px-5 rounded-md whitespace-nowrap transition"
                        style={{ background: P5_RED, color: "#FFF", fontSize: 13.5, fontWeight: 600, boxShadow: "0 1px 2px rgba(229,72,77,0.3), 0 8px 20px rgba(229,72,77,0.22)" }}>
                  Generate all documents
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>
                </button>
              ) : (
                <ProgressRunner onDone={() => { window.location.href = "Settlement - Preview.html"; }}/>
              )}
            </div>

            <div className="mt-8 pt-6" style={{ borderTop: `1px solid ${T.HAIR}` }}>
              <p style={{ fontSize: 12.5, color: T.MUTE, lineHeight: 1.55 }}>
                These use court-approved legal templates, built from your structured agreement. You'll review everything before any submission.
              </p>
            </div>
          </div>
        </div>

        {tweaks.router !== "inline" && <P4_FloatingRouter current="fin-generate"/>}
      </div>
      <P4_TweakPanel
        title="Generate"
        options={[
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{"router": "inline"}/*EDITMODE-END*/;

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
