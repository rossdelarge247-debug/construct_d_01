/* Phase 5 · View B — Document preview (Consent Order rendered as paper)
   Tabs: [Consent Order] [D81] [Pension Annex] [Settlement Summary]
   The consent order content is formatted as a legal document.
*/
(function(){
const { useState } = React;
const { P4_TOK: T, P4_SECTIONS, P4_Avatar, P4_TopBar, P4_ChapterRail,
        P4_FloatingRouter, P4_TweakPanel, P4_StatusChip,
        P5_Ic: I5, P5_FACTS: F, P5_CONSENT_CLAUSES: CLAUSES,
        P5_D81_SECTION10: D81S10, P5_SECTION_STATUS, P5_PAPER_BG } = window;

/* ============================================================
   LEGAL PAPER — the common A4-ish wrapper with subtle shadow
   ============================================================ */
function LegalPaper({ children }) {
  return (
    <div className="mx-auto" style={{
      maxWidth: 720,
      background: P5_PAPER_BG,
      padding: "56px 60px 64px",
      boxShadow: "0 1px 3px rgba(0,0,0,0.03), 0 12px 36px rgba(0,0,0,0.08)",
      borderRadius: 4,
      fontFamily: "'Source Serif Pro', Georgia, 'Times New Roman', serif",
      color: "#1A1A1A",
      lineHeight: 1.55
    }}>
      {children}
    </div>
  );
}

/* ============================================================
   CONSENT ORDER DOCUMENT
   ============================================================ */
function ConsentOrder() {
  let n = 0;
  return (
    <LegalPaper>
      <div style={{ textAlign: "left", fontSize: 12, letterSpacing: "0.06em", textTransform: "uppercase", fontWeight: 700 }}>
        IN THE FAMILY COURT<br/>
        AT EXETER
      </div>
      <div style={{ textAlign: "right", fontSize: 12, marginTop: -28, color: "#444" }}>
        Case No: {F.caseNo}
      </div>

      <div style={{ marginTop: 40, fontSize: 12, letterSpacing: "0.04em" }}>
        <div style={{ fontWeight: 700, textTransform: "uppercase" }}>BETWEEN:</div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8 }}>
          <span style={{ fontWeight: 700 }}>{F.applicant}</span>
          <span style={{ fontStyle: "italic" }}>Applicant</span>
        </div>
        <div style={{ textAlign: "center", margin: "6px 0", fontStyle: "italic" }}>and</div>
        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <span style={{ fontWeight: 700 }}>{F.respondent}</span>
          <span style={{ fontStyle: "italic" }}>Respondent</span>
        </div>
      </div>

      <div style={{ borderTop: "1px solid #C8C3B4", margin: "28px 0 24px" }}/>
      <h1 style={{ textAlign: "center", fontSize: 22, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", margin: 0 }}>
        Consent Order
      </h1>
      <div style={{ borderBottom: "1px solid #C8C3B4", margin: "24px 0 28px" }}/>

      <p style={{ fontSize: 13.5 }}>
        <span style={{ fontWeight: 700 }}>UPON</span> the parties having reached agreement on financial matters following their separation, recorded in this order and in the attached Statement of Information (Form D81)
      </p>
      <p style={{ fontSize: 13.5 }}>
        <span style={{ fontWeight: 700 }}>AND UPON</span> the parties having had the opportunity to take independent legal advice
      </p>
      <p style={{ fontSize: 13.5, marginTop: 20 }}>
        <span style={{ fontWeight: 700 }}>IT IS ORDERED BY CONSENT THAT:</span>
      </p>

      {CLAUSES.map((group) => (
        <div key={group.group} style={{ marginTop: 26 }}>
          <div style={{ fontSize: 12.5, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 12 }}>
            {group.group}
          </div>
          {group.items.map((it, i) => {
            n += 1;
            return (
              <div key={i} style={{ display: "flex", gap: 14, marginBottom: 12, fontSize: 13.5 }}>
                <span style={{ width: 24, flexShrink: 0, fontWeight: 600 }}>{n}.</span>
                <span>{it}</span>
              </div>
            );
          })}
        </div>
      ))}

      {/* Signature block */}
      <div style={{ marginTop: 44, fontSize: 13 }}>
        <div style={{ display: "flex", gap: 32, marginBottom: 24 }}>
          <div style={{ flex: 1 }}>
            <div style={{ borderBottom: "1px solid #444", height: 26 }}/>
            <div style={{ marginTop: 4 }}>Sarah Johnson · Applicant</div>
            <div style={{ color: "#666", fontSize: 12 }}>Dated: 14 May 2026</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ borderBottom: "1px solid #444", height: 26 }}/>
            <div style={{ marginTop: 4 }}>Mark Johnson · Respondent</div>
            <div style={{ color: "#666", fontSize: 12 }}>Dated: 14 May 2026</div>
          </div>
        </div>
      </div>
    </LegalPaper>
  );
}

/* ============================================================
   D81 STATEMENT OF INFORMATION
   ============================================================ */
function D81() {
  return (
    <LegalPaper>
      <div style={{ fontSize: 12, letterSpacing: "0.06em", textTransform: "uppercase", fontWeight: 700 }}>
        Form D81 · Statement of Information for a Consent Order
      </div>
      <div style={{ borderTop: "1px solid #C8C3B4", margin: "20px 0" }}/>

      <div style={{ fontSize: 13.5 }}>
        <p><span style={{ fontWeight: 700 }}>Court:</span> {F.caseCourt}</p>
        <p><span style={{ fontWeight: 700 }}>Case no:</span> {F.caseNo}</p>
        <p><span style={{ fontWeight: 700 }}>Applicant:</span> {F.applicant}</p>
        <p><span style={{ fontWeight: 700 }}>Respondent:</span> {F.respondent}</p>
      </div>

      <h3 style={{ fontSize: 14, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", marginTop: 28 }}>
        Section 1 — Status of the parties
      </h3>
      <p style={{ fontSize: 13.5 }}>
        Married 12 years. Separated since March 2025. Two children of the family, aged 10 and 8, living primarily with the Applicant. Both parties employed: Applicant (NHS, part-time, £32,000 gross); Respondent (engineering, full-time, £62,000 gross).
      </p>

      <h3 style={{ fontSize: 14, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", marginTop: 22 }}>
        Section 2 — Assets in brief
      </h3>
      <p style={{ fontSize: 13.5 }}>
        Family home (£230,000 net equity) · NHS pension CETV £180,412 · Joint savings £14,800 · Two vehicles with outstanding finance · Individual ISAs totalling £22,300 · No significant debts outside mortgage.
      </p>

      <h3 style={{ fontSize: 14, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase", marginTop: 22 }}>
        Section 10 — Reasons for the agreement
        <span style={{ fontSize: 11, fontWeight: 500, textTransform: "none", letterSpacing: 0, color: "#666", marginLeft: 8 }}>
          (compiled from your negotiation reasoning trail · 412 words)
        </span>
      </h3>
      {D81S10.map((para, i) => (
        <p key={i} style={{ fontSize: 13.5, marginTop: 12 }}>{para}</p>
      ))}

      <div style={{ marginTop: 44, fontSize: 13 }}>
        <div style={{ display: "flex", gap: 32 }}>
          <div style={{ flex: 1 }}>
            <div style={{ borderBottom: "1px solid #444", height: 26 }}/>
            <div style={{ marginTop: 4 }}>Applicant · Statement of truth</div>
            <div style={{ color: "#666", fontSize: 12 }}>Signed 14 May 2026</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ borderBottom: "1px solid #444", height: 26 }}/>
            <div style={{ marginTop: 4 }}>Respondent · Statement of truth</div>
            <div style={{ color: "#666", fontSize: 12 }}>Signed 14 May 2026</div>
          </div>
        </div>
      </div>
    </LegalPaper>
  );
}

/* ============================================================
   FORM P — Pension sharing annex
   ============================================================ */
function FormP() {
  return (
    <LegalPaper>
      <div style={{ fontSize: 12, letterSpacing: "0.06em", textTransform: "uppercase", fontWeight: 700 }}>
        Form P · Pension Sharing Annex
      </div>
      <div style={{ borderTop: "1px solid #C8C3B4", margin: "20px 0" }}/>

      <p style={{ fontSize: 13.5 }}>
        This annex accompanies the consent order dated 14 May 2026 in the Family Court at Exeter.
      </p>

      <div style={{ marginTop: 24, fontSize: 13.5 }}>
        {[
          ["Transferor (party with the pension)", F.applicant],
          ["Transferee (party receiving the share)", F.respondent],
          ["Scheme name", "NHS Pension Scheme (England & Wales)"],
          ["Scheme reference", "NHSPS-GBR · member no. [to be completed]"],
          ["CETV at date of order", `£${F.cetv.toLocaleString()}`],
          ["Valuation date", "14 May 2026"],
          ["Percentage to be shared", `${F.pensionPct}%`],
          ["Transfer value (approx.)", `£${F.pensionShare.toLocaleString()}`],
          ["Implementation period", "Four months from the date the order is sealed"]
        ].map(([k, v]) => (
          <div key={k} style={{ display: "flex", padding: "10px 0", borderBottom: "1px solid #E4DFCF" }}>
            <div style={{ width: 280, color: "#555" }}>{k}</div>
            <div style={{ flex: 1, fontWeight: 600 }}>{v}</div>
          </div>
        ))}
      </div>

      <p style={{ fontSize: 12.5, color: "#555", marginTop: 28 }}>
        The pension provider shall implement this pension sharing order in accordance with the
        Welfare Reform and Pensions Act 1999 and the Pensions on Divorce etc. (Provision of Information) Regulations 2000.
      </p>
    </LegalPaper>
  );
}

/* ============================================================
   PLAIN SETTLEMENT SUMMARY (this one is sans-serif — it's for the user)
   ============================================================ */
function SettlementSummary() {
  const rows = [
    ["Family home", "Sell, 50/50 split of net proceeds", "£115,000 each"],
    ["Pensions", "20% of NHS CETV to Mark", `£${F.pensionShare.toLocaleString()}`],
    ["Savings & accounts", "Each keeps own", "—"],
    ["Vehicles", "Each keeps own (with finance)", "—"],
    ["Debts", "Each responsible for own", "—"],
    ["Children", "Primary with Sarah · EOW + midweek for Mark · CMS £576/mo", "—"],
    ["Spousal maintenance", "Mark pays £400/mo for 24 months, non-extendable", "£9,600 total"]
  ];
  return (
    <div className="mx-auto" style={{
      maxWidth: 720,
      background: "#FFF",
      padding: "44px 52px 52px",
      boxShadow: "0 1px 3px rgba(0,0,0,0.03), 0 12px 36px rgba(0,0,0,0.08)",
      borderRadius: 4
    }}>
      <div className="label-xs" style={{ color: T.MUTE }}>For your records · plain-language summary</div>
      <h1 style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-0.02em", marginTop: 6 }}>
        Our settlement
      </h1>
      <p style={{ fontSize: 14, color: T.SUB, marginTop: 8, lineHeight: 1.6 }}>
        This is how we've agreed to divide things. The consent order is the legal version of the same terms; this is a plain-language summary for you to keep.
      </p>

      <div style={{ marginTop: 28 }}>
        {rows.map(([section, decision, money]) => (
          <div key={section} style={{ display: "grid", gridTemplateColumns: "160px 1fr 140px", gap: 16, padding: "14px 0", borderBottom: `1px solid ${T.HAIR}`, fontSize: 13.5 }}>
            <div style={{ fontWeight: 600 }}>{section}</div>
            <div style={{ color: T.SUB }}>{decision}</div>
            <div className="tabular-nums text-right" style={{ color: T.INK }}>{money}</div>
          </div>
        ))}
      </div>

      <div className="label-xs mt-8" style={{ color: T.MUTE }}>Why we settled this way</div>
      <p style={{ fontSize: 13, color: T.SUB, marginTop: 6, lineHeight: 1.6 }}>
        We used Decouple to work through three rounds of proposals. On property, vehicles, savings, debts and children we agreed at the first round. On pension sharing we closed from 0% (Sarah's opening) and 30% (Mark's opening) to 20%, reflecting primary-carer impact on future earnings. On spousal maintenance we agreed £400/mo for 24 months to allow Sarah's career rebuild while retaining a clean break.
      </p>
    </div>
  );
}

/* ============================================================
   PAGE
   ============================================================ */
const TABS = [
  { id: "consent",  label: "Consent order",    Comp: ConsentOrder },
  { id: "d81",      label: "D81 + Section 10", Comp: D81 },
  { id: "formp",    label: "Pension annex",    Comp: FormP },
  { id: "summary",  label: "Settlement summary", Comp: SettlementSummary }
];

function App() {
  const [tab, setTab] = useState(() => {
    try { return localStorage.getItem("p5_preview_tab") || "consent"; } catch { return "consent"; }
  });
  const setTabPersist = (t) => { setTab(t); try { localStorage.setItem("p5_preview_tab", t); } catch {} };
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => ({ ...t, [id]: value }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
  };
  const Active = TABS.find(t => t.id === tab).Comp;

  const topRight = (
    <div className="flex items-center gap-2">
      <button className="h-8 px-3 rounded-md inline-flex items-center gap-1.5 whitespace-nowrap" style={{ border: `1px solid ${T.HAIR}`, background: "#FFF", fontSize: 12.5, fontWeight: 500 }}>
        <I5.Print size={13}/> Print
      </button>
      <button className="h-8 px-3 rounded-md inline-flex items-center gap-1.5 whitespace-nowrap" style={{ border: `1px solid ${T.HAIR}`, background: "#FFF", fontSize: 12.5, fontWeight: 500 }}>
        <I5.Download size={13}/> Download PDF
      </button>
      <P4_Avatar who="S" size={28}/>
    </div>
  );

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar
        viewMeta={{ phase: "Phase 5", title: "Consent order · generated from v5.0", version: "v5.0", statusLabel: "READY TO FILE", statusKind: "agreed" }}
        right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={P5_SECTION_STATUS}
                        title="Generated documents"
                        subtitle="All 7 sections covered"
                        pct={100}
                        currentRoute="fin-preview"
                        showInlineRouter={tweaks.router === "inline"}/>

        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: T.BG }}>
          {/* tab bar */}
          <div className="sticky top-0 z-10" style={{ background: T.BG, borderBottom: `1px solid ${T.HAIR}`, padding: "14px 0 0" }}>
            <div className="max-w-[880px] mx-auto px-8">
              <div className="flex gap-1">
                {TABS.map(tb => {
                  const active = tb.id === tab;
                  return (
                    <button key={tb.id} onClick={() => setTabPersist(tb.id)}
                            className="px-3.5 py-2 whitespace-nowrap"
                            style={{
                              fontSize: 12.5, fontWeight: active ? 600 : 500,
                              color: active ? T.INK : T.SUB,
                              borderBottom: `2px solid ${active ? T.INK : "transparent"}`,
                              background: "transparent"
                            }}>
                      {tb.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="py-10 px-8">
            <Active/>

            {/* action banner */}
            <div className="mx-auto mt-8 rounded-xl p-4 flex items-center gap-4" style={{
              maxWidth: 720, background: "#FFF", border: `1px solid ${T.HAIR}`
            }}>
              <div className="flex-1">
                <div style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.4 }}>
                  This is your {TABS.find(t => t.id === tab).label.toLowerCase()}, generated from your agreement.
                </div>
                <div style={{ fontSize: 12, color: T.SUB, marginTop: 2, lineHeight: 1.5 }}>
                  Review it carefully. You can edit wording (subject to validation) or run a pre-flight check.
                </div>
              </div>
              <button className="h-9 px-3 rounded-md inline-flex items-center gap-1.5 whitespace-nowrap"
                      style={{ border: `1px solid ${T.HAIR}`, background: "#FFF", fontSize: 12.5, fontWeight: 500 }}>
                <I5.Edit size={12.5}/> Edit wording
              </button>
              <a href="Settlement - Pre-flight.html"
                 className="h-9 px-4 rounded-md inline-flex items-center gap-1.5 whitespace-nowrap"
                 style={{ background: T.INK, color: "#FFF", fontSize: 12.5, fontWeight: 600, textDecoration: "none" }}>
                Looks good — pre-flight check <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>
              </a>
            </div>

            <p className="mx-auto mt-4 text-center" style={{ maxWidth: 720, fontSize: 11.5, color: T.MUTE, lineHeight: 1.55 }}>
              These documents use court-approved legal templates, compiled from your structured agreement. Your pre-flight check validates against common rejection reasons. For reassurance you can request a fixed-fee professional review before submission — or submit directly if you're confident.
            </p>
          </div>
        </div>

        {tweaks.router !== "inline" && <P4_FloatingRouter current="fin-preview"/>}
      </div>
      <P4_TweakPanel
        title="Preview"
        options={[
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "router": "inline"
}/*EDITMODE-END*/;

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
