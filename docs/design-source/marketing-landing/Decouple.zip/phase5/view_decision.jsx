/* Phase 5 · View D — Review decision */
(function(){
const { useState } = React;
const { P4_TOK: T, P4_Avatar, P4_TopBar, P4_ChapterRail, P4_FloatingRouter, P4_TweakPanel,
        P5_Ic: I5, P5_SECTION_STATUS, P5_GREEN } = window;

function OptionCard({ title, price, lead, body, bullets, cta, featured, href }) {
  return (
    <div className="rounded-xl p-5 flex flex-col"
         style={{ background: "#FFF", border: featured ? `2px solid ${T.INK}` : `1px solid ${T.HAIR}`, position: "relative" }}>
      {featured && (
        <div className="absolute -top-2.5 left-4 px-2 py-0.5 rounded whitespace-nowrap"
             style={{ background: T.INK, color: "#FFF", fontSize: 10.5, fontWeight: 700, letterSpacing: "0.06em", textTransform: "uppercase" }}>
          Recommended
        </div>
      )}
      <div style={{ fontSize: 15, fontWeight: 600 }}>{title}</div>
      <div style={{ fontSize: 22, fontWeight: 600, marginTop: 6, letterSpacing: "-0.01em" }}>{price}</div>
      <div className="label-xs mt-1" style={{ color: T.MUTE }}>{lead}</div>
      <div className="mt-3" style={{ fontSize: 13, color: T.SUB, lineHeight: 1.55 }}>{body}</div>
      <ul className="mt-3 space-y-1.5" style={{ fontSize: 12.5, color: T.INK }}>
        {bullets.map((b, i) => (
          <li key={i} className="flex gap-2">
            <I5.Check size={12} stroke={P5_GREEN} strokeWidth={3}/>
            <span style={{ lineHeight: 1.5 }}>{b}</span>
          </li>
        ))}
      </ul>
      <div className="mt-auto pt-5">
        <a href={href} className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md whitespace-nowrap w-full justify-center"
           style={{ background: featured ? T.INK : "#FFF", color: featured ? "#FFF" : T.INK, border: featured ? "none" : `1px solid ${T.HAIR}`, fontSize: 13, fontWeight: 600, textDecoration: "none" }}>
          {cta}
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={featured ? "#FFF" : T.INK} strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>
        </a>
      </div>
    </div>
  );
}

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => ({ ...t, [id]: value }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
  };

  const topRight = <P4_Avatar who="S" size={28}/>;

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar viewMeta={{ phase: "Phase 5", title: "Review decision · optional professional check", version: "v5.0", statusLabel: "AGREED", statusKind: "agreed" }} right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={P5_SECTION_STATUS}
                        title="Review decision"
                        subtitle="Choose your submission path"
                        pct={100}
                        currentRoute="fin-decision"
                        showInlineRouter={tweaks.router === "inline"}/>

        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[960px] mx-auto px-8 py-10 pb-40">
            <div className="label-xs mb-1.5" style={{ color: T.MUTE }}>Phase 5 · Decision</div>
            <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
              Do you want a solicitor to review before submitting?
            </h1>
            <p className="mt-3 max-w-[620px]" style={{ fontSize: 14, color: T.SUB, lineHeight: 1.55 }}>
              Your documents passed our quality checks. Many couples submit directly from here. Others prefer the reassurance of a professional eye — especially on pensions or complex arrangements. Both are valid.
            </p>

            <div className="grid grid-cols-3 gap-4 mt-7">
              <OptionCard
                title="Submit directly"
                price="£0"
                lead="You do it yourself"
                body="Appropriate when your case is straightforward, both parties fully understand what they're signing, and pre-flight is clean."
                bullets={["No extra cost", "Submit today", "Court fee £53 applies"]}
                cta="Continue to submission"
                href="Settlement - Submit.html"/>
              <OptionCard
                title="Pensions-only review"
                price="£250"
                lead="Fixed fee · pensions expert"
                body="A pensions actuary reviews your sharing order for fairness and CETV arithmetic. Recommended if either pension is over £100k."
                bullets={["PSO & annex review", "48-hour turnaround", "Changes included"]}
                cta="Request pensions review"
                href="Settlement - Submit.html"
                featured/>
              <OptionCard
                title="Full document review"
                price="£450"
                lead="Fixed fee · family solicitor"
                body="A family law solicitor reviews all documents, flags risks, and confirms compliance. Best if your estate includes a business, trust, or overseas assets."
                bullets={["All documents reviewed", "Written advice", "72-hour turnaround"]}
                cta="Request full review"
                href="Settlement - Submit.html"/>
            </div>

            <div className="mt-7 rounded-xl p-4 flex items-start gap-3"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
              <I5.Info size={14} stroke={T.MUTE} strokeWidth={2}/>
              <div style={{ fontSize: 12.5, color: T.SUB, lineHeight: 1.55 }}>
                <strong style={{ color: T.INK }}>What courts look for.</strong> Judges approve consent orders when settlements look fair and both parties understood what they signed. Professional review doesn't change the legal effect — it's insurance, not necessity.
              </div>
            </div>
          </div>
        </div>

        {tweaks.router !== "inline" && <P4_FloatingRouter current="fin-decision"/>}
      </div>
      <P4_TweakPanel
        title="Decision"
        options={[
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{"router": "inline"}/*EDITMODE-END*/;

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
