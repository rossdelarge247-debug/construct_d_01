/* Phase 5 — Finalise: shared data
   Agreed settlement (v5.0), generated document content, pre-flight checks,
   reviewer marketplace, submission status.
*/
(function(){

const FACTS = {
  caseCourt: "Family Court at Exeter",
  caseNo: "— (to be assigned)",
  applicant: "SARAH ELIZABETH JOHNSON",
  respondent: "MARK DAVID JOHNSON",
  propertyAddress: "12 Oak Road, Exeter EX1 2AB",
  propertyNet: 230000,
  mortgageLender: "Halifax",
  cetv: 180412,
  pensionPct: 20,
  pensionShare: 36082,
  cms: 576,
  spousalMonthly: 400,
  spousalMonths: 24,
  courtFee: 593,
  filedOn: "16 May 2026 · 14:32",
  sealedOn: "28 June 2026"
};

/* ============================================================
   DOCUMENT LIST (View A)
   ============================================================ */
const DOCS = [
  {
    id: "consent",
    title: "Consent order",
    body: "The legal settlement between you and Mark. Once sealed by a judge, it becomes binding on both of you.",
    required: true,
    status: "ready"
  },
  {
    id: "d81",
    title: "D81 Statement of Information",
    body: "The form the judge reads alongside the consent order. Includes the Section 10 narrative — we'll compile that from your proposal reasoning across all three rounds.",
    required: true,
    status: "ready"
  },
  {
    id: "formp",
    title: "Pension sharing annex (Form P)",
    body: "Required because your settlement includes a pension sharing order. The pension provider will need this.",
    required: true,
    status: "ready"
  },
  {
    id: "summary",
    title: "Settlement summary (PDF)",
    body: "A plain-language summary for your own records. Includes all reasoning from your negotiation.",
    required: true,
    status: "ready"
  },
  {
    id: "children",
    title: "Statement of arrangements (children)",
    body: "Some courts want a separate document for children arrangements. Optional for you — your consent order already covers the key points.",
    required: false,
    status: "optional"
  }
];

/* ============================================================
   GENERATED DOCUMENT CONTENT (View B)
   Consent order clauses — shaped so the view can render them
   as numbered legal text with header groups.
   ============================================================ */
const CONSENT_CLAUSES = [
  { group: "THE FAMILY HOME", items: [
    "The property known as 12 Oak Road, Exeter EX1 2AB (the \"Property\") shall be placed on the market for sale by [date 4 weeks from sealing] at a price to be agreed between the parties following consultation with three estate agents.",
    "Upon completion of the sale of the Property, the net proceeds of sale (after discharge of the mortgage with Halifax, estate agent fees, and legal fees of sale) shall be divided equally between the parties."
  ]},
  { group: "PENSIONS", items: [
    "There shall be a pension sharing order in respect of the Applicant's pension held with NHS Pensions scheme (the \"NHS Pension\") in favour of the Respondent.",
    "The percentage to be shared is twenty per cent (20%) of the cash equivalent transfer value of £180,412 at the date of this order, giving a transfer value of approximately £36,082 to be implemented by the pension provider in accordance with the attached Form P."
  ]},
  { group: "SAVINGS AND ACCOUNTS", items: [
    "Each party shall retain the bank accounts, savings, and investments held in their sole name."
  ]},
  { group: "VEHICLES", items: [
    "The Applicant shall retain the 2019 Volkswagen Golf registered in her name, together with any outstanding finance on the said vehicle.",
    "The Respondent shall retain the 2020 Ford Focus registered in his name, together with any outstanding finance on the said vehicle."
  ]},
  { group: "DEBTS AND LIABILITIES", items: [
    "Each party shall be responsible for and shall indemnify the other against any debts and liabilities in their sole name."
  ]},
  { group: "CHILDREN", items: [
    "The children of the family, Emily Johnson (aged 10) and Thomas Johnson (aged 8), shall continue to live with the Applicant.",
    "The Respondent shall have contact with the children on alternate weekends from Friday after school to Sunday evening, and one midweek evening each week, with school holidays to be divided equally by agreement.",
    "The Respondent shall pay to the Applicant child maintenance of £576 per calendar month pursuant to the Child Maintenance Service calculation, payable on the first day of each month by standing order."
  ]},
  { group: "SPOUSAL MAINTENANCE", items: [
    "The Respondent shall pay to the Applicant periodical payments at the rate of £400 per calendar month for a term of 24 months from the date of sealing of this order, such term to be non-extendable pursuant to section 28(1A) of the Matrimonial Causes Act 1973.",
    "Upon expiry of the term, the Applicant's claim for periodical payments shall stand dismissed."
  ]},
  { group: "DISMISSAL OF CLAIMS", items: [
    "Save as set out above, all claims of either party against the other for financial remedies, including maintenance pending suit, lump sum, property adjustment, pension sharing (save as ordered above), and in respect of each other's estates, are dismissed.",
    "There shall be no order as to costs."
  ]}
];

/* ============================================================
   D81 SECTION 10 NARRATIVE (compiled from negotiation reasoning)
   ============================================================ */
const D81_SECTION10 = [
  "The parties were married for twelve years and have two children aged 10 and 8, who live primarily with the Applicant. The Respondent has agreed contact arrangements including alternate weekends and a midweek evening, with school holidays divided equally.",
  "The family home has agreed equity of approximately £230,000. The parties agreed an equal 50/50 division of the net sale proceeds, reflecting the equal contributions over the duration of the marriage and the fact that neither party proposed to retain the property.",
  "The Applicant's NHS pension has a cash equivalent transfer value of £180,412. After three rounds of negotiation the parties agreed a 20% pension share (£36,082) to the Respondent. The Respondent initially sought a 30% share; the Applicant opened at 0%. The agreed figure reflects a midpoint adjusted for the Applicant's role as primary carer and the lower disposable income that implies over the next eight years.",
  "Each party retains their own savings, bank accounts, vehicles (with associated finance), and is responsible for debts in their sole name. These positions were consistent across both parties' opening proposals and required no negotiation.",
  "Periodical payments of £400 per month for a non-extendable term of 24 months are included to reflect the income disparity during the period the Applicant will be rebuilding her career following reduced hours during the marriage. The term is limited to allow a clean break once that rebuilding period has concluded, as agreed by both parties.",
  "The Applicant and Respondent used Decouple, a structured disclosure and negotiation tool, to reach this agreement. Both parties have had the opportunity to take independent legal advice. Both parties consider the agreement fair and are willing to be bound by it."
];

/* ============================================================
   PRE-FLIGHT CHECKS (View C)
   ============================================================ */
const CHECKS = [
  {
    id: "clauses",
    title: "All required clauses present",
    body: "Property, pension, maintenance, dismissal of claims, and costs all included in the order.",
    detail: "We checked for 8 standard clauses a consent order must contain. All 8 are present with correct legal wording.",
    pass: true
  },
  {
    id: "cleanbreak",
    title: "Clean break wording correctly applied",
    body: "Clause 18 dismisses all future claims except the ordered pension share and spousal maintenance.",
    detail: "The dismissal language uses the standard MCA 1973 form. Spousal maintenance is explicitly non-extendable under s.28(1A). This prevents future claims between the parties.",
    pass: true
  },
  {
    id: "pso",
    title: "Pension sharing order formatted per WRPA 1999",
    body: "Percentage, scheme name, and CETV valuation date are all present. Form P annex attached.",
    detail: "The PSO states the scheme (NHS Pensions), the share (20%), the CETV (£180,412) at the date of the order, and the approximate transfer value (£36,082). Form P has been prepopulated and is ready for the pension provider.",
    pass: true
  },
  {
    id: "d81",
    title: "D81 Section 10 completed",
    body: "Narrative compiled from your proposal reasoning across 3 rounds. This is the #1 reason courts reject consent orders — yours is comprehensive.",
    detail: "Your Section 10 is 412 words and explains: the duration of the marriage, the children's living arrangements, the reasoning behind the 50/50 property split, the derivation of the 20% pension share, the rationale for time-limited spousal maintenance, and each party's opportunity to take legal advice.",
    pass: true
  },
  {
    id: "sot",
    title: "Both parties' statements of truth included",
    body: "Both Sarah and Mark have signed statements of truth. The D81 includes both signature blocks.",
    detail: "Statements of truth are required under FPR Part 17. Both parties signed on 14 May 2026 via the Decouple digital signature flow.",
    pass: true
  },
  {
    id: "fairness",
    title: "Fairness check — within typical range",
    body: "Overall split is 52% / 48%. For a 12-year marriage with primary care and a 1:2 income disparity, courts typically approve 50%–65% favouring the primary carer. You're within range.",
    detail: "Based on published consent order data, judges in the Family Court rarely reject settlements that fall within the typical range for similar circumstances. The 52/48 split is close to equal and will not raise concerns.",
    pass: true
  },
  {
    id: "unusual",
    title: "No unusual terms flagged",
    body: "No non-standard clauses, unusual indemnities, or ambiguous wording detected.",
    detail: "We scanned the order against a corpus of common consent order templates. No clauses deviate from standard legal forms.",
    pass: true
  },
  {
    id: "fee",
    title: "Court fee calculated",
    body: "£593 payable at submission. This is the current fee for a consent order under the financial remedies procedure.",
    detail: "Fee per Family Proceedings Fees Order. Payable by card at submission via MyHMCTS.",
    pass: true
  }
];

/* ============================================================
   REVIEWER MARKETPLACE (View D)
   ============================================================ */
const REVIEWERS = [
  {
    id: "mary",
    name: "Mary Thompson",
    credentials: "Family law specialist · 18 years",
    accreditation: "Resolution accredited · Exeter",
    rating: 4.9,
    reviews: 47,
    price: 250,
    initials: "MT",
    avatarColor: "#8B5CF6"
  },
  {
    id: "ahmed",
    name: "Ahmed Khan",
    credentials: "Family + pensions specialist · 22 years",
    accreditation: "Resolution accredited · Remote",
    rating: 5.0,
    reviews: 82,
    price: 350,
    initials: "AK",
    avatarColor: "#0EA5E9"
  },
  {
    id: "emma",
    name: "Emma Walsh",
    credentials: "Family + tax specialist · 15 years",
    accreditation: "Law Society accredited · London",
    rating: 4.8,
    reviews: 31,
    price: 400,
    initials: "EW",
    avatarColor: "#F97316"
  }
];

/* ============================================================
   SUBMISSION STATUSES (View E)
   ============================================================ */
const STATUS_STEPS = [
  { id: "submit", label: "Submitted",      when: "16 May" },
  { id: "judge",  label: "With the judge", when: "17 May — in progress" },
  { id: "sealed", label: "Sealed",         when: "expected 24 Jun – 21 Jul" }
];

/* ============================================================
   P5 SECTION STATUS (for left rail — all agreed after v5.0)
   ============================================================ */
const SECTION_STATUS = {
  home: "agreed", pensions: "agreed", savings: "agreed",
  vehicles: "agreed", debts: "agreed", children: "agreed",
  spousal: "agreed"
};

Object.assign(window, {
  P5_FACTS: FACTS,
  P5_DOCS: DOCS,
  P5_CONSENT_CLAUSES: CONSENT_CLAUSES,
  P5_D81_SECTION10: D81_SECTION10,
  P5_CHECKS: CHECKS,
  P5_REVIEWERS: REVIEWERS,
  P5_STATUS_STEPS: STATUS_STEPS,
  P5_SECTION_STATUS: SECTION_STATUS
});
})();
