/* Phase 5 · View C — Pre-flight quality check */
(function(){
const { useState } = React;
const { P4_TOK: T, P4_Avatar, P4_TopBar, P4_ChapterRail, P4_FloatingRouter, P4_TweakPanel,
        P5_Ic: I5, P5_CHECKS, P5_SECTION_STATUS, P5_GREEN } = window;

function CheckRow({ check, failFlag }) {
  const [open, setOpen] = useState(false);
  const failed = failFlag === check.id;
  const tintBg = failed ? "#FEF3C7" : "transparent";
  const iconBg = failed ? "#F59E0B" : P5_GREEN;
  return (
    <div style={{ background: tintBg, borderRadius: 8 }}>
      <button onClick={() => setOpen(o => !o)}
              className="w-full text-left flex items-start gap-3 py-3 px-2 transition"
              style={{ background: "transparent" }}>
        <span className="flex items-center justify-center rounded-full flex-shrink-0"
              style={{ width: 22, height: 22, background: iconBg, marginTop: 1 }}>
          {failed ? <I5.Warn size={12} stroke="#FFF" strokeWidth={2.5}/> : <I5.Check size={12} stroke="#FFF" strokeWidth={3}/>}
        </span>
        <div className="flex-1 min-w-0">
          <div style={{ fontSize: 13.5, fontWeight: 600 }}>
            {failed ? "D81 Section 10 is brief" : check.title}
          </div>
          <div style={{ fontSize: 12.5, color: T.SUB, marginTop: 2, lineHeight: 1.5 }}>
            {failed ? "Your Section 10 is 180 words. Courts typically prefer 300+ words explaining the rationale for the settlement." : check.body}
          </div>
          {open && (
            <div className="mt-2 rounded-md px-3 py-2.5"
                 style={{ background: "#FAFAF7", border: `1px solid ${T.HAIR}`, fontSize: 12.5, color: T.SUB, lineHeight: 1.6 }}>
              <div className="label-xs mb-1" style={{ color: T.MUTE }}>What we checked</div>
              {check.detail}
              {failed && (
                <div className="mt-3">
                  <button className="inline-flex items-center gap-1.5 h-7 px-3 rounded-md" style={{ background: T.INK, color: "#FFF", fontSize: 11.5, fontWeight: 600 }}>
                    Expand Section 10 <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={T.MUTE} strokeWidth="2"
             style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform 180ms", marginTop: 4 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>
    </div>
  );
}

function App() {
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => ({ ...t, [id]: value }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
  };

  const failFlag = tweaks.state === "one_warning" ? "d81" : null;
  const passed = P5_CHECKS.filter(c => !(failFlag && failFlag === c.id)).length;

  const topRight = (
    <div className="flex items-center gap-2">
      <button className="h-8 px-3 rounded-md inline-flex items-center gap-1.5 whitespace-nowrap" style={{ border: `1px solid ${T.HAIR}`, background: "#FFF", fontSize: 12.5 }}>
        <I5.Print size={13}/> Print report
      </button>
      <P4_Avatar who="S" size={28}/>
    </div>
  );

  const allPass = !failFlag;

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar viewMeta={{ phase: "Phase 5", title: `Quality check · v5.0 · ${allPass ? "passed" : "1 warning"}`, version: "v5.0", statusLabel: allPass ? "PASSED" : "REVIEW", statusKind: allPass ? "agreed" : "pending" }} right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={P5_SECTION_STATUS}
                        title="Pre-flight check"
                        subtitle={`${passed} of ${P5_CHECKS.length} checks passed`}
                        pct={Math.round(passed / P5_CHECKS.length * 100)}
                        currentRoute="fin-preflight"
                        showInlineRouter={tweaks.router === "inline"}/>

        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[760px] mx-auto px-8 py-10 pb-40">
            <div className="label-xs mb-1.5" style={{ color: P5_GREEN }}>Phase 5 · Pre-flight</div>
            <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
              Pre-flight quality check
            </h1>
            <p className="mt-3" style={{ fontSize: 14, color: T.SUB, lineHeight: 1.55 }}>
              We've validated your documents against the most common reasons courts reject consent orders. Here's what we found.
            </p>

            <div className="mt-7 rounded-xl pl-4 pr-3 py-2"
                 style={{ background: "#FFF", border: `1px solid ${T.HAIR}`, borderLeft: `2px solid ${allPass ? P5_GREEN : "#F59E0B"}` }}>
              {P5_CHECKS.map(c => (
                <div key={c.id} style={{ borderBottom: `1px solid ${T.HAIR}` }}>
                  <CheckRow check={c} failFlag={failFlag}/>
                </div>
              )).slice(0, -1).concat(
                <div key="last"><CheckRow check={P5_CHECKS[P5_CHECKS.length - 1]} failFlag={failFlag}/></div>
              )}
            </div>

            <div className="mt-6 rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
              <div className="flex items-center justify-between gap-4 mb-3">
                <div>
                  <div className="label-xs mb-1" style={{ color: T.MUTE }}>Results</div>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>
                    {allPass
                      ? `${passed} of ${P5_CHECKS.length} checks passed. No issues found.`
                      : `${passed} passed · 1 advisory. You can still submit — or address the warning first.`}
                  </div>
                </div>
                <span className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md whitespace-nowrap"
                      style={{ background: allPass ? "#E8F4EF" : "#FEF3C7", color: allPass ? P5_GREEN : "#92400E", fontSize: 11.5, fontWeight: 700, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  <I5.Shield size={11}/> {allPass ? "All clear" : "Advisory"}
                </span>
              </div>

              <div style={{ fontSize: 13, color: T.SUB, lineHeight: 1.55 }}>
                Your documents are ready. Before submitting, you have two choices:
              </div>
              <div className="mt-4 flex flex-wrap gap-3">
                <a href="Settlement - Submit.html" className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md whitespace-nowrap"
                   style={{ background: T.INK, color: "#FFF", fontSize: 13, fontWeight: 600, textDecoration: "none" }}>
                  Submit directly to court
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#FFF" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>
                </a>
                <a href="Settlement - Decision.html" className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md whitespace-nowrap"
                   style={{ background: "#FFF", color: T.INK, border: `1px solid ${T.HAIR}`, fontSize: 13, fontWeight: 600, textDecoration: "none" }}>
                  Get a solicitor to review first — from £250
                </a>
              </div>
              <p className="mt-3" style={{ fontSize: 11.5, color: T.MUTE, lineHeight: 1.5 }}>
                Direct submission is legal and appropriate for the standard case. Professional review adds reassurance at a fixed fee. Either is a good choice.
              </p>
            </div>
          </div>
        </div>

        {tweaks.router !== "inline" && <P4_FloatingRouter current="fin-preflight"/>}
      </div>
      <P4_TweakPanel
        title="Pre-flight"
        options={[
          { id: "state", label: "State", variants: [
            { value: "all_pass",    label: "All checks pass",  sub: "Default — 8 of 8 green" },
            { value: "one_warning", label: "One advisory",     sub: "D81 Section 10 brief" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "state": "all_pass",
  "router": "inline"
}/*EDITMODE-END*/;

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
