/* Phase 5 · View E — Submit to court */
(function(){
const { useState } = React;
const { P4_TOK: T, P4_Avatar, P4_TopBar, P4_ChapterRail, P4_FloatingRouter, P4_TweakPanel,
        P5_Ic: I5, P5_SECTION_STATUS, P5_GREEN, P5_DOCS } = window;

function ChecklistItem({ checked, setChecked, label, body }) {
  return (
    <label className="flex items-start gap-3 py-3 cursor-pointer" style={{ borderBottom: `1px solid ${T.HAIR}` }}>
      <span className="inline-flex items-center justify-center flex-shrink-0 rounded"
            style={{ width: 20, height: 20, marginTop: 1, background: checked ? P5_GREEN : "#FFF", border: `1.5px solid ${checked ? P5_GREEN : T.HAIR}` }}>
        {checked && <I5.Check size={12} stroke="#FFF" strokeWidth={3}/>}
      </span>
      <div className="flex-1">
        <div style={{ fontSize: 13.5, fontWeight: 600 }}>{label}</div>
        <div style={{ fontSize: 12.5, color: T.SUB, marginTop: 2, lineHeight: 1.5 }}>{body}</div>
      </div>
      <input type="checkbox" checked={checked} onChange={e => setChecked(e.target.checked)} style={{ display: "none" }}/>
    </label>
  );
}

function App() {
  const [step, setStep] = useState("form"); // form | submitting | success
  const [sigS, setSigS] = useState(true);
  const [sigM, setSigM] = useState(true);
  const [paid, setPaid] = useState(false);
  const [consent, setConsent] = useState(false);
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const setTweak = (id, value) => {
    setTweaks(t => ({ ...t, [id]: value }));
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [id]: value } }, "*");
  };

  const ready = sigS && sigM && paid && consent;

  const submit = () => {
    setStep("submitting");
    setTimeout(() => setStep("success"), 1600);
  };

  const topRight = <P4_Avatar who="S" size={28}/>;

  const successMode = step === "success" || tweaks.state === "submitted";

  return (
    <div className="flex flex-col" style={{ height: "100vh", background: T.BG }}>
      <P4_TopBar viewMeta={{ phase: "Phase 5", title: successMode ? "Submitted · Case AB-2024-00847 · Family Court" : "Submit to court · final step", version: "v5.0", statusLabel: successMode ? "SUBMITTED" : "READY", statusKind: "agreed" }} right={topRight}/>
      <div className="flex-1 flex min-h-0 relative">
        <P4_ChapterRail sectionStatus={P5_SECTION_STATUS}
                        title={successMode ? "Submitted to court" : "Submit"}
                        subtitle={successMode ? "Case received · AB-2024-00847" : "Final checks before sending"}
                        pct={100}
                        currentRoute="fin-submit"
                        showInlineRouter={tweaks.router === "inline"}/>

        <div className="flex-1 overflow-y-auto nice-scroll">
          <div className="max-w-[720px] mx-auto px-8 py-10 pb-40">
            {!successMode && (
              <>
                <div className="label-xs mb-1.5" style={{ color: T.MUTE }}>Phase 5 · Submit</div>
                <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
                  Submit to Family Court
                </h1>
                <p className="mt-3" style={{ fontSize: 14, color: T.SUB, lineHeight: 1.55 }}>
                  Once submitted, the court typically responds within 6–12 weeks. You'll be notified at each stage.
                </p>

                <div className="mt-7 rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
                  <div className="label-xs mb-2" style={{ color: T.MUTE }}>Package contents</div>
                  {P5_DOCS.filter(d => d.required).map(d => (
                    <div key={d.id} className="flex items-center gap-2.5 py-1.5" style={{ fontSize: 13 }}>
                      <I5.Doc size={13} stroke={T.SUB}/>
                      <span>{d.title}</span>
                      <span className="ml-auto label-xs" style={{ color: T.MUTE }}>Ready</span>
                    </div>
                  ))}
                </div>

                <div className="mt-6 rounded-xl px-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
                  <ChecklistItem checked={sigS} setChecked={setSigS}
                                 label="Sarah's signature confirmed"
                                 body="Signed Nov 18, 2024 · verified via identity check"/>
                  <ChecklistItem checked={sigM} setChecked={setSigM}
                                 label="Mark's signature confirmed"
                                 body="Signed Nov 18, 2024 · verified via identity check"/>
                  <ChecklistItem checked={paid} setChecked={setPaid}
                                 label="Court fee paid (£53)"
                                 body="Consent order application fee · HMCTS"/>
                  <ChecklistItem checked={consent} setChecked={setConsent}
                                 label="I confirm this represents our full agreement"
                                 body="Both parties understand this is legally binding once sealed"/>
                </div>

                <div className="mt-7 flex items-center gap-3">
                  <button onClick={submit} disabled={!ready}
                          className="inline-flex items-center gap-2 h-11 px-5 rounded-md whitespace-nowrap"
                          style={{ background: ready ? T.INK : "#D4D2CC", color: "#FFF", fontSize: 13.5, fontWeight: 600, cursor: ready ? "pointer" : "not-allowed" }}>
                    Submit to Family Court
                    <I5.Send size={13} stroke="#FFF" strokeWidth={2.2}/>
                  </button>
                  {!ready && (
                    <span style={{ fontSize: 12, color: T.MUTE }}>Complete all confirmations above</span>
                  )}
                </div>

                {step === "submitting" && (
                  <div className="mt-6 rounded-xl p-5 flex items-center gap-3" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
                    <div className="w-4 h-4 rounded-full animate-pulse" style={{ background: T.INK }}/>
                    <span style={{ fontSize: 13, color: T.INK, fontWeight: 500 }}>Transmitting to HMCTS · generating case number…</span>
                  </div>
                )}
              </>
            )}

            {successMode && (
              <>
                <div className="flex items-center gap-3 mb-4">
                  <span className="inline-flex items-center justify-center rounded-full" style={{ width: 44, height: 44, background: "#E8F4EF" }}>
                    <I5.Check size={22} stroke={P5_GREEN} strokeWidth={2.5}/>
                  </span>
                  <div className="label-xs" style={{ color: P5_GREEN }}>Submitted · Nov 18, 2024 at 14:32</div>
                </div>
                <h1 style={{ fontSize: 34, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.1 }}>
                  Your consent order is with the court
                </h1>
                <p className="mt-3" style={{ fontSize: 15, color: T.SUB, lineHeight: 1.55 }}>
                  Case number <strong style={{ color: T.INK }}>AB-2024-00847</strong> · Family Court (Central London).
                  You'll both receive email confirmations within 10 minutes.
                </p>

                <div className="mt-7 rounded-xl p-5" style={{ background: "#FFF", border: `1px solid ${T.HAIR}` }}>
                  <div className="label-xs mb-3" style={{ color: T.MUTE }}>What happens next</div>
                  {[
                    { t: "Court acknowledgement", when: "Within 3 working days", d: "HMCTS will confirm receipt and assign a judge." },
                    { t: "Judicial review", when: "6–10 weeks", d: "A judge reviews your order to confirm it appears fair. No hearing usually required." },
                    { t: "Sealed order", when: "Typically 8–12 weeks", d: "You'll both receive a sealed copy. The order is then legally binding." },
                    { t: "Implementation", when: "Following sealing", d: "Pensions and property transfers can proceed. We'll guide you through the steps." },
                  ].map((x, i) => (
                    <div key={i} className="flex gap-3 py-2.5" style={{ borderTop: i === 0 ? "none" : `1px solid ${T.HAIR}` }}>
                      <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#F5F3EE", color: T.INK, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 600, flexShrink: 0 }}>{i + 1}</div>
                      <div className="flex-1">
                        <div className="flex items-baseline gap-2">
                          <span style={{ fontSize: 13.5, fontWeight: 600 }}>{x.t}</span>
                          <span className="label-xs" style={{ color: T.MUTE }}>{x.when}</span>
                        </div>
                        <div style={{ fontSize: 12.5, color: T.SUB, marginTop: 2, lineHeight: 1.5 }}>{x.d}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex flex-wrap gap-3">
                  <button className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md" style={{ background: T.INK, color: "#FFF", fontSize: 13, fontWeight: 600 }}>
                    <I5.Print size={13} stroke="#FFF" strokeWidth={2}/> Download submission pack
                  </button>
                  <button className="inline-flex items-center gap-1.5 h-10 px-4 rounded-md" style={{ background: "#FFF", color: T.INK, border: `1px solid ${T.HAIR}`, fontSize: 13, fontWeight: 600 }}>
                    Return to dashboard
                  </button>
                </div>
              </>
            )}
          </div>
        </div>

        {tweaks.router !== "inline" && <P4_FloatingRouter current="fin-submit"/>}
      </div>
      <P4_TweakPanel
        title="Submit"
        options={[
          { id: "state", label: "State", variants: [
            { value: "form",      label: "Pre-submission",  sub: "Checklist + Submit button" },
            { value: "submitted", label: "Submitted",       sub: "Confirmation + next steps" }
          ]},
          { id: "router", label: "Journey router", variants: [
            { value: "inline",   label: "Inline",   sub: "Housed inside left column" },
            { value: "floating", label: "Floating", sub: "Lozenge at bottom of screen" }
          ]}
        ]}
        values={tweaks}
        onChange={setTweak}/>
    </div>
  );
}

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "state": "form",
  "router": "inline"
}/*EDITMODE-END*/;

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
})();
