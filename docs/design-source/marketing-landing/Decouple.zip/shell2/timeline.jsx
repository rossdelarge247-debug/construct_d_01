/* Shared Version History timeline + popover
   Pattern: phase swimlane (Draft / Approval) above two rows — Versions + Activities.
   Used in desktop full-rail, icon-rail, and mobile.
*/
(function(){
const { useState, useEffect, useRef } = React;
const { XIcon, ChevronRight, ChevronDown } = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";

/* Phase tints — soft, like the reference image */
const DRAFT_BG     = "#E8E5DF"; /* warm grey */
const DRAFT_INK    = "#5C5750";
const APPROVAL_BG  = "#FCE99A"; /* honey yellow */
const APPROVAL_INK = "#7A5807";
const SHARED_BG    = "#FFE0DD"; /* soft red-pink */
const SHARED_INK   = "#9B2D2D";

const PERSON = {
  S: { name: "Sarah",  initial: "S", color: "#2F6D5F" },
  M: { name: "Mark",   initial: "M", color: "#7E5A4E" },
  N: { name: "Nina",   initial: "N", color: "#D45D6E" }  /* advisor */
};

/* ============================================================
   TIMELINE DATA — relative day offsets 0..5
   ============================================================ */
const DAYS = [
  { d: "8 Oct",  label: "Mon" },
  { d: "9 Oct",  label: "Tue" },
  { d: "10 Oct", label: "Wed" },
  { d: "11 Oct", label: "Thu" },
  { d: "12 Oct", label: "Fri" },
  { d: "13 Oct", label: "Sat" }
];

/* phases span [startCol, endCol] inclusive into the day grid */
const PHASES = [
  { name: "Draft",     bg: DRAFT_BG,    fg: DRAFT_INK,    start: 0, end: 2 },
  { name: "Approval",  bg: APPROVAL_BG, fg: APPROVAL_INK, start: 3, end: 5 }
];

/* Versions — milestones on a timeline row */
const VERSIONS = [
  { day: 0, person: "S", label: "v0.6", note: "Initial draft from imports" },
  { day: 1, person: "S", label: "v0.7", note: "Added pensions section" },
  { day: 2, person: "S", label: "v0.8", note: "Property estimate added", current: true },
  { day: 4, person: "S", label: "v1.0", note: "Marked Ready · shared with Mark" }
];

/* Activities — small avatar+verb pills */
const ACTS = [
  { day: 0, person: "S", verb: "view",    label: "Sarah opened picture" },
  { day: 0, person: "S", verb: "edit",    label: "Sarah edited Children" },
  { day: 1, person: "N", verb: "view",    label: "Nina (advisor) reviewed" },
  { day: 1, person: "N", verb: "comment", label: "Nina commented on §3 Pensions" },
  { day: 2, person: "S", verb: "share",   label: "Sarah shared with Nina" },
  { day: 2, person: "S", verb: "comment", label: "Sarah replied to Nina" },
  { day: 2, person: "S", verb: "edit",    label: "Sarah edited Property value" },
  { day: 4, person: "M", verb: "view",    label: "Mark opened the picture" },
  { day: 4, person: "M", verb: "comment", label: "Mark commented on §2 The home" },
  { day: 5, person: "S", verb: "edit",    label: "Sarah responded · v1.1 in draft" }
];

/* ============================================================
   ICONS — verbs
   ============================================================ */
const Verb = ({ kind, size = 9 }) => {
  const ic = {
    view:    <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></>,
    edit:    <><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></>,
    comment: <path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>,
    share:   <><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></>
  }[kind];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">{ic}</svg>
  );
};

/* Avatar bubble */
function PAvatar({ p, size = 18, ring }) {
  const person = PERSON[p];
  return (
    <div className="rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
         style={{
           width: size, height: size,
           background: person.color,
           fontSize: size <= 16 ? 8.5 : size <= 20 ? 9.5 : 11,
           boxShadow: ring ? `0 0 0 ${ring}px #FFFFFF` : "none"
         }}>
      {person.initial}
    </div>
  );
}

/* ============================================================
   THE TIMELINE — used inline in popover and in mobile sheet
   width: full width of container; rows are absolutely positioned
   onto a CSS grid of N day columns.
   ============================================================ */
function Timeline({ width = 560 }) {
  /* layout */
  const PAD_L = 84;            /* lane label width */
  const PAD_R = 16;
  const innerW = width - PAD_L - PAD_R;
  const colW = innerW / DAYS.length;
  const colX = (i) => PAD_L + colW * i + colW / 2;

  const ROW_H_VER = 36;
  const ROW_H_ACT = 40;
  const PHASE_H = 22;

  /* group activities by day so they cluster nicely */
  const byDay = {};
  ACTS.forEach(a => { (byDay[a.day] ||= []).push(a); });

  const totalH = 26 + PHASE_H + 14 + ROW_H_VER + ROW_H_ACT + 8;

  return (
    <div style={{ width, position: "relative", paddingTop: 26, height: totalH }}>
      {/* Day labels */}
      <div style={{ position: "absolute", top: 0, left: PAD_L, right: PAD_R, height: 18 }}>
        {DAYS.map((d, i) => (
          <div key={i} style={{
            position: "absolute",
            left: colX(i) - PAD_L - 28, width: 56, textAlign: "center",
            fontSize: 11, color: SUB, fontWeight: 500
          }}>{d.d}</div>
        ))}
      </div>

      {/* Phase swimlane */}
      <div style={{ position: "relative", height: PHASE_H, marginLeft: PAD_L, marginRight: PAD_R }}>
        {PHASES.map((p, i) => {
          const x1 = colX(p.start) - PAD_L - colW * 0.42;
          const x2 = colX(p.end)   - PAD_L + colW * 0.42;
          return (
            <div key={i} style={{
              position: "absolute",
              left: x1, width: x2 - x1, top: 0, height: PHASE_H,
              background: p.bg, color: p.fg,
              borderRadius: 999,
              fontSize: 11, fontWeight: 600,
              display: "flex", alignItems: "center", paddingLeft: 12
            }}>
              {p.name}
            </div>
          );
        })}
      </div>

      {/* Today shading — vertical band at column "today" (col 2) */}
      {(() => {
        const TODAY = 2;
        const left = colX(TODAY) - colW / 2;
        return (
          <div style={{
            position: "absolute", top: 26, left, width: colW,
            height: PHASE_H + 14 + ROW_H_VER + ROW_H_ACT, background: "rgba(0,0,0,0.035)",
            borderRadius: 6, pointerEvents: "none"
          }}/>
        );
      })()}

      {/* Versions row */}
      <Row label="Versions" top={PHASE_H + 14} h={ROW_H_VER} padL={PAD_L} padR={PAD_R}>
        {/* horizontal line */}
        <div style={{ position: "absolute", left: PAD_L + 6, right: PAD_R + 6, top: ROW_H_VER / 2,
                      height: 1, background: "#E5E7EB" }}/>
        {VERSIONS.map((v, i) => (
          <div key={i} style={{
            position: "absolute", left: colX(v.day) - 12, top: ROW_H_VER / 2 - 12,
            display: "flex", alignItems: "center", gap: 4
          }}
          title={`${v.label} — ${v.note}`}>
            <PAvatar p={v.person} size={24} ring={2}/>
            {v.current && (
              <span className="chip whitespace-nowrap" style={{
                background: "#111", color: "#FFFFFF",
                padding: "1.5px 6px", fontSize: 9.5, letterSpacing: "0.04em"
              }}>{v.label}</span>
            )}
          </div>
        ))}
      </Row>

      {/* Activities row */}
      <Row label="Activities" top={PHASE_H + 14 + ROW_H_VER} h={ROW_H_ACT} padL={PAD_L} padR={PAD_R}>
        {Object.entries(byDay).map(([day, items]) => {
          const x = colX(parseInt(day, 10));
          /* lay out cluster horizontally, centered */
          const PILL_W = 20;        /* a single-icon pill */
          const PILL_W_2 = 30;      /* avatar + verb */
          const GAP = 4;
          const totalW = items.reduce((s, _) => s + PILL_W_2 + GAP, -GAP);
          let cursor = x - totalW / 2;
          return items.map((a, i) => {
            const left = cursor;
            cursor += PILL_W_2 + GAP;
            const person = PERSON[a.person];
            return (
              <div key={day + "-" + i}
                   title={a.label}
                   style={{
                     position: "absolute", left, top: ROW_H_ACT / 2 - 10,
                     height: 20, paddingLeft: 2, paddingRight: 5,
                     borderRadius: 999, background: "#F1F1EE",
                     display: "flex", alignItems: "center", gap: 3
                   }}>
                <PAvatar p={a.person} size={16}/>
                <span style={{ color: person.color }}>
                  <Verb kind={a.verb} size={9}/>
                </span>
              </div>
            );
          });
        })}
      </Row>
    </div>
  );
}

function Row({ label, top, h, padL, padR, children }) {
  return (
    <div style={{ position: "absolute", left: 0, right: 0, top: top + 26, height: h }}>
      <div style={{
        position: "absolute", left: 0, top: h / 2 - 8,
        width: padL - 8, textAlign: "right",
        fontSize: 11, color: SUB, fontWeight: 500
      }}>
        {label}
      </div>
      {children}
    </div>
  );
}

/* ============================================================
   POPOVER — anchored to "Version history" button
   ============================================================ */
function VersionHistoryPopover({ anchorRect, onClose, embedded, side = "bottom-right" }) {
  const ref = useRef(null);

  useEffect(() => {
    if (embedded) return;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [onClose, embedded]);

  /* compute popover position from anchorRect (in containing element coords) */
  const W = 620;
  let left = 0, top = 0;
  if (anchorRect) {
    if (side === "bottom-right") {
      left = Math.max(8, anchorRect.right - W);
      top = anchorRect.bottom + 6;
    } else if (side === "right") {
      left = anchorRect.right + 8;
      top = anchorRect.top;
    }
  }

  const inner = (
    <div ref={ref}
         className="bg-white rounded-xl flex flex-col"
         style={{
           width: W, maxHeight: 520,
           boxShadow: "0 18px 40px rgba(0,0,0,0.18)",
           border: `1px solid ${LINE}`,
           overflow: "hidden"
         }}>
      <div className="px-4 pt-3.5 pb-3 flex items-start gap-2"
           style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="flex-1">
          <div style={{ fontSize: 14, fontWeight: 600, color: INK }}>Version history</div>
          <div style={{ fontSize: 12, color: SUB, marginTop: 1, lineHeight: 1.45 }}>
            Sarah's Picture · 4 versions over 6 days · <b style={{ color: APPROVAL_INK }}>Approval phase</b>
          </div>
        </div>
        <Legend/>
        {!embedded && (
          <button onClick={onClose}
                  className="w-7 h-7 rounded-md hover:bg-[#F3F4F6] flex items-center justify-center">
            <XIcon size={14}/>
          </button>
        )}
      </div>

      {/* The timeline itself */}
      <div className="px-4 pt-2 pb-1" style={{ background: "#FCFCFB" }}>
        <Timeline width={W - 32}/>
      </div>

      {/* Version list under the timeline */}
      <div className="overflow-y-auto nice-scroll" style={{ background: "#FFFFFF" }}>
        <div className="px-2 py-2" style={{ borderTop: `1px solid ${LINE}` }}>
          <VersionRow v={{ id: "v1.1", who: "S", time: "13 Oct · 2 hrs ago", note: "In draft — responding to Mark's housing comment" }} draft/>
          <VersionRow v={{ id: "v1.0", who: "S", time: "11 Oct · 12:14",       note: "Marked Ready · shared with Mark · 9 sections complete" }} ready/>
          <VersionRow v={{ id: "v0.8", who: "S", time: "10 Oct · 18:30",       note: "Added property valuation, marked CETV gap" }} current/>
          <VersionRow v={{ id: "v0.7", who: "S", time: "9 Oct · 21:05",        note: "Pensions section + spending breakdown" }}/>
          <VersionRow v={{ id: "v0.6", who: "S", time: "8 Oct · 09:20",        note: "Initial draft from imported accounts" }}/>
        </div>
      </div>

      <div className="px-4 py-2.5 flex items-center justify-between flex-shrink-0"
           style={{ background: "#FAFAFA", borderTop: `1px solid ${LINE}` }}>
        <span style={{ fontSize: 11.5, color: SUB }}>Versions are kept for the lifetime of your case.</span>
        <button className="text-[12px] font-semibold inline-flex items-center gap-1" style={{ color: INK }}>
          Compare versions <ChevronRight size={11}/>
        </button>
      </div>
    </div>
  );

  if (embedded) return inner;

  return (
    <div className="absolute inset-0 z-40" onClick={onClose} style={{ pointerEvents: "auto" }}>
      <div style={{ position: "absolute", left, top, pointerEvents: "auto" }}
           onClick={e => e.stopPropagation()}>
        {inner}
      </div>
    </div>
  );
}

function Legend() {
  return (
    <div className="flex items-center gap-2 mr-2" style={{ fontSize: 10.5, color: SUB }}>
      {[
        ["S", "You"],
        ["M", "Mark"],
        ["N", "Advisor"]
      ].map(([p, l], i) => (
        <span key={i} className="inline-flex items-center gap-1">
          <PAvatar p={p} size={12}/> {l}
        </span>
      ))}
    </div>
  );
}

function VersionRow({ v, current, ready, draft }) {
  const phaseChip = ready
    ? { bg: "#D1FAE5", fg: "#065F46", label: "READY" }
    : draft
      ? { bg: "#FEF3C7", fg: "#92400E", label: "DRAFT" }
      : current
        ? { bg: "#111", fg: "#FFFFFF", label: "CURRENT" }
        : null;
  return (
    <button className="w-full flex items-start gap-3 px-2.5 py-2 rounded-lg text-left hover:bg-[#FAFAFA] transition">
      <PAvatar p={v.who} size={22}/>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="tabular-nums" style={{ fontSize: 13, fontWeight: 600, color: INK }}>{v.id}</span>
          {phaseChip && (
            <span className="chip" style={{ background: phaseChip.bg, color: phaseChip.fg, padding: "1.5px 6px", fontSize: 9.5 }}>
              {phaseChip.label}
            </span>
          )}
          <span style={{ fontSize: 11.5, color: MUTE }}>· {v.time}</span>
        </div>
        <div style={{ fontSize: 12, color: SUB, lineHeight: 1.45, marginTop: 1 }}>{v.note}</div>
      </div>
      <ChevronRight size={12} style={{ color: MUTE, marginTop: 4 }}/>
    </button>
  );
}

Object.assign(window, { Timeline, VersionHistoryPopover, PAvatar, PERSON, PHASES, VERSIONS, ACTS });
})();
