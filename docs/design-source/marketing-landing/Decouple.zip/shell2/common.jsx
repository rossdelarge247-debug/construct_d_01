/* Shared primitives for Rail + Notebook variations */
(function(){
const { useState, useEffect, useRef } = React;

const Ic = ({ children, size = 18, stroke = "currentColor", strokeWidth = 1.75, style }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={stroke}
       strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style}>
    {children}
  </svg>
);
const MenuIcon = (p) => <Ic {...p}><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="13" x2="20" y2="13"/><line x1="4" y1="19" x2="14" y2="19"/></Ic>;
const XIcon = (p) => <Ic {...p}><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></Ic>;
const ChevronRight = (p) => <Ic {...p}><polyline points="9 6 15 12 9 18"/></Ic>;
const ChevronLeft = (p) => <Ic {...p}><polyline points="15 6 9 12 15 18"/></Ic>;
const ChevronDown = (p) => <Ic {...p}><polyline points="6 9 12 15 18 9"/></Ic>;
const ChevronUp = (p) => <Ic {...p}><polyline points="6 15 12 9 18 15"/></Ic>;
const MessageSquare = (p) => <Ic {...p}><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></Ic>;
const Check = (p) => <Ic {...p}><polyline points="5 12 10 17 19 7"/></Ic>;
const Share = (p) => <Ic {...p}><path d="M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></Ic>;
const Edit = (p) => <Ic {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></Ic>;
const History = (p) => <Ic {...p}><polyline points="3 8 3 3 8 3"/><path d="M3.5 12a8.5 8.5 0 1 0 2.3-5.8L3 9"/><polyline points="12 7 12 12 15.5 14"/></Ic>;
const Plus = (p) => <Ic {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const FileText = (p) => <Ic {...p}><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/></Ic>;
const Home = (p) => <Ic {...p}><path d="M3 11l9-8 9 8"/><path d="M5 10v10a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V10"/></Ic>;
const Compass = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><polygon points="16 8 13.5 13.5 8 16 10.5 10.5 16 8"/></Ic>;
const Lock = (p) => <Ic {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></Ic>;
const Settings = (p) => <Ic {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></Ic>;
const LifeBuoy = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/></Ic>;
const Users = (p) => <Ic {...p}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/></Ic>;
const Dot = (p) => <Ic {...p}><circle cx="12" cy="12" r="1.5" fill="currentColor" stroke="none"/></Ic>;
const BookOpen = (p) => <Ic {...p}><path d="M2 4h6a4 4 0 0 1 4 4v12a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v12a3 3 0 0 1 3-3h7z"/></Ic>;
const PanelRight = (p) => <Ic {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="15" y1="3" x2="15" y2="21"/></Ic>;

/* Wordmark */
function Wordmark({ small, dark, serif }) {
  const color = dark ? "#F7F7F5" : "#111";
  return (
    <div className="flex items-center gap-2 select-none">
      <div className="relative" style={{ width: small ? 18 : 22, height: small ? 18 : 22 }} aria-hidden>
        <div className="absolute inset-0 rounded-full" style={{ background: color }} />
        <div className="absolute rounded-full" style={{
          left: "42%", top: 0, width: "58%", height: "100%",
          background: dark ? "#1A1A1A" : "#F7F7F5"
        }} />
        <div className="absolute rounded-full" style={{ left: "45%", top: "12%", width: "10%", height: "76%", background: color }} />
      </div>
      <span style={{
        fontSize: small ? 14 : 16,
        letterSpacing: serif ? "0.005em" : "-0.01em",
        fontWeight: 600, color,
        fontFamily: serif ? "'Fraunces', 'Times New Roman', serif" : undefined
      }}>decouple</span>
    </div>
  );
}

const STATES = {
  A: { key: "A", label: "Building",  phase: "Phase 2", title: "Sarah's Picture", version: "v0.6", status: "DRAFT",             chipBg: "#FEF3C7", chipFg: "#92400E", accent: "#B45309", bodyKind: "building" },
  B: { key: "B", label: "Reviewing", phase: "Pre-share", title: "Sarah's Picture", version: "v1.0", status: "READY",             chipBg: "#D1FAE5", chipFg: "#065F46", accent: "#047857", bodyKind: "reviewing" },
  C: { key: "C", label: "Proposal",  phase: "Phase 4", title: "Settlement",      version: "v2.1", status: "2 ITEMS PENDING",    chipBg: "#FEE2E2", chipFg: "#991B1B", accent: "#B91C1C", bodyKind: "proposal" }
};

function StateSwitcher({ state, setState }) {
  const opts = [
    { k: "A", label: "Building my picture",    sub: "Phase 2 · draft" },
    { k: "B", label: "Reviewing the document", sub: "Pre-share · ready" },
    { k: "C", label: "Reviewing a proposal",   sub: "Phase 4 · pending" }
  ];
  return (
    <div className="flex flex-wrap gap-1.5 items-center">
      <span className="label-xs mr-1" style={{ color: "#9CA3AF" }}>State</span>
      {opts.map(o => {
        const active = state === o.k;
        return (
          <button key={o.k} onClick={() => setState(o.k)}
            className="flex items-center gap-1.5 px-2 py-1 rounded-md transition"
            style={{
              background: active ? "#111" : "#FFFFFF",
              color: active ? "#FFFFFF" : "#1A1A1A",
              border: active ? "1px solid #111" : "1px solid #E5E7EB",
              fontSize: 11.5
            }}>
            <span className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full text-[9px] font-semibold"
                  style={{ background: active ? "#FFFFFF" : "#F3F4F6", color: active ? "#111" : "#6B7280" }}>
              {o.k}
            </span>
            <span className="font-semibold">{o.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* Shared doc content helpers */
const ASSETS = [
  ["NHS pension (CETV)",         "Defined benefit", "£214,000", true],
  ["Halifax mortgage — equity",  "Property",        "£187,500", true],
  ["First Direct joint savings", "Cash",            "£28,400",  true],
  ["Vanguard ISA — Sarah",       "Investment",      "£42,150",  false],
  ["Ford Kuga 2021",             "Vehicle",         "£14,800",  false]
];

const COMMENT_THREAD = {
  target: "§3.2 Housing",
  items: [
    { who: "Mark",  initial: "M", color: "#7E5A4E", time: "2h ago",
      text: "I'd like to revisit the Halifax equity split — the figure doesn't reflect the 2018 deposit." },
    { who: "Sarah", initial: "S", color: "#2F6D5F", time: "4h ago",
      text: "Happy to discuss. I've asked our advisor to pull the original completion statement." }
  ]
};

const ACTIVITY = {
  A: [
    ["Autosaved 'Future needs'", "15m ago"],
    ["NHS pension imported",      "2h ago"],
    ["Halifax mortgage linked",   "Today"],
    ["Session started",           "Today"]
  ],
  B: [
    ["Sarah marked picture as Ready",   "Just now"],
    ["NHS pension imported (£214k)",    "Today"],
    ["Halifax mortgage linked",         "Today"],
    ["2 children added to household",   "3 days ago"]
  ],
  C: [
    ["Mark accepted 6 of 8 clauses",    "Yesterday"],
    ["Sarah proposed v2.1",             "Yesterday"],
    ["Document signed off by advisor",  "2 days ago"]
  ]
};

Object.assign(window, {
  Ic, MenuIcon, XIcon, ChevronRight, ChevronLeft, ChevronDown, ChevronUp, MessageSquare,
  Check, Share, Edit, History, Plus, FileText, Home, Compass, Lock, Settings, LifeBuoy,
  Users, Dot, BookOpen, PanelRight, Wordmark, STATES, StateSwitcher,
  ASSETS, COMMENT_THREAD, ACTIVITY
});
})();
