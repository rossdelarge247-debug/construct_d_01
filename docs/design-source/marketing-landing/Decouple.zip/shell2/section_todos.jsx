/* ====================================================================
   Section To-do panel — contextual right-rail
   Phase 2 · Your Picture · "Outgoings" section
   --------------------------------------------------------------------
   Three variations explored side-by-side on a design canvas:
     A · Stacked checklist     — closest to existing dashboard pattern
     B · Inline-resolve cards  — every task is a one-tap resolve
     C · Triage queue          — AI-prioritised, single-focus
   ====================================================================*/
(function(){
const { useState } = React;

/* ---- design tokens (match shell2/picture.jsx) ---- */
const INK = "#1A1A1A";
const SUB = "#5F6368";
const MUTE = "#9AA0A6";
const LINE = "#EAECEF";
const LINE2 = "#F1F2F4";
const PAPER = "#FFFFFF";
const PANEL = "#FAFAF9";
const AMBER_BG = "#FEF7E7";
const AMBER_BORDER = "#F3D88A";
const AMBER_INK = "#92620A";
const AMBER_INK2 = "#7A5307";
const BANK_BG = "#E7F3EC";
const BANK_FG = "#0A6B39";
const SELF_BG = "#EEF1F6";
const SELF_FG = "#4A5772";
const ACCENT = "#2F6D5F";
const ACCENT_BG = "#E8F1EE";
const DANGER = "#E5484D";
const VIOLET_BG = "#F1ECFA";
const VIOLET_FG = "#5A3EB8";

/* ---- icons ---- */
const I = (ch, p = {}) => (
  <svg width={p.s || 14} height={p.s || 14} viewBox="0 0 24 24" fill="none"
       stroke={p.c || "currentColor"} strokeWidth={p.w || 1.75}
       strokeLinecap="round" strokeLinejoin="round" style={p.style}>{ch}</svg>
);
const Check = (p) => I(<polyline points="5 12 10 17 19 7"/>, p);
const Plus = (p) => I(<><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>, p);
const Pencil = (p) => I(<><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></>, p);
const ArrowOut = (p) => I(<><path d="M7 17 17 7"/><polyline points="8 7 17 7 17 16"/></>, p);
const ArrowR = (p) => I(<><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></>, p);
const ArrowL = (p) => I(<><line x1="19" y1="12" x2="5" y2="12"/><polyline points="11 6 5 12 11 18"/></>, p);
const ChevDown = (p) => I(<polyline points="6 9 12 15 18 9"/>, p);
const Sparkle = (p) => I(<><path d="M12 3v3"/><path d="M12 18v3"/><path d="M3 12h3"/><path d="M18 12h3"/><path d="M5.6 5.6 7.7 7.7"/><path d="M16.3 16.3l2.1 2.1"/><path d="M5.6 18.4 7.7 16.3"/><path d="M16.3 7.7l2.1-2.1"/></>, p);
const Doc = (p) => I(<><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><polyline points="14 3 14 8 19 8"/></>, p);
const Bell = (p) => I(<><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></>, p);
const X = (p) => I(<><line x1="6" y1="6" x2="18" y2="18"/><line x1="18" y1="6" x2="6" y2="18"/></>, p);
const Filter = (p) => I(<polygon points="22 3 2 3 10 12.5 10 19 14 21 14 12.5 22 3"/>, p);

/* ---- shared chrome: section header eyebrow & footer link ---- */
function PanelEyebrow({ section, count, done }) {
  const pct = Math.round((done / count) * 100);
  return (
    <div className="px-4 pt-4 pb-3" style={{ borderBottom: `1px solid ${LINE}` }}>
      <div className="flex items-center gap-1.5 mb-1.5">
        <span className="label-xs" style={{ color: MUTE }}>For this section</span>
      </div>
      <div className="flex items-baseline justify-between mb-2">
        <div style={{ fontSize: 14, fontWeight: 600, color: INK, letterSpacing: "-0.005em" }}>
          {section}
        </div>
        <div className="tabular-nums" style={{ fontSize: 11.5, color: SUB }}>
          {done} of {count}
        </div>
      </div>
      <div className="w-full h-[3px] rounded-full overflow-hidden" style={{ background: "#EFEFEC" }}>
        <div className="h-full" style={{ width: `${pct}%`, background: ACCENT, transition: "width 200ms" }}/>
      </div>
    </div>
  );
}

function PanelFooter({ total, doneAll }) {
  return (
    <div className="px-4 py-3 mt-auto flex items-center justify-between"
         style={{ borderTop: `1px solid ${LINE}`, background: PAPER }}>
      <span className="tabular-nums" style={{ fontSize: 11, color: MUTE, letterSpacing: "0.04em" }}>
        {doneAll} of {total} across all sections
      </span>
      <button className="inline-flex items-center gap-1 text-[11.5px] font-semibold"
              style={{ color: INK }}>
        See all <ArrowR s={11}/>
      </button>
    </div>
  );
}

/* ---- shared task atoms ---- */
function TaskBadge({ kind }) {
  const map = {
    estimate: { bg: SELF_BG, fg: SELF_FG, glyph: "✎",  label: "Self-declared estimate" },
    gap:      { bg: AMBER_BG, fg: AMBER_INK, glyph: "!", label: "Information gap" },
    bank:     { bg: BANK_BG, fg: BANK_FG, glyph: "🏦", label: "Bank-evidenced" },
    doc:      { bg: VIOLET_BG, fg: VIOLET_FG, glyph: "↗", label: "Outside Decouple" },
    ai:       { bg: "#FFF3DD", fg: "#7A4F00", glyph: "✦", label: "AI suggestion" }
  };
  const b = map[kind] || map.estimate;
  return (
    <span title={b.label}
      className="inline-flex items-center justify-center rounded-full flex-shrink-0"
      style={{
        width: 18, height: 18, background: b.bg, color: b.fg,
        fontSize: kind === "gap" ? 11 : (kind === "doc" ? 11 : 10),
        fontWeight: 700, lineHeight: 1
      }}>
      {b.glyph}
    </span>
  );
}

/* ============================================================
   VARIATION A — Stacked checklist (default, closest to dashboard)
   ============================================================ */
function VariationA() {
  const [done, setDone] = useState({});
  const toggle = (id) => setDone(d => ({ ...d, [id]: !d[id] }));

  const TASKS = [
    { id: "t1", kind: "estimate", title: "Confirm child expenses",
      meta: "£400 / month · est. from nursery & uniform",
      action: "Confirm", anchor: "Outgoings · row 4" },
    { id: "t2", kind: "estimate", title: "Confirm leisure spend",
      meta: "£250 / month · gym, dining, cinema",
      action: "Confirm", anchor: "Outgoings · row 5" },
    { id: "t3", kind: "gap", title: "Categorise 12 transactions",
      meta: "Decouple couldn't classify these — 2 mins",
      action: "Review", anchor: "Outgoings · uncategorised" },
    { id: "t4", kind: "doc", title: "Upload Barclaycard statement",
      meta: "Last 3 months · joint card not yet linked",
      action: "Upload", anchor: "Outside Decouple" }
  ];

  return (
    <div className="flex flex-col" style={{ width: 280, height: 760, background: PAPER, border: `1px solid ${LINE}`, borderRadius: 12, overflow: "hidden" }}>
      <PanelEyebrow section="Outgoings" count={7} done={3 + Object.values(done).filter(Boolean).length}/>

      <div className="flex-1 overflow-y-auto nice-scroll">
        <div className="px-4 pt-4 pb-2">
          <div className="label-xs" style={{ color: MUTE }}>To do here · {TASKS.length}</div>
        </div>

        <ul className="px-2 pb-2">
          {TASKS.map((t) => {
            const isDone = !!done[t.id];
            return (
              <li key={t.id} className="px-2 py-2.5 rounded-lg group"
                  style={{ background: isDone ? "#FAFAF9" : "transparent", transition: "background 140ms" }}>
                <div className="flex items-start gap-2.5">
                  <button onClick={() => toggle(t.id)}
                    className="flex-shrink-0 mt-[1px] w-[16px] h-[16px] rounded-[4px] flex items-center justify-center"
                    style={{
                      background: isDone ? ACCENT : PAPER,
                      border: isDone ? `1px solid ${ACCENT}` : `1.4px solid #C9CDD2`,
                      transition: "all 140ms"
                    }}>
                    {isDone && <Check s={10} c="#FFF" w={2.5}/>}
                  </button>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <TaskBadge kind={t.kind}/>
                      <span style={{
                        fontSize: 13, fontWeight: 600, color: isDone ? MUTE : INK,
                        textDecoration: isDone ? "line-through" : "none",
                        letterSpacing: "-0.003em"
                      }}>{t.title}</span>
                    </div>
                    <div style={{
                      fontSize: 11.5, color: SUB, lineHeight: 1.45, paddingLeft: 24,
                      textDecoration: isDone ? "line-through" : "none"
                    }}>{t.meta}</div>
                    {!isDone && (
                      <div className="flex items-center gap-2 mt-2" style={{ paddingLeft: 24 }}>
                        <button className="h-[26px] px-2.5 rounded-md text-[11.5px] font-semibold inline-flex items-center gap-1"
                                style={{ background: INK, color: PAPER }}>
                          {t.action}
                          {t.kind === "doc" && <ArrowOut s={10}/>}
                        </button>
                        <button className="h-[26px] px-2 rounded-md text-[11px] font-medium"
                                style={{ color: SUB, background: "transparent" }}>
                          Skip
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </li>
            );
          })}
        </ul>

        {/* Section AI nudge */}
        <div className="mx-3 mb-3 mt-1 p-3 rounded-lg flex gap-2"
             style={{ background: "#F8F6F1", border: `1px solid #ECE7DA` }}>
          <Sparkle s={13} c="#7A4F00" style={{ marginTop: 1, flexShrink: 0 }}/>
          <div>
            <div style={{ fontSize: 11.5, fontWeight: 600, color: "#5C3B00", letterSpacing: "0.02em", textTransform: "uppercase" }}>
              AI noticed
            </div>
            <div style={{ fontSize: 12, color: "#5F4A1F", lineHeight: 1.5, marginTop: 2 }}>
              Spending exceeds income by <b>£892/mo</b>. Worth flagging at proposal.
            </div>
          </div>
        </div>
      </div>

      <PanelFooter total={24} doneAll={9 + Object.values(done).filter(Boolean).length}/>
    </div>
  );
}

/* ============================================================
   VARIATION B — Inline-resolve cards
   Each task expands into its own resolution UI; one-tap close.
   ============================================================ */
function VariationB() {
  const TASKS = [
    { id: "t1", kind: "estimate", title: "Household utilities & maintenance",
      hint: "Bank average suggests £300 — does that look right?",
      value: "£300", confirmable: true, anchor: "Outgoings · row 1" },
    { id: "t2", kind: "estimate", title: "Personal & living expenses",
      hint: "Covers groceries, clothing, household sundries.",
      value: "£380", confirmable: true, anchor: "Outgoings · row 2" },
    { id: "t3", kind: "gap", title: "12 transactions need categorising",
      hint: "Mostly £30–80 — likely groceries or fuel.",
      cta: "Categorise (2 min)", anchor: "Outgoings · uncategorised" },
    { id: "t4", kind: "doc", title: "Upload Barclaycard statement",
      hint: "Joint card isn't linked — needed for full picture.",
      cta: "Upload PDF", anchor: "Outside Decouple" }
  ];

  return (
    <div className="flex flex-col" style={{ width: 280, height: 760, background: PANEL, border: `1px solid ${LINE}`, borderRadius: 12, overflow: "hidden" }}>
      <PanelEyebrow section="Outgoings" count={7} done={3}/>

      <div className="flex-1 overflow-y-auto nice-scroll px-3 py-3" style={{ background: PANEL }}>
        <div className="label-xs mb-2 px-1" style={{ color: MUTE }}>4 things to resolve</div>

        <div className="flex flex-col gap-2">
          {TASKS.map(t => (
            <div key={t.id} className="rounded-lg p-3" style={{ background: PAPER, border: `1px solid ${LINE}` }}>
              <div className="flex items-start gap-2 mb-1">
                <TaskBadge kind={t.kind}/>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: INK, lineHeight: 1.35, flex: 1 }}>
                  {t.title}
                </div>
              </div>
              <div style={{ fontSize: 11.5, color: SUB, lineHeight: 1.5, marginTop: 4 }}>
                {t.hint}
              </div>

              {t.confirmable && (
                <div className="mt-3 flex items-center gap-1.5">
                  <button className="flex-1 h-[28px] rounded-md text-[12px] font-semibold inline-flex items-center justify-center gap-1"
                          style={{ background: ACCENT, color: PAPER }}>
                    <Check s={11} w={2.5}/> Confirm {t.value}
                  </button>
                  <button className="h-[28px] w-[28px] rounded-md inline-flex items-center justify-center"
                          style={{ background: "#F3F4F6", color: INK }}
                          title="Edit value">
                    <Pencil s={11}/>
                  </button>
                </div>
              )}
              {!t.confirmable && (
                <button className="mt-3 w-full h-[28px] rounded-md text-[12px] font-semibold inline-flex items-center justify-center gap-1.5"
                        style={{
                          background: t.kind === "gap" ? AMBER_BG : "#FFFFFF",
                          color: t.kind === "gap" ? AMBER_INK : INK,
                          border: `1px solid ${t.kind === "gap" ? AMBER_BORDER : LINE}`
                        }}>
                  {t.cta}
                  {t.kind === "doc" && <ArrowOut s={11}/>}
                </button>
              )}
              <div className="mt-2 pt-2 flex items-center justify-between" style={{ borderTop: `1px dashed ${LINE2}` }}>
                <span className="tabular-nums" style={{ fontSize: 10.5, color: MUTE, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  {t.anchor}
                </span>
                <button style={{ fontSize: 10.5, color: MUTE, letterSpacing: "0.04em", textTransform: "uppercase" }}>
                  Skip
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <PanelFooter total={24} doneAll={9}/>
    </div>
  );
}

/* ============================================================
   VARIATION C — Triage queue (single-focus, AI-ordered)
   ============================================================ */
function VariationC() {
  const QUEUE = [
    { kind: "estimate", title: "Confirm child expenses",
      body: "Decouple sees roughly £400/month going to nursery, school clothing and uniform across the last 12 months. We listed it as an estimate.",
      value: "£400", impact: "Affects monthly need calculation" },
    { kind: "gap", title: "Categorise 12 transactions",
      body: "Mostly £30–80, paid weekly to ASDA, Tesco, Esso. Decouple couldn't tell groceries from fuel.",
      impact: "12 transactions · ~£640 total" },
    { kind: "doc", title: "Upload Barclaycard statement",
      body: "The joint Barclaycard isn't connected to Open Banking. A 3-month PDF closes the gap.",
      impact: "Likely £200–300 / month not yet visible" }
  ];
  const [idx, setIdx] = useState(0);
  const t = QUEUE[idx];

  return (
    <div className="flex flex-col" style={{ width: 280, height: 760, background: PAPER, border: `1px solid ${LINE}`, borderRadius: 12, overflow: "hidden" }}>
      <PanelEyebrow section="Outgoings" count={7} done={3}/>

      <div className="flex-1 flex flex-col">
        {/* Queue position */}
        <div className="px-4 pt-3 pb-2 flex items-center justify-between">
          <div className="label-xs" style={{ color: MUTE }}>Up next · 1 of {QUEUE.length}</div>
          <div className="flex items-center gap-1">
            <button onClick={() => setIdx(i => Math.max(0, i - 1))}
                    disabled={idx === 0}
                    className="w-6 h-6 rounded inline-flex items-center justify-center"
                    style={{ color: idx === 0 ? "#D6D8DA" : SUB, background: "transparent" }}>
              <ArrowL s={12}/>
            </button>
            <button onClick={() => setIdx(i => Math.min(QUEUE.length - 1, i + 1))}
                    disabled={idx === QUEUE.length - 1}
                    className="w-6 h-6 rounded inline-flex items-center justify-center"
                    style={{ color: idx === QUEUE.length - 1 ? "#D6D8DA" : SUB, background: "transparent" }}>
              <ArrowR s={12}/>
            </button>
          </div>
        </div>

        <div className="px-4 py-2 flex-1 flex flex-col">
          <div className="flex items-center gap-2 mb-2">
            <TaskBadge kind={t.kind}/>
            <span style={{ fontSize: 10.5, fontWeight: 600, color: SUB, letterSpacing: "0.06em", textTransform: "uppercase" }}>
              {t.kind === "estimate" ? "Estimate to confirm" : t.kind === "gap" ? "Information gap" : "Outside Decouple"}
            </span>
          </div>
          <div style={{ fontSize: 17, fontWeight: 600, color: INK, lineHeight: 1.25, letterSpacing: "-0.012em" }}>
            {t.title}
          </div>
          <div style={{ fontSize: 12.5, color: SUB, lineHeight: 1.6, marginTop: 8 }}>
            {t.body}
          </div>

          {t.kind === "estimate" && (
            <div className="mt-4 p-3 rounded-lg" style={{ background: PANEL, border: `1px solid ${LINE}` }}>
              <div className="flex items-baseline justify-between">
                <span style={{ fontSize: 11.5, color: MUTE, textTransform: "uppercase", letterSpacing: "0.06em", fontWeight: 600 }}>
                  Decouple's estimate
                </span>
                <span className="tabular-nums" style={{ fontSize: 18, fontWeight: 600, color: INK }}>
                  {t.value}<span style={{ fontSize: 11, color: MUTE, fontWeight: 500 }}> / mo</span>
                </span>
              </div>
              <div className="mt-2 flex items-center gap-1">
                <input type="text" placeholder="Or enter your figure"
                       className="flex-1 h-7 px-2 rounded text-[12px] tabular-nums"
                       style={{ background: PAPER, border: `1px solid ${LINE}`, color: INK }}/>
              </div>
            </div>
          )}

          {/* Why-it-matters */}
          <div className="mt-3 flex items-start gap-2 px-1">
            <Sparkle s={12} c={MUTE} style={{ marginTop: 2, flexShrink: 0 }}/>
            <div style={{ fontSize: 11.5, color: SUB, lineHeight: 1.5 }}>
              {t.impact}
            </div>
          </div>

          <div className="flex-1"/>

          {/* Primary action */}
          <div className="pt-3 flex items-center gap-2" style={{ borderTop: `1px solid ${LINE2}` }}>
            {t.kind === "estimate" && (
              <button onClick={() => setIdx(i => Math.min(QUEUE.length - 1, i + 1))}
                className="flex-1 h-[34px] rounded-md text-[12.5px] font-semibold inline-flex items-center justify-center gap-1.5"
                style={{ background: ACCENT, color: PAPER }}>
                <Check s={12} w={2.5}/> Confirm {t.value}
              </button>
            )}
            {t.kind === "gap" && (
              <button onClick={() => setIdx(i => Math.min(QUEUE.length - 1, i + 1))}
                className="flex-1 h-[34px] rounded-md text-[12.5px] font-semibold inline-flex items-center justify-center gap-1.5"
                style={{ background: AMBER_BG, color: AMBER_INK, border: `1px solid ${AMBER_BORDER}` }}>
                Categorise transactions
              </button>
            )}
            {t.kind === "doc" && (
              <button onClick={() => setIdx(i => Math.min(QUEUE.length - 1, i + 1))}
                className="flex-1 h-[34px] rounded-md text-[12.5px] font-semibold inline-flex items-center justify-center gap-1.5"
                style={{ background: PAPER, color: INK, border: `1px solid ${INK}` }}>
                Upload statement <ArrowOut s={11}/>
              </button>
            )}
            <button onClick={() => setIdx(i => Math.min(QUEUE.length - 1, i + 1))}
              className="h-[34px] px-2.5 rounded-md text-[11.5px] font-medium"
              style={{ color: SUB, background: "transparent" }}>
              Skip
            </button>
          </div>
        </div>
      </div>

      {/* Mini-queue indicator */}
      <div className="px-4 py-2 flex items-center gap-1" style={{ borderTop: `1px solid ${LINE}` }}>
        {QUEUE.map((_, i) => (
          <button key={i} onClick={() => setIdx(i)}
            className="flex-1 h-[3px] rounded-full"
            style={{ background: i === idx ? INK : (i < idx ? ACCENT : "#E6E7E9") }}/>
        ))}
      </div>

      <PanelFooter total={24} doneAll={9}/>
    </div>
  );
}

/* ============================================================
   VARIATION D — In-context inline (no rail; tasks pinned to rows)
   Demonstrates the alternative where tasks live INSIDE the doc.
   ============================================================ */
function VariationD() {
  // Mini reproduction of the Outgoings list with inline task chips.
  const ROWS = [
    { icon: "🏠", title: "Household utilities & maintenance", val: "£300", task: "estimate" },
    { icon: "🏠", title: "Personal & living expenses",        val: "£380", task: "estimate" },
    { icon: "🏠", title: "Transportation costs",              val: "£560", task: null },
    { icon: "👶", title: "Child expenses (nursery, clothing)",val: "£400", task: "estimate", flag: true },
    { icon: "🏠", title: "Leisure & other (gym, cinema)",     val: "£250", task: "estimate" }
  ];
  return (
    <div style={{ width: 540, background: PAPER, border: `1px solid ${LINE}`, borderRadius: 12, padding: 24 }}>
      <div className="flex items-baseline gap-3 mb-4">
        <span className="label-xs tabular-nums" style={{ color: MUTE, width: 22 }}>§8</span>
        <h2 style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em", color: INK }}>Outgoings</h2>
        <span style={{ fontSize: 12, color: MUTE }}>— 12-month average from connected accounts</span>
      </div>

      {/* Section-level callout */}
      <div className="mb-3 p-3 rounded-lg flex items-start gap-2.5"
           style={{ background: "#F8F6F1", border: `1px solid #ECE7DA` }}>
        <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
              style={{ width: 22, height: 22, background: "#FFF3DD", color: "#7A4F00", fontSize: 12, fontWeight: 700 }}>!</span>
        <div className="flex-1">
          <div style={{ fontSize: 13, fontWeight: 600, color: "#5C3B00" }}>
            4 things to resolve in this section
          </div>
          <div style={{ fontSize: 12, color: "#7A5821", lineHeight: 1.55, marginTop: 2 }}>
            We've estimated some figures from your bank data. Confirm or edit each one below.
          </div>
        </div>
        <button className="h-[26px] px-2.5 rounded-md text-[11.5px] font-semibold whitespace-nowrap"
                style={{ background: PAPER, color: "#5C3B00", border: `1px solid #ECE7DA` }}>
          Resolve all
        </button>
      </div>

      {/* Rows w/ inline tasks */}
      <div>
        {ROWS.map((r, i) => (
          <div key={i} className="py-2.5"
               style={{ borderBottom: i < ROWS.length - 1 ? `1px dashed ${LINE}` : "none", background: r.flag ? "#FCFAF4" : "transparent" }}>
            <div className="flex items-center gap-3">
              <span style={{ fontSize: 14, width: 16 }}>{r.icon}</span>
              <span style={{ fontSize: 14, color: INK, flex: 1 }}>{r.title}</span>
              <span className="tabular-nums" style={{ fontSize: 14, fontWeight: 500, color: INK }}>{r.val} / mo</span>
              {r.task === "estimate" && (
                <span className="inline-flex items-center rounded-full"
                      style={{ background: SELF_BG, color: SELF_FG, fontSize: 10.5, fontWeight: 600, padding: "2px 8px", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                  estimate
                </span>
              )}
            </div>
            {r.task === "estimate" && (
              <div className="flex items-center gap-1.5 mt-1.5" style={{ paddingLeft: 28 }}>
                <button className="h-[24px] px-2.5 rounded-md text-[11px] font-semibold inline-flex items-center gap-1"
                        style={{ background: ACCENT_BG, color: ACCENT, border: `1px solid #D5E5DF` }}>
                  <Check s={10} w={2.5}/> Confirm
                </button>
                <button className="h-[24px] px-2 rounded-md text-[11px] font-medium inline-flex items-center gap-1"
                        style={{ background: "transparent", color: SUB }}>
                  <Pencil s={10}/> Edit
                </button>
                <span style={{ fontSize: 11, color: MUTE }}>· based on 12 months of transactions</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ====================================================================
   Spec / annotation card explaining the contextual behaviour
   ====================================================================*/
function SpecCard() {
  return (
    <div style={{ width: 360, padding: 24, background: PAPER, border: `1px solid ${LINE}`, borderRadius: 12, color: INK }}>
      <div className="label-xs mb-2" style={{ color: MUTE }}>Brief</div>
      <h3 style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em" }}>Contextual to-do panel</h3>
      <p style={{ fontSize: 13, color: SUB, lineHeight: 1.6, marginTop: 8 }}>
        The dashboard shows <b style={{ color: INK }}>all</b> of Sarah's open to-dos.
        On a section page like <b style={{ color: INK }}>Your Picture · Outgoings</b>, the right rail
        narrows to just the to-dos that belong to <em>this</em> section, so Sarah can
        clear them where she's already working.
      </p>

      <div className="mt-5 label-xs" style={{ color: MUTE }}>Behaviour</div>
      <ul style={{ fontSize: 12.5, color: INK, lineHeight: 1.65, marginTop: 6, paddingLeft: 18, listStyleType: "disc" }}>
        <li>Anchored to the section currently in view (scroll-spied).</li>
        <li>Three task types — <b>estimate</b> (✎), <b>gap</b> (!), <b>outside</b> (↗).</li>
        <li>Resolutions update the section live; both the panel and the row reflect the change.</li>
        <li>Footer link returns to the dashboard's full to-do panel.</li>
      </ul>

      <div className="mt-5 label-xs" style={{ color: MUTE }}>Variations</div>
      <div className="mt-2 space-y-2.5">
        {[
          ["A · Stacked checklist", "Closest to the dashboard panel. Skim & tick."],
          ["B · Inline-resolve cards", "Each task carries its own resolution UI. Higher density of action."],
          ["C · Triage queue", "Single-focus, AI-ordered. Best when items are non-trivial."],
          ["D · Inline (no rail)", "Reference: tasks pinned to their rows in the doc itself."]
        ].map(([t, s]) => (
          <div key={t}>
            <div style={{ fontSize: 12.5, fontWeight: 600, color: INK }}>{t}</div>
            <div style={{ fontSize: 11.5, color: SUB, lineHeight: 1.5 }}>{s}</div>
          </div>
        ))}
      </div>

      <div className="mt-5 p-3 rounded-lg" style={{ background: AMBER_BG, border: `1px solid ${AMBER_BORDER}` }}>
        <div style={{ fontSize: 11.5, fontWeight: 600, color: AMBER_INK, textTransform: "uppercase", letterSpacing: "0.05em" }}>Open question</div>
        <div style={{ fontSize: 12, color: AMBER_INK2, lineHeight: 1.55, marginTop: 4 }}>
          Should the rail follow scroll position (refreshing as Sarah moves through sections), or pin to whichever section she clicked first? A or B feels right; happy to mock both.
        </div>
      </div>
    </div>
  );
}

window.SectionTodos_VariationA = VariationA;
window.SectionTodos_VariationB = VariationB;
window.SectionTodos_VariationC = VariationC;
window.SectionTodos_VariationD = VariationD;
window.SectionTodos_SpecCard = SpecCard;

})();
