/* Three layouts wrapping <PictureDoc/> + version-history popover.
   Layout A — Full Rail (with right side panel)
   Layout B — Icon Rail (hover to expand · no right panel · timeline opens as side sheet)
   Layout C — Mobile (375px frame · bottom sheet for timeline)
*/
(function(){
const { useState, useEffect, useRef } = React;
const {
  Wordmark, ChevronRight, ChevronDown, ChevronLeft, MessageSquare, Check, Share, Edit,
  History, Plus, FileText, Home, Compass, LifeBuoy, Users, Dot, MenuIcon, XIcon,
  PictureDoc, VersionHistoryPopover, Timeline, PAvatar
} = window;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";

/* Same chapters list reused across layouts */
const CHAPTERS = [
  { n: 1, title: "The children",          items: 3, done: 3 },
  { n: 2, title: "The home",              items: 4, done: 4, gap: 1 },
  { n: 3, title: "Pensions",              items: 3, done: 1, gap: 1 },
  { n: 4, title: "Savings & investments", items: 4, done: 4 },
  { n: 5, title: "Vehicles & other",      items: 4, done: 4 },
  { n: 6, title: "Debts",                 items: 5, done: 5 },
  { n: 7, title: "Income",                items: 2, done: 2, gap: 1 },
  { n: 8, title: "Monthly spending",      items: 6, done: 6 },
  { n: 9, title: "Summary",               items: 6, done: 6 }
];

/* ============================================================
   Common version-history button (with popover)
   anchorRef so the popover knows where to attach
   ============================================================ */
function VersionHistoryButton({ onOpen, isOpen, anchorRef, compact }) {
  return (
    <button ref={anchorRef} onClick={onOpen}
      className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium transition"
      style={{
        borderColor: isOpen ? "#111" : LINE,
        background: isOpen ? "#111" : "#FFFFFF",
        color: isOpen ? "#FFFFFF" : INK
      }}>
      <History size={13}/>
      {!compact && <>Version history <ChevronDown size={11}/></>}
      {compact && <span className="tabular-nums">v0.8</span>}
    </button>
  );
}

/* ============================================================
   LAYOUT A — Full Rail (existing 3-col)
   ============================================================ */
function LayoutFull({ onOpenShare }) {
  const [mode, setMode] = useState("edit");
  const [active, setActive] = useState(1);
  const [vhOpen, setVhOpen] = useState(false);
  const [vhRect, setVhRect] = useState(null);
  const vhBtn = useRef(null);
  const containerRef = useRef(null);

  const openVh = () => {
    if (!vhBtn.current || !containerRef.current) return;
    const a = vhBtn.current.getBoundingClientRect();
    const c = containerRef.current.getBoundingClientRect();
    setVhRect({ left: a.left - c.left, right: a.right - c.left, top: a.top - c.top, bottom: a.bottom - c.top });
    setVhOpen(true);
  };

  return (
    <div ref={containerRef} className="flex flex-col h-full bg-white relative" style={{ overflow: "hidden" }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-5 flex-shrink-0"
           style={{ height: 56, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
        <div className="flex items-center gap-3">
          <Wordmark small/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <div className="flex items-center gap-1.5 text-[12.5px]" style={{ color: SUB }}>
            <span>Your picture</span>
            <ChevronRight size={12} style={{ color: "#D4D4D4" }}/>
            <span className="whitespace-nowrap" style={{ color: INK, fontWeight: 600 }}>Sarah's Picture</span>
            <span className="chip ml-1 whitespace-nowrap" style={{ background: "#FEF3C7", color: "#92400E" }}>v0.8 · DRAFT</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <ModeToggle mode={mode} setMode={setMode}/>
          <VersionHistoryButton anchorRef={vhBtn} isOpen={vhOpen} onOpen={openVh}/>
          <button onClick={onOpenShare}
                  className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-medium text-white"
                  style={{ background: DANGER }}>
            <Share size={13}/> Share with Mark
          </button>
          <div className="w-px h-5 mx-1" style={{ background: "#EFEFEF" }}/>
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold"
               style={{ background: ACCENT }}>SJ</div>
        </div>
      </div>

      <div className="flex-1 flex min-h-0">
        <ChapterRail active={active} setActive={setActive}/>
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFFFFF" }}>
          <PictureDoc editMode={mode === "edit"}/>
        </div>
        <RightSnapshot/>
      </div>

      {vhOpen && (
        <VersionHistoryPopover
          anchorRect={vhRect}
          onClose={() => setVhOpen(false)}
          side="bottom-right"
        />
      )}
    </div>
  );
}

function ModeToggle({ mode, setMode }) {
  return (
    <div className="inline-flex items-center rounded-md p-0.5"
         style={{ background: "#F3F4F6", border: `1px solid ${LINE}` }}>
      {[
        { k: "doc",  label: "Read", icon: <FileText size={12}/> },
        { k: "edit", label: "Edit", icon: <Edit size={12}/> }
      ].map(t => {
        const on = mode === t.k;
        return (
          <button key={t.k} onClick={() => setMode(t.k)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[11.5px] font-medium transition"
            style={{
              background: on ? "#FFFFFF" : "transparent",
              color: on ? INK : SUB,
              boxShadow: on ? "0 1px 2px rgba(0,0,0,0.06)" : "none"
            }}>
            {t.icon}{t.label}
          </button>
        );
      })}
    </div>
  );
}

/* Left chapter rail (full) */
function ChapterRail({ active, setActive }) {
  return (
    <div style={{ width: 240, background: "#FAFAFA", borderRight: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">
      <div className="px-4 py-3.5">
        <div className="label-xs mb-2" style={{ color: MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: INK }}>Sarah's Picture</div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full" style={{ width: "86%", background: ACCENT }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 11, color: ACCENT, fontWeight: 600 }}>86%</span>
        </div>
      </div>
      <div className="px-2 pb-3 flex-1 overflow-y-auto nice-scroll">
        {CHAPTERS.map(c => {
          const isActive = active === c.n;
          const complete = c.done === c.items && !c.gap;
          return (
            <button key={c.n} onClick={() => setActive(c.n)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{
                background: isActive ? "#EEF1F0" : "transparent",
                color: INK, fontSize: 12.5, fontWeight: isActive ? 600 : 500
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = "#F1F1F0"; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = "transparent"; }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: MUTE, width: 14 }}>{c.n}</span>
              <span className="flex-1 truncate">{c.title}</span>
              {c.gap ? (
                <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
                      style={{ width: 14, height: 14, background: "#FEF7E7",
                               color: "#92620A", fontSize: 10, fontWeight: 700 }}>!</span>
              ) : complete ? (
                <Check size={11} style={{ color: ACCENT }} strokeWidth={2.5}/>
              ) : null}
            </button>
          );
        })}
      </div>
      <div className="px-3 py-2.5 text-[11.5px] flex items-center gap-1.5"
           style={{ color: SUB, borderTop: `1px solid ${LINE}` }}>
        <LifeBuoy size={12}/> Get support
      </div>
    </div>
  );
}

/* Right snapshot (full) */
function RightSnapshot() {
  return (
    <div style={{ width: 320, background: "#FAFAFA", borderLeft: `1px solid ${LINE}` }}
         className="flex flex-col flex-shrink-0">
      <div className="p-4" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Snapshot</div>
        <div className="space-y-2">
          {[
            ["Net position", "£54,560", INK],
            ["Assets",       "£282,240", INK],
            ["Debts",        "(£227,680)", DANGER],
            ["Monthly gap",  "(£892)", DANGER]
          ].map(([k, v, c], i) => (
            <div key={i} className="flex items-baseline justify-between gap-2">
              <span className="whitespace-nowrap" style={{ fontSize: 12, color: SUB }}>{k}</span>
              <span className="tabular-nums whitespace-nowrap" style={{ fontSize: 13, fontWeight: 600, color: c }}>{v}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="p-4" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Data sources</div>
        <div className="space-y-1.5">
          {[
            ["Barclays",     "8 min ago",  "ok",      3],
            ["Monzo",        "8 min ago",  "ok",      1],
            ["Halifax",      "1 day ago",  "ok",      1],
            ["NHS Pensions", "Pending",    "pending", 0],
            ["HMRC",         "3 days ago", "ok",      1]
          ].map(([n, t, k, c], i) => {
            const pending = k === "pending";
            return (
              <div key={i} className="flex items-center gap-1.5 min-w-0">
                <span className="inline-block w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ background: pending ? "#E5B048" : ACCENT }}/>
                <span className="whitespace-nowrap flex-shrink-0" style={{ fontSize: 12, color: INK, fontWeight: 500 }}>{n}</span>
                {c > 0 && <span className="tabular-nums whitespace-nowrap flex-shrink-0" style={{ fontSize: 10.5, color: MUTE }}>· {c} {c === 1 ? "acct" : "accts"}</span>}
                <span className="flex-1"/>
                <span className="whitespace-nowrap flex-shrink-0" style={{ fontSize: 10.5, color: pending ? "#B45309" : MUTE, fontWeight: pending ? 600 : 400 }}>{t}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="p-4 flex-1">
        <div className="label-xs mb-2" style={{ color: MUTE }}>Needs your attention</div>
        {[
          ["NHS CETV figure", "Awaiting provider response"],
          ["Property valuation", "Currently a self-estimate"],
          ["Recent payslip", "Needed for finalisation"]
        ].map(([t, s], i) => (
          <button key={i} className="w-full flex items-start gap-2 py-2 text-left rounded-md px-1 hover:bg-[#F1F1F0]"
                  style={{ borderBottom: `1px dashed ${LINE}` }}>
            <span className="inline-flex items-center justify-center rounded-full flex-shrink-0 mt-0.5"
                  style={{ width: 14, height: 14, background: "#FEF7E7",
                           color: "#92620A", fontSize: 10, fontWeight: 700 }}>!</span>
            <div className="flex-1 min-w-0">
              <div style={{ fontSize: 12.5, fontWeight: 500, color: INK }}>{t}</div>
              <div style={{ fontSize: 11, color: MUTE, lineHeight: 1.4, marginTop: 1 }}>{s}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   LAYOUT B — Icon Rail (hover-to-expand)
   No right panel by default. Version history opens as a SIDE SHEET on the right.
   ============================================================ */
function LayoutIconRail({ onOpenShare }) {
  const [mode, setMode] = useState("edit");
  const [active, setActive] = useState(1);
  const [expanded, setExpanded] = useState(false);
  const [vhOpen, setVhOpen] = useState(false);

  return (
    <div className="flex flex-col h-full bg-white relative" style={{ overflow: "hidden" }}>
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 flex-shrink-0"
           style={{ height: 52, borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
        <div className="flex items-center gap-2.5">
          <Wordmark small/>
          <span style={{ color: "#E5E7EB" }}>/</span>
          <span className="whitespace-nowrap" style={{ fontSize: 12.5, color: INK, fontWeight: 600 }}>Sarah's Picture</span>
          <span className="chip whitespace-nowrap" style={{ background: "#FEF3C7", color: "#92400E" }}>v0.8 · DRAFT</span>
        </div>
        <div className="flex items-center gap-2">
          <ModeToggle mode={mode} setMode={setMode}/>
          <button onClick={() => setVhOpen(o => !o)}
            className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-md border text-[12.5px] font-medium transition"
            style={{
              borderColor: vhOpen ? "#111" : LINE,
              background: vhOpen ? "#111" : "#FFFFFF",
              color: vhOpen ? "#FFFFFF" : INK
            }}>
            <History size={13}/> v0.8
          </button>
          <button onClick={onOpenShare}
            className="inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-[12.5px] font-medium text-white"
            style={{ background: DANGER }}>
            <Share size={13}/> Share
          </button>
          <div className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[11px] font-semibold"
               style={{ background: ACCENT }}>SJ</div>
        </div>
      </div>

      <div className="flex-1 flex min-h-0 relative">
        {/* Icon rail */}
        <div
          onMouseEnter={() => setExpanded(true)}
          onMouseLeave={() => setExpanded(false)}
          style={{
            width: expanded ? 240 : 56,
            background: "#FAFAFA",
            borderRight: `1px solid ${LINE}`,
            transition: "width 220ms cubic-bezier(.2,.8,.2,1)",
            zIndex: 5,
            position: "relative",
            overflow: "hidden"
          }}
          className="flex flex-col flex-shrink-0">
          {expanded ? (
            <ChapterRailInner active={active} setActive={setActive}/>
          ) : (
            <CompressedRail active={active} setActive={setActive}/>
          )}
        </div>

        {/* Document */}
        <div className="flex-1 overflow-y-auto nice-scroll" style={{ background: "#FFFFFF" }}>
          <PictureDoc editMode={mode === "edit"}/>
        </div>

        {/* Side sheet — version history */}
        <div style={{
          width: vhOpen ? 420 : 0,
          background: "#FCFCFB",
          borderLeft: vhOpen ? `1px solid ${LINE}` : "none",
          transition: "width 240ms cubic-bezier(.2,.8,.2,1)",
          overflow: "hidden", flexShrink: 0
        }} className="flex flex-col">
          <div style={{ width: 420, height: "100%" }} className="flex flex-col">
            <div className="px-4 py-3 flex items-center gap-2 flex-shrink-0"
                 style={{ borderBottom: `1px solid ${LINE}`, background: "#FFFFFF" }}>
              <History size={14} style={{ color: SUB }}/>
              <span style={{ fontSize: 13, fontWeight: 600, color: INK }}>Version history</span>
              <span className="ml-auto"/>
              <button onClick={() => setVhOpen(false)} className="w-7 h-7 rounded-md hover:bg-[#F3F4F6] flex items-center justify-center">
                <XIcon size={14}/>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto nice-scroll p-4">
              <SideSheetTimeline width={420 - 32}/>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ChapterRailInner({ active, setActive }) {
  return (
    <>
      <div className="px-4 py-3.5">
        <div className="label-xs mb-2" style={{ color: MUTE }}>In this document</div>
        <div style={{ fontSize: 13, fontWeight: 600, color: INK }}>Sarah's Picture</div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-[4px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full" style={{ width: "86%", background: ACCENT }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 11, color: ACCENT, fontWeight: 600 }}>86%</span>
        </div>
      </div>
      <div className="px-2 pb-3 flex-1 overflow-y-auto nice-scroll">
        {CHAPTERS.map(c => {
          const isActive = active === c.n;
          const complete = c.done === c.items && !c.gap;
          return (
            <button key={c.n} onClick={() => setActive(c.n)}
              className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left transition mb-0.5"
              style={{
                background: isActive ? "#EEF1F0" : "transparent",
                color: INK, fontSize: 12.5, fontWeight: isActive ? 600 : 500
              }}>
              <span className="label-xs tabular-nums flex-shrink-0" style={{ color: MUTE, width: 14 }}>{c.n}</span>
              <span className="flex-1 truncate">{c.title}</span>
              {c.gap ? (
                <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
                      style={{ width: 14, height: 14, background: "#FEF7E7",
                               color: "#92620A", fontSize: 10, fontWeight: 700 }}>!</span>
              ) : complete ? <Check size={11} style={{ color: ACCENT }} strokeWidth={2.5}/> : null}
            </button>
          );
        })}
      </div>
    </>
  );
}

function CompressedRail({ active, setActive }) {
  return (
    <div className="flex-1 flex flex-col py-3 gap-1 items-center">
      <div className="text-[10px] tabular-nums font-bold mb-1.5" style={{ color: ACCENT }}>86%</div>
      {CHAPTERS.map(c => {
        const isActive = active === c.n;
        const complete = c.done === c.items && !c.gap;
        return (
          <button key={c.n} onClick={() => setActive(c.n)}
            title={`§${c.n} ${c.title}`}
            className="w-9 h-9 rounded-md flex items-center justify-center transition relative"
            style={{
              background: isActive ? "#EEF1F0" : "transparent",
              color: isActive ? INK : SUB
            }}>
            <span className="tabular-nums" style={{ fontSize: 12, fontWeight: 600 }}>{c.n}</span>
            {c.gap && <span className="absolute top-0.5 right-1 w-1.5 h-1.5 rounded-full" style={{ background: "#E5B048" }}/>}
            {complete && <span className="absolute top-0.5 right-1 w-1.5 h-1.5 rounded-full" style={{ background: ACCENT }}/>}
          </button>
        );
      })}
    </div>
  );
}

/* Side-sheet timeline — VERTICAL orientation, days running top→bottom.
   Better fit in a 420px column than the horizontal version.
*/
function SideSheetTimeline({ width }) {
  const { PHASES, VERSIONS, ACTS, PERSON } = window;
  const DAYS = ["8 Oct", "9 Oct", "10 Oct", "11 Oct", "12 Oct", "13 Oct"];
  const CELL_H = 56;
  const TODAY = 2;

  /* group activities by day */
  const byDay = {};
  ACTS.forEach(a => { (byDay[a.day] ||= []).push(a); });

  return (
    <div style={{ width, position: "relative" }}>
      <div className="label-xs mb-3" style={{ color: MUTE }}>Sarah's Picture · Past 6 days</div>

      {/* Phase swatches column header */}
      <div className="flex items-stretch gap-2 mb-3">
        {PHASES.map((p, i) => {
          const span = (p.end - p.start + 1);
          return (
            <div key={i} style={{
              flex: span,
              background: p.bg, color: p.fg,
              borderRadius: 999, padding: "4px 10px",
              fontSize: 11, fontWeight: 600
            }}>{p.name} · {span} days</div>
          );
        })}
      </div>

      {/* Timeline column */}
      <div style={{ position: "relative" }}>
        {/* vertical line */}
        <div style={{
          position: "absolute", left: 70, top: 8, bottom: 8,
          width: 1, background: "#E5E7EB"
        }}/>
        {DAYS.map((d, i) => {
          const isToday = i === TODAY;
          const acts = byDay[i] || [];
          const ver = VERSIONS.find(v => v.day === i);
          return (
            <div key={i} style={{
              position: "relative", minHeight: CELL_H,
              padding: "8px 0 8px 90px",
              background: isToday ? "rgba(0,0,0,0.025)" : "transparent",
              borderRadius: 6, marginLeft: -10, paddingLeft: 100
            }}>
              {/* Day label */}
              <div style={{
                position: "absolute", left: 0, top: 8,
                width: 64, textAlign: "right",
                fontSize: 11.5, color: isToday ? INK : SUB,
                fontWeight: isToday ? 700 : 500
              }}>{d}{isToday && <div style={{ fontSize: 9.5, color: MUTE, fontWeight: 500 }}>today</div>}</div>

              {/* Dot or version avatar */}
              <div style={{ position: "absolute", left: 70 - 6, top: 14 }}>
                {ver ? (
                  <PAvatar p={ver.person} size={20} ring={2}/>
                ) : (
                  <div className="rounded-full" style={{ width: 7, height: 7, background: "#D4D4D3", marginTop: 6, marginLeft: 2.5 }}/>
                )}
              </div>

              {/* Version label */}
              {ver && (
                <div className="mb-1.5 flex items-center gap-2">
                  <span className="tabular-nums" style={{ fontSize: 12, fontWeight: 600, color: INK }}>{ver.label}</span>
                  {ver.current && (
                    <span className="chip whitespace-nowrap" style={{
                      background: "#111", color: "#FFFFFF",
                      padding: "1.5px 6px", fontSize: 9.5, letterSpacing: "0.04em"
                    }}>CURRENT</span>
                  )}
                  <span style={{ fontSize: 11, color: MUTE }}>{ver.note}</span>
                </div>
              )}

              {/* Activity pills */}
              <div className="flex flex-wrap gap-1.5">
                {acts.map((a, j) => {
                  const person = PERSON[a.person];
                  return (
                    <div key={j} className="inline-flex items-center gap-1.5 px-1.5 py-0.5 rounded-full"
                         style={{ background: "#F1F1EE" }}>
                      <PAvatar p={a.person} size={14}/>
                      <span style={{ fontSize: 10.5, color: INK, fontWeight: 500 }}>{a.label.replace(person.name + " ", "")}</span>
                    </div>
                  );
                })}
                {!acts.length && !ver && (
                  <span style={{ fontSize: 11, color: MUTE, fontStyle: "italic" }}>No activity</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   LAYOUT C — Mobile (375 × 812 frame)
   ============================================================ */
function LayoutMobile({ onOpenShare }) {
  const [active, setActive] = useState(1);
  const [chapDrawer, setChapDrawer] = useState(false);
  const [vhSheet, setVhSheet] = useState(false);

  return (
    <div className="mx-auto relative bg-white"
         style={{
           width: 390, height: 760, borderRadius: 38,
           boxShadow: "0 6px 24px rgba(0,0,0,0.12), 0 0 0 12px #1A1A1A, 0 0 0 13px #2A2A2A",
           overflow: "hidden", marginTop: 20
         }}>
      {/* status bar */}
      <div className="flex items-center justify-between px-7 flex-shrink-0"
           style={{ height: 38, fontSize: 13, fontWeight: 600 }}>
        <span>9:41</span>
        <span className="flex items-center gap-1">
          <span style={{ fontSize: 11 }}>•••</span>
          <svg width="16" height="11" viewBox="0 0 16 11" fill="none">
            <path d="M1 8a7 7 0 0 1 14 0" stroke="#000" strokeWidth="1.2" strokeLinecap="round"/>
            <path d="M3.5 8a4.5 4.5 0 0 1 9 0" stroke="#000" strokeWidth="1.2" strokeLinecap="round"/>
            <circle cx="8" cy="8" r="1.2" fill="#000"/>
          </svg>
          <svg width="22" height="11" viewBox="0 0 22 11" fill="none">
            <rect x="0.5" y="0.5" width="18" height="10" rx="2.5" stroke="#000"/>
            <rect x="2" y="2" width="13" height="7" fill="#000" rx="1"/>
          </svg>
        </span>
      </div>

      {/* App top bar */}
      <div className="flex items-center justify-between px-4 flex-shrink-0"
           style={{ height: 50, borderBottom: `1px solid ${LINE}` }}>
        <button onClick={() => setChapDrawer(true)} className="w-8 h-8 rounded-md flex items-center justify-center hover:bg-[#F3F4F6]">
          <MenuIcon size={18}/>
        </button>
        <div className="flex flex-col items-center min-w-0">
          <span className="whitespace-nowrap truncate" style={{ fontSize: 13.5, fontWeight: 600, color: INK }}>Sarah's Picture</span>
          <button onClick={() => setVhSheet(true)} className="flex items-center gap-1">
            <span className="chip whitespace-nowrap" style={{ background: "#FEF3C7", color: "#92400E", fontSize: 9.5, padding: "1px 6px" }}>v0.8 · DRAFT</span>
          </button>
        </div>
        <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-[11px] font-semibold"
             style={{ background: ACCENT }}>SJ</div>
      </div>

      {/* Sticky progress strip + share */}
      <div className="px-4 py-2.5 flex items-center gap-3 flex-shrink-0"
           style={{ background: "#FAFAFA", borderBottom: `1px solid ${LINE}` }}>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline gap-1.5">
            <span className="tabular-nums" style={{ fontSize: 13, fontWeight: 600, color: INK }}>86%</span>
            <span style={{ fontSize: 11, color: SUB }}>· 2 gaps remaining</span>
          </div>
          <div className="mt-1 h-[3px] rounded-full overflow-hidden" style={{ background: "#E5E7EB" }}>
            <div className="h-full rounded-full" style={{ width: "86%", background: ACCENT }}/>
          </div>
        </div>
        <button onClick={onOpenShare}
                className="inline-flex items-center gap-1 h-7 px-2.5 rounded-md text-[11.5px] font-semibold text-white flex-shrink-0"
                style={{ background: DANGER }}>
          <Share size={11}/> Share
        </button>
      </div>

      {/* Document — scrollable */}
      <div className="overflow-y-auto nice-scroll" style={{ height: 760 - 38 - 50 - 53 - 56 }}>
        <MobileDoc/>
      </div>

      {/* Bottom tab bar */}
      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-around px-4"
           style={{ height: 56, borderTop: `1px solid ${LINE}`, background: "rgba(255,255,255,0.96)", backdropFilter: "blur(6px)" }}>
        <BotTab icon={<FileText size={18}/>} label="Document" active/>
        <BotTab icon={<History size={18}/>} label="History" onClick={() => setVhSheet(true)}/>
        <BotTab icon={<MessageSquare size={18}/>} label="Comments" badge="2"/>
        <BotTab icon={<Compass size={18}/>} label="More"/>
      </div>

      {/* Chapter drawer (left) */}
      {chapDrawer && (
        <div className="absolute inset-0 z-30" style={{ background: "rgba(15,18,22,0.45)" }} onClick={() => setChapDrawer(false)}>
          <div onClick={e => e.stopPropagation()}
               className="absolute top-0 left-0 bottom-0 bg-white flex flex-col"
               style={{ width: 300, boxShadow: "4px 0 24px rgba(0,0,0,0.18)" }}>
            <div className="px-4 py-3 flex items-center gap-2" style={{ borderBottom: `1px solid ${LINE}` }}>
              <span style={{ fontSize: 14, fontWeight: 600, color: INK }}>Chapters</span>
              <span className="ml-auto"/>
              <button onClick={() => setChapDrawer(false)} className="w-7 h-7 rounded-md flex items-center justify-center hover:bg-[#F3F4F6]">
                <XIcon size={14}/>
              </button>
            </div>
            <div className="overflow-y-auto nice-scroll p-2 flex-1">
              {CHAPTERS.map(c => {
                const isActive = active === c.n;
                const complete = c.done === c.items && !c.gap;
                return (
                  <button key={c.n} onClick={() => { setActive(c.n); setChapDrawer(false); }}
                    className="w-full flex items-center gap-2 px-3 py-2.5 rounded-md text-left mb-0.5"
                    style={{ background: isActive ? "#EEF1F0" : "transparent", fontSize: 13.5, fontWeight: isActive ? 600 : 500, color: INK }}>
                    <span className="label-xs tabular-nums flex-shrink-0" style={{ color: MUTE, width: 14 }}>{c.n}</span>
                    <span className="flex-1 truncate">{c.title}</span>
                    {c.gap ? (
                      <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
                            style={{ width: 16, height: 16, background: "#FEF7E7", color: "#92620A", fontSize: 10, fontWeight: 700 }}>!</span>
                    ) : complete ? <Check size={12} style={{ color: ACCENT }} strokeWidth={2.5}/> : null}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Version-history bottom sheet */}
      {vhSheet && (
        <div className="absolute inset-0 z-30 flex flex-col justify-end"
             style={{ background: "rgba(15,18,22,0.4)" }}
             onClick={() => setVhSheet(false)}>
          <div onClick={e => e.stopPropagation()}
               className="bg-white flex flex-col"
               style={{
                 height: "78%",
                 borderTopLeftRadius: 18, borderTopRightRadius: 18,
                 boxShadow: "0 -6px 28px rgba(0,0,0,0.2)"
               }}>
            <div className="pt-2 flex justify-center flex-shrink-0">
              <span style={{ width: 36, height: 4, background: "#D4D4D3", borderRadius: 4 }}/>
            </div>
            <div className="px-4 pt-3 pb-2 flex items-start gap-2 flex-shrink-0">
              <div className="flex-1">
                <div style={{ fontSize: 15, fontWeight: 600, color: INK }}>Version history</div>
                <div style={{ fontSize: 12, color: SUB, marginTop: 1 }}>4 versions · Approval phase</div>
              </div>
              <button onClick={() => setVhSheet(false)} className="w-7 h-7 rounded-md hover:bg-[#F3F4F6] flex items-center justify-center">
                <XIcon size={14}/>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto nice-scroll px-4 pb-6">
              <SideSheetTimeline width={358}/>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BotTab({ icon, label, active, badge, onClick }) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-0.5 relative" style={{ color: active ? INK : SUB }}>
      <div className="relative">
        {icon}
        {badge && (
          <span className="absolute -top-1 -right-2 inline-flex items-center justify-center rounded-full text-[9px] font-semibold text-white"
                style={{ minWidth: 14, height: 14, padding: "0 3px", background: DANGER }}>{badge}</span>
        )}
      </div>
      <span style={{ fontSize: 10, fontWeight: active ? 600 : 500 }}>{label}</span>
    </button>
  );
}

/* Mobile-tuned doc — same content, smaller padding */
function MobileDoc() {
  return (
    <div style={{ padding: "20px 18px 60px" }}>
      <div className="label-xs mb-2" style={{ color: MUTE }}>Phase 2 · Your financial picture</div>
      <h1 style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.18 }}>Sarah's Picture</h1>
      <p style={{ fontSize: 13, color: SUB, lineHeight: 1.55, marginTop: 6 }}>
        A structured record of what you own, owe, earn and spend. Based on 247 transactions across 12 months.
      </p>

      <MobileSection n={1} title="The children" status="complete">
        <MobileRow label="Emma · 7" value=""/>
        <MobileRow label="Jake · 4" value=""/>
        <MobileRow label="Bright Horizons nursery" value="£600 / mo" badge="bank"/>
      </MobileSection>

      <MobileSection n={2} title="The home" status="gap">
        <MobileRow label="Property value (est.)" value="£450,000" badge="self"/>
        <MobileRow label="Halifax mortgage" value="(£220,000)" badge="bank" negative/>
        <MobileRow label="Net equity" value="£230,000" bold/>
        <MobileGap title="Property value is an estimate" body="Three valuations recommended for settlement."/>
      </MobileSection>

      <MobileSection n={3} title="Pensions" status="gap">
        <MobileRow label="NHS Pension CETV" value="Pending" badge="gap"/>
        <MobileGap title="Awaiting CETV from NHS Pensions" body="Expected in 4–6 weeks. Updates automatically."/>
      </MobileSection>

      <MobileSection n={9} title="Summary" status="complete">
        <MobileRow label="Net position"      value="£54,560"  bold/>
        <MobileRow label="Total assets"      value="£282,240"/>
        <MobileRow label="Total debts"       value="(£227,680)" negative/>
        <MobileRow label="Monthly gap"       value="(£892) / mo" negative/>
      </MobileSection>

      <div className="mt-6 pt-4 text-[11px]" style={{ color: MUTE, borderTop: `1px solid ${LINE}`, lineHeight: 1.5 }}>
        Generated by Decouple · v0.8 · Private draft. Nothing is shared with Mark until you press Share.
      </div>
    </div>
  );
}

function MobileSection({ n, title, status, children }) {
  const dot = status === "gap" ? "#E5B048" : status === "complete" ? ACCENT : "#D4D4D3";
  return (
    <section className="mt-6">
      <div className="flex items-center gap-2 mb-2">
        <span className="label-xs tabular-nums" style={{ color: MUTE }}>§{n}</span>
        <h2 style={{ fontSize: 16, fontWeight: 600, color: INK }}>{title}</h2>
        <span className="ml-auto inline-block w-1.5 h-1.5 rounded-full" style={{ background: dot }}/>
      </div>
      <div className="pl-2.5" style={{ borderLeft: `2px solid ${LINE}` }}>{children}</div>
    </section>
  );
}
function MobileRow({ label, value, badge, negative, bold }) {
  return (
    <div className="flex items-baseline gap-2 py-1.5" style={{ borderBottom: `1px dashed ${LINE}` }}>
      {badge && <BadgeM kind={badge}/>}
      <span style={{ fontSize: 13, color: INK }} className="flex-1">{label}</span>
      {value && (
        <span className="tabular-nums whitespace-nowrap"
              style={{ fontSize: 13, fontWeight: bold ? 700 : 500, color: negative ? DANGER : INK }}>
          {value}
        </span>
      )}
    </div>
  );
}
function MobileGap({ title, body }) {
  return (
    <div className="mt-2 p-2.5 rounded-lg flex items-start gap-2"
         style={{ background: "#FEF7E7", border: "1px solid #F3D88A" }}>
      <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
            style={{ width: 16, height: 16, background: "#FEF7E7", color: "#92620A", fontSize: 11, fontWeight: 700, border: "1px solid #F3D88A" }}>!</span>
      <div>
        <div style={{ fontSize: 12.5, fontWeight: 600, color: "#92620A" }}>{title}</div>
        <div style={{ fontSize: 11.5, color: "#7A5307", lineHeight: 1.5, marginTop: 2 }}>{body}</div>
      </div>
    </div>
  );
}
function BadgeM({ kind }) {
  const map = {
    bank: { bg: "#E7F3EC", fg: "#0A6B39", glyph: "🏦" },
    self: { bg: "#EEF1F6", fg: "#4A5772", glyph: "✎" },
    gap:  { bg: "#FEF7E7", fg: "#92620A", glyph: "!" }
  };
  const b = map[kind];
  return (
    <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
          style={{ width: 16, height: 16, background: b.bg, color: b.fg, fontSize: 9.5, fontWeight: 700 }}>
      {b.glyph}
    </span>
  );
}

Object.assign(window, { LayoutFull, LayoutIconRail, LayoutMobile });
})();
