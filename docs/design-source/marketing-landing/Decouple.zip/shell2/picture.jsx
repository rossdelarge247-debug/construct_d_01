/* Your Picture — document content, sections, summary, share modal */
(function(){
const { useState } = React;

const INK = "#1A1A1A", SUB = "#5F6368", MUTE = "#9AA0A6", LINE = "#EAECEF", PAPER = "#FFFFFF";
const AMBER_BG = "#FEF7E7", AMBER_BORDER = "#F3D88A", AMBER_INK = "#92620A";
const ACCENT = "#2F6D5F", DANGER = "#E5484D";

/* ---- tiny icons ---- */
const I = (ch, p = {}) => (
  <svg width={p.s || 14} height={p.s || 14} viewBox="0 0 24 24" fill="none"
       stroke={p.c || "currentColor"} strokeWidth={p.w || 1.75}
       strokeLinecap="round" strokeLinejoin="round">{ch}</svg>
);
const ChevDown = (p) => I(<polyline points="6 9 12 15 18 9"/>, p);
const Pencil = (p) => I(<><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></>, p);
const Check = (p) => I(<polyline points="5 12 10 17 19 7"/>, p);
const XI = (p) => I(<><line x1="5" y1="5" x2="19" y2="19"/><line x1="19" y1="5" x2="5" y2="19"/></>, p);
const Arrow = (p) => I(<><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></>, p);
const Plus = (p) => I(<><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>, p);
const EyeS = (p) => I(<><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></>, p);

/* ---- trust badges ---- */
function Badge({ kind }) {
  const map = {
    bank: { bg: "#E7F3EC", fg: "#0A6B39", glyph: "🏦", label: "bank-evidenced" },
    self: { bg: "#EEF1F6", fg: "#4A5772", glyph: "✎",  label: "self-declared" },
    doc:  { bg: "#F1ECFA", fg: "#5A3EB8", glyph: "📄", label: "document" },
    gap:  { bg: AMBER_BG, fg: AMBER_INK, glyph: "!", label: "gap — info needed" }
  };
  const b = map[kind];
  return (
    <span title={b.label}
      className="inline-flex items-center justify-center rounded-full flex-shrink-0"
      style={{
        width: 18, height: 18, background: b.bg, color: b.fg,
        fontSize: kind === "gap" ? 11 : 10, fontWeight: 700, lineHeight: 1
      }}>
      {b.glyph}
    </span>
  );
}

/* ---- Row — value item inside a section ---- */
function Row({ label, value, badge, sub, editMode, onEdit, negative }) {
  const [hover, setHover] = useState(false);
  return (
    <div className="group flex items-baseline gap-3 py-2"
         onMouseEnter={() => setHover(true)}
         onMouseLeave={() => setHover(false)}
         style={{ borderBottom: `1px dashed ${LINE}` }}>
      <div className="flex items-center gap-2 flex-1 min-w-0">
        {badge && <Badge kind={badge}/>}
        <span style={{ fontSize: 14, color: INK }}>{label}</span>
        {sub && <span style={{ fontSize: 12, color: MUTE }}>· {sub}</span>}
      </div>
      <div className="flex items-center gap-2">
        <span className="tabular-nums" style={{
          fontSize: 14, fontWeight: 500,
          color: value ? (negative ? DANGER : INK) : MUTE,
          fontVariantNumeric: "tabular-nums"
        }}>
          {value || "—"}
        </span>
        {editMode && hover && onEdit && (
          <button onClick={onEdit}
            className="inline-flex items-center gap-1 h-6 px-2 rounded text-[11px] font-medium"
            style={{ background: "#F3F4F6", color: INK }}>
            <Pencil s={11}/> Edit
          </button>
        )}
      </div>
    </div>
  );
}

/* ---- Gap callout row ---- */
function GapRow({ title, body, editMode }) {
  return (
    <div className="mt-2 p-3 rounded-lg flex items-start gap-2.5"
         style={{ background: AMBER_BG, border: `1px solid ${AMBER_BORDER}` }}>
      <Badge kind="gap"/>
      <div className="flex-1">
        <div style={{ fontSize: 13, fontWeight: 600, color: AMBER_INK }}>{title}</div>
        <div style={{ fontSize: 12.5, color: "#7A5307", lineHeight: 1.55, marginTop: 2 }}>{body}</div>
      </div>
      {editMode && (
        <button className="flex-shrink-0 inline-flex items-center gap-1 h-7 px-2.5 rounded-md text-[11.5px] font-semibold"
                style={{ background: "#FFFFFF", color: AMBER_INK, border: `1px solid ${AMBER_BORDER}` }}>
          <Plus s={11}/> Add information
        </button>
      )}
    </div>
  );
}

/* ---- Section wrapper (collapsible) ---- */
function Section({ n, title, meta, defaultOpen = true, children }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section id={`sec-${n}`} className="mb-6">
      <button onClick={() => setOpen(!open)}
              className="w-full flex items-baseline gap-3 py-2 text-left group">
        <span className="label-xs tabular-nums" style={{ color: MUTE, width: 22 }}>§{n}</span>
        <h2 style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-0.01em", color: INK }}>{title}</h2>
        {meta && <span style={{ fontSize: 12, color: MUTE }}>— {meta}</span>}
        <span className="flex-1"/>
        <ChevDown s={14} c={MUTE} style={{ transform: open ? "none" : "rotate(-90deg)", transition: "transform 160ms" }}/>
      </button>
      {open && (
        <div className="pl-[34px] pr-1" style={{ borderLeft: `2px solid ${LINE}` }}>
          {children}
        </div>
      )}
      {!open && <div style={{ height: 1, background: LINE, marginTop: 4 }}/>}
    </section>
  );
}

/* ---- Subtitle line (e.g. dependent info) ---- */
function Line({ children, muted }) {
  return (
    <div style={{ fontSize: 14, lineHeight: 1.65, color: muted ? SUB : INK, padding: "3px 0" }}>
      {children}
    </div>
  );
}

/* ---- Money helpers ---- */
const M = (n) => `£${n.toLocaleString("en-GB")}`;
const Mneg = (n) => `(£${n.toLocaleString("en-GB")})`;

/* ========================================================= */
/*  The document body                                        */
/* ========================================================= */
function PictureDoc({ editMode }) {
  return (
    <div className="max-w-[720px] mx-auto px-10 py-10" style={{ color: INK }}>
      {/* Eyebrow + title */}
      <div className="mb-8 pb-6" style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs mb-2" style={{ color: MUTE }}>Phase 2 · Your financial picture</div>
        <h1 style={{ fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em", lineHeight: 1.15 }}>
          Sarah's Picture
        </h1>
        <p style={{ fontSize: 14.5, color: SUB, lineHeight: 1.6, marginTop: 6, maxWidth: 560 }}>
          A structured record of what you own, owe, earn and spend, as of {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}.
          Based on 247 transactions across 12 months from your connected accounts, plus items you've added yourself.
        </p>
      </div>

      <Section n="1" title="The children" meta="2 dependents">
        <Line><b>Emma</b> (7) · <b>Jake</b> (4)</Line>
        <Line muted>Primary care: Sarah · Contact with Mark: to be agreed</Line>
        <Line muted>School: St Mary's Primary (state, no fees)</Line>
        <div className="mt-2">
          <Row label="Bright Horizons Nursery — childcare" value="£600 / month" badge="bank" editMode={editMode} onEdit={()=>{}}/>
        </div>
      </Section>

      <Section n="2" title="The home" meta="12 Oak Road, Exeter">
        <Line muted>Joint ownership with Mark · Sarah and children live here; Mark moved out.</Line>
        <div className="mt-2">
          <Row label="Value — estimated"   value={M(450000)}   badge="self" editMode={editMode} onEdit={()=>{}}/>
          <Row label="Mortgage (Halifax)"  value={Mneg(220000)} badge="bank" editMode={editMode} onEdit={()=>{}} negative/>
          <Row label="Net equity"          value={M(230000)}/>
          <Row label="Council tax — Exeter CC" value="£185 / month" badge="bank" editMode={editMode} onEdit={()=>{}}/>
        </div>
        <GapRow title="Property value is an estimate"
                body="For an accurate settlement figure we recommend three agent valuations, or a RICS survey."
                editMode={editMode}/>
      </Section>

      <Section n="3" title="Pensions">
        <Line><b>NHS Pension</b> — workplace, defined benefit</Line>
        <div className="mt-2">
          <Row label="Cash Equivalent Transfer Value (CETV)" value="Not yet received" badge="gap"/>
          <Row label="Status" value="Requested 2 weeks ago · expected in 4–6 weeks" sub="" badge="self"/>
          <Row label="Provider" value="NHS Pensions" badge="self"/>
        </div>
        <GapRow title="CETV is the most important pension figure for settlement"
                body="We'll update your picture automatically the moment the figure arrives from NHS Pensions."
                editMode={editMode}/>
      </Section>

      <Section n="4" title="Savings & investments">
        <Row label="Barclays joint current" value={M(2400)} sub="as of 31 March" badge="bank" editMode={editMode} onEdit={()=>{}}/>
        <Row label="Barclays savings"        value={M(8200)} badge="bank" editMode={editMode} onEdit={()=>{}}/>
        <Row label="Monzo (sole)"            value={M(1240)} badge="bank" editMode={editMode} onEdit={()=>{}}/>
        <Row label="Hargreaves Lansdown ISA" value={M(6000)} badge="self" editMode={editMode} onEdit={()=>{}}/>
      </Section>

      <Section n="5" title="Vehicles & other assets">
        <Line><b>Ford Escort</b> (2019) · Registered to Sarah</Line>
        <div className="mt-2">
          <Row label="Value — estimated"     value={M(8000)}   badge="self" editMode={editMode} onEdit={()=>{}}/>
          <Row label="BMW Finance — balance" value={Mneg(4200)} badge="bank" editMode={editMode} onEdit={()=>{}} negative/>
          <Row label="Net value"             value={M(3800)}/>
        </div>
        <div className="mt-5">
          <Line><b>Life insurance</b> · Legal &amp; General (term life)</Line>
          <div className="mt-2">
            <Row label="Surrender value" value={M(4500)} badge="self" editMode={editMode} onEdit={()=>{}}/>
          </div>
        </div>
      </Section>

      <Section n="6" title="Debts">
        <Row label="Mortgage (see §2 The home)" value={Mneg(220000)} badge="bank" negative/>
        <Row label="Barclaycard — balance"      value={Mneg(3200)}  badge="self" editMode={editMode} onEdit={()=>{}} negative/>
        <Row label="Barclaycard — monthly payment" value="£85 / month" badge="bank"/>
        <Row label="BMW Finance (see §5 Vehicles)" value={Mneg(4200)} badge="bank" negative/>
        <Row label="Klarna"                     value={Mneg(280)}   badge="bank" editMode={editMode} onEdit={()=>{}} negative/>
        <div className="flex items-baseline justify-between pt-3 mt-2" style={{ borderTop: `1px solid ${LINE}` }}>
          <span style={{ fontSize: 13.5, fontWeight: 600, color: INK }}>Total non-mortgage debt</span>
          <span className="tabular-nums" style={{ fontSize: 15, fontWeight: 600, color: DANGER }}>{Mneg(7680)}</span>
        </div>
      </Section>

      <Section n="7" title="Income">
        <Row label="Employment — NHS (net)"    value="£2,400 / month" badge="bank" editMode={editMode} onEdit={()=>{}}/>
        <Row label="Child Benefit — HMRC"      value="£96 / 4-weekly" badge="bank"/>
        <div className="flex items-baseline justify-between pt-3 mt-2" style={{ borderTop: `1px solid ${LINE}` }}>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>Total monthly income</span>
          <span className="tabular-nums" style={{ fontSize: 15, fontWeight: 600 }}>£2,496</span>
        </div>
        <GapRow title="Gross salary and tax details"
                body="For finalisation we'll need a recent payslip and P60 — upload when convenient."
                editMode={editMode}/>
      </Section>

      <Section n="8" title="Monthly spending" meta="12-month average from connected accounts">
        <SpendRow cat="Housing"   sub="mortgage · council tax · insurance"    amt="£1,377" pct={41}/>
        <SpendRow cat="Utilities" sub="gas · electric · water"                amt="£168"   pct={5}/>
        <SpendRow cat="Children"  sub="nursery · school · activities"         amt="£680"   pct={20}/>
        <SpendRow cat="Transport" sub="fuel · car insurance · MOT"            amt="£220"   pct={6.5}/>
        <SpendRow cat="Personal"  sub="groceries · clothing · health"         amt="£630"   pct={19}/>
        <SpendRow cat="Leisure"   sub="dining · holidays · subscriptions"     amt="£313"   pct={9}/>
        <div className="flex items-baseline justify-between pt-3 mt-2" style={{ borderTop: `1px solid ${LINE}` }}>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>Total monthly spending</span>
          <span className="tabular-nums" style={{ fontSize: 15, fontWeight: 600 }}>£3,388</span>
        </div>
        <div className="mt-3 p-3 rounded-lg flex items-start gap-2.5"
             style={{ background: "#F4F7FB", border: `1px solid #DCE4F0` }}>
          <span className="inline-flex items-center justify-center rounded-full flex-shrink-0"
                style={{ width: 18, height: 18, background: "#DCE4F0", color: "#1E4080", fontSize: 11, fontWeight: 700 }}>i</span>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#1E4080" }}>
              Spending exceeds income by £892 / month
            </div>
            <div style={{ fontSize: 12.5, color: "#3557A0", lineHeight: 1.55, marginTop: 2 }}>
              This figure is relevant for maintenance discussions. It doesn't yet include any contribution from Mark.
            </div>
          </div>
        </div>
      </Section>

      <Section n="9" title="Summary" meta="Your half only — Mark's picture not yet included">
        <div className="grid grid-cols-2 gap-x-8 gap-y-1 py-2">
          <Row label="Total assets"         value={M(282240)} />
          <Row label="Total debts"          value={Mneg(227680)} negative/>
          <Row label="Net position"         value={M(54560)} />
          <Row label="Monthly income"       value="£2,496"/>
          <Row label="Monthly spending"     value="£3,388"/>
          <Row label="Gap"                  value="(£892) / mo" negative/>
        </div>
      </Section>

      <div className="mt-8 pt-5 text-[11.5px]" style={{ color: MUTE, borderTop: `1px solid ${LINE}` }}>
        Generated by Decouple on {new Date().toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}
        · v0.8 · Private draft · Nothing on this page is shared with Mark until you press <b>Share with Mark</b>.
      </div>
    </div>
  );
}

function SpendRow({ cat, sub, amt, pct }) {
  return (
    <div className="py-2" style={{ borderBottom: `1px dashed ${LINE}` }}>
      <div className="flex items-baseline justify-between gap-3">
        <div className="flex-1">
          <div style={{ fontSize: 14, color: INK }}>{cat}</div>
          <div style={{ fontSize: 12, color: MUTE, marginTop: 1 }}>{sub}</div>
        </div>
        <div className="flex items-center gap-2" style={{ minWidth: 160 }}>
          <div className="h-[4px] rounded-full overflow-hidden flex-1" style={{ background: "#F1F3F5" }}>
            <div className="h-full rounded-full" style={{ width: pct * 2 + "%", background: "#C9D1D9" }}/>
          </div>
          <span className="tabular-nums" style={{ fontSize: 13.5, fontWeight: 500, minWidth: 56, textAlign: "right" }}>{amt}</span>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { PictureDoc, Badge, Pencil, Check, XI, Arrow, Plus, EyeS, M, Mneg, ChevDown });
})();
