/* =========================================================================
   TRUST SIGNALS BAND
   ========================================================================= */
function TrustCardsBand() {
  const cards = [
    {
      icon: Shield,
      label: "Regulated",
      copy: "Bank connection is FCA-regulated via TrueLayer. We can read transactions but cannot move money. Read-only. Disconnect anytime."
    },
    {
      icon: Compass,
      label: "Built with experts",
      copy: "Designed alongside separating couples, family lawyers, and mediators. Reviewed for legal accuracy. Pre-flight checked against court requirements."
    },
    {
      icon: Lock,
      label: "Your data, your control",
      copy: "End-to-end encryption. Granular sharing — you decide what your ex sees. Deletable on request."
    },
  ];
  return (
    <section aria-labelledby="trust-h"
             style={{ paddingTop: 100, paddingBottom: 100 }}>
      <div className="mx-auto px-8" style={{ maxWidth: 1240 }}>
        <h2 id="trust-h" className="sr-only">Trust</h2>
        <div className="grid gap-5" style={{ gridTemplateColumns: "repeat(3, minmax(0, 1fr))" }}>
          {cards.map((c, i) => {
            const Icon = c.icon;
            return (
              <div key={c.label}
                   className={"sec-in sec-in-" + Math.min(i+1, 4)}
                   style={{
                     background: PANEL,
                     border: `1px solid ${LINE}`,
                     borderRadius: 14,
                     padding: "26px 26px 28px",
                   }}>
                <div className="flex items-center justify-center"
                     style={{
                       width: 36, height: 36, borderRadius: 9,
                       background: CANVAS, border: `1px solid ${LINE}`,
                       color: INK
                     }}>
                  <Icon size={17} sw={1.7}/>
                </div>
                <div className="serif mt-5"
                     style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.015em" }}>
                  {c.label}
                </div>
                <p className="mt-3" style={{ fontSize: 13.5, lineHeight: 1.6, color: SUB }}>
                  {c.copy}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

window.TrustCardsBand = TrustCardsBand;
