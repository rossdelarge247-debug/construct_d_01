/* =========================================================================
   STICKY HEADER · shrinks on scroll past hero
   ========================================================================= */
function Header({ shrunk, onSetState }) {
  return (
    <header
      role="banner"
      className={"sticky top-0 z-40 transition-all duration-200 ease-out " + (shrunk ? "hdr-shrink" : "")}
      style={{
        height: 78,
        background: "rgba(245,245,244,0.92)",
        backdropFilter: "blur(14px)",
        borderBottom: shrunk ? `1px solid ${LINE}` : "1px solid transparent"
      }}>
      <div className="mx-auto h-full px-8 flex items-center justify-between"
           style={{ maxWidth: 1240 }}>
        <a href="#top" className="flex items-center gap-2">
          <Wordmark size={shrunk ? 15 : 17}/>
        </a>

        <nav aria-label="Primary" className="hidden md:flex items-center gap-7"
             style={{ fontSize: 13.5, color: SUB }}>
          <a href="#picture" className="hover:text-[#1A1A1A]">The picture</a>
          <a href="#journey" className="hover:text-[#1A1A1A]">How it works</a>
          <a href="#compare" className="hover:text-[#1A1A1A]">Why us</a>
          <a href="#pricing" className="hover:text-[#1A1A1A]">Pricing</a>
        </nav>

        <div className="flex items-center gap-5">
          <a href="#signin"
             className="text-[13.5px]"
             style={{ color: SUB }}>
            Sign in
          </a>
          <a href="#start"
             className="cta-primary inline-flex items-center gap-2 rounded-full font-medium"
             style={{
               padding: shrunk ? "8px 16px" : "10px 18px",
               background: INK, color: "#FFF",
               fontSize: shrunk ? 12.5 : 13,
               border: `1px solid ${INK}`
             }}>
            Start your free plan
            <ArrowRight size={13}/>
          </a>
        </div>
      </div>
    </header>
  );
}

window.Header = Header;
