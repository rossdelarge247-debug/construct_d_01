/* =========================================================================
   HERO SECTION · full-bleed, generous, hero card offset right
   ========================================================================= */
function Hero() {
  return (
    <section id="hero" aria-labelledby="hero-h" className="relative" style={{ paddingTop: 72, paddingBottom: 96 }}>
      <div className="mx-auto px-8 grid gap-x-12" style={{ maxWidth: 1240, gridTemplateColumns: "minmax(0, 1.05fr) minmax(0, 0.95fr)" }}>

        {/* --- LEFT: copy --- */}
        <div className="sec-in sec-in-1" style={{ paddingTop: 12 }}>
          <Eyebrow>The complete settlement workspace for separating couples</Eyebrow>

          <h1 id="hero-h" className="serif mt-7"
              style={{
                fontSize: 76, fontWeight: 600, letterSpacing: "-0.035em",
                lineHeight: 1.02, color: INK, textWrap: "balance"
              }}>
            Sort out your<br/>
            complete separation —{" "}
            <span style={{ fontStyle: "italic", color: "#3F3F3F" }}>together</span>.
          </h1>

          <p className="serif mt-7"
             style={{
               fontSize: 23, lineHeight: 1.45, fontStyle: "italic",
               color: SUB, maxWidth: 560, fontWeight: 400, letterSpacing: "-0.005em"
             }}>
            Sort out finances, children, housing — all of it —
            for under £1,000 and in 3 months.
            Instead of £15,000 and 18 months.
          </p>

          <div className="mt-10 flex items-end gap-7 flex-wrap">
            <CTAPrimary/>
            <a href="#journey"
               className="inline-flex items-center gap-1.5 pb-1"
               style={{
                 fontSize: 14, color: INK,
                 borderBottom: `1px solid ${INK}`,
                 marginBottom: 8
               }}>
              How it works
              <ArrowDown size={14}/>
            </a>
          </div>

          <div className="mt-12 pt-7" style={{ borderTop: `1px solid ${LINE}`, maxWidth: 620 }}>
            <TrustBand/>
          </div>
        </div>

        {/* --- RIGHT: editorial product preview, offset right --- */}
        <div className="sec-in sec-in-2 relative" style={{ paddingTop: 30 }}>
          <HeroComposition/>
        </div>
      </div>
    </section>
  );
}

/* --- The "complete picture" composition: four areas around a central document spine --- */
function HeroComposition() {
  const Card = ({ label, sub, x, y, rot, w=180, accent }) => (
    <div className="absolute" style={{ left: x, top: y, width: w, transform: `rotate(${rot}deg)` }}>
      <div className="rounded-xl bg-white"
           style={{
             border: `1px solid ${LINE}`,
             boxShadow: "0 12px 28px rgba(26,26,26,0.06), 0 2px 6px rgba(26,26,26,0.04)",
             padding: 14
           }}>
        <div className="flex items-center gap-2 mb-2">
          <span style={{
            display: "inline-block", width: 7, height: 7, borderRadius: 99,
            background: accent
          }}/>
          <span className="label-xs" style={{ color: MUTE, fontSize: 9.5 }}>{label}</span>
        </div>
        <div className="serif" style={{ fontSize: 14, fontWeight: 600, color: INK, lineHeight: 1.25 }}>
          {sub.title}
        </div>
        <div className="mt-2 space-y-1.5">
          {sub.rows.map((r, i) => (
            <div key={i} className="flex items-center justify-between" style={{ fontSize: 11, color: SUB }}>
              <span>{r[0]}</span>
              <span className="mono tabular" style={{ color: INK, fontSize: 10.5 }}>{r[1]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative" style={{ height: 560 }}>
      {/* annotation */}
      <div className="absolute" style={{ right: 0, top: -10 }}>
        <PlaceholderTag>EDITORIAL · not a literal screenshot</PlaceholderTag>
      </div>

      {/* central document spine */}
      <div className="absolute"
           style={{
             left: "50%", top: 60, transform: "translateX(-50%)",
             width: 220, height: 460,
             background: "#FFFFFF",
             border: `1px solid ${LINE}`,
             borderRadius: 12,
             boxShadow: "0 18px 42px rgba(26,26,26,0.07), 0 2px 6px rgba(26,26,26,0.04)"
           }}>
        <div className="px-5 pt-6">
          <div className="label-xs" style={{ color: MUTE, fontSize: 9.5 }}>One document</div>
          <div className="serif mt-1.5" style={{ fontSize: 17, fontWeight: 600, lineHeight: 1.2, letterSpacing: "-0.01em" }}>
            The Settlement
          </div>
          <div className="serif italic mt-1" style={{ fontSize: 12.5, color: SUB }}>
            covering all four areas
          </div>
        </div>

        <div className="mx-5 mt-5 space-y-2.5">
          {[
            ["§1", "Finances", "#4338CA"],
            ["§2", "Children", "#9D174D"],
            ["§3", "Housing", "#0369A1"],
            ["§4", "Future needs", "#166534"],
          ].map(([n, t, c]) => (
            <div key={t} className="flex items-center gap-2.5 py-1.5 px-2 rounded-md"
                 style={{ background: CANVAS, border: `1px solid ${LINE}` }}>
              <span className="mono" style={{ fontSize: 10, color: c, fontWeight: 600 }}>{n}</span>
              <span style={{ fontSize: 12, color: INK, flex: 1 }}>{t}</span>
              <Check size={11} sw={2.4} style={{ color: c }}/>
            </div>
          ))}
        </div>

        <div className="mx-5 mt-5 pt-4" style={{ borderTop: `1px solid ${LINE}` }}>
          <div className="flex items-center justify-between" style={{ fontSize: 10.5, color: MUTE }}>
            <span>Court-ready</span>
            <span className="mono">v1 · draft</span>
          </div>
          <div className="mt-3 flex items-center gap-1.5">
            {Array.from({length: 14}).map((_, i) => (
              <span key={i} style={{
                flex: 1, height: 3, borderRadius: 2,
                background: i < 9 ? INK : "#E5E3DC"
              }}/>
            ))}
          </div>
        </div>
      </div>

      {/* four interdependent cards orbiting */}
      <Card label="Area 01"
            accent="#4338CA"
            x={-30} y={20} rot={-5} w={185}
            sub={{ title: "Finances", rows: [["Assets", "£612,400"], ["Pensions", "£148,200"], ["Debts", "£42,180"]] }}/>
      <Card label="Area 02"
            accent="#9D174D"
            x={310} y={0} rot={4} w={180}
            sub={{ title: "Children", rows: [["Living", "Shared 60/40"], ["Holidays", "Alternating"], ["Schools", "Continued"]] }}/>
      <Card label="Area 03"
            accent="#0369A1"
            x={-12} y={340} rot={3} w={175}
            sub={{ title: "Housing", rows: [["Family home", "Sarah stays"], ["Move date", "12 months"], ["Mortgage", "Refinanced"]] }}/>
      <Card label="Area 04"
            accent="#166534"
            x={300} y={360} rot={-3} w={195}
            sub={{ title: "Future needs", rows: [["Maintenance", "£1,200/mo · 5y"], ["Career restart", "Funded"], ["Pension share", "32%"]] }}/>

      {/* faint connection lines */}
      <svg className="absolute inset-0 pointer-events-none" width="100%" height="100%" aria-hidden>
        <defs>
          <pattern id="dots" width="2" height="2" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="0.5" fill="#A8A29E"/>
          </pattern>
        </defs>
      </svg>
    </div>
  );
}

window.Hero = Hero;
