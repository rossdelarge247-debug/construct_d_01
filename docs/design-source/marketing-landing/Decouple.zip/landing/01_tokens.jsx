/* =========================================================================
   TOKENS · shared across landing components
   ========================================================================= */
const INK   = "#1A1A1A";
const SUB   = "#57534E";
const MUTE  = "#78716C";
const SOFT  = "#A8A29E";
const LINE  = "#E5E3DC";
const BG    = "#F5F5F4";
const PANEL = "#FFFFFF";
const CANVAS= "#FAFAF7";
const WARM  = "#F5F3EE";

/* phase tints — used ONLY where we reference the phases themselves */
const PHASE = {
  start:    { ink: "#1A1A1A", soft: "#F5F3EE", num: "#78716C" },
  build:    { ink: "#4338CA", soft: "#EEF2FF", num: "#4338CA" },
  reconcile:{ ink: "#9D174D", soft: "#FCE7F3", num: "#9D174D" },
  settle:   { ink: "#0369A1", soft: "#E0F2FE", num: "#0369A1" },
  finalise: { ink: "#166534", soft: "#DCFCE7", num: "#166534" },
};

Object.assign(window, { INK, SUB, MUTE, SOFT, LINE, BG, PANEL, CANVAS, WARM, PHASE });
