/* =========================================================================
   THE COMPLETE PICTURE BAND · four equal cards, neutral
   ========================================================================= */
function PictureBand() {
  const cards = [
    { icon: Coins,    label: "Finances",
      copy: "Assets, debts, pensions, income, spending — auto-populated from your bank." },
    { icon: Children, label: "Children",
      copy: "Living arrangements, contact, holidays, schools — central, not a footnote." },
    { icon: Home,     label: "Housing",
      copy: "Who stays, who leaves, when. Interim arrangements. Future housing affordability." },
    { icon: Compass,  label: "Future needs",
      copy: "Post-separation budgets. Career restart. Pension implications. Maintenance." },
  ];
  return (
    <section id="picture" aria-labelledby="picture-h"
             style={{ paddingTop: 96, paddingBottom: 96, background: PANEL, borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}` }}>
      <div className="mx-auto px-8" style={{ maxWidth: 1240 }}>
        <div className="sec-in sec-in-1">
          <Eyebrow>The complete picture</Eyebrow>
          <h2 id="picture-h" className="serif mt-4"
              style={{ fontSize: 40, fontWeight: 600, letterSpacing: "-0.022em", lineHeight: 1.1, maxWidth: 820, textWrap: "balance" }}>
            A divorce settlement covers four interdependent areas.{" "}
            <span style={{ fontStyle: "italic", color: SUB }}>Decouple covers all of them.</span>
          </h2>
        </div>

        <div className="mt-14 grid gap-5"
             style={{ gridTemplateColumns: "repeat(4, minmax(0, 1fr))" }}>
          {cards.map((c, i) => {
            const Icon = c.icon;
            return (
              <div key={c.label}
                   className={"sec-in sec-in-" + Math.min(i+1, 4)}
                   style={{
                     background: CANVAS,
                     border: `1px solid ${LINE}`,
                     borderRadius: 14,
                     padding: "26px 24px 28px",
                     boxShadow: "0 1px 0 rgba(26,26,26,0.02)"
                   }}>
                <div className="flex items-center justify-center"
                     style={{
                       width: 36, height: 36, borderRadius: 9,
                       background: "#FFFFFF", border: `1px solid ${LINE}`,
                       color: INK
                     }}>
                  <Icon size={17} sw={1.6}/>
                </div>
                <div className="serif mt-5"
                     style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.015em", color: INK }}>
                  {c.label}
                </div>
                <p className="mt-3" style={{ fontSize: 13.5, lineHeight: 1.55, color: SUB }}>
                  {c.copy}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

window.PictureBand = PictureBand;
