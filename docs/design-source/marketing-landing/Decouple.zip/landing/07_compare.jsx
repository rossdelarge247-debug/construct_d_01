/* =========================================================================
   COST + TIME COMPARISON BAND
   ========================================================================= */
function CompareBand() {
  return (
    <section id="compare" aria-labelledby="compare-h"
             style={{ paddingTop: 100, paddingBottom: 100, background: PANEL, borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}` }}>
      <div className="mx-auto px-8" style={{ maxWidth: 1240 }}>
        <div className="sec-in sec-in-1" style={{ maxWidth: 820 }}>
          <Eyebrow>Why us</Eyebrow>
          <h2 id="compare-h" className="serif mt-4"
              style={{ fontSize: 40, fontWeight: 600, letterSpacing: "-0.022em", lineHeight: 1.1, textWrap: "balance" }}>
            Built to replace the{" "}
            <span style={{ fontStyle: "italic" }}>£14,561</span>{" "}
            solicitor-led divorce.
          </h2>
        </div>

        <div className="mt-14 grid gap-6"
             style={{ gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>

          {/* Conventional */}
          <div className="sec-in sec-in-2"
               aria-label="Conventional path: £14,561 average, 18 months, 20+ hours of paperwork, two solicitors"
               style={{
                 background: CANVAS,
                 border: `1px solid ${LINE}`,
                 borderRadius: 14,
                 padding: "32px 32px 28px"
               }}>
            <Eyebrow color={MUTE}>Conventional path</Eyebrow>
            <div className="serif mt-3"
                 style={{ fontSize: 56, fontWeight: 600, letterSpacing: "-0.03em", lineHeight: 1, color: SOFT }}>
              £14,561
            </div>
            <div style={{ fontSize: 13, color: MUTE, marginTop: 6 }}>average all-in cost</div>

            <div className="mt-8 grid gap-4" style={{ gridTemplateColumns: "1fr 1fr" }}>
              {[
                ["Time", "18 months"],
                ["Paperwork", "20+ hours"],
                ["Pictures", "Two — never reconciled"],
                ["Workspace", "Email + Word + post"],
              ].map(([k, v]) => (
                <div key={k} style={{ borderTop: `1px solid ${LINE}`, paddingTop: 10 }}>
                  <div className="label-xs" style={{ color: MUTE, fontSize: 9.5 }}>{k}</div>
                  <div className="mt-1" style={{ fontSize: 14, color: SUB }}>{v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Decouple */}
          <div className="sec-in sec-in-3"
               aria-label="Decouple: £800 to £1,100 all-in, 3 months typical, 15 minutes to a full picture, one shared workspace"
               style={{
                 background: PANEL,
                 border: `1.5px solid ${INK}`,
                 borderRadius: 14,
                 padding: "32px 32px 28px",
                 boxShadow: "0 8px 24px rgba(26,26,26,0.06)"
               }}>
            <div className="flex items-center justify-between">
              <Eyebrow color={INK}>Decouple</Eyebrow>
              <span className="label-xs" style={{ color: "#166534", fontSize: 9.5 }}>·  All-in</span>
            </div>
            <div className="serif mt-3"
                 style={{ fontSize: 56, fontWeight: 600, letterSpacing: "-0.03em", lineHeight: 1, color: INK }}>
              £800–£1,100
            </div>
            <div style={{ fontSize: 13, color: SUB, marginTop: 6 }}>including consent order generation</div>

            <div className="mt-8 grid gap-4" style={{ gridTemplateColumns: "1fr 1fr" }}>
              {[
                ["Time", "3 months typical"],
                ["To full picture", "15 minutes"],
                ["Picture", "One — shared, evidenced"],
                ["Workspace", "Decouple"],
              ].map(([k, v]) => (
                <div key={k} style={{ borderTop: `1px solid ${LINE}`, paddingTop: 10 }}>
                  <div className="label-xs" style={{ color: MUTE, fontSize: 9.5 }}>{k}</div>
                  <div className="mt-1" style={{ fontSize: 14, color: INK, fontWeight: 500 }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-8 label-xs" style={{ color: MUTE, fontSize: 10 }}>
          Sources: Resolution / Citizens Advice cost surveys, 2024. Decouple pricing is all-inclusive of consent order generation.
        </div>
      </div>
    </section>
  );
}

window.CompareBand = CompareBand;
