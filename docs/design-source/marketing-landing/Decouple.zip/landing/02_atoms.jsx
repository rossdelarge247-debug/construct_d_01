/* =========================================================================
   ATOMS · wordmark, icons, common pieces
   ========================================================================= */
const { useState, useEffect, useRef, useMemo } = React;

/* --- inline icon factory --- */
function Ic({ children, size = 16, sw = 1.75, style }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
         strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style} aria-hidden="true">
      {children}
    </svg>
  );
}
const ArrowRight = (p) => <Ic {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></Ic>;
const ArrowDown  = (p) => <Ic {...p}><line x1="12" y1="5" x2="12" y2="19"/><polyline points="6 13 12 19 18 13"/></Ic>;
const Plus       = (p) => <Ic {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></Ic>;
const Shield     = (p) => <Ic {...p}><path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z"/></Ic>;
const Lock       = (p) => <Ic {...p}><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></Ic>;
const Check      = (p) => <Ic {...p}><polyline points="5 12 10 17 19 7"/></Ic>;
const Coins      = (p) => <Ic {...p}><circle cx="9" cy="9" r="6"/><path d="M15 8a6 6 0 1 1 0 8"/></Ic>;
const Children   = (p) => <Ic {...p}><circle cx="12" cy="6" r="2.5"/><path d="M7 22v-7l-2-3 4-3 3 3 3-3 4 3-2 3v7"/></Ic>;
const Home       = (p) => <Ic {...p}><path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/></Ic>;
const Compass    = (p) => <Ic {...p}><circle cx="12" cy="12" r="9"/><polygon points="15 9 11 13 9 15 13 11"/></Ic>;
const ArrowUpRight = (p) => <Ic {...p}><line x1="7" y1="17" x2="17" y2="7"/><polyline points="9 7 17 7 17 15"/></Ic>;

/* --- Wordmark — same construction as Welcome Tour --- */
function Wordmark({ size = 18 }) {
  return (
    <div className="flex items-center gap-2 select-none" aria-label="Decouple">
      <div className="relative" style={{ width: size+4, height: size+4 }} aria-hidden>
        <div className="absolute inset-0 rounded-full" style={{ background: "#111" }}/>
        <div className="absolute rounded-full" style={{ left:"42%", top:0, width:"58%", height:"100%", background: BG }}/>
        <div className="absolute rounded-full" style={{ left:"45%", top:"12%", width:"10%", height:"76%", background:"#111" }}/>
      </div>
      <span style={{ fontSize: size, letterSpacing: "-0.01em", fontWeight: 600, color: "#111" }}>
        decouple
      </span>
    </div>
  );
}

/* --- Primary CTA pill, with C-V14 time-estimate sub-label --- */
function CTAPrimary({ label = "Start your free plan", time = "~3 minutes · no account needed", href="#start", size="lg", inverse=false }) {
  const padY = size === "lg" ? 16 : 12;
  const padX = size === "lg" ? 26 : 20;
  const fs   = size === "lg" ? 15 : 13.5;
  return (
    <div className="inline-flex flex-col items-start gap-2">
      <a href={href}
         className="cta-primary inline-flex items-center gap-2.5 rounded-full font-medium"
         style={{
           padding: `${padY}px ${padX}px`,
           background: inverse ? "#FFFFFF" : INK,
           color: inverse ? INK : "#FFFFFF",
           border: inverse ? `1px solid ${INK}` : `1px solid ${INK}`,
           fontSize: fs,
           letterSpacing: "-0.005em"
         }}>
        {label}
        <ArrowRight size={fs+2} sw={2}/>
      </a>
      <div className="flex items-center gap-2 pl-1" style={{ color: MUTE }}>
        <span className="mono tabular" style={{ fontSize: 11, letterSpacing: "0.02em" }}>{time}</span>
        <span className="kbd" style={{ marginLeft: 4 }}>↵</span>
      </div>
    </div>
  );
}

/* --- Trust band (C-V11) — three signals, dot-separated, centred --- */
function TrustBand() {
  return (
    <div className="flex items-center justify-center gap-x-5 gap-y-2 flex-wrap text-[12.5px]"
         style={{ color: SUB }}>
      <span className="flex items-center gap-2">
        <Shield size={13} sw={1.8} style={{ color: MUTE }}/>
        FCA-regulated bank connection via TrueLayer
      </span>
      <span style={{ width: 3, height: 3, borderRadius: 99, background: "#D6D3CC" }} aria-hidden/>
      <span className="flex items-center gap-2">
        <Lock size={13} sw={1.8} style={{ color: MUTE }}/>
        Read-only · we can't move money
      </span>
      <span style={{ width: 3, height: 3, borderRadius: 99, background: "#D6D3CC" }} aria-hidden/>
      <span className="flex items-center gap-2" style={{ color: INK, fontWeight: 500 }}>
        <Check size={13} sw={2.1} style={{ color: "#166534" }}/>
        Free until you choose to sign up
      </span>
    </div>
  );
}

/* --- Eyebrow / kicker --- */
function Eyebrow({ children, color = MUTE }) {
  return <div className="label-xs" style={{ color }}>{children}</div>;
}

/* --- Section header (smaller serif, italic accent option) --- */
function SectionHead({ eyebrow, children, max = 720 }) {
  return (
    <div style={{ maxWidth: max }}>
      {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
      <h2 className="serif"
          style={{
            fontSize: 38, fontWeight: 600, letterSpacing: "-0.022em",
            lineHeight: 1.1, color: INK, marginTop: eyebrow ? 14 : 0,
            textWrap: "balance"
          }}>
        {children}
      </h2>
    </div>
  );
}

/* --- Annotation tag (for placeholders) --- */
function PlaceholderTag({ children }) {
  return (
    <span className="mono"
          style={{
            fontSize: 10.5, letterSpacing: "0.04em",
            color: MUTE, background: "rgba(255,255,255,0.85)",
            padding: "3px 7px", borderRadius: 4,
            border: `1px solid ${LINE}`
          }}>
      {children}
    </span>
  );
}

Object.assign(window, {
  Ic, ArrowRight, ArrowDown, Plus, Shield, Lock, Check, Coins, Children, Home, Compass, ArrowUpRight,
  Wordmark, CTAPrimary, TrustBand, Eyebrow, SectionHead, PlaceholderTag
});
