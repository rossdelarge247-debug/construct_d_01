/* =========================================================================
   APP · orchestrator with state-toggle (Tweaks)
   ========================================================================= */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "view": "desktop",
  "scrolled": false,
  "faq_open_index": -1,
  "show_state_label": true
}/*EDITMODE-END*/;

function useTweaks(defaults) {
  const [tweaks, setTweaks] = useState(defaults);
  const update = (patch) => {
    setTweaks(prev => {
      const next = { ...prev, ...patch };
      try {
        window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
      } catch (e) {}
      return next;
    });
  };
  return [tweaks, update];
}

function StateLabel({ children }) {
  return (
    <div className="fixed left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full mono"
         style={{
           top: 14, background: "rgba(26,26,26,0.92)", color: "#FFF",
           fontSize: 10.5, letterSpacing: "0.06em", textTransform: "uppercase",
           backdropFilter: "blur(12px)"
         }}>
      {children}
    </div>
  );
}

function TweaksPanel({ tweaks, setTweak }) {
  const [show, setShow] = useState(false);
  const [pos, setPos] = useState({ x: 24, y: 24 });
  const dragRef = useRef(null);

  useEffect(() => {
    const onMsg = (e) => {
      const d = e.data || {};
      if (d.type === "__activate_edit_mode") setShow(true);
      else if (d.type === "__deactivate_edit_mode") setShow(false);
    };
    window.addEventListener("message", onMsg);
    try { window.parent.postMessage({ type: "__edit_mode_available" }, "*"); } catch (e) {}
    return () => window.removeEventListener("message", onMsg);
  }, []);

  if (!show) return null;

  const states = [
    { id: "desktop",         label: "1 · Default scroll (desktop)" },
    { id: "desktop-scrolled",label: "2 · Mid-scroll (header shrunk)" },
    { id: "desktop-faq",     label: "3 · FAQ open" },
    { id: "mobile",          label: "4 · Mobile reflow (375×667)" },
  ];

  return (
    <div className="fixed z-[60] rounded-xl"
         style={{
           right: 20, bottom: 20, width: 280,
           background: "#FFF", border: `1px solid ${LINE}`,
           boxShadow: "0 16px 48px rgba(0,0,0,0.18)"
         }}>
      <div className="flex items-center justify-between px-4 py-3"
           style={{ borderBottom: `1px solid ${LINE}` }}>
        <div className="label-xs" style={{ color: INK, fontSize: 10 }}>Tweaks</div>
        <button onClick={() => {
          setShow(false);
          try { window.parent.postMessage({ type: "__edit_mode_dismissed" }, "*"); } catch (e) {}
        }}
                style={{ fontSize: 11, color: MUTE, background: "transparent", border: "none", cursor: "pointer" }}>
          Close
        </button>
      </div>
      <div className="p-3">
        <div className="label-xs mb-2" style={{ color: MUTE, fontSize: 9.5 }}>State</div>
        <div className="flex flex-col gap-1.5">
          {states.map(s => {
            const active = computeStateId(tweaks) === s.id;
            return (
              <button key={s.id}
                      onClick={() => applyState(s.id, setTweak)}
                      className="text-left rounded-md"
                      style={{
                        padding: "8px 10px",
                        background: active ? INK : CANVAS,
                        color: active ? "#FFF" : INK,
                        border: `1px solid ${active ? INK : LINE}`,
                        fontSize: 12, fontWeight: 500,
                        cursor: "pointer"
                      }}>
                {s.label}
              </button>
            );
          })}
        </div>

        <div className="mt-4 pt-3" style={{ borderTop: `1px solid ${LINE}` }}>
          <label className="flex items-center gap-2" style={{ fontSize: 12, color: SUB, cursor: "pointer" }}>
            <input type="checkbox"
                   checked={tweaks.show_state_label}
                   onChange={(e) => setTweak({ show_state_label: e.target.checked })}/>
            Show state label overlay
          </label>
        </div>
      </div>
    </div>
  );
}

function computeStateId(t) {
  if (t.view === "mobile") return "mobile";
  if (t.faq_open_index >= 0) return "desktop-faq";
  if (t.scrolled) return "desktop-scrolled";
  return "desktop";
}

function applyState(id, setTweak) {
  const patches = {
    "desktop":          { view: "desktop", scrolled: false, faq_open_index: -1 },
    "desktop-scrolled": { view: "desktop", scrolled: true,  faq_open_index: -1 },
    "desktop-faq":      { view: "desktop", scrolled: true,  faq_open_index: 1 },
    "mobile":           { view: "mobile",  scrolled: false, faq_open_index: -1 },
  };
  setTweak(patches[id] || patches.desktop);
}

/* --- DESKTOP PAGE --- */
function DesktopPage({ shrunk, faqOpenIndex }) {
  return (
    <>
      <a href="#main" className="skip">Skip to content</a>
      <Header shrunk={shrunk}/>
      <main id="main" role="main">
        <Hero/>
        <PictureBand/>
        <JourneyBand/>
        <CompareBand/>
        <TrustCardsBand/>
        <PricingTeaser/>
        <FAQBand defaultOpen={faqOpenIndex}/>
        <ClosingCTA/>
      </main>
      <Footer/>
    </>
  );
}

/* --- MOBILE PAGE — shown in a phone frame on a soft canvas --- */
function MobilePage() {
  return (
    <div style={{ background: "#E8E5DE", minHeight: "100vh", padding: "60px 20px" }}>
      <div className="text-center mb-8">
        <Eyebrow>Mobile reflow · 375×667</Eyebrow>
        <div className="serif mt-2" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.02em" }}>
          Hero · Journey · Closing CTA
        </div>
      </div>
      <MobileReflow/>
      <div className="text-center mt-8 mono" style={{ fontSize: 10.5, color: MUTE, letterSpacing: "0.04em" }}>
        Single column · hero CTA always above fold · phase journey vertical stack
      </div>
    </div>
  );
}

/* --- ROOT --- */
function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const stateId = computeStateId(tweaks);
  const labels = {
    "desktop":          "State 1 · Default scroll",
    "desktop-scrolled": "State 2 · Mid-scroll · header shrunk",
    "desktop-faq":      "State 3 · FAQ open",
    "mobile":           "State 4 · Mobile 375×667",
  };

  return (
    <>
      {tweaks.show_state_label && <StateLabel>{labels[stateId]}</StateLabel>}
      {tweaks.view === "mobile"
        ? <MobilePage/>
        : <DesktopPage shrunk={tweaks.scrolled} faqOpenIndex={tweaks.faq_open_index}/>}
      <TweaksPanel tweaks={tweaks} setTweak={setTweak}/>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
