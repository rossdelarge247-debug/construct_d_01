/* =========================================================================
   CLOSING CTA + FOOTER
   ========================================================================= */
function ClosingCTA() {
  return (
    <section aria-labelledby="closing-h"
             style={{ paddingTop: 110, paddingBottom: 110, background: PANEL, borderTop: `1px solid ${LINE}` }}>
      <div className="mx-auto px-8 text-center" style={{ maxWidth: 760 }}>
        <div className="sec-in sec-in-1">
          <Eyebrow>The free plan is yours to keep</Eyebrow>
          <h2 id="closing-h" className="serif mt-5"
              style={{
                fontSize: 52, fontWeight: 600, letterSpacing: "-0.03em",
                lineHeight: 1.05, textWrap: "balance"
              }}>
            Whether you're ready{" "}
            <span style={{ fontStyle: "italic", color: SUB }}>or just looking</span>,
            the free plan is yours to keep.
          </h2>

          <div className="mt-10 flex items-center justify-center">
            <CTAPrimary/>
          </div>

          <div className="mt-12 pt-6"
               style={{ borderTop: `1px solid ${LINE}`, display: "flex", justifyContent: "center" }}>
            <a href="#invited"
               style={{ fontSize: 13.5, color: SUB, borderBottom: `1px solid ${LINE}`, paddingBottom: 1 }}>
              I'm the partner who's been invited →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* =========================================================================
   FOOTER
   ========================================================================= */
function Footer() {
  const cols = [
    { h: "Product",  links: ["How it works", "Pricing", "For mediators", "For solicitors", "Help centre"] },
    { h: "Trust",    links: ["Privacy", "Terms", "Safeguarding", "Data & deletion", "Open Banking"] },
    { h: "Company",  links: ["About", "Press", "Contact", "Careers"] },
  ];
  return (
    <footer role="contentinfo"
            style={{ background: BG, borderTop: `1px solid ${LINE}`, padding: "60px 0 40px" }}>
      <div className="mx-auto px-8 grid gap-12"
           style={{ maxWidth: 1240, gridTemplateColumns: "1.4fr 1fr 1fr 1fr" }}>
        <div>
          <Wordmark size={17}/>
          <p className="serif italic mt-5"
             style={{ fontSize: 15, color: SUB, lineHeight: 1.5, maxWidth: 280 }}>
            The complete picture.
          </p>
          <div className="mt-7 flex flex-col gap-2" style={{ fontSize: 11.5, color: MUTE }}>
            <span>Decouple Ltd · London</span>
            <span>Open Banking via TrueLayer (FCA regulated)</span>
            <span className="mono" style={{ fontSize: 10.5, letterSpacing: "0.04em" }}>v1 · 2026</span>
          </div>
        </div>

        {cols.map((col) => (
          <div key={col.h}>
            <Eyebrow>{col.h}</Eyebrow>
            <ul className="mt-4 flex flex-col gap-2.5" style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {col.links.map((l) => (
                <li key={l}>
                  <a href="#" style={{ fontSize: 13.5, color: SUB }}>{l}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mx-auto px-8 mt-14 pt-6"
           style={{ maxWidth: 1240, borderTop: `1px solid ${LINE}` }}>
        <div className="flex items-center justify-between flex-wrap gap-3"
             style={{ fontSize: 11.5, color: MUTE }}>
          <span>© Decouple Ltd 2026 · All rights reserved</span>
          <span>Decouple is not a law firm and does not provide legal advice. We help you prepare a settlement; the court reviews and approves it.</span>
        </div>
      </div>
    </footer>
  );
}

window.ClosingCTA = ClosingCTA;
window.Footer = Footer;
