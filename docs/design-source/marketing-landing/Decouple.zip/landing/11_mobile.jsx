/* =========================================================================
   MOBILE REFLOW · 375×667 — hero, journey, closing CTA
   ========================================================================= */
function MobileReflow() {
  return (
    <div className="mobile-frame mx-auto">
      <div className="mobile-screen">
        {/* status bar */}
        <div className="flex items-center justify-between px-5 pt-3 pb-2"
             style={{ fontSize: 12, color: INK, fontWeight: 600 }}>
          <span>9:41</span>
          <span style={{ fontSize: 10, color: MUTE }}>·</span>
          <span style={{ fontSize: 10 }}>●●●●○</span>
        </div>

        {/* sticky header */}
        <header className="sticky top-0 z-30 flex items-center justify-between px-5"
                style={{
                  height: 52, background: "rgba(245,245,244,0.95)",
                  backdropFilter: "blur(12px)",
                  borderBottom: `1px solid ${LINE}`
                }}>
          <Wordmark size={14}/>
          <a href="#start"
             className="rounded-full"
             style={{
               padding: "7px 14px", background: INK, color: "#FFF",
               fontSize: 12, fontWeight: 500, letterSpacing: "-0.005em"
             }}>
            Start free
          </a>
        </header>

        {/* HERO — single column */}
        <section className="px-5 pt-8 pb-10">
          <div className="label-xs" style={{ color: MUTE, fontSize: 9.5 }}>
            The complete settlement workspace
          </div>
          <h1 className="serif mt-4"
              style={{
                fontSize: 36, fontWeight: 600, letterSpacing: "-0.03em",
                lineHeight: 1.05, textWrap: "balance"
              }}>
            Sort out your separation —{" "}
            <span style={{ fontStyle: "italic", color: SUB }}>together</span>.
          </h1>
          <p className="serif italic mt-4"
             style={{ fontSize: 15.5, lineHeight: 1.45, color: SUB }}>
            Finances, children, housing — for under £1,000 and in 3 months.
          </p>

          <a href="#start"
             className="mt-6 w-full inline-flex items-center justify-center gap-2 rounded-full"
             style={{
               padding: "14px 22px", background: INK, color: "#FFF",
               fontSize: 14, fontWeight: 500
             }}>
            Start your free plan
            <ArrowRight size={14}/>
          </a>
          <div className="mt-2.5 mono tabular text-center" style={{ fontSize: 10.5, color: MUTE }}>
            ~3 minutes · no account needed
          </div>

          {/* trust band — stacked */}
          <div className="mt-6 pt-5 flex flex-col gap-2"
               style={{ borderTop: `1px solid ${LINE}` }}>
            {[
              [Shield, "FCA-regulated via TrueLayer"],
              [Lock,   "Read-only · we can't move money"],
              [Check,  "Free until you sign up"],
            ].map(([Ic, t], i) => (
              <span key={i} className="flex items-center gap-2"
                    style={{ fontSize: 11.5, color: i === 2 ? INK : SUB }}>
                <Ic size={12} sw={1.8} style={{ color: i === 2 ? "#166534" : MUTE }}/>
                {t}
              </span>
            ))}
          </div>
        </section>

        {/* JOURNEY — vertical stack */}
        <section className="px-5 pt-8 pb-8"
                 style={{ background: PANEL, borderTop: `1px solid ${LINE}`, borderBottom: `1px solid ${LINE}` }}>
          <Eyebrow>How it works</Eyebrow>
          <h2 className="serif mt-3"
              style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.018em", lineHeight: 1.15, textWrap: "balance" }}>
            Five phases. <span style={{ fontStyle: "italic", color: SUB }}>From first question to court-sealed.</span>
          </h2>

          <div className="mt-6 flex flex-col gap-2.5">
            {[
              { n: "1", k: "Start",     doc: "Free orientation",     a: PHASE.start },
              { n: "2", k: "Build",     doc: "Sarah's Picture",       a: PHASE.build },
              { n: "3", k: "Reconcile", doc: "Our Household Picture", a: PHASE.reconcile },
              { n: "4", k: "Settle",    doc: "The Settlement Proposal", a: PHASE.settle },
              { n: "5", k: "Finalise",  doc: "Court-ready package",   a: PHASE.finalise },
            ].map((p) => (
              <div key={p.k}
                   className="flex items-center gap-3 rounded-xl"
                   style={{
                     background: p.a.soft, padding: "12px 14px",
                     border: `1px solid ${LINE}`
                   }}>
                <span className="inline-flex items-center justify-center"
                      style={{
                        width: 26, height: 26, borderRadius: 99,
                        background: "#FFFFFF", border: `1px solid ${LINE}`,
                        color: p.a.num, fontSize: 12, fontWeight: 700
                      }}>{p.n}</span>
                <div className="flex-1 min-w-0">
                  <div className="label-xs" style={{ color: p.a.ink, fontSize: 9 }}>{p.k}</div>
                  <div className="serif italic" style={{ fontSize: 13, color: INK, lineHeight: 1.25 }}>{p.doc}</div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CLOSING CTA */}
        <section className="px-5 pt-8 pb-10 text-center">
          <Eyebrow>Yours to keep</Eyebrow>
          <h2 className="serif mt-3"
              style={{ fontSize: 24, fontWeight: 600, letterSpacing: "-0.022em", lineHeight: 1.15, textWrap: "balance" }}>
            Whether you're ready{" "}
            <span style={{ fontStyle: "italic", color: SUB }}>or just looking</span>,
            the free plan is yours to keep.
          </h2>

          <a href="#start"
             className="mt-6 w-full inline-flex items-center justify-center gap-2 rounded-full"
             style={{ padding: "14px 22px", background: INK, color: "#FFF", fontSize: 14, fontWeight: 500 }}>
            Start your free plan
            <ArrowRight size={14}/>
          </a>
          <div className="mt-2.5 mono tabular" style={{ fontSize: 10.5, color: MUTE }}>
            ~3 minutes · no account needed
          </div>

          <div className="mt-6 pt-4" style={{ borderTop: `1px solid ${LINE}` }}>
            <a href="#invited" style={{ fontSize: 12, color: SUB, borderBottom: `1px solid ${LINE}`, paddingBottom: 1 }}>
              I'm the partner who's been invited →
            </a>
          </div>
        </section>
      </div>
    </div>
  );
}

window.MobileReflow = MobileReflow;
