/* =========================================================================
   PRICING TEASER + FAQ
   ========================================================================= */
function PricingTeaser() {
  return (
    <section id="pricing" aria-labelledby="pricing-h"
             style={{ paddingTop: 60, paddingBottom: 60 }}>
      <div className="mx-auto px-8" style={{ maxWidth: 920 }}>
        <div className="sec-in sec-in-1 text-center"
             style={{
               background: PANEL,
               border: `1px solid ${LINE}`,
               borderRadius: 16,
               padding: "44px 36px 40px"
             }}>
          <Eyebrow>Pricing</Eyebrow>
          <h2 id="pricing-h" className="serif mt-4"
              style={{ fontSize: 34, fontWeight: 600, letterSpacing: "-0.022em", lineHeight: 1.15, textWrap: "balance" }}>
            <span style={{ fontStyle: "italic" }}>£800–£1,100</span> all-in for the complete settlement journey —
            including consent order generation.
          </h2>
          <p className="mt-4 mx-auto" style={{ fontSize: 15, color: SUB, lineHeight: 1.55, maxWidth: 540 }}>
            Free up to your AI plan. Pay only when you decide to build.
          </p>
          <div className="mt-7 flex items-center justify-center gap-3">
            <a href="#pricing-detail"
               className="inline-flex items-center gap-1.5 pb-1"
               style={{ fontSize: 14, color: INK, borderBottom: `1px solid ${INK}` }}>
              See pricing detail
              <ArrowUpRight size={14}/>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* --- FAQ Accordion · single open at a time --- */
const FAQS = [
  { q: "Is this legal? Will the court accept it?",
    a: "Yes. Decouple produces the same documents your solicitor would — Form D81, the consent order, and supporting disclosure — formatted to court requirements. We pre-flight every package against the rules a district judge applies. The court reviews and seals the order; you can also have a solicitor sign off before submission if you'd prefer." },
  { q: "What if my ex won't cooperate?",
    a: "You can build your own picture privately first — there's no requirement for your ex-partner to be involved at that stage. When you invite them, they see only what you choose to share. If they don't engage, your picture and the orientation plan are still yours to keep, and you can take them to a mediator or solicitor without losing the work." },
  { q: "How is Decouple different from mediation or a solicitor?",
    a: "Mediation is a conversation; a solicitor writes the documents. Decouple is the workspace where the picture, the negotiation, and the documents live in one place — at consumer-software cost. Mediation and a final solicitor sign-off both still fit alongside Decouple. We make either of them shorter and cheaper, not redundant." },
  { q: "What if our finances are complicated — self-employed, foreign assets, trusts?",
    a: "We handle most consumer cases end-to-end — including self-employment, multiple pensions, and second properties. For genuinely complex situations (offshore trusts, business valuations, contested non-matrimonial assets), Decouple still produces the picture and disclosure bundle; we'll flag clearly where a specialist solicitor or accountant is the right next step." },
  { q: "Can I use this if I'm not sure I want to separate yet?",
    a: "Yes — and many people do. The free orientation produces a picture you can hold privately. Some people use it to think things through; some discover it gives them clarity to stay; some use it later if they decide to separate. Whatever you do next, the picture is yours." },
  { q: "Is my data safe if my ex has access to my devices?",
    a: "Decouple supports a discreet mode: no email notifications, no app on the home screen, a private passcode separate from your device PIN, and one-tap exit. We can also send a paper copy of your picture to a different address. If safety is a concern, please tell us — we'll route you to the right support before going further." },
];

function FAQBand({ defaultOpen = -1 }) {
  const [openIdx, setOpenIdx] = useState(defaultOpen);
  return (
    <section id="faq" aria-labelledby="faq-h"
             style={{ paddingTop: 60, paddingBottom: 100 }}>
      <div className="mx-auto px-8" style={{ maxWidth: 920 }}>
        <div className="sec-in sec-in-1">
          <Eyebrow>Common questions</Eyebrow>
          <h2 id="faq-h" className="serif mt-4"
              style={{ fontSize: 34, fontWeight: 600, letterSpacing: "-0.022em", lineHeight: 1.15 }}>
            What people ask first.
          </h2>
        </div>

        <div className="mt-10" style={{ borderTop: `1px solid ${LINE}` }}>
          {FAQS.map((f, i) => {
            const open = i === openIdx;
            return (
              <div key={i}
                   className="faq-row"
                   style={{ borderBottom: `1px solid ${LINE}` }}>
                <button
                  onClick={() => setOpenIdx(open ? -1 : i)}
                  aria-expanded={open}
                  aria-controls={`faq-body-${i}`}
                  className="w-full flex items-center justify-between gap-6 text-left"
                  style={{ padding: "22px 4px", background: "transparent", border: "none", cursor: "pointer" }}>
                  <span className="serif"
                        style={{ fontSize: 19, fontWeight: 600, letterSpacing: "-0.012em", color: INK, lineHeight: 1.3 }}>
                    {f.q}
                  </span>
                  <span className="faq-chev flex-shrink-0"
                        style={{
                          width: 28, height: 28, borderRadius: 99,
                          border: `1px solid ${LINE}`, background: PANEL,
                          display: "inline-flex", alignItems: "center", justifyContent: "center",
                          color: INK,
                          transform: open ? "rotate(45deg)" : "rotate(0deg)",
                          transition: "transform 240ms ease"
                        }}>
                    <Plus size={14} sw={2}/>
                  </span>
                </button>
                <div id={`faq-body-${i}`}
                     style={{
                       maxHeight: open ? 400 : 0,
                       opacity: open ? 1 : 0,
                       overflow: "hidden",
                       transition: "max-height 280ms ease-out, opacity 200ms ease-out, padding 280ms ease-out",
                       paddingBottom: open ? 22 : 0,
                       paddingRight: 56
                     }}>
                  <p style={{ fontSize: 15, lineHeight: 1.65, color: SUB }}>{f.a}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

window.PricingTeaser = PricingTeaser;
window.FAQBand = FAQBand;
